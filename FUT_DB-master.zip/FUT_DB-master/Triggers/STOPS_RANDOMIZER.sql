---------------------------------------------------------------------------------------------------------------------------
-- Trigger STOPS_RANDOMIZER
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 5
--  -> STOPS, IS_PART_OF, TMP_MATCH, PLAYER, CLUB_CARD;
-- TRIGGER:
--  -> Gestisce gli infortuni dei player dopo che hanno disputato un match.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER STOPS_RANDOMIZER AFTER
    UPDATE OF RESULTS ON MATCH
    FOR EACH ROW
DECLARE
    N1           NUMBER(5, 0);--Id dell'ultimo match.
    N2           NUMBER(2, 0) := 1;--Contatore generico, corrisponde al numero di giocatori infortunati.
    P_NAME       VARCHAR2(32);--Nome del player infortunato.
    HOME_SQUAD   VARCHAR2(16);--Nome della squadra in casa.
    HOME_CLUB    CLUB.CLUB_NAME%TYPE;--Nome del club della squadra in casa.
    AWAY_SQUAD   VARCHAR2(16);--Nome della squadra fuori casa.
    AWAY_CLUB    CLUB.CLUB_NAME%TYPE;--Nome del club della squadra fuori casa.
    NEW_STOP     STOPS%ROWTYPE;--Nuovo infortunio.
    STOP_P       NUMBER(2, 0);--Percentuale d'infortunio.
    RAND_VALUE   NUMBER(3, 0);--Numero random.
    INJURY_TYPE  NUMBER(1, 0);--Tipo d'infortunio.
    DAYS         NUMBER(1, 0);--Giorni di fermo per l'infortunio.

--Record che contiene i codici carta e la forma fisica dei player della squadra.
    TYPE P_FF IS RECORD (
        C_CODE  ACTIVE_DATA_PLAYER.P_CARD_CODE%TYPE,
        FF      ACTIVE_DATA_PLAYER.PLAYER_FITNESS%TYPE
    );

--Lista del record <p_ff>.
    TYPE P_FF_INFO IS TABLE OF P_FF;
    P_FF_LIST    P_FF_INFO;

    TYPE ARRAY_BP IS VARRAY(7) OF VARCHAR2(16);
    BP_ARR       ARRAY_BP; --Array del tipo di infortunio.

BEGIN
--Tipo d'infortunio.
    BP_ARR := ARRAY_BP('Foot', 'Leg', 'Knee', 'Arm', 'UpperBody','Head');
--Seleziono l'id dell'ultimo match.
    SELECT
        MAX(MATCH_ID)
    INTO N1
    FROM
        TMP_MATCH;

--Se il match corrente e' l'ultimo disputato.
    IF N1 = :OLD.MATCH_ID THEN
--Selezino nome della squadra, e nome del club delle squadre che hanno appena giocato.
        HOME_SQUAD:=:NEW.HOME_SQUAD_NAME;

        SELECT SQUAD_CLUB_NAME INTO HOME_CLUB
        FROM SQUAD WHERE NAME = HOME_SQUAD;

        AWAY_SQUAD:=:NEW.VISITORS_SQUAD_NAME;
        
        SELECT SQUAD_CLUB_NAME INTO AWAY_CLUB
        FROM SQUAD WHERE NAME = AWAY_SQUAD;

--Seleziono codice carta, e forma fisica dei player infortunati.
        SELECT
            P_CARD_CODE,
            PLAYER_FITNESS
        BULK COLLECT
        INTO P_FF_LIST
        FROM
            ACTIVE_DATA_PLAYER
        WHERE
            P_CARD_CODE IN (
                SELECT
                    PLAYER_CARD_CODE
                FROM
                    IS_PART_OF
                WHERE
                    ( SQUAD_NAME = HOME_SQUAD
                      OR SQUAD_NAME = AWAY_SQUAD )
                    AND HOLDER = '1'
            );
        
        FOR INDX IN 1..P_FF_LIST.COUNT LOOP
--Se un giocatore ha forma fisica >= 80 non si puo' infortunare.
            STOP_P := 80 - P_FF_LIST(INDX).FF;
            RAND_VALUE := DBMS_RANDOM.VALUE(LOW => 1, HIGH => 100);
--Il player potrebbe infortunarsi.
            IF RAND_VALUE < STOP_P THEN
            
                RAND_VALUE := DBMS_RANDOM.VALUE(LOW => 1, HIGH => 100);
-- Il giocatore si infortunia.
                IF RAND_VALUE < 5 THEN 
--Tipologia di infortunio.
                INJURY_TYPE := DBMS_RANDOM.VALUE(LOW => 1, HIGH => 7); 
--Giorni di infortunio.
                DAYS := DBMS_RANDOM.VALUE(LOW => 1, HIGH => 5);

--Preparo la nuova tupla di infortunio <stop>.
                SELECT
                    SYSDATE,
                    BP_ARR(INJURY_TYPE),
                    DAYS,
                    P_FF_LIST(INDX).C_CODE
                INTO NEW_STOP
                FROM
                    DUAL;

--Inserisco la nuova tupla.
                INSERT INTO STOPS VALUES NEW_STOP;

--Seleziono il nome del player, per notificare all'utente quale giocatore ha subito un infortunio.                   
                SELECT
                    PLAYER_NAME
                INTO P_NAME
                FROM
                         CLUB_CARD CC
                    JOIN PLAYER P ON CC.PLAYER_ID = P.CARD_ID
                WHERE
                    CC.CARD_CODE = P_FF_LIST(INDX).C_CODE;

                DBMS_OUTPUT.PUT_LINE('Giocatore infortunato -> ['
                                     || N2
                                     || '] '
                                     || P_NAME
                                     || ' ('
                                     || P_FF_LIST(INDX).C_CODE
                                     || ') - ('
                                     || NEW_STOP.BODY_PART
                                     || ')'
                                     || CHR(10));
--Incremento il numero di giocatori infortunati.
                N2 := N2 + 1;
            END IF;
        END IF;
        END LOOP;
--Azzero il numero di giocatori infortunati.
        N2 := 1;
    END IF;

END STOPS_RANDOMIZER;
/