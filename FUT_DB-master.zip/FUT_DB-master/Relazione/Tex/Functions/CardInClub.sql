-- Tabelle interessate: 4
--	-> CLUB_CARD, IS_FOUND, PACK_PURCHASE, TRANSACTION
    
-- INPUT:
--	-> c_code: il codice carta;
-- 	-> c_name: il nome del club che possiede la carta identificata dal <c_code>;
-- OUTPUT:
--	-> number: 1 -> se il club possiede la carta, altrimenti 0.

CREATE OR REPLACE FUNCTION CARD_IN_CLUB (
C_CODE  CLUB_CARD.CARD_CODE%TYPE,
C_NAME  CLUB.CLUB_NAME%TYPE
) RETURN NUMBER IS
N1 NUMBER(2, 0);    --Valore di ritorno
BEGIN

--Controlla se la carta <c_code> e' stata trovata in un pacchetto <pack>.
SELECT
    COUNT(*)
INTO N1
FROM
    CLUB_CARD
WHERE CARD_CODE = C_CODE
    AND CARD_CODE IN (
        SELECT CARD_CODE
        FROM IS_FOUND
        WHERE P_ID IN (
                SELECT PURCHASE_ID
                FROM PACK_PURCHASE
                WHERE BUYING_CLUB_NAME = C_NAME));

--Se n1 = 0, la carta non e' stata trovata in un <pack>;
--Controllo se e' stata comprata.
IF N1 = 0 THEN
    SELECT
        COUNT(CARD_CODE)
    INTO N1
    FROM CLUB_CARD
    WHERE CARD_CODE = C_CODE
        AND CARD_CODE IN (
            SELECT T_CARD_CODE
            FROM TRANSACTION
            WHERE TRANSITION_B_CLUB_NAME = C_NAME);
END IF;
--Ritorno il risultato.
    RETURN N1;
END CARD_IN_CLUB;
/