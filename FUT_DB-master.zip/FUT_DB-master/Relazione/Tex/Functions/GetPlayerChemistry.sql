-- Function interessate: 1
--	-> IDX_POSITION;	

-- INPUT:
--	-> p_position: la posizione <player_position> del <player> nella squadra;
-- 	-> pos: la posizione <position> naturale dal <player>;
-- OUTPUT:
--	-> number: la nuova intesa <chemistry> del <player>.

CREATE OR REPLACE FUNCTION GET_PLAYER_CHEMISTRY (
P_POSITION  PLAYER.POSITION%TYPE,
POS         PLAYER.POSITION%TYPE
) RETURN NUMBER IS      
--Data una posizione esempio: 'RB' <terzino destro> il ruolo sara' uguale a 2;
--Nello specifico sara': 
--      1 = portiere, 2 = difensore, 3 = centrocampista, 4 = attaccante.
RUOLO_SCELTO  INTEGER;
RUOLO_PREF    INTEGER;
CHEMISTRY     NUMBER(2, 0);  --Valore di ritorno, intesa del giocatore.
M_CHEMISTRY   NUMBER(2, 0);  --Bonus intesa data dal manager.
BEGIN
--IDX_POSITION(pos,'r'):
--input: pos la posizione di cui si vuole ottenere l'indice o il ruolo;
--       'r' la funzione ritora il ruolo (1=Porta,2=Difesa,3=Centrocampo,4=Attacco).
--       'i' la funzione ritorna l'indice intero della posizione.   
SELECT
    IDX_POSITION(P_POSITION, 'r'),
    IDX_POSITION(POS, 'r')
INTO
    RUOLO_SCELTO,
    RUOLO_PREF
FROM
    DUAL;

--Calcolo intesa <player_chemistry> del <player>.
IF RUOLO_SCELTO = 1 THEN
--Portiere
--Se il ruolo del <player> corrisponde al ruolo naturale.
    IF P_POSITION = POS
        AND ABS(RUOLO_SCELTO - RUOLO_PREF) = 0
    THEN
        CHEMISTRY := 9;
--Se un <player> non portiere, viene schierato in porta
--l'intesa <chemistry> del <player> sara' = 0.
    ELSIF P_POSITION != POS
        AND ABS(RUOLO_SCELTO - RUOLO_PREF) > 0
    THEN
        CHEMISTRY := 0;
    END IF;
-- Se non si tratta del portiere.
ELSE 
--Se la posizione scelta <p_position> corrisponde alla posizione naturale <pos>
--      e il ruolo <ruolo_scelto> corrisponde al ruolo preferito <ruolo_pref>
--Esempio:      p_position = 'CB' (Central Back); RUOLO_SCELTO = 2 (Difesa);
--              pos = 'CB'; RUOLO_PREF = 2;
    IF P_POSITION = POS
        AND ABS(RUOLO_SCELTO - RUOLO_PREF) = 0
    THEN
        CHEMISTRY := 9;

--Se la posizione scelta <p_position> NON corrisponde alla posizione naturale <pos>
--      e il ruolo <ruolo_scelto> corrisponde al ruolo preferito <ruolo_pref>
--Esempio:      p_position = 'CB' (Central Back); RUOLO_SCELTO = 2 (Difesa);
--              pos = 'RB' (Right Back); RUOLO_PREF = 2;
    ELSIF P_POSITION != POS
        AND ABS(RUOLO_SCELTO - RUOLO_PREF) = 0
    THEN
        CHEMISTRY := 7;

--Se la posizione scelta <p_position> NON corrisponde alla posizione naturale <pos>
--      e il ruolo <ruolo_scelto> NON corrisponde al ruolo preferito <ruolo_pref>
--Esempio:      p_position = 'CB' (Central Back); RUOLO_SCELTO = 2 (Difesa);
--              pos = 'CM' (Central Midfield); RUOLO_PREF = 3 (Centrocampo);
    ELSIF P_POSITION != POS
        AND ABS(RUOLO_SCELTO - RUOLO_PREF) = 1
    THEN
        CHEMISTRY := 5;

--Se la posizione scelta <p_position> NON corrisponde alla posizione naturale <pos>
--      e il ruolo <ruolo_scelto> NON corrisponde al ruolo preferito <ruolo_pref>
--Esempio:      p_position = 'CB' (Central Back); RUOLO_SCELTO = 2 (Difesa);
--              pos = 'ST' (Striker); RUOLO_PREF = 4 (Attacco);
    ELSIF P_POSITION != POS
        AND ABS(RUOLO_SCELTO - RUOLO_PREF) > 1
    THEN
        CHEMISTRY := 3;
    END IF;
END IF;

RETURN CHEMISTRY;
END GET_PLAYER_CHEMISTRY;
/