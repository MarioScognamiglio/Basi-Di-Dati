-- Tabelle interessate: 4
--  -> CLUB_CARD, SQUAD, MANAGER, PLAYER;

-- INPUT:
--  -> player_id: il card id del player;
--  -> s_name: il nome della squadra che contiene il player;
--  -> c_name: il nome del club che possiede la squadra <s_name>;
-- OUTPUT:
--  -> numero: 1 se il player ha la stessa nazionalita' del manager, o la stessa lega <league>,
--             0 altrimenti. 
CREATE OR REPLACE FUNCTION MANAGER_CHEMISTRY (
PLAYER_ID  IN  PLAYER.CARD_ID%TYPE,
P_CODE     IN  CLUB_CARD.CARD_CODE%TYPE,
S_NAME     IN  SQUAD.NAME%TYPE,
C_NAME     IN  CLUB.CLUB_NAME%TYPE
) RETURN NUMBER IS

M_CNT        NUMBER(1, 0);      --Se e' > 0 c'e' l'allenatore altrimenti no.
M_NATION     VARCHAR2(64);      --Nazionalita' del manager.
M_LEAGUE     VARCHAR2(64);      --Liga del manager.
M_ID         NUMBER(2, 0);      --Id del manager.
P_NATION     VARCHAR2(64);      --Nazionalita' del player.
P_LEAGUE     VARCHAR2(64);      --Lega del player.
P_TEAM       VARCHAR2(64);      --Squadra del player.
M_CHEMISTRY  NUMBER(1, 0);      --Bonus intesa <player_chemistry> dato dal manager.

BEGIN
--Controllo che la squadra abbia un manager schierato.
SELECT
    COUNT(MANAGER_ID)
INTO M_CNT
FROM
    CLUB_CARD
WHERE
    CARD_CODE IN (
        SELECT
            MANAGER_CARD_CODE
        FROM
            MANAGES
        WHERE SQUAD_NAME = S_NAME
    );

--Se c'e' il manager.                
IF M_CNT > 0 THEN
--Seleziono l'ID del manager.
    SELECT
        MANAGER_ID
    INTO M_ID
    FROM
        CLUB_CARD
    WHERE
        CARD_CODE IN (
            SELECT
                MANAGER_CARD_CODE
            FROM
                MANAGES
            WHERE SQUAD_NAME = S_NAME
        );

--Seleziono nazionalita e lega del manager.
    SELECT
        NATIONALITY,
        LEAGUE_NAME
    INTO
        M_NATION,
        M_LEAGUE
    FROM
        MANAGER
    WHERE
        CARD_ID = M_ID;

--Seleziono nazionalita' e lega del player.
    SELECT
        NATIONALITY,
        LEAGUE_NAME,
        TEAM_NAME
    INTO
        P_NATION,
        P_LEAGUE,
        P_TEAM
    FROM
        PLAYER
    WHERE
            CARD_ID = PLAYER_ID
        AND CARD_ID IN (
            SELECT
                PLAYER_ID
            FROM
                CLUB_CARD
            WHERE
                CARD_CODE = P_CODE
        );

--Se la nazionalita' del player o la lega corrispondono a quelle del manager.
    IF P_NATION = M_NATION OR P_LEAGUE = M_LEAGUE THEN
        M_CHEMISTRY := 1;
    ELSE
        M_CHEMISTRY := 0;
    END IF;
END IF;
    RETURN M_CHEMISTRY;
END MANAGER_CHEMISTRY;
/