-- Tabelle interessate: 4
--	-> CONSUMABLE, CLUB_CARD, IS_PART_OF, PLAYER  		

-- INPUT:
--	-> c_code: il codice carta della carta di tipo consumabile;
-- 	-> p_code: il codice carta del player o manager alla quale applicare il consumabile <c_code>;
--	-> tp:	   il tipo <type> del consumabile che puo' essere (Player,Manager);
-- OUTPUT:
--	-> number: nuovo valore di contratti <contracts> del player <p_code> calcolato dopo 
--	   aver applicato il consumabile <c_code>;

CREATE OR REPLACE FUNCTION GET_CONTRACT (
C_CODE  IN  CLUB_CARD.CARD_CODE%TYPE,
P_CODE  IN  CLUB_CARD.CARD_CODE%TYPE,
TP      IN  CONSUMABLE.TYPE%TYPE
) RETURN NUMBER IS

N1          NUMBER(2, 0); --Contatore di controllo.
C_TYPE      CONSUMABLE.TYPE%TYPE; --tipo del consumabile.
BRONZE_CTC  CONSUMABLE.BRONZE_CONTRACT%TYPE; --Numero di contratti se il <player> e di rarita' <bronze>.
SILVER_CTC  CONSUMABLE.SILVER_CONTRACT%TYPE; --Numero di contratti se il <player> e di rarita' <silver>.
GOLD_CTC    CONSUMABLE.GOLD_CONTRACT%TYPE;   --Numero di contratti se il <player> e di rarita' <gold>.	

P_RARITY    PLAYER.RARITY_NAME%TYPE; --Rarita' del <player>.

INVALID_CLASS EXCEPTION; --Se il tipo in ingresso non corrisponde al tipo del consumabile <c_code>.
MAX_CONTRACTS EXCEPTION; --Se il <player> ha 99 contratti che e' il valore massimo.

BEGIN

--Seleziono i dati del consumabile <c_code>.
SELECT
    TYPE,
    BRONZE_CONTRACT,
    SILVER_CONTRACT,
    GOLD_CONTRACT
INTO
    C_TYPE,
    BRONZE_CTC,
    SILVER_CTC,
    GOLD_CTC
FROM
    CONSUMABLE
WHERE
    CARD_ID IN (
        SELECT
            CONSUMABLE_ID
        FROM
            CLUB_CARD
        WHERE
            CARD_CODE = C_CODE
    );

--Se il tipo <C_TYPE> del consumabile <c_code> e' diverso dal tipo <TP> fornito in input.
IF C_TYPE != TP THEN
    RAISE INVALID_CLASS; --Comunica all'utente che il tipo e' errato.
END IF;

--Se il tipo <TP> e' uguale a 'Player' e corrisponde a quello del cosnumabile.
IF
    TP = 'Player'
    AND C_TYPE = TP
THEN

--Seleziono i contratti del <player>.
    SELECT
        CONTRACTS
    INTO N1
    FROM
        ACTIVE_DATA_PLAYER
    WHERE
        P_CARD_CODE = P_CODE;

--Se il <player> ha 99 contratti, ha gia' il numero massimo e lo comunico all'utente.
    IF N1 = 99 THEN
        RAISE MAX_CONTRACTS;
    ELSE --Se il <player> ha meno di 99 contratti.
--Seleziono la rarita' del <player>.
        SELECT
            RARITY_NAME
        INTO P_RARITY
        FROM
            PLAYER
        WHERE
            CARD_ID IN (
                SELECT
                    PLAYER_ID
                FROM
                    CLUB_CARD
                WHERE
                    CARD_CODE = P_CODE
            );

--Se il <player> e' di rarita' <Bronze>.
        IF P_RARITY = 'Bronze - Rare' OR P_RARITY = 'Bronze - Non-Rare' THEN
--Controllo che il valore dei contratti del <player> (<n1> + i) contratti <bronze_ctc> dati dal consumabile 
-- non superano il massimo numero di contratti (99), se lo superano pongo (n1 = 99).
            IF N1 + BRONZE_CTC >
            99 THEN
                N1 := 99;
            ELSE--Altrimenti n1 sara' uguale ad (n1 + i) contratti dati dalla carta consumabile.
                N1 := BRONZE_CTC + N1;
            END IF;
--Se il <player> e' di rarita' <Silver>.
        ELSIF P_RARITY = 'Silver - Rare' OR P_RARITY = 'Silver - Non-Rare' THEN
            IF N1 + SILVER_CTC > 99 THEN
                N1 := 99;
            ELSE
                N1 := SILVER_CTC + N1;
            END IF;
--Se il <player> e' di rarita' <Gold> o altre rarita'.   
        ELSE
            IF N1 + GOLD_CTC > 99 THEN
                N1 := 99;
            ELSE
                N1 := GOLD_CTC + N1;
            END IF;
        END IF;

    END IF;

ELSIF
    TP = 'Manager'
    AND C_TYPE = TP
THEN
--Seleziono i contratti del <manager>.
    SELECT
        CONTRACTS
    INTO N1
    FROM
        ACTIVE_DATA_MANAGER
    WHERE
        M_CARD_CODE = P_CODE;

--Se il <manager> ha 99 contratti.
    IF N1 = 99 THEN
        RAISE MAX_CONTRACTS;
    ELSE --Se il <manager> ha meno di 99 contratti.
--Seleziono la rarita' del <manager>.
        SELECT
            RARITY_NAME
        INTO P_RARITY
        FROM
            MANAGER
        WHERE
            CARD_ID IN (
                SELECT
                    MANAGER_ID
                FROM
                    CLUB_CARD
                WHERE
                    CARD_CODE = P_CODE
            );

--Se il <manager> e' di rarita' <Bronze>.
        IF P_RARITY = 'Bronze - Rare' OR P_RARITY = 'Bronze - Non-Rare' THEN
--Controllo che il valore dei contratti del <manager> (<n1> + i) contratti <bronze_ctc> dati dal consumabile, 
-- non superano il massimo numero di contratti (99), se lo superano pongo (n1 = 99).
            IF N1 + BRONZE_CTC >
            99 THEN
                N1 := 99;
            ELSE
                N1 := BRONZE_CTC + N1;
            END IF;
--Se il <manager> e' di rarita' <Silver>.
        ELSIF P_RARITY = 'Silver - Rare' OR P_RARITY = 'Silver - Non-Rare' THEN
            IF N1 + SILVER_CTC > 99 THEN
                N1 := 99;
            ELSE
                N1 := SILVER_CTC + N1;
            END IF;
--Se il <manager> e' di rarita' <Gold> o altre rarita'. 
        ELSE
            IF N1 + GOLD_CTC > 99 THEN
                N1 := 99;
            ELSE
                N1 := GOLD_CTC + N1;
            END IF;
        END IF;

    END IF;

END IF;
--Ritorno il valore dei contratti del player o del manager.
RETURN N1;
EXCEPTION
WHEN INVALID_CLASS THEN
    RAISE_APPLICATION_ERROR('-20003', 'La tipo '
                                        || TP
                                        || ' scelta non e'' valida per la carta scelta!');
WHEN MAX_CONTRACTS THEN
    RAISE_APPLICATION_ERROR('20004', 'La carta ha il massimo dei contratti!');
END GET_CONTRACT;
/