-- INPUT-OUTPUT:
--	-> pos:     posizione del <player>;
--  -> choice:  se e' uguale ad 'r' la funzione ritorna il ruolo del player secondo la posizione del <player>;
--              se e' uguale ad 'i' la funzione ritorna l'indice intero della posizione del <player>. 
CREATE OR REPLACE FUNCTION IDX_POSITION (
POS     IN  PLAYER.POSITION%TYPE,
CHOICE  IN  CHAR
) RETURN INTEGER IS

RUOLO    INTEGER; --Valore di ritorno nel caso in cui la <choice = 'r'>. 
IDX_POS  INTEGER; --Valore di ritorno nel caso in cui la <choice = 'i'>.
TYPE ARRAY_POS IS VARRAY(17) OF VARCHAR2(3);
POS_ARR  ARRAY_POS; --Array che contiene tutte le posizioni.
INVALID_CHOICE EXCEPTION; --Se la <choice> e' diversa da 'r' o 'i'.

BEGIN
POS_ARR := ARRAY_POS('GK','RB','CB','LB','RWB','LWB','CDM','CM','CAM','RM','LM','RW','LW','CF','RF','LF','ST');
FOR I IN 1..17 LOOP
    IF POS_ARR(I) = POS THEN
        IDX_POS := I;
--ruolo 1 = portiere.
        IF I = 1 THEN
            RUOLO := 1;
--ruolo 2 = difensore.
        ELSIF I > 1 AND I < 7 THEN 
            RUOLO := 2;
--ruolo 3 = centrocampista.
        ELSIF I >= 7 AND I < 12 THEN 
            RUOLO := 3;
--ruolo 4 = attaccante.
        ELSIF I >= 12 AND I < 18 THEN 
            RUOLO := 4;
        END IF;
    END IF;
END LOOP;

IF CHOICE = 'r' THEN
    RETURN RUOLO;
ELSIF CHOICE = 'i' THEN
    RETURN IDX_POS;
ELSE
    RAISE INVALID_CHOICE;
END IF;

EXCEPTION
WHEN INVALID_CHOICE THEN
    RAISE_APPLICATION_ERROR('-20003', 'La scelta (' || CHOICE || ') non e'' valida!');
END IDX_POSITION;