-- Tabelle interessate: 3
--  -> CLUB_ITEM, CLUB_CARD, CLUB;

-- INPUT:
--	-> c_name:  nome del club;
-- OUTPUT:
--  -> Dettagli dei club item attivi del club <c_name>.
CREATE OR REPLACE FUNCTION GET_ACTIVE_CLUB_ITEM_F (
    C_NAME CLUB.CLUB_NAME%TYPE
) RETURN SYS_REFCURSOR IS
    G_C_INFO SYS_REFCURSOR;
BEGIN
    OPEN G_C_INFO FOR   
--Seleziona i dettagli che riguardano lo stemma del club.
        SELECT
            CARD_ID,
            CATEGORY_ITEM,
            TEAM_NAME
        FROM
                CLUB_ITEM C
            JOIN CLUB_CARD CC ON C.CARD_ID = CC.CLUB_ITEM_ID
                                AND CC.CARD_CODE IN (
                SELECT
                    ACTIVE_BADGE_CODE
                FROM CLUB
                WHERE CLUB_NAME = C_NAME)
        UNION
    --Seleziona i dettagli che riguardano lo stadio del club.
        SELECT
            CARD_ID,
            CATEGORY_ITEM,
            TEAM_NAME
        FROM
                CLUB_ITEM C
            JOIN CLUB_CARD CC ON C.CARD_ID = CC.CLUB_ITEM_ID
                                AND CC.CARD_CODE IN (
                SELECT
                    ACTIVE_STADIUM_CODE
                FROM CLUB
                WHERE CLUB_NAME = C_NAME)
        UNION
    --Seleziona i dettagli che riguardano il pallone del club.
        SELECT
            CARD_ID,
            CATEGORY_ITEM,
            TEAM_NAME
        FROM
                CLUB_ITEM C
            JOIN CLUB_CARD CC ON C.CARD_ID = CC.CLUB_ITEM_ID
                                AND CC.CARD_CODE IN (
                SELECT
                    ACTIVE_BALL_CODE
                FROM CLUB
                WHERE CLUB_NAME = C_NAME)
        UNION
    --Seleziona i dettagli che riguardano la divisa in casa del club.
        SELECT
            CARD_ID,
            CATEGORY_ITEM,
            TEAM_NAME
        FROM
                CLUB_ITEM C
            JOIN CLUB_CARD CC ON C.CARD_ID = CC.CLUB_ITEM_ID
                                AND CC.CARD_CODE IN (
                SELECT
                    ACTIVE_FIRST_KIT_CODE
                FROM CLUB
                WHERE CLUB_NAME = C_NAME)
        UNION
    --Seleziona i dettagli che riguardano la divisa fuori casa del club.
        SELECT
            CARD_ID,
            CATEGORY_ITEM,
            TEAM_NAME
        FROM
                CLUB_ITEM C
            JOIN CLUB_CARD CC ON C.CARD_ID = CC.CLUB_ITEM_ID
                                AND CC.CARD_CODE IN (
                SELECT
                    ACTIVE_SECOND_KIT_CODE
                FROM CLUB
                WHERE CLUB_NAME = C_NAME);

    RETURN G_C_INFO;
END GET_ACTIVE_CLUB_ITEM_F;
/