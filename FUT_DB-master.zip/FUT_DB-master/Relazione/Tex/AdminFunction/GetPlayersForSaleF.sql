-- Tabelle interessate: 5
--  -> CLUB_CARD, PLAYER, TRANSACTION;

-- INPUT:
--	-> c_name:  nome del club;
-- OUTPUT:
--  -> Dettagli dei player acquistabili dal club fornito in ingresso.
CREATE OR REPLACE FUNCTION GET_PLAYERS_FOR_SALE_F (
    C_NAME SQUAD.SQUAD_CLUB_NAME%TYPE
) RETURN SYS_REFCURSOR IS
    GETPLAYERS SYS_REFCURSOR;
BEGIN
    OPEN GETPLAYERS FOR 
        SELECT
            CARD_CODE,
            CARD_ID,
            PLAYER_NAME,
            POSITION,
            NATIONALITY,
            LEAGUE_NAME
        FROM 
            PLAYER P
            JOIN CLUB_CARD C ON P.CARD_ID = C.PLAYER_ID
        AND C.CARD_CODE IN (
                SELECT
                    T_CARD_CODE
                FROM TRANSACTION
                WHERE TRANSITION_S_CLUB_NAME <> C_NAME
                    AND TRANSITION_B_CLUB_NAME IS NULL);

    RETURN GETPLAYERS;
END GET_PLAYERS_FOR_SALE_F;
/