-- Tabelle interessate: 5
--  -> MATCH, SQUAD;

-- INPUT:
--	-> c_name:  nome del club;
-- OUTPUT:
--  -> Dettagli dei match disputati dalle squadre del club fornito in ingresso.
CREATE OR REPLACE FUNCTION GET_MATCH_F (
    C_NAME CLUB.CLUB_NAME%TYPE
) RETURN SYS_REFCURSOR IS
    G_MATCH SYS_REFCURSOR;
BEGIN
    OPEN G_MATCH FOR 
        SELECT
            M_DATE,
            HOME_SQUAD_NAME,
            VISITORS_SQUAD_NAME,
            RESULTS,
            HOME_POINTS   AS POINTS,
            HOME_CREDITS  AS CREDITS
        FROM
                MATCH M
            JOIN SQUAD S ON M.HOME_SQUAD_NAME = S.NAME
                            AND S.SQUAD_CLUB_NAME = C_NAME
        UNION
        SELECT
            M_DATE,
            HOME_SQUAD_NAME,
            VISITORS_SQUAD_NAME,
            RESULTS,
            VISITORS_POINTS,
            VISITORS_CREDITS
        FROM
                MATCH M
            JOIN SQUAD S ON M.VISITORS_SQUAD_NAME = S.NAME
                            AND S.SQUAD_CLUB_NAME = C_NAME;

    RETURN G_MATCH;
END GET_MATCH_F;
/