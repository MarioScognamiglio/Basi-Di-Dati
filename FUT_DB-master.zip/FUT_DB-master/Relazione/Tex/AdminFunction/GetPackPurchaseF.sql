-- Tabelle interessate: 2
--  -> PACK_PURCHASE, PACK;

-- INPUT:
--	-> c_name:  nome del club;
-- OUTPUT:
--  -> Cronologia dei pacchetti acquistati dal club fornito in ingresso.
CREATE OR REPLACE FUNCTION GET_PACK_PURCHASE_F (
    C_NAME CLUB.CLUB_NAME%TYPE
) RETURN SYS_REFCURSOR IS
    G_PACK_PURCHASE SYS_REFCURSOR;
BEGIN
    OPEN G_PACK_PURCHASE FOR 
        SELECT
            PURCHASE_ID,
            BUYING_PACK_NAME,
            P_DATE,
            PRICE
        FROM
                PACK_PURCHASE P
            JOIN PACK PP ON P.BUYING_PACK_NAME = PP.PACK_NAME
                            AND P.BUYING_CLUB_NAME = C_NAME;

    RETURN G_PACK_PURCHASE;
END GET_PACK_PURCHASE_F;
/