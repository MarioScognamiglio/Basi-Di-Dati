-- Tabelle interessate: 5
--  -> CLUB_CARD, MANAGER, IS_FOUND, PACK_PURCHASE, TRANSACTION;

-- INPUT:
--	-> c_name:  nome del club;
-- OUTPUT:
--  -> Dettagli dei manager posseduti dal club fornito in ingresso.
CREATE OR REPLACE FUNCTION GET_MANAGER_F (
    C_NAME CLUB.CLUB_NAME%TYPE
) RETURN SYS_REFCURSOR IS
    G_MANAGER SYS_REFCURSOR;
BEGIN
    OPEN G_MANAGER FOR 
        SELECT
            CARD_CODE,
            CARD_ID,
            F_NAME,
            S_NAME,
            NATIONALITY,
            LEAGUE_NAME AS REAL_LEAGUE,
            MANAGER_LEAGUE AS ACTUAL_LEAGUE,
            CONTRACTS,
            MIN_PRICE,
            MAX_PRICE
        FROM
                MANAGER M
            JOIN CLUB_CARD C ON M.CARD_ID = C.MANAGER_ID
            JOIN ACTIVE_DATA_MANAGER A ON A.M_CARD_CODE = C.CARD_CODE
                                AND C.CARD_CODE IN (
                SELECT
                    CARD_CODE
                FROM IS_FOUND
                WHERE P_ID IN (
                        SELECT PURCHASE_ID
                        FROM PACK_PURCHASE
                        WHERE BUYING_CLUB_NAME = C_NAME))
        UNION
        SELECT
            CARD_CODE,
            CARD_ID,
            F_NAME,
            S_NAME,
            NATIONALITY,
            LEAGUE_NAME AS REAL_LEAGUE,
            MANAGER_LEAGUE AS ACTUAL_LEAGUE,
            MIN_PRICE,
            MAX_PRICE
        FROM
                MANAGER M
            JOIN CLUB_CARD C ON M.CARD_ID = C.MANAGER_ID
            JOIN ACTIVE_DATA_MANAGER A ON A.M_CARD_CODE = C.CARD_CODE
                                AND C.CARD_CODE IN (
                SELECT
                    T_CARD_CODE
                FROM TRANSACTION
                WHERE TRANSITION_B_CLUB_NAME = C_NAME);
    RETURN G_MANAGER;
END GET_MANAGER_F;
/