-- Tabelle interessate: 1
--  -> PACK;

-- OUTPUT:
--  -> Dettagli dei pacchetti con relativo prezzo, disponibili per l'acquisto.

CREATE OR REPLACE FUNCTION GET_AVAIABLE_PACK_F RETURN SYS_REFCURSOR IS
    G_PACK SYS_REFCURSOR;
BEGIN
    OPEN G_PACK FOR 
        SELECT
            PACK_NAME,
            PRICE
        FROM
            PACK
        WHERE
            AVAILABLE = '1';

    RETURN G_PACK;
END GET_AVAIABLE_PACK_F;
/