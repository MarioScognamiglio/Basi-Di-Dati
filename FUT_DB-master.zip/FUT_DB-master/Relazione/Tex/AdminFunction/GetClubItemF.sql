-- Tabelle interessate: 3
--  -> CLUB_ITEM, CLUB_CARD, IF_FOUND, TRANSACTION;

-- INPUT:
--	-> c_name:  nome del club;
-- OUTPUT:
--  -> Dettagli dei club_item del club fornito in ingresso.
CREATE OR REPLACE FUNCTION GET_CLUB_ITEM_F (
    USR_CLUB_NAME CLUB.CLUB_NAME%TYPE
) RETURN SYS_REFCURSOR IS
    G_C_ITEM SYS_REFCURSOR;
BEGIN
    OPEN G_C_ITEM FOR 
        SELECT
            CARD_ID,
            CARD_CODE,
            CATEGORY_ITEM,
            TEAM_NAME,
            RARITY_NAME,
            MIN_PRICE,
            MAX_PRICE
        FROM
                CLUB_ITEM C
            JOIN CLUB_CARD CC ON C.CARD_ID = CC.CLUB_ITEM_ID
                                AND CC.CARD_CODE IN (
                SELECT
                    CARD_CODE
                FROM IS_FOUND
                WHERE P_ID IN (
                        SELECT PURCHASE_ID
                        FROM PACK_PURCHASE
                        WHERE BUYING_CLUB_NAME = USR_CLUB_NAME))
        UNION
        SELECT
            CARD_ID,
            CARD_CODE,
            CARD_ID,
            CATEGORY_ITEM,
            TEAM_NAME,
            RARITY_NAME,
            MIN_PRICE,
            MAX_PRICE
        FROM
                CLUB_ITEM C
            JOIN CLUB_CARD CC ON C.CARD_ID = CC.CLUB_ITEM_ID
                                AND CC.CARD_CODE IN (
                SELECT
                    T_CARD_CODE
                FROM TRANSACTION
                WHERE TRANSITION_B_CLUB_NAME = USR_CLUB_NAME);

    RETURN G_C_ITEM;
END GET_CLUB_ITEM_F;
/