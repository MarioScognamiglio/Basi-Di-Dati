--Utilizzato come parametro di output nella funzione MODULE_POSITIONS. 
--E' un array che conterra' le posizioni dei player in base al modulo scelto.
create OR REPLACE TYPE array_pos_t is VARRAY(11) of VARCHAR2(3);