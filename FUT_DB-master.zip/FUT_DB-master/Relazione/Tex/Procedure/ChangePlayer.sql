-- Tabelle interessate: 1
--  -> IS_PART_OF;

-- Funzioni interessate: 1
--  -> IS_ADMIN;

-- INPUT:
--	-> p_code_old:  codice carta del player;
--	-> c_code_new:  codice carta del player;
--  -> s_name: nome della squadra;
--	-> cc_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
-- OUTPUT:
--  -> Se il player <p_code_old> e titolare andra' nelle riserve
--      e il player <p_code_new> diventera titolare, o viceversa.

CREATE OR REPLACE PROCEDURE CHANGE_PLAYER (
P_CODE_OLD  CLUB_CARD.CARD_CODE%TYPE,
P_CODE_NEW  CLUB_CARD.CARD_CODE%TYPE,
S_NAME      CLUB.CLUB_NAME%TYPE,
CC_NAME     CLUB.CLUB_NAME%TYPE
) IS

N1      NUMBER(2, 0); 
N2      NUMBER(2, 0); 
C_NAME  CLUB.CLUB_NAME%TYPE; --Nome effettivo del club (is_admin).
SAME    NUMBER(1,0):= 0; --Se e' = 1, i player sono entrambi nelle riserve o entrambi titolari.

NO_DATA_FOUND_OLD EXCEPTION; --Il player con codice carta <p_code_old> non e' stato trovato.
NO_DATA_FOUND_NEW EXCEPTION; --Il player con codice carta <p_code_new> non e' stato trovato.
SAME_HOLDER_0 EXCEPTION; --Se i player sono entrambi nelle riserve.
SAME_HOLDER_1 EXCEPTION; --Se i player sono entrambi titolari.

BEGIN
--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione CHANGE_PLAYER;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <cc_name>
--Altrimenti il nome del club <c_name> sara' quello dell'utente.
--In breve l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
SELECT
    IS_ADMIN(CC_NAME, USER)
INTO C_NAME
FROM
    DUAL;

--Controllo se <p_code_old> corrisponde a <p_code_new>.
IF P_CODE_OLD = P_CODE_NEW THEN
    SAME:= 1;
END IF;

--Controllo se il player <p_code_old> e' titolare.
SELECT
    COUNT(*)
INTO N1
FROM
    IS_PART_OF
WHERE
        SQUAD_NAME = S_NAME
    AND PLAYER_CARD_CODE = P_CODE_OLD
    AND HOLDER = '1';

--Se <n1 = 0>, il player <p_code_old> non e' titolare.
--Controllo se e' nelle riserve.
IF N1 = 0 THEN
    SELECT
        COUNT(*)
    INTO N2
    FROM
        IS_PART_OF
    WHERE
            SQUAD_NAME = S_NAME
        AND PLAYER_CARD_CODE = P_CODE_OLD
        AND HOLDER = '0';

--Se <n2 = 0>, il player con codice carta <p_code_old> non e' stato trovato.
    IF N2 = 0 THEN
        RAISE NO_DATA_FOUND_OLD;
    END IF;
END IF;

--Se <n1 != 0>, il player <p_code_old> e' titolare.
IF N1 <> 0 THEN
    --Se <p_code_old> corrisponde a <p_code_new> cambio il valore holder di <p_code_old>.
    IF SAME = 1 THEN
        UPDATE IS_PART_OF
        SET HOLDER = '0'
        WHERE PLAYER_CARD_CODE = P_CODE_OLD;
    ELSE
    --Controllo che il player con <p_code_new> e' nelle riserve.
        SELECT
            COUNT(*)
        INTO N1
        FROM
            IS_PART_OF
        WHERE
                SQUAD_NAME = S_NAME
            AND PLAYER_CARD_CODE = P_CODE_NEW
            AND HOLDER = '0';

        --Se <n1 = 0>, il player <p_code_new> non e' titolare.
        -- controllo se e' nelle riserve.
        IF N1 = 0 THEN
            SELECT
            COUNT(*)
            INTO N1
            FROM
                IS_PART_OF
            WHERE
                    SQUAD_NAME = S_NAME
                AND PLAYER_CARD_CODE = P_CODE_NEW
                AND HOLDER = '1';

            --Se <n1 = 0>, il player <p_code_new> non e' stato trovato.
            if N1 = 0 THEN
                RAISE NO_DATA_FOUND_NEW;
            
            --Altrimenti i player sono entrambi titolari e non c'e' niente da cambiare.
            ELSE
                RAISE SAME_HOLDER_1;
            END IF;

        --Se <n1 != 0>, il player <p_code_new> e' nelle riserve e diventera' titolare.
        ELSE
    --Imposto <holder> del player <p_code_new> ad '1', cioe' titolare.
            UPDATE IS_PART_OF
            SET
                HOLDER = '1'
            WHERE
                    SQUAD_NAME = S_NAME
                AND PLAYER_CARD_CODE = P_CODE_NEW;

    --Il player <p_code_old> andra' nelle riserve, imposto <holder> = '0'.
            UPDATE IS_PART_OF
            SET
                HOLDER = '0'
            WHERE
                    SQUAD_NAME = S_NAME
                AND PLAYER_CARD_CODE = P_CODE_OLD;

    --Confermo
            COMMIT;
        END IF;
    END IF;
--Se <n2 != 0>, il player <p_code_old> e' nelle riserve.
ELSIF N2 <> 0 THEN
    --Se <p_code_old> corrisponde a <p_code_new> cambio il valore holder di <p_code_old>.
    IF SAME = 1 THEN
        UPDATE IS_PART_OF
        SET HOLDER = '1'
        WHERE PLAYER_CARD_CODE = P_CODE_OLD;
    ELSE
        --Controllo se il player <p_code_new> e' titolare.
        SELECT
        COUNT(*)
        INTO N1
        FROM
            IS_PART_OF
        WHERE
                SQUAD_NAME = S_NAME
            AND PLAYER_CARD_CODE = P_CODE_NEW
            AND HOLDER = '1';

        --Il player <p_code_new> non e' titolare, controllo se e' nelle riserve.
        IF N1 = 0 THEN
            SELECT
            COUNT(*)
            INTO N1
            FROM
                IS_PART_OF
            WHERE
                    SQUAD_NAME = S_NAME
                AND PLAYER_CARD_CODE = P_CODE_NEW
                AND HOLDER = '0';

            --Se <n1 = 0>, il player <p_code_new> non e' stato trovato.
            IF N1 = 0 THEN
                RAISE NO_DATA_FOUND_NEW;

            --Se <n1 != 0>, i player sono entrambi nelle riserve, non c'e' niente da cambiare.
            ELSIF N1 != 0 THEN
                RAISE SAME_HOLDER_0;
            END IF;
        END IF;

        --Se <n1 != 0>, il player <p_code_new> era titolare e andra' nelle riserve <holder = '0'>.
        IF N1 <> 0 THEN
            UPDATE IS_PART_OF
            SET
                HOLDER = '0'
            WHERE
                    SQUAD_NAME = S_NAME
                AND PLAYER_CARD_CODE = P_CODE_NEW;

    --Il player <p_code_old> andra' titolare <holder = '1'>.
            UPDATE IS_PART_OF
            SET
                HOLDER = '1'
            WHERE
                    SQUAD_NAME = S_NAME
                AND PLAYER_CARD_CODE = P_CODE_OLD;

    --Confermo
            COMMIT;
        END IF;
    END IF;
END IF;

EXCEPTION
WHEN NO_DATA_FOUND_OLD THEN
    RAISE_APPLICATION_ERROR('-20001', 'Il giocatore con codice carta ('
                                        || P_CODE_OLD
                                        || ') non e'' stato trovato!');
WHEN NO_DATA_FOUND_NEW THEN
    RAISE_APPLICATION_ERROR('-20001', 'Il giocatore con codice carta ('
                                        || P_CODE_NEW
                                        || ') non e'' stato trovato!');
WHEN SAME_HOLDER_0 THEN
    RAISE_APPLICATION_ERROR('-20003', 'I giocatori con codici carta ('
                                        || P_CODE_OLD
                                        || ') - ('
                                        || P_CODE_NEW
                                        || ') sono entrambi nelle riserve!');
WHEN SAME_HOLDER_1 THEN
    RAISE_APPLICATION_ERROR('-20003', 'I giocatori con codici carta ('
                                        || P_CODE_OLD
                                        || ') - ('
                                        || P_CODE_NEW
                                        || ') sono entrambi titolari!');

END CHANGE_PLAYER;
/