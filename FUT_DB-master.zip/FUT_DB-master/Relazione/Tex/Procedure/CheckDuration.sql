-- Procedura per Job Transaction:
--  -> Elimina le transazioni scadute (duration = 0), 
--      e decrementa di uno l'attributo duration di transaction, viene chiamata solo dal job 
--       transaction che si attiva ogni ora.
CREATE OR REPLACE PROCEDURE CHECK_DURATION IS
BEGIN
   --Elimino le transazioni scadute.
   DELETE FROM TRANSACTION
   WHERE
         DURATION = 0
      AND TRANSITION_B_CLUB_NAME IS NULL;

   --Aggiorno la durata rimanante poiche' e' passata un'ora.
   UPDATE TRANSACTION
   SET
      DURATION = DURATION - 1
   WHERE
      DURATION > 0;

   --Confermo
   COMMIT;
END CHECK_DURATION;
/