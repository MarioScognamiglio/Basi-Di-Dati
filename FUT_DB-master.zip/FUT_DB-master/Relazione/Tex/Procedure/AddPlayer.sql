-- Tabelle interessate: 5
--  -> CLUB_CARD, PLAYER, IS_PART_OF, SQUAD;

-- Funzioni interessate: 4
--  -> IS_ADMIN, CARD_IN_CLUB, GET_MANAGER_CHEMISTRY, GET_PLAYER_CHEMISTRY

-- INPUT:
--	-> c_code:  codice carta di tipo <player>;
--	-> s_name:  nome della squadra dove schierare il <player>;
--	-> cc_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
--  -> p_position: posizione in campo del <player>;
--  -> flag: 1 = titolare, 0 = panchina;
-- OUTPUT:
--  -> Aggiunge il player <c_code> alla squadra <s_name>.

CREATE OR REPLACE PROCEDURE ADD_PLAYER (
C_CODE      CLUB_CARD.CARD_CODE%TYPE,
S_NAME      SQUAD.NAME%TYPE,
CC_NAME     CLUB.CLUB_NAME%TYPE,
P_POSITION  PLAYER.POSITION%TYPE,
FLAG        CHAR
) IS

N1     NUMBER(1, 0); --Controlla se il giocatore e' gia presente nella squadra.
N2     NUMBER(2, 0); --Controlla il massimo numero di giocatori di una squadra (max=18).
N3     NUMBER(2, 0); --Controlla se il giocatore e' presente in altre squadre dello stesso club.
POS    PLAYER.POSITION%TYPE; --Contiene la posizione naturale del <player>. 
OVE    PLAYER.OVERALL%TYPE; --Valutazione <overall> del player.
C_ID   PLAYER.CARD_ID% TYPE; --Card_id del <player> che si vuole aggiungere. 
P_NAME PLAYER.PLAYER_NAME%TYPE; --Nome del <player>.
HOLD   CHAR; --Se e' uguale a 0 il giocatore andra' in panchina altrimenti titolare.  

--Controllo utente
C_NAME CLUB.CLUB_NAME%TYPE; --Nome effettivo del club (is_admin).

--Controllo posizioni modulo scelto
A_MODULES VARCHAR2(10); --Modulo della squadra <s_name>.
P_CHEM ARRAY_POS_T; --Posizioni del modulo <a_modules>.
CNT_POS NUMBER(1, 0); --Quante posizioni uguali a quella scelta ci sono libere nel modulo <a_modules>.

--Aggiornamento Rating di squadra
S_RATING NUMBER(2, 0); --Valutazione della squadra.

--Aggiornamento intesa di squadra
S_CHEMISTRY NUMBER(3, 0);--Intesa della squadra.
M_CHEMISTRY NUMBER(1, 0);--Bonus intesa dato dal manager.
CHEMISTRY NUMBER(2, 0);--Intesa <chemistry> del <player>.

--Conterra' una query, nel caso in cui la posizione scelta <p_position> e' diversa dalla posizione naturale del <player>
-- la valutazione del giocatore <player_rating> cambia in base alla posizione, di conseguenza viene
-- selezionata la nuova valutazione <player_rating> in base alla posizione <p_position>.
PLSQL_QUERY_RATING_POS  VARCHAR(500);
EXISTING_PLAYER EXCEPTION; --Il player e' gia' presente in squadra.
MAX_PLAYER EXCEPTION; --Raggiunto limite massimo di <player> per la squadra.
INVALID_FLAG EXCEPTION; --Flag diverso da 0 o 1.

BEGIN
--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione ADD_PLAYER;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <cc_name>
--Altrimenti il nome del club <c_name> sara' quello dell'utente.
--In breve l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
SELECT
    IS_ADMIN(CC_NAME, USER)
INTO C_NAME
FROM
    DUAL;

--La funzione card_in_club, controlla che il club identificato dal nome <c_name> possieda la carta identificata dal <c_code>
-- se n1 != 0 il club possiede la carta, altrimenti no.
SELECT
    CARD_IN_CLUB(C_CODE, C_NAME)
INTO N1
FROM
    DUAL;

--Se <n1 = 0>, il <player> con codice carta <c_code> non e' stato trovato.
IF N1 = 0 THEN
    RAISE NO_DATA_FOUND;
END IF;

--Seleziono il nome,posizione e valutazione del <player>.
SELECT
    PLAYER_NAME,
    POSITION,
    OVERALL
INTO
    P_NAME,
    POS,
    OVE
FROM
            CLUB_CARD CC
    JOIN PLAYER P ON CC.PLAYER_ID = P.CARD_ID
WHERE
    CC.CARD_CODE = C_CODE;

--Controllo se il <player> e' gia presente nella squadra <s_name>.
SELECT
    COUNT(PLAYER_CARD_CODE)
INTO N1
FROM
            IS_PART_OF IPF
    JOIN CLUB_CARD  CC ON IPF.PLAYER_CARD_CODE = CC.CARD_CODE
    JOIN PLAYER     P ON CC.PLAYER_ID = P.CARD_ID
WHERE
        S_NAME = SQUAD_NAME
    AND ( PLAYER_CARD_CODE = C_CODE
            OR P.PLAYER_NAME = P_NAME );

--Controlla quanti player ci sono in squadra (max=18).
SELECT
    COUNT(PLAYER_CARD_CODE)
INTO N2
FROM
    IS_PART_OF
WHERE
        S_NAME = SQUAD_NAME;

--Se <n1 != 0> il <player> e' presente nella squadra.
IF N1 != 0 THEN
    RAISE EXISTING_PLAYER;
--Raggiunto limite massimo giocatori in squadra.
ELSIF N2 > 18 THEN
    RAISE MAX_PLAYER;
ELSE 
--Se la posizione scelta <p_position> e' diversa da quella naturale  
-- e se la posizione e diversa da 'GK' cioe' portiere; seleziono 
-- la valutazione <player_rating> del <player> in base alla posizione scelta.
    IF
        P_POSITION != POS
        AND P_POSITION != 'GK'
    THEN
        PLSQL_QUERY_RATING_POS := 'SELECT '
                                    || P_POSITION
                                    || ' FROM CLUB_CARD CC JOIN PLAYER P ON CC.PLAYER_ID = P.CARD_ID WHERE CC.CARD_CODE='''
                                    || C_CODE
                                    || '''';
        EXECUTE IMMEDIATE PLSQL_QUERY_RATING_POS
        INTO OVE;
    END IF;

--Se la posizione scelta <p_position> non corrisponde a quella naturale <pos>, ed e' uguale a 'GK'
-- si vuole schierare in porta, un giocatore non portiere, di conseguenza la sua valutazione <ove> cambia drasticamente.
    IF
        P_POSITION != POS
        AND P_POSITION = 'GK'
    THEN
        OVE := 20;
    END IF;

--Quanti <player> della squadra in quella posizione sono titolari = N2.
    SELECT
        COUNT(PLAYER_CARD_CODE)
    INTO N2
    FROM
        IS_PART_OF
    WHERE
            PLAYER_POSITION = P_POSITION
        AND HOLDER = '1'
        AND SQUAD_NAME = S_NAME;

--Seleziono il modulo della squadra <s_name>.
    SELECT
        MODULES
    INTO A_MODULES
    FROM
        SQUAD
    WHERE
            NAME = S_NAME
        AND SQUAD_CLUB_NAME = C_NAME;

--La funzione MODULE_POSITIONS, prende in input un modulo e ritorna le sue posizioni.
--Esempio:    <a_modules> = '4-3-3'
--  output: ('GK','LB','CB','CB','RB','CM','CM','CM','LW','ST','RW');
    SELECT
        MODULE_POSITIONS(A_MODULES)
    INTO P_CHEM
    FROM
        DUAL;

--Quante posizioni ci sono nel modulo che corrispondono a quella scelta <p_position>.
    CNT_POS := 0; 



--Se <flag != 0>, il <player> andra' titolare.
    IF FLAG != '0' THEN

--Vediamo quante posizioni ci sono nel modulo che corrispondono a quella scelta.
-- Perche' ad esempio nel modulo '4-3-3' ci sono 3 'CM' centrocampisti centrali.
        FOR I IN 1..11 LOOP
            IF P_CHEM(I) = P_POSITION THEN
                CNT_POS := CNT_POS + 1;
            END IF;
        END LOOP;

--Se <n2 = 0> non ci sono <player> titolari in quella posizione.
--E <cnt_pos > 0> significa che il modulo contiene la posizione scelta. 
        IF
            N2 = 0
            AND CNT_POS > 0
        THEN
            HOLD := '1'; --Il <player> diventa titolare.

--Se <n2 > 0> ci sono <player> titolari in posizione <p_position>.
--E se <n2 < CNT_POS>, ci sono posizioni libere nel ruolo.
--Esempio: vogliamo aggiungere un difensore centrale, c'e' gia' un difensore titolare, ma se ne possono schierare 2. 
        ELSIF
            N2 > 0
            AND N2 < CNT_POS
        THEN
            HOLD := '1'; --Il <player> diventa titolare.
        ELSE--Non ci sono posizioni disponibili nel modulo, il <player> va nelle riserve.
            HOLD := '0';
        END IF;
--Se <flag = 0>, il <player> va schierato nelle riserve.
    ELSIF FLAG = '0' THEN
        HOLD := '0'; 
--Se viene inserito un flag diverso da 0 o 1.       
    ELSE
        RAISE INVALID_FLAG;
    END IF;

--Funzione che calcola l'intesa <chemistry> del <player>.
    SELECT
        GET_PLAYER_CHEMISTRY(P_POSITION, POS)
    INTO CHEMISTRY
    FROM
        DUAL;    

--Calcolo bonus intesa del manager.
--MANAGER_CHEMISTRY ritorna 1 se il manager ha nazionalita' o lega uguale al player altrimenti 0;
    SELECT
        MANAGER_CHEMISTRY(C_ID, C_CODE, S_NAME, C_NAME)
    INTO M_CHEMISTRY
    FROM
        DUAL;

--Se il bonus e 1 e l'intesa <chemistry> del <player> non e' al massimo <10>.
    IF
        M_CHEMISTRY IS NOT NULL
        AND CHEMISTRY < 10
    THEN
--Aggiungo il bonus dato dal manager a l'intesa del <player>.
        CHEMISTRY := CHEMISTRY + M_CHEMISTRY;
    END IF;  

--Inserisco il <player> in squadra.
    INSERT INTO IS_PART_OF (
        PLAYER_CARD_CODE,
        SQUAD_NAME,
        PLAYER_POSITION,
        PLAYER_CHEMISTRY,
        PLAYER_RATING,
        HOLDER
    )
        SELECT
            C_CODE,
            S_NAME,
            P_POSITION,
            CHEMISTRY,
            OVE,
            HOLD
        FROM
            DUAL; 

--Calcolo della nuova valutazione <s_rating> della squadra. 
    SELECT
        GET_SQUAD_RATING(S_NAME, C_NAME)
    INTO S_RATING
    FROM
        DUAL;

--Inseirsco la nuova valutazione <s_rating> della squadra.
    UPDATE SQUAD
    SET
        SQUAD_RATING = S_RATING
    WHERE
            NAME = S_NAME
        AND SQUAD_CLUB_NAME = C_NAME;     

--Calcolo intesa della squadra come somma dell'intesa di ogni <player>.
    SELECT
        SUM(PLAYER_CHEMISTRY)
    INTO S_CHEMISTRY
    FROM
        IS_PART_OF
    WHERE
            SQUAD_NAME = S_NAME
        AND HOLDER = '1';

--Inseirsco la nuova intesa <s_chemistry> della squadra.
    UPDATE SQUAD
    SET
        SQUAD_CHEMISTRY = S_CHEMISTRY
    WHERE
            NAME = S_NAME
        AND SQUAD_CLUB_NAME = C_NAME;

--Confermo
    COMMIT;
END IF;

EXCEPTION
WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(-20001, 'Giocatore non trovato!'
                                    || CHR(10)
                                    || SQLCODE
                                    || ' - ERROR - '
                                    || SQLERRM);
WHEN EXISTING_PLAYER THEN
    DBMS_OUTPUT.PUT_LINE('Il giocatore '
                            || P_NAME
                            || ' e'' gia'' presente in '
                            || S_NAME);
WHEN MAX_PLAYER THEN
    RAISE_APPLICATION_ERROR(-20004, 'Impossibile aggiungere giocatore, hai raggiunto il limite massimo!');
WHEN INVALID_FLAG THEN
    RAISE_APPLICATION_ERROR(-20003, 'Flag error!');
END ADD_PLAYER;
/