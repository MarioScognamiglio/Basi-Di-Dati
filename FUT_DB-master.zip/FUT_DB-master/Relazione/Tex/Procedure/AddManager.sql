-- Tabelle interessate: 6
--  -> CLUB_CARD, MANAGER, MANGES, ACTIVE_DATA_MANAGER, PLAYER, IS_PART_OF;

-- Funzioni interessate: 2
--  -> IS_ADMIN, CARD_IN_CLUB;

-- INPUT:
--	-> m_card_code: codice carta di tipo manager;
--	-> s_name:  nome della squadra;
--	-> cc_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
-- OUTOUT:
--  -> Schiera il manager <m_card_code> nella squadra <s_name>.
CREATE OR REPLACE PROCEDURE ADD_MANAGER (
M_CARD_CODE  IN  CLUB_CARD.CARD_CODE%TYPE,
S_NAME       IN  SQUAD.NAME%TYPE,
CC_NAME      IN  SQUAD.NAME%TYPE
) IS
--Controlli
N1             NUMBER(2, 0); --Controlla che il club possiede le carte.
N2             NUMBER(2, 0); --Controlla che il manager non allena gia' una squadra.
FLAG           NUMBER(1, 0); --Variabile di controllo.
C_NAME         CLUB.CLUB_NAME%TYPE; --Nome del club effettivo (is_admin).

--Manager
A_M_CARD_CODE  CLUB_CARD.CARD_CODE%TYPE; --<card_code> del manager qualora c'e' gia un manager attivo nella squadra.
M_LEAGUE       MANAGER.LEAGUE_NAME%TYPE; --Lega del manager.
M_NATION       MANAGER.NATIONALITY%TYPE; --Nazionalita' del manager.
M_ID           MANAGER.CARD_ID%TYPE; --<card_id> del manager.

--Player
P_NATION       PLAYER.NATIONALITY%TYPE; --Nazionalita' dei player della squadra.
P_LEAGUE       PLAYER.LEAGUE_NAME%TYPE; --Lega preferita dei player della squadra.

TYPE ARRAY_CC_T IS VARRAY(18) OF VARCHAR2(8);
ARR_CARD_CODE  ARRAY_CC_T; --Array che conterra' i <card_code> dei player della squadra.

NO_MANAGER_FOUND EXCEPTION; --Il manager <m_card_code> non e' stato trovato.
EXISTING_MANAGER EXCEPTION; --La squadra <s_name> e' gia' allenata dal manager <m_card_code>.

BEGIN
FLAG := 0; --Se e' uguale ad 1, significa che c'e' un manager nella squadra <s_name> e va sostituito.

--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione ADD_MANAGER;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <cc_name>
--Altrimenti il nome del club <c_name> sara' quello dell'utente.
--In breve l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
SELECT
    IS_ADMIN(CC_NAME, USER)
INTO C_NAME
FROM
    DUAL;

--La funzione card_in_club, controlla che il club identificato dal nome <c_name> possieda la carta identificata dal <c_code>
-- se n1 != 0 il club possiede la carta, altrimenti no.
SELECT
    CARD_IN_CLUB(M_CARD_CODE, C_NAME)
INTO N1
FROM
    DUAL;

IF N1 = 0 THEN
    RAISE NO_MANAGER_FOUND;
END IF;

--Controllo che la squadra <s_name> non abbia gia' un'allenatore.
SELECT
    COUNT(MANAGER_CARD_CODE)
INTO N2
FROM
    MANAGES
WHERE
        SQUAD_NAME = S_NAME;

--Se <n2 > 0> la squadra <s_name> ha gia' un allenatore
-- controllo se e' uguale al manager che voglio schierare.
IF N2 > 0 THEN

--Seleziono il codice carta <card_code> del manager della squadra <s_name>.
    SELECT
        MANAGER_CARD_CODE
    INTO A_M_CARD_CODE
    FROM
        MANAGES
    WHERE
            SQUAD_NAME = S_NAME;

--Se e' uguale al codice carta <m_card_code> del manager che voglio aggiungere, genero un eccezione.
    IF A_M_CARD_CODE = M_CARD_CODE THEN
        RAISE EXISTING_MANAGER;
--Altrimenti pongo <flag = 1> ovvero c'e' un manager che va sostituito.
    ELSIF A_M_CARD_CODE IS NOT NULL THEN
        FLAG := 1;
    END IF;

END IF;

--Seleziono il <card_id> del manager, per poi selezionare nazionalita e lega.
SELECT
    MANAGER_ID
INTO M_ID
FROM
    CLUB_CARD
WHERE
    CARD_CODE = M_CARD_CODE;

--Seleziono nazionalita e lega del manager.
SELECT
    NATIONALITY,
    LEAGUE_NAME
INTO
    M_NATION,
    M_LEAGUE
FROM
            MANAGER M
    JOIN CLUB_CARD C ON M.CARD_ID = C.MANAGER_ID
                        AND C.CARD_CODE = M_CARD_CODE;

--Se <flag = 1>, c'e' un manager da sostituire.
IF FLAG = 1 THEN
--Aggiorno il <manager_card_code> con quello del nuovo manager. 
    UPDATE MANAGES
    SET
        MANAGER_CARD_CODE = M_CARD_CODE
    WHERE
            SQUAD_NAME = S_NAME;

ELSE--Se la squadra <s_name> non ha un'allenatore.

--Inserisco la tupla in manages
    INSERT INTO MANAGES VALUES (
        M_CARD_CODE,
        C_NAME,
        S_NAME
    );

END IF;

--Se il manager aveva gia' dati attivi, <n1 > 0> non devo inserirli nuovamente.
SELECT
    COUNT(*)
INTO N1
FROM
    ACTIVE_DATA_MANAGER
WHERE
    M_CARD_CODE = M_CARD_CODE;

--Se il manager non aveva dati attivi, inserisco la nuova tupla.
IF N1 = 0 THEN
    INSERT INTO ACTIVE_DATA_MANAGER VALUES (
        M_CARD_CODE,
        M_LEAGUE,
        7
    );

END IF;

--Confermo
COMMIT;

--Seleziono i codici carta <card_code> dei <player> della squadra <s_name>.
SELECT
    PLAYER_CARD_CODE
BULK COLLECT
INTO ARR_CARD_CODE
FROM
    IS_PART_OF
WHERE
        SQUAD_NAME = S_NAME;
        
FOR I IN 1..ARR_CARD_CODE.COUNT LOOP
--Seleziono nazionalita' e lega del <player> i-esimo.
    SELECT
        NATIONALITY,
        LEAGUE_NAME
    INTO
        P_NATION,
        P_LEAGUE
    FROM
                PLAYER P
        JOIN CLUB_CARD C ON P.CARD_ID = C.PLAYER_ID
                            AND C.CARD_CODE = ARR_CARD_CODE(I);

--Se la nazionalita' o la lega del player corrispondono a quella del manager
-- il player guadagna un bonus di 1 sull'intesa <player_chemistry>. 
    IF P_NATION = M_NATION OR P_LEAGUE = M_LEAGUE THEN

--Aggiorno l'intesa <player_chemistry> del player i-esimo.
        UPDATE
        IS_PART_OF
        SET
            PLAYER_CHEMISTRY = PLAYER_CHEMISTRY + 1
        WHERE
                PLAYER_CARD_CODE = ARR_CARD_CODE(I)
            AND PLAYER_CHEMISTRY < 10;

--Confermo
        COMMIT;
    END IF;

END LOOP;

EXCEPTION
WHEN NO_MANAGER_FOUND THEN
    RAISE_APPLICATION_ERROR('-20007', 'Il manager con codice carta ('
                                        || M_CARD_CODE
                                        || ') non e'' stato trovato!');
WHEN EXISTING_MANAGER THEN
    RAISE_APPLICATION_ERROR('-20007', 'Il manager con card_code ('
                                        || M_CARD_CODE
                                        || ') e'' gia presente!');
END ADD_MANAGER;
/