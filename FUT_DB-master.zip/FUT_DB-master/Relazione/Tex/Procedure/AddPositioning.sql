-- Tabelle interessate: 3
--  -> CLUB_CARD, IS_PART_OF, CONSUMABLE;

-- Funzioni interessate: 2
--  -> IS_ADMIN, CARD_IN_CLUB;

-- INPUT:
--	-> c_code:  codice carta di tipo <consumable> di categoria <positioning>;
--	-> p_code:  codice carta di tipo <player>;
--	-> cc_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
-- OUTPUT:
--  -> Cambia la posizione <player_position> del <player> con quella indicata dal consumabile.
CREATE OR REPLACE PROCEDURE ADD_POSITIONING (
C_CODE   CLUB_CARD.CARD_CODE%TYPE,
P_CODE   CLUB_CARD.CARD_CODE%TYPE,
CC_NAME  CLUB.CLUB_NAME%TYPE
) IS

N1          NUMBER(2, 0);
C_T         CONSUMABLE.TYPE%TYPE; --Posizione indicata dal consumabile <c_code>.
P_POSITION  IS_PART_OF.PLAYER_POSITION%TYPE; --Posizione attuale del <player> <p_code>. 
RESULT      NUMBER(1, 0); --Variabile di controllo, se e' uguale ad 0 la posizione del player e' stata cambiata.
C_NAME      CLUB.CLUB_NAME%TYPE; --Nome effettivo del club (is_admin).
P_NAME      PLAYER.PLAYER_NAME%TYPE; --Nome del player.

NO_PLAYER_FOUND EXCEPTION; --Il <player> con codice carta <p_code> non e' stato trovato.
POSITION_ERROR EXCEPTION; --Se la posizione del player non corrisponde a quella indicata dal consumabile.

BEGIN
RESULT := 1; -- se e' uguale a 0 la posizione del player e' stata cambiata

--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione ADD_POSITIONING;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <cc_name>
--Altrimenti il nome del club <c_name> sara' quello dell'utente.
--In breve l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
SELECT
    IS_ADMIN(CC_NAME, USER)
INTO C_NAME
FROM
    DUAL;
--La funzione card_in_club, controlla che il club identificato dal nome <c_name> possieda la carta identificata dal <c_code>
-- se n1 != 0 il club possiede la carta, altrimenti no.
SELECT
    CARD_IN_CLUB(C_CODE, C_NAME)
INTO N1
FROM
    DUAL;

-- Se <n1 = 0>, il club non possiede il consumabile <c_code>, oppure e' stato inserito un <c_code> errato.
IF N1 = 0 THEN
    RAISE NO_DATA_FOUND;

-- Altrimenti vediamo di che tipo e' il consumabile <c_code>.
ELSE
    SELECT
        TYPE
    INTO C_T
    FROM CONSUMABLE
    WHERE CARD_ID IN (
            SELECT
                CONSUMABLE_ID
            FROM
                CLUB_CARD
            WHERE
                CARD_CODE = C_CODE
        );

--Verifico che il club possiede il <player> con <card_code> <p_code>.
    SELECT
        CARD_IN_CLUB(P_CODE, C_NAME)
    INTO N1
    FROM
        DUAL;

-- Se <n1 = 0>, il club non possiede il player <p_code>, oppure e' stato inserito un <p_code> errato.
    IF N1 = 0 THEN
        RAISE NO_PLAYER_FOUND;
    END IF;

--Seleziono la posizione attuale del <player>.
    SELECT
        PLAYER_POSITION
    INTO P_POSITION
    FROM
        IS_PART_OF
    WHERE
        PLAYER_CARD_CODE = P_CODE;

-- In base al tipo di consumabile, se la posizione del player corrisponde, aggiorno la posizione a quella indicata dal consumabile.
-- Se l'operazione ha successo imposto <result> uguale a 0.
    IF C_T = 'LWBLB' THEN
        IF P_POSITION != 'LWB' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'LB'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'LBLWB' THEN
        IF P_POSITION != 'LB' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'LWB'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'RWBRB' THEN
        IF P_POSITION != 'RWB' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'RB'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'RBRWB' THEN
        IF P_POSITION != 'RB' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'RWB'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'LMLW' THEN
        IF P_POSITION != 'LM' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'LW'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'LWLM' THEN
        IF P_POSITION != 'LW' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'LM'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'RMRW' THEN
        IF P_POSITION != 'RM' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'RW'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'RWRM' THEN
        IF P_POSITION != 'RW' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'RM'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'LWLF' THEN
        IF P_POSITION != 'LW' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'LF'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'LFLW' THEN
        IF P_POSITION != 'LF' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'LW'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'RWRF' THEN
        IF P_POSITION != 'RW' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'RF'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'RFRW' THEN
        IF P_POSITION != 'RF' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'RW'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'CMCAM' THEN
        IF P_POSITION != 'CM' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'CAM'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'CAMCM' THEN
        IF P_POSITION != 'CAM' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'CM'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'CDMCM' THEN
        IF P_POSITION != 'CDM' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'CM'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'CMCDM' THEN
        IF P_POSITION != 'CM' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'CDM'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'CAMCF' THEN
        IF P_POSITION != 'CAM' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'CF'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'CFCAM' THEN
        IF P_POSITION != 'CF' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'CAM'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'CFST' THEN
        IF P_POSITION != 'CF' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'ST'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    ELSIF C_T = 'STCF' THEN
        IF P_POSITION != 'ST' THEN
            RAISE POSITION_ERROR;
        ELSE
            UPDATE IS_PART_OF
            SET
                PLAYER_POSITION = 'CF'
            WHERE
                PLAYER_CARD_CODE = P_CODE;

            RESULT := 0;
        END IF;
    END IF;

--Se <result = 0>, il consumabile <c_code> e' stato utilizzato e va eliminato.
    IF RESULT = 0 THEN
        DELETE FROM CLUB_CARD
        WHERE CARD_CODE = C_CODE;
        COMMIT;
    END IF;
END IF;

EXCEPTION
WHEN POSITION_ERROR THEN 
-- Seleziona il nome del player in <p_name>.
    SELECT
        PLAYER_NAME
    INTO P_NAME
    FROM PLAYER
    WHERE CARD_ID IN (
            SELECT
                PLAYER_ID
            FROM
                CLUB_CARD
            WHERE
                CARD_CODE = P_CODE
        );
    RAISE_APPLICATION_ERROR('-20002', 'Posizione non valida per '
                                        || P_NAME
                                        || ' ('
                                        || P_CODE
                                        || ')!');
WHEN NO_PLAYER_FOUND THEN
    RAISE_APPLICATION_ERROR('-20001', 'Il giocatore con codice carta ('
                                        || P_CODE
                                        || ') non e'' stato trovato!');
END ADD_POSITIONING;
/