-- Tabelle interessate: 9
--  -> CLUB_CARD, CLUB, PLAYER, CONSUMABLE, CLUB_ITEM, MANAGER, IS_FOUND, PACK_PURCHASE, TRANSACTION;

-- INPUT:
--	-> p_name:  nome del pacchetto che si vuole aprire;
--	-> usr_1:  nome utente;
-- OUTPUT:
--  -> Apre il pacchetto <p_name>.
CREATE OR REPLACE PROCEDURE PACK_OPENING (
P_NAME  PACK.PACK_NAME%TYPE,
USR_1   CLUB.USER_NICK%TYPE
) IS

P         PACK%ROWTYPE; --Info sul pacchetto da aprire.
CRT       CLUB.CREDITS%TYPE; --Crediti dell'utente.
USR       CLUB.USER_NICK%TYPE; --Nome utente effettivo (isAdmin).
--Variabile d'appoggio per operare sul nome utente <usr_1> fornito in input.
USR_2     CLUB.USER_NICK%TYPE;
N1        NUMBER(4,0); 
STR1      VARCHAR2(8); --Codice carta.
STR2      VARCHAR2(8); 
COUNTER   NUMBER(2, 0); 
M_LEAGUE  MANAGER.LEAGUE_NAME%TYPE; --lega del manager.

NO_USER_FOUND EXCEPTION; --L'utente con nome utente <usr_1> non e' stato trovato.
--Se ad esempio l'utente 'PLAYER1' prova ad aprire un pack con un altro nome utente, solo l'amministratore puo'.
USER_ERROR EXCEPTION;
BEGIN
--Salvo il nome utente <usr_1> in <usr_2>.
USR_2 := USR_1;

--Se l'utente chiamante non e' amministratore.
IF USER <> 'ADMINFUT' THEN
--Controllo se l'utente ha un club.
    SELECT
        COUNT(*)
    INTO N1
    FROM
        CLUB
    WHERE
        LOWER(USER_NICK) = LOWER(USER);

--Se <n1 = 0>, l'utente con nome utente <usr_1> non e' stato trovato.
    IF N1 = 0 THEN
        RAISE NO_USER_FOUND;
    END IF;

--Seleziono il nome utente chiamante in <usr>.
    SELECT
        USER
    INTO USR
    FROM
        DUAL;
--Se l'utente chiamante e' amministratore il nome utente corrisponde a quello dato in input.
ELSE
    USR := USR_1;
END IF;

--Se il nome utente dato in input <usr_2> non e' null 
-- ed e' diverso dal nome utente che chiama la funzione, e non e' amministratore.
IF
    USR_2 IS NOT NULL
    AND USR <> USR_2
    AND USER <> 'ADMINFUT'
THEN
    RAISE USER_ERROR;
END IF;

--La funzione Number Of Cards, controlla il volume delle carte del club;
--Il quale non puo' superare 1500, se il massimo non viene superato varra' 
--notificato all'utente quante carte ha collezionato fin ora e 
-- quante ne potra' ancora collezionare.
ADMINFUT.NUMBER_OF_CARDS(USR);

--Seleziono i crediti del club dell'utente, e il prezzo del pacchetto.
SELECT
    CLUB.CREDITS,
    PACK.PRICE
INTO
    CRT,
    P.PRICE
FROM
    CLUB,
    PACK
WHERE
        CLUB.USER_NICK = USR
    AND PACK.PACK_NAME = P_NAME;

--Se il club non ha abbastanza crediti.
IF CRT < P.PRICE THEN
    DBMS_OUTPUT.PUT_LINE('Crediti insufficenti!');
ELSE
--Controllo se il pacchetto e' disponibile.
    SELECT
        AVAILABLE
    INTO P.AVAILABLE
    FROM
        PACK
    WHERE
        PACK_NAME = P_NAME; 

--Se il pacchetto e' disponibile.
    IF P.AVAILABLE = '1' THEN	

--Seleziono i dettagli del pacchetto in <p>.
        SELECT
            *
        INTO P
        FROM
            PACK
        WHERE
            PACK_NAME = P_NAME;

--Calcolo il codice carta.
        STR1 := DBMS_RANDOM.STRING('a', 8);

--Inserisco la tupla del pacchetto aquistato in <pack_purchase>.
        INSERT INTO PACK_PURCHASE
            SELECT
                STR1,
                CLUB_NAME,
                P_NAME,
                SYSDATE
            FROM
                CLUB
            WHERE
                USER_NICK = USR; 

--Aggiorno il bilancio dei crediti sottraendo il costo del pacchetto.
        UPDATE CLUB
        SET
            CREDITS = CREDITS - P.PRICE
        WHERE
            USER_NICK = USR;

--Se <p.players> ovvero la quantita di <player> che possono uscire dal pacchetto
--  e' maggiore di 0.
        IF P.PLAYERS > 0 THEN
--Carte di tipo <player> di rarita' <gold>
        FOR COUNTER IN 1..P.PLAYERS LOOP
            IF P.GOLD_QUANTITY > 0 THEN
--Genero il codice carta.
                    STR2 := DBMS_RANDOM.STRING('a', 8);
--Inserisco la nuova carta trovata in <club_Card>.
                    INSERT
                    INTO CLUB_CARD (
                        CARD_CODE,
                        PLAYER_ID
                    )
                        SELECT
                            *
                        FROM
                            (
                                SELECT
                                    STR2,
                                    CARD_ID
                                FROM
                                    PLAYER
                                WHERE
                                    RARITY_NAME = 'Gold - Rare'
                                    OR RARITY_NAME = 'Gold - Non-Rare'
                                ORDER BY
                                    DBMS_RANDOM.RANDOM
                            )
                        WHERE
                            ROWNUM <= 1;

--Inserisco la tupla in <is_found>.
                    INSERT INTO IS_FOUND (
                        P_ID,
                        CARD_CODE
                    )
                        SELECT
                            STR1,
                            STR2
                        FROM
                            DUAL;
                            
                    P.GOLD_QUANTITY := P.GOLD_QUANTITY - 1;
                    
--Inserisco i dati attivi in <active_data_player>.
                    INSERT INTO ACTIVE_DATA_PLAYER (
                            P_CARD_CODE,
                            CONTRACTS,
                            PLAYER_FITNESS
                    )
                            SELECT
                                STR2,
                                7,
                                99
                            FROM
                                DUAL;
                                
--Carta di tipo <player> di rarita' <silver>.
            ELSIF P.SILVER_QUANTITY > 0 THEN
                    STR2 := DBMS_RANDOM.STRING('a', 8);
                    INSERT INTO CLUB_CARD (
                        CARD_CODE,
                        PLAYER_ID
                    )
                        SELECT
                            *
                        FROM
                            (
                                SELECT
                                    STR2,
                                    CARD_ID
                                FROM
                                    PLAYER
                                WHERE
                                    RARITY_NAME = 'Silver - Rare'
                                    OR RARITY_NAME = 'Silver - Non-Rare'
                                ORDER BY
                                    DBMS_RANDOM.RANDOM
                            )
                        WHERE
                            ROWNUM <= 1;

                    INSERT INTO IS_FOUND (
                        P_ID,
                        CARD_CODE
                    )
                        SELECT
                            STR1,
                            STR2
                        FROM
                            DUAL;

--Inserisco i dati attivi in <active_data_player>.
                    INSERT INTO ACTIVE_DATA_PLAYER (
                            P_CARD_CODE,
                            CONTRACTS,
                            PLAYER_FITNESS
                    )
                            SELECT
                                STR2,
                                7,
                                99
                            FROM
                                DUAL;
                        
                    P.SILVER_QUANTITY := P.SILVER_QUANTITY - 1;
--Carta di tipo <player> di rarita' <bronze>.
            ELSIF P.BRONZE_QUANTITY > 0 THEN
                    STR2 := DBMS_RANDOM.STRING('a', 8);
                    INSERT INTO CLUB_CARD (
                        CARD_CODE,
                        PLAYER_ID
                    )
                        SELECT
                            *
                        FROM
                            (
                                SELECT
                                    STR2,
                                    CARD_ID
                                FROM
                                    PLAYER
                                WHERE
                                    RARITY_NAME = 'Bronze - Rare'
                                    OR RARITY_NAME = 'Bronze - Non-Rare'
                                ORDER BY
                                    DBMS_RANDOM.RANDOM
                            )
                        WHERE
                            ROWNUM <= 1;

                    INSERT INTO IS_FOUND (
                        P_ID,
                        CARD_CODE
                    )
                        SELECT
                            STR1,
                            STR2
                        FROM
                            DUAL;

--Inserisco i dati attivi in <active_data_player>.
                    INSERT INTO ACTIVE_DATA_PLAYER (
                            P_CARD_CODE,
                            CONTRACTS,
                            PLAYER_FITNESS
                    )
                            SELECT
                                STR2,
                                7,
                                99
                            FROM
                                DUAL;

                    P.BRONZE_QUANTITY := P.BRONZE_QUANTITY - 1;
            ELSE
                DBMS_OUTPUT.PUT_LINE('Error inserimento player');
            END IF;
            END LOOP;
        END IF;

--Carta di tipo <consumable> di rarita' <gold>.
        IF P.CONSUMABLES > 0 THEN
            FOR COUNTER IN 1..P.CONSUMABLES LOOP
            IF P.GOLD_QUANTITY > 0 THEN
                    STR2 := DBMS_RANDOM.STRING('a', 8);
                    INSERT INTO CLUB_CARD (
                        CARD_CODE,
                        CONSUMABLE_ID
                    )
                        SELECT
                            *
                        FROM
                            (
                                SELECT
                                    STR2,
                                    CARD_ID
                                FROM
                                    CONSUMABLE
                                WHERE
                                    RARITY_NAME = 'Gold'
                                ORDER BY
                                    DBMS_RANDOM.RANDOM
                            )
                        WHERE
                            ROWNUM <= 1;

                    INSERT INTO IS_FOUND (
                        P_ID,
                        CARD_CODE
                    )
                        SELECT
                            STR1,
                            STR2
                        FROM
                            DUAL;
                        
                        
                        P.GOLD_QUANTITY := P.GOLD_QUANTITY - 1;
                
--Carta di tipo <consumable> di rarita' <silver>.
            ELSIF P.SILVER_QUANTITY > 0 THEN
                    STR2 := DBMS_RANDOM.STRING('a', 8);
                    INSERT INTO CLUB_CARD (
                        CARD_CODE,
                        CONSUMABLE_ID
                    )
                        SELECT
                            *
                        FROM
                            (
                                SELECT
                                    STR2,
                                    CARD_ID
                                FROM
                                    CONSUMABLE
                                WHERE
                                    RARITY_NAME = 'Silver'
                                ORDER BY
                                    DBMS_RANDOM.RANDOM
                            )
                        WHERE
                            ROWNUM <= 1;

                    INSERT INTO IS_FOUND (
                        P_ID,
                        CARD_CODE
                    )
                        SELECT
                            STR1,
                            STR2
                        FROM
                            DUAL;
                            
                        
                        P.SILVER_QUANTITY := P.SILVER_QUANTITY - 1;

--Carta di tipo <consumable> di rarita' <bronze>.
            ELSIF P.BRONZE_QUANTITY > 0 THEN
                    STR2 := DBMS_RANDOM.STRING('a', 8);
                    INSERT INTO CLUB_CARD (
                        CARD_CODE,
                        CONSUMABLE_ID
                    )
                        SELECT
                            *
                        FROM
                            (
                                SELECT
                                    STR2,
                                    CARD_ID
                                FROM
                                    CONSUMABLE
                                WHERE
                                    RARITY_NAME = 'Bronze'
                                ORDER BY
                                    DBMS_RANDOM.RANDOM
                            )
                        WHERE
                            ROWNUM <= 1;

                    INSERT INTO IS_FOUND (
                        P_ID,
                        CARD_CODE
                    )
                        SELECT
                            STR1,
                            STR2
                        FROM
                            DUAL;
                        
                        P.BRONZE_QUANTITY := P.BRONZE_QUANTITY - 1;
                        
            ELSE
                DBMS_OUTPUT.PUT_LINE('Error inserimento consumable');
            END IF;
            END LOOP;
        END IF;

        IF P.CLUB_ITEMS > 0 THEN
        FOR COUNTER IN 1..P.CLUB_ITEMS LOOP
--Carta di tipo <club_item> di rarita' <gold>. 
            IF P.GOLD_QUANTITY > 0 THEN
                    STR2 := DBMS_RANDOM.STRING('a', 8);
                    INSERT INTO CLUB_CARD (
                        CARD_CODE,
                        CLUB_ITEM_ID
                    )
                        SELECT
                            *
                        FROM
                            (
                                SELECT
                                    STR2,
                                    CARD_ID
                                FROM
                                    CLUB_ITEM
                                WHERE
                                    RARITY_NAME = 'Gold'
                                ORDER BY
                                    DBMS_RANDOM.RANDOM
                            )
                        WHERE
                            ROWNUM <= 1;

                    INSERT INTO IS_FOUND (
                        P_ID,
                        CARD_CODE
                    )
                        SELECT
                            STR1,
                            STR2
                        FROM
                            DUAL;

                        P.GOLD_QUANTITY := P.GOLD_QUANTITY - 1;
--Carta di tipo <club_item> di rarita' <silver>.
            ELSIF P.SILVER_QUANTITY > 0 THEN
                    STR2 := DBMS_RANDOM.STRING('a', 8);
                    INSERT INTO CLUB_CARD (
                        CARD_CODE,
                        CLUB_ITEM_ID
                    )
                        SELECT
                            *
                        FROM
                            (
                                SELECT
                                    STR2,
                                    CARD_ID
                                FROM
                                    CLUB_ITEM
                                WHERE
                                    RARITY_NAME = 'Silver'
                                ORDER BY
                                    DBMS_RANDOM.RANDOM
                            )
                        WHERE
                            ROWNUM <= 1;

                    INSERT INTO IS_FOUND (
                        P_ID,
                        CARD_CODE
                    )
                        SELECT
                            STR1,
                            STR2
                        FROM
                            DUAL;

                        P.SILVER_QUANTITY := P.SILVER_QUANTITY - 1;
--Carta di tipo <club_item> di rarita' <bronze>.
            ELSIF P.BRONZE_QUANTITY > 0 THEN
                    STR2 := DBMS_RANDOM.STRING('a', 8);
                    INSERT INTO CLUB_CARD (
                        CARD_CODE,
                        CLUB_ITEM_ID
                    )
                        SELECT
                            *
                        FROM
                            (
                                SELECT
                                    STR2,
                                    CARD_ID
                                FROM
                                    CLUB_ITEM
                                WHERE
                                    RARITY_NAME = 'Bronze'
                                ORDER BY
                                    DBMS_RANDOM.RANDOM
                            )
                        WHERE
                            ROWNUM <= 1;

                    INSERT INTO IS_FOUND (
                        P_ID,
                        CARD_CODE
                    )
                        SELECT
                            STR1,
                            STR2
                        FROM
                            DUAL;


                        P.BRONZE_QUANTITY := P.BRONZE_QUANTITY - 1;
            ELSE
                DBMS_OUTPUT.PUT_LINE('Error inserimento club_items');
            END IF;
            
            END LOOP;
            
        END IF;

        IF P.STAFF > 0 THEN
        FOR COUNTER IN 1..P.STAFF LOOP
--Carta di tipo <manager> di rarita' <gold>.
            IF P.GOLD_QUANTITY > 0 THEN
                    STR2 := DBMS_RANDOM.STRING('a', 8);
                    INSERT INTO CLUB_CARD (
                        CARD_CODE,
                        MANAGER_ID
                    )
                        SELECT
                            *
                        FROM
                            (
                                SELECT
                                    STR2,
                                    CARD_ID
                                FROM
                                    MANAGER
                                WHERE
                                    RARITY_NAME = 'Gold'
                                ORDER BY
                                    DBMS_RANDOM.RANDOM
                            )
                        WHERE
                            ROWNUM <= 1;

                    INSERT INTO IS_FOUND (
                        P_ID,
                        CARD_CODE
                    )
                        SELECT
                            STR1,
                            STR2
                        FROM
                            DUAL;
                            
                            
                    SELECT
                            LEAGUE_NAME
                    INTO    M_LEAGUE
                    FROM
                            MANAGER M
                        JOIN CLUB_CARD C ON M.CARD_ID = C.MANAGER_ID
                                            AND C.CARD_CODE = STR2;
                    
--Inserisco i dati attivi in <active_data_manager>.
                    INSERT INTO ACTIVE_DATA_MANAGER (
                            M_CARD_CODE,
                            MANAGER_LEAGUE,
                            CONTRACTS
                    )
                            SELECT
                                STR2,
                                M_LEAGUE,
                                7
                            FROM
                                DUAL;

                        P.GOLD_QUANTITY := P.GOLD_QUANTITY - 1;
--Carta di tipo <manager> di rarita' <silver>.
            ELSIF P.SILVER_QUANTITY > 0 THEN
                    STR2 := DBMS_RANDOM.STRING('a', 8);
                    INSERT INTO CLUB_CARD (
                        CARD_CODE,
                        MANAGER_ID
                    )
                        SELECT
                            *
                        FROM
                            (
                                SELECT
                                    STR2,
                                    CARD_ID
                                FROM
                                    MANAGER
                                WHERE
                                    RARITY_NAME = 'Silver'
                                ORDER BY
                                    DBMS_RANDOM.RANDOM
                            )
                        WHERE
                            ROWNUM <= 1;

                    INSERT INTO IS_FOUND (
                        P_ID,
                        CARD_CODE
                    )
                        SELECT
                            STR1,
                            STR2
                        FROM
                            DUAL;


                    SELECT
                            LEAGUE_NAME
                    INTO    M_LEAGUE
                    FROM
                            MANAGER M
                        JOIN CLUB_CARD C ON M.CARD_ID = C.MANAGER_ID
                                            AND C.CARD_CODE = STR2;
                    
--Inserisco i dati attivi in <active_data_manager>.
                    INSERT INTO ACTIVE_DATA_MANAGER (
                            M_CARD_CODE,
                            MANAGER_LEAGUE,
                            CONTRACTS
                    )
                            SELECT
                                STR2,
                                M_LEAGUE,
                                7
                            FROM
                                DUAL;

                        P.SILVER_QUANTITY := P.SILVER_QUANTITY - 1;
--Carta di tipo <manager> di rarita' <bronze>.
            ELSIF P.BRONZE_QUANTITY > 0 THEN
                    STR2 := DBMS_RANDOM.STRING('a', 8);
                    INSERT INTO CLUB_CARD (
                        CARD_CODE,
                        MANAGER_ID
                    )
                        SELECT
                            *
                        FROM
                            (
                                SELECT
                                    STR2,
                                    CARD_ID
                                FROM
                                    MANAGER
                                WHERE
                                    RARITY_NAME = 'Bronze'
                                ORDER BY
                                    DBMS_RANDOM.RANDOM
                            )
                        WHERE
                            ROWNUM <= 1;

                    INSERT INTO IS_FOUND (
                        P_ID,
                        CARD_CODE
                    )
                        SELECT
                            STR1,
                            STR2
                        FROM
                            DUAL;
                            
                            
                    SELECT
                            LEAGUE_NAME
                    INTO    M_LEAGUE
                    FROM
                            MANAGER M
                        JOIN CLUB_CARD C ON M.CARD_ID = C.MANAGER_ID
                                            AND C.CARD_CODE = STR2;
                    
--Inserisco i dati attivi in <active_data_manager>.
                    INSERT INTO ACTIVE_DATA_MANAGER (
                            M_CARD_CODE,
                            MANAGER_LEAGUE,
                            CONTRACTS
                    )
                            SELECT
                                STR2,
                                M_LEAGUE,
                                7
                            FROM
                                DUAL;

                        P.BRONZE_QUANTITY := P.BRONZE_QUANTITY - 1;
            ELSE
                DBMS_OUTPUT.PUT_LINE('Error inserimento manager');
            END IF;
            
            END LOOP;
            
        END IF;
--Se il pacchetto che si vuole acquistare non e' disponibile.
    ELSIF P.AVAILABLE = '0' THEN
        DBMS_OUTPUT.PUT_LINE('Il pacchetto selezionato non e'' disponibile!');
--Se viene inserito un nome di un pacchetto inesistente.
    ELSE
        DBMS_OUTPUT.PUT_LINE('Il pacchetto selezionato non esiste!');
    END IF;

    COMMIT;
END IF;

EXCEPTION
WHEN NO_USER_FOUND THEN
    RAISE_APPLICATION_ERROR('-20001', 'L''utente '
                                        || USER
                                        || ' non e'' stato trovato!');
WHEN USER_ERROR THEN
    RAISE_APPLICATION_ERROR('-20003', 'L''utente '
                                        || USR_1
                                        || ' non corrisponde all''utente loggato '
                                        || USER);
END PACK_OPENING;
/