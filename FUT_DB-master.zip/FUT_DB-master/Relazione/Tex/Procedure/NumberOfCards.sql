-- Tabelle interessate: 5
--  -> CLUB_CARD, IS_FOUND, PACK_PURCHASE, CLUB, TRANSACTION;

-- INPUT:
--	-> usr: nome utente;
-- OUTPUT:
--  -> Verifica del volume delle carte che non puo' superare le 1500;
CREATE OR REPLACE PROCEDURE NUMBER_OF_CARDS (
USR CLUB.USER_NICK%TYPE
) IS
N1  NUMBER(4, 0);
N2  NUMBER(4, 0);
MAX_CARDS EXCEPTION;

BEGIN

--Quante carte provengono da pacchetti = N1.
SELECT
   COUNT(*)
INTO N1
FROM
   CLUB_CARD
WHERE
   CARD_CODE IN (
      SELECT
         CARD_CODE
      FROM
         IS_FOUND
      WHERE
         P_ID IN (
            SELECT
               PURCHASE_ID
            FROM
               PACK_PURCHASE
            WHERE
               BUYING_CLUB_NAME IN (
                  SELECT
                     CLUB_NAME
                  FROM
                     CLUB
                  WHERE
                     LOWER(USER_NICK) = LOWER(USR)
               )
         )
   );

--Quante carte ha comprato = N2.
SELECT
   COUNT(*)
INTO N2
FROM
   CLUB_CARD
WHERE
   CARD_CODE IN (
      SELECT
         T_CARD_CODE
      FROM
         TRANSACTION
      WHERE
         TRANSITION_B_CLUB_NAME IN (
            SELECT
               CLUB_NAME
            FROM
               CLUB
            WHERE
               LOWER(USER_NICK) = LOWER(USR)
         )
   );

--Carte totali possedute dal cclub = N1
N1 := N1 + N2;
IF N1 > 1500 THEN
   RAISE MAX_CARDS;
ELSE
   DBMS_OUTPUT.PUT_LINE('Hai collezionato ' || N1 || ' carte, restano altri '
                        ||(1500 - N1)
                        || ' posti disponibili!');
END IF;

EXCEPTION
   WHEN MAX_CARDS THEN
      RAISE_APPLICATION_ERROR('-20005', 'Attenzione! Possiedi '
                                       || N1
                                       || ' cards, hai raggiunto il limite massimo!');
END NUMBER_OF_CARDS;
/