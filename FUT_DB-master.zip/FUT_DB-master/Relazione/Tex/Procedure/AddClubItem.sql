-- Tabelle interessate: 2
--  -> CLUB_CARD, CLUB;

-- Funzioni interessate: 2
--  -> IS_ADMIN, CARD_IN_CLUB;

-- INPUT:
--	-> c_code:  codice carta di tipo <club_item>;
--	-> cc_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
-- OUTPUT:
--  -> Rende attivo il <club_item>.
CREATE OR REPLACE PROCEDURE ADD_CLUB_ITEM (
C_CODE   CLUB_CARD.CARD_CODE%TYPE,
CC_NAME  CLUB.CLUB_NAME%TYPE
) IS

N1      NUMBER(1, 0); 
N2      NUMBER(1, 0); --Controllo su <club_item> di tipo 'Kit' (Firts).
N3      NUMBER(1, 0); --Controllo su <club_item> di tipo 'Kit' (Second).
N4      NUMBER(1, 0); --Controllo su <club_item> di tipo 'Badge'.
N5      NUMBER(1, 0); --Controllo su <club_item> di tipo 'Ball'.
N6      NUMBER(1, 0); --Controllo su <club_item> di tipo 'Stadium'.
A_CODE  CLUB_CARD.CARD_CODE%TYPE; --Codice carta del <club_item> che diventera' attivo.
C_NAME  CLUB.CLUB_NAME%TYPE; --Nome del club effettivo (is_admin).
C_ITEM  CLUB_ITEM.CATEGORY_ITEM%TYPE; --Categoria del club item.
SAME_ITEM EXCEPTION; --Nel caso in cui si prova ad attivare un <club_item> gia' attivo.
INVALID_CATEGORY EXCEPTION; --Nel caso in cui la categoria del <club_item> sia errata.

BEGIN
--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione ADD_CLUB_ITEM;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <cc_name>;
--Altrimenti il nome del club <c_name> sara' quello dell'utente.
--In breve, l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul proprio club.
SELECT IS_ADMIN(CC_NAME, USER)
INTO C_NAME
FROM DUAL;

--La funzione card_in_club, controlla che il club identificato dal nome <c_name> possiede la carta identificata dal <c_code>
-- se n1 != 0 il club possiede la carta, altrimenti no.
SELECT CARD_IN_CLUB(C_CODE, C_NAME)
INTO N1
FROM DUAL;

--Controlla che il <club_item> non sia gia' attivo.
SELECT
    COUNT(ACTIVE_FIRST_KIT_CODE),
    COUNT(ACTIVE_SECOND_KIT_CODE),
    COUNT(ACTIVE_BADGE_CODE),
    COUNT(ACTIVE_BALL_CODE),
    COUNT(ACTIVE_STADIUM_CODE)
INTO N2, N3, N4, N5, N6
FROM
    CLUB
WHERE
    ACTIVE_FIRST_KIT_CODE = C_CODE
    OR ACTIVE_SECOND_KIT_CODE = C_CODE
    OR ACTIVE_BADGE_CODE = C_CODE
    OR ACTIVE_BALL_CODE = C_CODE
    OR ACTIVE_STADIUM_CODE = C_CODE;

SELECT CATEGORY_ITEM
INTO C_ITEM
FROM CLUB_ITEM C
    JOIN CLUB_CARD CC
    ON C.CARD_ID = CC.CLUB_ITEM_ID
    AND CC.CARD_CODE = C_CODE;

--Se <n1 = 0> il club non possiede la carta, oppure e' stato inserito un <c_code> errato.
IF N1 = 0 THEN
    RAISE NO_DATA_FOUND;
ELSIF N2 != 0 OR N3 != 0 OR N4 != 0 OR N5 != 0 OR N6 != 0 THEN
    RAISE SAME_ITEM;
ELSE--Altrimenti controllo la categoria <c_item> del <club_item>.
    IF C_ITEM = 'Kit' THEN
--Controllo che non ci sia un <club_item> gia' attivo.
        SELECT
            COUNT(ACTIVE_FIRST_KIT_CODE),
            COUNT(ACTIVE_SECOND_KIT_CODE)
        INTO N1, N2
        FROM CLUB
        WHERE CLUB_NAME = C_NAME;

--Se il primo kit e' libero, inserisco <c_code> in <active_first_kit_code>.
        IF N1 = 0 THEN
            UPDATE CLUB
            SET
                ACTIVE_FIRST_KIT_CODE = C_CODE
            WHERE
                CLUB_NAME = C_NAME;

            COMMIT;
--Se il secondo kit e' libero, inserisco <c_code> in <active_second_kit_code>.
        ELSIF N2 = 0 THEN
            UPDATE CLUB
            SET
                ACTIVE_SECOND_KIT_CODE = C_CODE
            WHERE
                CLUB_NAME = C_NAME;

            COMMIT;
        END IF;

    ELSIF C_ITEM = 'Ball' THEN
        UPDATE CLUB
        SET
            ACTIVE_BALL_CODE = C_CODE
        WHERE
            CLUB_NAME = C_NAME;

        COMMIT;
    ELSIF C_ITEM = 'Badge' THEN
        UPDATE CLUB
        SET
            ACTIVE_BADGE_CODE = C_CODE
        WHERE
            CLUB_NAME = C_NAME;

        COMMIT;
    ELSIF C_ITEM = 'Stadium' THEN
        UPDATE CLUB
        SET
            ACTIVE_STADIUM_CODE = C_CODE
        WHERE
            CLUB_NAME = C_NAME;

        COMMIT;
    ELSE
        RAISE INVALID_CATEGORY;
    END IF;
END IF;

EXCEPTION
WHEN SAME_ITEM THEN
    RAISE_APPLICATION_ERROR('-20001', 'Il ['
                                        || C_ITEM
                                        || '] e'' gia'' attivo!');
WHEN INVALID_CATEGORY THEN
    RAISE_APPLICATION_ERROR('-20002', 'La ['
                                        || C_ITEM
                                        || '] non e'' valida!');
WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR('-20003', 'La carta non e'' stata trovata!');
END ADD_CLUB_ITEM;