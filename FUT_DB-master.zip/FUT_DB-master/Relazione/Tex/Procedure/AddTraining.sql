-- Tabelle interessate: 4
--  -> CLUB_CARD, IS_PART_OF, ACTIVE_DATA_PLAYER, SQUAD;

-- Funzioni interessate: 2
--  -> IS_ADMIN, CARD_IN_CLUB;

-- INPUT:
--	-> c_code:  codice carta di tipo <consumable> di categoria <training> o <GKTraining>;
--	-> p_code:  codice carta di tipo <player> alla quale applicare il <consumable>;
--  -> s_name:  nome della squadra dove gioca il player;
--	-> cc_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
-- OUTPUT:
--  -> Rende attivo il consumabile <c_code> sul player <p_code>.

CREATE OR REPLACE PROCEDURE ADD_TRAINING (
C_CODE   CLUB_CARD.CARD_CODE%TYPE,
P_CODE   CLUB_CARD.CARD_CODE%TYPE,
S_NAME   SQUAD.NAME%TYPE,
CC_NAME  SQUAD.SQUAD_CLUB_NAME%TYPE
) IS

N1            NUMBER(2, 0); --Controlla che il club possieda il consumabile <c_code> e il player <p_code>.
C_NAME        CLUB.CLUB_NAME%TYPE; --Nome effettivo del club (is_admin).
C_CONSUMABLE  CONSUMABLE.CATEGORY%TYPE; --Categoria del consumabile 'Training' o 'GKTraining'.
P_POSITION    PLAYER.POSITION%TYPE; --Posizione del player.
FLAG          NUMBER(1, 0) := 0; --Se e' uguale ad 1, tutti i controlli sono superati.

--Due casi:
-- 1. Si cerca di utilizzare un consumabile di tipo 'Training' su un player in posizione 'GK' cioe' portiere.
-- 2. Si cerca di utilizzare un consumabile di tipo 'GKTraining' su un player non 'GK' portiere.
TRAINING_ERROR EXCEPTION;
NO_PLAYER_FOUND EXCEPTION;-- il player <p_code> non e' stato trovato.

BEGIN
--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione ADD_TRAINING;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <cc_name>
--Altrimenti il nome del club <c_name> sara' quello dell'utente.
--In breve l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
SELECT
    IS_ADMIN(CC_NAME, USER)
INTO C_NAME
FROM
    DUAL;

--La funzione card_in_club, controlla che il club identificato dal nome <c_name> possieda la carta identificata dal <c_code>
-- se n1 != 0 il club possiede la carta, altrimenti no.
SELECT
    CARD_IN_CLUB(C_CODE, C_NAME)
INTO N1
FROM
    DUAL;

--Se <n1 = 0>, il club non possiede il consumabile <c_code>, oppure e' stato inserito un <c_code> errato.
IF N1 = 0 THEN
    RAISE NO_DATA_FOUND;
END IF;

--Controllo se il club possiede il player <p_code>.
SELECT
    CARD_IN_CLUB(P_CODE, C_NAME)
INTO N1
FROM
    DUAL;

--Se <n1 = 0>, il club non possiede il player <p_code>, oppure e' stato inserito un <p_code> errato.
IF N1 = 0 THEN
    RAISE NO_PLAYER_FOUND;
END IF;

--Seleziono il tipo del consumabile <c_code> in <c_consumable>.
SELECT
    CATEGORY
INTO C_CONSUMABLE
FROM
            CONSUMABLE C
    JOIN CLUB_CARD CC ON C.CARD_ID = CC.CONSUMABLE_ID
                            AND CC.CARD_CODE = C_CODE;

--Seleziono la posizione del player <p_code>.
SELECT
    PLAYER_POSITION
INTO P_POSITION
FROM
    IS_PART_OF
WHERE
    PLAYER_CARD_CODE = P_CODE;

--Se il consumabile <c_code> e di tipo <training> e la posizione del player <p_code> e diversa da 'GK' portiere.
IF
    C_CONSUMABLE = 'Training'
    AND P_POSITION <> 'GK'
THEN
    FLAG := 1; --Posso procedere ad applicare il consumabile <c_code>.
--Se il consumabile <c_code> e di tipo <GKtraining> e la posizione del player <p_code> e uguale a 'GK' portiere.
ELSIF
    C_CONSUMABLE = 'GKTraining'
    AND P_POSITION = 'GK'
THEN
    FLAG := 1; --Posso procedere ad applicare il consumabile <c_code>.
--Altrimenti non posso procedere poiche' il tipo di consumabile non corrisponde alla posizione del player.
ELSE
    FLAG := 0;
    RAISE TRAINING_ERROR;
END IF;

--Se <flag = 1>, posso procedere ad applicare il consumabile <c_code>.
IF FLAG = 1 THEN

--Aggiorno il campo <active_training> del player <p_code>.
    UPDATE ACTIVE_DATA_PLAYER
    SET
        ACTIVE_TRAINING = C_CODE
    WHERE
        P_CARD_CODE = P_CODE;

--Aggiungo un bonus di 2 dato dal training, alla valutazione <player_rating> del player.
    UPDATE IS_PART_OF
    SET
        PLAYER_RATING = PLAYER_RATING + 2
    WHERE
        PLAYER_CARD_CODE = P_CODE;

--Aggiorno la valutazione della squadra, poiche' e appena variata la valutazione di un player.
    UPDATE SQUAD
    SET
        SQUAD_RATING = (
            SELECT
                GET_SQUAD_RATING(S_NAME, C_NAME)
            FROM
                DUAL
        )
    WHERE
            NAME = S_NAME
        AND SQUAD_CLUB_NAME = C_NAME;

--Elimino il consumabile <c_code> utilizzato.
    DELETE FROM CLUB_CARD
    WHERE
        CARD_CODE = C_CODE;

--Confermo
    COMMIT;
END IF;

EXCEPTION
WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR('-20001', 'Il training con codice carta ('
                                        || C_CODE
                                        || ') non e'' stato trovato!');
WHEN NO_PLAYER_FOUND THEN
    RAISE_APPLICATION_ERROR('-20001', 'Il giocatore con codice carta ('
                                        || P_CODE
                                        || ') non e'' stato trovato!');
WHEN TRAINING_ERROR THEN
    RAISE_APPLICATION_ERROR('-20003', 'Il consumabile e'' di tipo ('
                                        || C_CONSUMABLE
                                        || ') la posizione del player e'' ('
                                        || P_POSITION
                                        || ')!');
END ADD_TRAINING;
/