-- Tabelle interessate: 2
--  -> USER_FUT, CLUB;

-- Procedure interessate: 1
--  -> PACK_OPENING;

-- Triggers interessati: 1
--  -> INSERT_USER;

-- INPUT:
--	-> usr_nick: nome utente;
--	-> usr_email: email;
--	-> usr_club_name: il nome del club;
-- OUTPUT:
--  -> Crea il club <usr_club_name> per l'utente identificato dal nome utente <usr_nick>.
CREATE OR REPLACE PROCEDURE CLUB_CREATION (
USR_NICK       USER_FUT.NICKNAME%TYPE,
USR_EMAIL      USER_FUT.EMAIL%TYPE,
USR_CLUB_NAME  CLUB.CLUB_NAME%TYPE
) IS

COUNTER  NUMBER(2, 0); --Contatore usato per eseguire piu' volte la procedura PACK_OPENING.
N1       NUMBER(1, 0); --Controlla se il nome utente scelto e' disponibile.
N2       NUMBER(1, 0); --Controlla se il nome del club scelto e' disponibile.
USER_EXISTING EXCEPTION; --Nel caso in cui il nome utente non e' disponibile.
INVALID_DATA EXCEPTION; --Nel caso in cui ci siano errori sui dati inseriti.

BEGIN
--Controllo se il nome utente <usr_nick> e' disponibile.
SELECT COUNT(NICKNAME)
INTO N1
FROM USER_FUT
WHERE NICKNAME = USR_NICK;
--Controllo se il nome del club <usr_club_name> e' disponibile.
SELECT COUNT(USER_NICK)
INTO N2
FROM CLUB
WHERE USER_NICK = USR_NICK;

--Se il nome utente e il nome del club sono disponibili, creo il nuovo utente.
IF N1 = 0
    AND N2 = 0
THEN
--Inserisco il nuovo utente.
    INSERT INTO USER_FUT
        SELECT
            USR_NICK,
            USR_EMAIL
        FROM
            DUAL;
--Inserisco il club dell'utente <usr_nick>.
    INSERT INTO CLUB (
        CLUB_NAME,
        USER_NICK,
        CREDITS,
        DIVISION_NUMBER
    )
        SELECT
            USR_CLUB_NAME,
            USR_NICK,
            3750,
            10
        FROM
            DUAL;
--Nel caso in cui o il nome ustente o il nome del club non siano disponibili.
ELSIF N1 > 0 OR N2 > 0 THEN
    RAISE USER_EXISTING;
ELSE
    RAISE INVALID_DATA;
END IF;

--Quando si crea un club ci sono 3 pacchetti <pack> in omaggio.
FOR COUNTER IN 1..3 LOOP
    PACK_OPENING('Bronze Player Pack', USR_NICK);
END LOOP;

COMMIT;
EXCEPTION
WHEN USER_EXISTING THEN
    RAISE_APPLICATION_ERROR('-20003', 'Il nome utente '
                                        || USR_NICK
                                        || ' non e'' disponibile!');
WHEN INVALID_DATA THEN
    RAISE_APPLICATION_ERROR('-20004', 'Invalid data error');
END CLUB_CREATION;