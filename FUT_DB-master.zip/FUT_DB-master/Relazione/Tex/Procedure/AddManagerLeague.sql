-- Tabelle interessate: 3
--  -> CLUB_CARD, ACTIVE_DATA_MANAGER, CONSUMABLE;

-- Funzioni interessate: 2
--  -> IS_ADMIN, CARD_ID_CLUB;

-- INPUT:
--  -> c_code: codice carta di tipo <consumable> di categoria <manager league>.
--	-> m_code: codice carta di tipo manager.
--	-> cc_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
-- OUTPUT:
--  -> Cambia la lega del manager con quella specificata dal consumabile.
CREATE OR REPLACE PROCEDURE ADD_MANAGER_LEAGUE (
C_CODE   CLUB_CARD.CARD_CODE%TYPE,
M_CODE   CLUB_CARD.CARD_CODE%TYPE,
CC_NAME  CLUB.CLUB_NAME%TYPE
) IS

N1        NUMBER(2, 0); 
M_LEAGUE  MANAGER.LEAGUE_NAME%TYPE; --La lega del manager indicata dal consumabile.
C_NAME    CLUB.CLUB_NAME%TYPE; --Il nome del club effettivo (is_admin).

NO_CONSUMABLE_FOUND EXCEPTION; --Se il consumabile <c_code> non e' stato trovato.
NO_MANAGER_FOUND EXCEPTION; --Se la squadra non ha manager <m_code> attivo.

BEGIN
--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione ADD_MANAGER_LEAGUE;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <cc_name>
--Altrimenti il nome del club <c_name> sara' quello dell'utente.
--In breve l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
SELECT IS_ADMIN(CC_NAME, USER)
INTO C_NAME
FROM DUAL;

--La funzione card_in_club, controlla che il club identificato dal nome <c_name> possieda la carta identificata dal <c_code>
-- se n1 != 0 il club possiede la carta, altrimenti no.
SELECT CARD_IN_CLUB(C_CODE, C_NAME)
INTO N1
FROM DUAL;

-- Se <n1 = 0>, il club non possiede il consumabile, oppure e' stato inserito un codice carta <c_code> errato.
IF N1 = 0 THEN
    RAISE NO_CONSUMABLE_FOUND;
END IF;
SELECT CARD_IN_CLUB(M_CODE, C_NAME)
INTO N1
FROM DUAL;

-- Se <n1 = 0>, il club non ha un manager attivo, oppure e' stato inserito un codice carta <m_code> errato.
IF N1 = 0 THEN
    RAISE NO_MANAGER_FOUND;
END IF;

--Seleziono la lega del consumabile <c_code> in <m_league>.
SELECT
    TYPE
INTO M_LEAGUE
FROM CONSUMABLE
WHERE CARD_ID IN (
        SELECT CONSUMABLE_ID
        FROM CLUB_CARD
        WHERE CARD_CODE = C_CODE
    );

-- Aggiorno il valore <manager_league> uguale alla nuova lega <m_league>.
UPDATE ACTIVE_DATA_MANAGER
SET MANAGER_LEAGUE = M_LEAGUE
WHERE M_CARD_CODE = M_CODE;

-- Cancello il consumabile <c_code> appena utilizzato.
DELETE FROM CLUB_CARD
WHERE CARD_CODE = C_CODE;
COMMIT;

EXCEPTION
WHEN NO_CONSUMABLE_FOUND THEN
    RAISE_APPLICATION_ERROR('-20001', 'Il consumabile ('
                                        || C_CODE
                                        || ') non e'' stato trovato!');
WHEN NO_MANAGER_FOUND THEN
    RAISE_APPLICATION_ERROR('-20001', 'Il manager con codice carta ('
                                        || M_CODE
                                        || ') non e'' stato trovato');
END ADD_MANAGER_LEAGUE;