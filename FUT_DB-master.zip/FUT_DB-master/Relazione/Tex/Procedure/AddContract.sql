-- Tabelle interessate: 2
--  -> CLUB_CARD, ACTIVE_DATA_PLAYER;

-- Funzioni interessate: 3
--  -> IS_ADMIN, CARD_IN_CLUB, GET_CONTRACT;

-- INPUT:
--	-> c_code: codice carta di tipo <consumable> di categoria <contract>;
--	-> p_card_code: codice carta di tipo <player>;
--	-> cc_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
-- OUTPUT:
--  -> Applica il consumabile al player.

CREATE OR REPLACE PROCEDURE ADD_CONTRACT (
C_CODE       CLUB_CARD.CARD_CODE%TYPE,
P_CARD_CODE  CLUB_CARD.CARD_CODE%TYPE,
CC_NAME      CLUB.CLUB_NAME%TYPE
) IS

S_NAME  SQUAD.NAME%TYPE; --Nome delle squadra dov'e' schierato il player <p_card_code>.
C_NAME  SQUAD.SQUAD_CLUB_NAME%TYPE; --Nome del club che possiede la squadra <s_name>.
RESULT  NUMBER(2, 0); --Conterra' il nuovo valore di <contracts> dopo aver applicato il consumabile.
N1      NUMBER(2, 0);

BEGIN
--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione ADD_CONTRACT;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <cc_name>;
--Altrimenti il nome del club <c_name> sara' quello dell'utente.
--In breve, l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul proprio club.
SELECT
    IS_ADMIN(CC_NAME, USER)
INTO C_NAME
FROM
    DUAL;

--La funzione card_in_club, controlla che il club identificato dal nome <c_name> possieda la carta identificata dal <c_code>
-- se n1 != 0 il club possiede la carta, altrimenti no.
SELECT
    CARD_IN_CLUB(C_CODE, C_NAME)
INTO N1
FROM
    DUAL;

-- Se n1 e' ancora uguale a 0 il club non possiede la carta <c_code>, o e' stato inserito un <c_code> errato.
IF N1 = 0 THEN
    RAISE NO_DATA_FOUND;
ELSE
-- Altrimenti il club possiede la carta; Calcolo il nuovo valore di <contracts> con la funzione GET_CONTRACT
-- la quale prende in input il codice carta <c_code> del consumabile, il codice carta <p_card_code> del player 
-- e il tipo del consumabile, quest'ultimo puo' essere 'Player' o 'Manager'.
-- La funzione restituisce in <result> il nuovo valore di <contracts> calcolato dopo aver applicato il consumabile
-- e considerando che il player/manager non puo' superare i 99 contratti.
    SELECT
        GET_CONTRACT(C_CODE, P_CARD_CODE, 'Player')
    INTO RESULT
    FROM
        DUAL;

-- Aggiorno i contratti <contracts> del player.
    UPDATE ACTIVE_DATA_PLAYER
    SET
        CONTRACTS = RESULT
    WHERE
        P_CARD_CODE = P_CARD_CODE;

-- Cancello il consumabile <c_code> appena utilizzato.
    DELETE FROM CLUB_CARD
    WHERE
        CARD_CODE = C_CODE;

--Confermo
    COMMIT;
END IF;

EXCEPTION
WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR('-20001', 'La carta con card_code ('
                                        || C_CODE
                                        || ') non e''  stata trovata!');
END ADD_CONTRACT;
/