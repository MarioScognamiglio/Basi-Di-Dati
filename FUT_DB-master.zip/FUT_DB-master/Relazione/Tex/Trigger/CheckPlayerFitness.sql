-- Trigger CHECK_PLAYER_FITNESS

-- Tabelle interessate: 4
--  -> CLUB_CARD, PLAYER, IS_PART_OF, ACTIVE_DATA_PLAYER;
-- Scopo:
--  -> Controlla la forma fisica dei player di una squadra che sta per disputare un match,
--      se e' minore di 10, notifica all'utente i player stanchi.
CREATE OR REPLACE TRIGGER CHECK_PLAYER_FITNESS BEFORE
INSERT OR UPDATE ON MATCH
FOR EACH ROW
DECLARE
--Contatori di controllo.
N1             NUMBER(2, 0);
N2             NUMBER(2, 0);
FLAG           NUMBER(1, 0) := 0;
P_CARD_CODE    CLUB_CARD.CARD_CODE%TYPE; --Codice carta.
P_NAME         PLAYER.PLAYER_NAME%TYPE; --Nome del player.
TYPE ARRAY_CC_T IS VARRAY(18) OF VARCHAR2(8);
ARR_CARD_CODE  ARRAY_CC_T; --Array codici carta.

BEGIN
--Quando si sta inserendo un nuovo match, cioe' un squdra si mette in attesa di un avversario per disputare il match.
IF INSERTING THEN
--Quanti player sono stanchi della squadra, che e' in attesa, in casa.
    SELECT
        COUNT(*)
    INTO N1
    FROM IS_PART_OF I
        JOIN ACTIVE_DATA_PLAYER A 
            ON I.PLAYER_CARD_CODE = A.P_CARD_CODE
                AND I.SQUAD_NAME = :NEW.HOME_SQUAD_NAME
                AND :NEW.VISITORS_SQUAD_NAME IS NULL
                AND A.PLAYER_FITNESS < 10;
--Se <n1 = 0>, o non ci sono player stanchi, oppure non c'e' una squadra in attesa in casa, controllo la squadra fuori casa.
    IF N1 = 0 THEN
--Quanti player sono stanchi della squadra, che e' in attesa, fuori casa.
        SELECT
            COUNT(*)
        INTO N2
        FROM IS_PART_OF I
            JOIN ACTIVE_DATA_PLAYER A 
                ON I.PLAYER_CARD_CODE = A.P_CARD_CODE
                    AND I.SQUAD_NAME = :NEW.VISITORS_SQUAD_NAME
                    AND :NEW.HOME_SQUAD_NAME IS NULL
                    AND A.PLAYER_FITNESS < 10;
    END IF;
--Se <n2 = 0>, non ci sono player stanchi e il trigger termina.
    IF N2 = 0 THEN
        RETURN;
    ELSE
--Se <n1 != 0>, ci sono player stanchi della squadra in casa.
        IF N1 <> 0 THEN
--Seleziono i codici carta dei player.
            SELECT
                PLAYER_CARD_CODE
            BULK COLLECT
            INTO ARR_CARD_CODE
            FROM IS_PART_OF I
                JOIN ACTIVE_DATA_PLAYER A 
                    ON I.PLAYER_CARD_CODE = A.P_CARD_CODE
                        AND I.SQUAD_NAME = :NEW.HOME_SQUAD_NAME
                        AND A.PLAYER_FITNESS < 10;
--Ci sono player stanchi nella squadra fuori casa <n2 != 0>.
--Ricordo che siamo in 'INSERTING' significa che c'e' una sola squadra (in casa o fuori casa) in attesa del avversario.
        ELSIF
            N1 = 0
            AND N2 <> 0
        THEN
            SELECT
                PLAYER_CARD_CODE
            BULK COLLECT
            INTO ARR_CARD_CODE
            FROM IS_PART_OF I
                JOIN ACTIVE_DATA_PLAYER A 
                    ON I.PLAYER_CARD_CODE = A.P_CARD_CODE
                        AND I.SQUAD_NAME = :NEW.VISITORS_SQUAD_NAME
                        AND A.PLAYER_FITNESS < 10;
        END IF;

--Notifico al utente quali player sono stanchi con relativo codice carta, in modo da facilitare l'eventuale attivazione di una carta di tipo consumabile.
        DBMS_OUTPUT.PUT_LINE('ATTENZIONE! I seguenti player hanno forma fisica al minimo!' || CHR(10));
        FOR I IN 1..ARR_CARD_CODE.COUNT LOOP
            SELECT PLAYER_NAME
            INTO P_NAME
            FROM PLAYER
            WHERE CARD_ID IN (
                    SELECT PLAYER_ID
                    FROM CLUB_CARD
                    WHERE CARD_CODE = ARR_CARD_CODE(I)
                );

            DBMS_OUTPUT.PUT_LINE('['
                                    || I
                                    || '] '
                                    || P_NAME
                                    || ' ('
                                    || ARR_CARD_CODE(I)
                                    || ')'
                                    || CHR(10));

        END LOOP;
    END IF;
--Se stiamo aggiornando un match 'UPDATING', ci troviamo dalla parte dell'avversario.
ELSIF UPDATING THEN
--Se prima la squadra in casa era NULL, significa che l'ultima squadra inserita giochera' in casa.
    IF :OLD.HOME_SQUAD_NAME IS NULL THEN
--Verifico quanti player sono stanchi della squadra in casa.
        SELECT
            COUNT(*)
        INTO N1
        FROM IS_PART_OF I
            JOIN ACTIVE_DATA_PLAYER A 
                ON I.PLAYER_CARD_CODE = A.P_CARD_CODE
                    AND I.SQUAD_NAME = :NEW.HOME_SQUAD_NAME
                    AND A.PLAYER_FITNESS < 10;

--Se <n1 = 0>, non ci sono player stanchi.
        IF N1 = 0 THEN
            RETURN;
        ELSE
--Seleziono i codici carta dei player della squadra.
            SELECT
                PLAYER_CARD_CODE
            BULK COLLECT
            INTO ARR_CARD_CODE
            FROM IS_PART_OF I
                JOIN ACTIVE_DATA_PLAYER A 
                    ON I.PLAYER_CARD_CODE = A.P_CARD_CODE
                        AND I.SQUAD_NAME = :NEW.HOME_SQUAD_NAME
                        AND A.PLAYER_FITNESS < 10;
            FLAG := 1; --Notifica al utente i player stanchi.
        END IF;

    ELSIF :OLD.VISITORS_SQUAD_NAME IS NULL THEN
--Quanti player sono stanchi nella squadra fuori casa.
        SELECT
            COUNT(*)
        INTO N1
        FROM IS_PART_OF I
            JOIN ACTIVE_DATA_PLAYER A 
                ON I.PLAYER_CARD_CODE = A.P_CARD_CODE
                    AND I.SQUAD_NAME = :NEW.VISITORS_SQUAD_NAME
                    AND A.PLAYER_FITNESS < 10;

--Se <n1 = 0>, non ci sono player stanchi.
        IF N1 = 0 THEN
            RETURN;
        ELSE
--Seleziono i codici carta dei player stanchi.
            SELECT
                PLAYER_CARD_CODE
            BULK COLLECT
            INTO ARR_CARD_CODE
            FROM IS_PART_OF I
                JOIN ACTIVE_DATA_PLAYER A 
                    ON I.PLAYER_CARD_CODE = A.P_CARD_CODE
                        AND I.SQUAD_NAME = :NEW.VISITORS_SQUAD_NAME
                        AND A.PLAYER_FITNESS < 10;

            FLAG := 1; --Notifica al utente i player stanchi.

        END IF;

    END IF;

    IF FLAG = 1 THEN
--Notifico all'utente i player che sono stanchi con relativo codice carta.
        DBMS_OUTPUT.PUT_LINE('ATTENZIONE! I seguenti player hanno forma fisica al minimo!' || CHR(10));
        FOR I IN 1..ARR_CARD_CODE.COUNT LOOP
            SELECT
                PLAYER_NAME
            INTO P_NAME
            FROM PLAYER
            WHERE CARD_ID IN (
                    SELECT PLAYER_ID
                    FROM CLUB_CARD
                    WHERE CARD_CODE = ARR_CARD_CODE(I)
                );
            DBMS_OUTPUT.PUT_LINE('['
                                    || I
                                    || '] '
                                    || P_NAME
                                    || ' ('
                                    || ARR_CARD_CODE(I)
                                    || ')'
                                    || CHR(10));
        END LOOP;
    END IF;
END IF;
END CHECK_PLAYER_FITNESS;
/