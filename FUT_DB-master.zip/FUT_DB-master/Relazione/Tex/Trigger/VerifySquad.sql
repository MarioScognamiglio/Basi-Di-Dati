-- Tabelle interessate: 6
--  -> CLUB_CARD, SQUAD, IS_PART_OF, STOPS, PLAYER, ACTIVE_DATA_PLAYER;

-- Scopo:
--  -> Verifica che i player della squadra che vuole disputare un match, abbiano almeno un contratto, 
--      e che non ci siano player titolari infortunati, in caso affermativo la squadra non puo' disputare il match. 
--     Inoltre notifica all'utente se ha player non titolari infortunati, in questo caso puo' comunque disputare il match.
CREATE OR REPLACE TRIGGER VERIFY_SQUAD BEFORE
INSERT OR UPDATE ON MATCH
FOR EACH ROW

DECLARE
C_NAME         SQUAD.SQUAD_CLUB_NAME%TYPE; --Nome del club.
S_NAME         SQUAD.NAME%TYPE; --Nome della squadra.
N1             NUMBER(5, 0);
N2             NUMBER(2, 0);
N3             NUMBER(2, 0);
N4             NUMBER(2, 0);
P_NAME         PLAYER.PLAYER_NAME%TYPE; --Nome del player.
B_PART         STOPS.BODY_PART%TYPE; --Parte del corpo infortunata.
TYPE ARRAY_CC_T IS VARRAY(18) OF VARCHAR2(8);
ARR_CARD_CODE  ARRAY_CC_T; --Array dei codici carta dei player della squadra.
VERIFY_SQUAD EXCEPTION; --Se la squadra non rispetta i requisiti per disputare il match.
OLD_MATCH EXCEPTION; --Ritorna senza fare nulla.

BEGIN
--Se si sta inserendo un nuovo match, una delle due squadre e' NULL, poiche' si
-- sta inserendo in attesa dell'avversario.
IF INSERTING THEN         
--Controllo se la squadra da verificare e' quella in casa <home_squad_name>.
SELECT
    COUNT(SQUAD_CLUB_NAME)
INTO N1
FROM
    SQUAD
WHERE
        NAME = :NEW.HOME_SQUAD_NAME
    AND :NEW.VISITORS_SQUAD_NAME IS NULL;




--Se <n1 = 0>, non e' la squadra in casa, controllo quella fuori casa.
IF N1 = 0 THEN
    
    SELECT
        COUNT(SQUAD_CLUB_NAME)
    INTO N1
    FROM
        SQUAD
    WHERE
            NAME = :NEW.VISITORS_SQUAD_NAME
        AND :NEW.HOME_SQUAD_NAME IS NULL;

--Se <n1 = 0>, genero un'eccezione poiche' non ho trovato la squadra.
    IF N1 = 0 THEN
        RAISE NO_DATA_FOUND;
    END IF;

    --Seleziono nome <s_name>, e nome del club <c_name> della squadra fuori casa.
    S_NAME:=:NEW.VISITORS_SQUAD_NAME;
    SELECT SQUAD_CLUB_NAME INTO C_NAME
    FROM SQUAD WHERE NAME = S_NAME;
--Se <n1 != 0>, la squadra da verificare e' quella in casa.
ELSIF N1 <> 0 THEN
    S_NAME:=:NEW.HOME_SQUAD_NAME;
    SELECT SQUAD_CLUB_NAME INTO C_NAME
    FROM SQUAD WHERE NAME = S_NAME;
END IF;

--Controllo quanti player titolari sono senza contratti = N1.
SELECT
    COUNT(*)
INTO N1
FROM IS_PART_OF I
    JOIN ACTIVE_DATA_PLAYER A 
        ON I.PLAYER_CARD_CODE = A.P_CARD_CODE
            AND I.SQUAD_NAME = S_NAME
            AND I.HOLDER = '1'
            AND A.CONTRACTS < 1;    

--Contorllo quanti player titolari sono infortunati = N2.
SELECT
    COUNT(P_CARD_CODE)
INTO N2
FROM STOPS S
    JOIN IS_PART_OF I 
        ON S.P_CARD_CODE = I.PLAYER_CARD_CODE
            AND I.SQUAD_NAME = S_NAME
            AND I.HOLDER = '1';




--Controllo quanti player NON titolari sono infortunati = N3.
SELECT
    COUNT(P_CARD_CODE)
INTO N3
FROM STOPS S
    JOIN IS_PART_OF I 
        ON S.P_CARD_CODE = I.PLAYER_CARD_CODE
            AND I.SQUAD_NAME = S_NAME
            AND I.HOLDER = '0';

    --Controllo i contratti del manager.
SELECT
        COUNT(*)
INTO N4
FROM
    MANAGES M
    JOIN ACTIVE_DATA_MANAGER MM
        ON M.MANAGER_CARD_CODE = MM.M_CARD_CODE
            AND M.SQUAD_NAME = S_NAME
            AND MM.CONTRACTS < 1;

--Se uno dei contatori di controllo e' maggiore di 0 genero la verifica della squadra.
IF N1 > 0 OR N2 > 0 OR N3 > 0 OR N4 > 0 THEN
    RAISE VERIFY_SQUAD;
ELSE
    RETURN;
END IF;
--Se stiamo aggiornando una tupla in match, va analizzata solo l'ultima squadra inserita;
-- poiche' la squadra che aspettava l'avversario e' stata gia' analizzata quando e' stata inserita.
ELSIF UPDATING THEN
--Mi assicuro di analizzare solo l'ultimo match.
SELECT
    MAX(MATCH_ID)
INTO N1
FROM
    TMP_MATCH;

--Se il match corrente e' l'ultimo.
IF N1 = :OLD.MATCH_ID THEN

    --Controllo se l'ultima squadra inserita e' quella in casa.
    SELECT
        COUNT(SQUAD_CLUB_NAME)
    INTO N1
    FROM
        SQUAD
    WHERE
            NAME = :NEW.HOME_SQUAD_NAME
        AND :OLD.HOME_SQUAD_NAME IS NULL;

    --Se non e' quella in casa, controllo quella fuori casa.
    IF N1 = 0 THEN
        SELECT
            COUNT(SQUAD_CLUB_NAME)
        INTO N1
        FROM
            SQUAD
        WHERE
                NAME = :NEW.VISITORS_SQUAD_NAME
            AND :OLD.VISITORS_SQUAD_NAME IS NULL;

        --E' una partita vecchia, genero un eccezione.
        IF N1 = 0 THEN
            RAISE OLD_MATCH;
        END IF;

    --Seleziono nome <s_name>, e nome del club <c_name> della squadra fuori casa.
        SELECT
            SQUAD_CLUB_NAME,
            NAME
        INTO
            C_NAME,
            S_NAME
        FROM
            SQUAD
        WHERE
            NAME = :NEW.VISITORS_SQUAD_NAME;

    ELSIF N1 <> 0 THEN
    --Seleziono nome <s_name>, e nome del club <c_name> della squadra in casa.
        SELECT
            SQUAD_CLUB_NAME,
            NAME
        INTO
            C_NAME,
            S_NAME
        FROM SQUAD
        WHERE
            NAME = :NEW.HOME_SQUAD_NAME;
    END IF;
    
    --Quanti player titolari sono senza contratti = N1.
    SELECT
        COUNT(*)
    INTO N1
    FROM IS_PART_OF I
        JOIN ACTIVE_DATA_PLAYER A 
            ON I.PLAYER_CARD_CODE = A.P_CARD_CODE
                AND I.SQUAD_NAME = S_NAME
                AND I.HOLDER = '1'
                AND A.CONTRACTS < 1;    

    --Quanti player titolari sono infortunati = N2.
    SELECT
        COUNT(*)
    INTO N2
    FROM
        IS_PART_OF
    WHERE
            SQUAD_NAME = S_NAME
        AND HOLDER = '1'
        AND PLAYER_CARD_CODE IN (
            SELECT P_CARD_CODE
            FROM STOPS );

    --Quanti player NON titolari sono infortunati = N3;
    SELECT
        COUNT(*)
    INTO N3
    FROM
        IS_PART_OF
    WHERE
            SQUAD_NAME = S_NAME
        AND HOLDER = '0'
        AND PLAYER_CARD_CODE IN (
            SELECT
                P_CARD_CODE
            FROM
                STOPS
        );

    --Controllo i contratti del manager.
    SELECT
        COUNT(*)
    INTO N4
    FROM
        MANAGES M
        JOIN ACTIVE_DATA_MANAGER MM
            ON M.MANAGER_CARD_CODE = MM.M_CARD_CODE
                AND M.SQUAD_NAME = S_NAME
                AND MM.CONTRACTS < 1;

--Se uno dei contatori di controllo e' maggiore di 0 genero la verifica della squadra.
    IF N1 > 0 OR N2 > 0 OR N3 > 0 OR N4 > 0 THEN
        RAISE VERIFY_SQUAD;
    ELSE
        RETURN;
    END IF;

ELSE
    RETURN;
END IF;

END IF;
EXCEPTION
    WHEN OLD_MATCH THEN
        RETURN;
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR('-20001', 'No squad found!');
    WHEN VERIFY_SQUAD THEN
    --Se <n1 > 0> la squadra ha <n1> player titolari senza contratti.
    --Se <n2 > 0> la squadra ha <n2> player titolari infortunati.
    IF N1 > 0 OR N2 > 0 THEN

        IF N1 > 0 THEN

             --Se <n4 > 0>, c'e' il manager della squadra senza contratti.
            IF N4 > 0 THEN
                --Seleziono il codice carta e il nome del manager.
                SELECT MANAGER_CARD_CODE,F_NAME
                INTO M_CODE, M_NAME
                FROM MANAGER M
                JOIN CLUB_CARD C
                ON M.CARD_ID = C.MANAGER_ID
                JOIN MANAGES MM
                ON C.CARD_CODE = MM.MANAGER_CARD_CODE
                AND MM.SQUAD_NAME = S_NAME;

                DBMS_OUTPUT.PUT_LINE('Manager ' || m_name || ' (' || m_code || ')');
            END IF;

            DBMS_OUTPUT.PUT_LINE('ATTENZIONE! Contratti esauriti!');
            
            --Seleziono i codici carta dei player titolari senza contratti.
            SELECT
                PLAYER_CARD_CODE
            BULK COLLECT
            INTO ARR_CARD_CODE
            FROM IS_PART_OF I
                JOIN ACTIVE_DATA_PLAYER A 
                    ON I.PLAYER_CARD_CODE = A.P_CARD_CODE
                        AND I.SQUAD_NAME = S_NAME
                        AND I.HOLDER = '1'
                        AND A.CONTRACTS < 1;

            FOR I IN 1..ARR_CARD_CODE.COUNT LOOP
                SELECT
                    PLAYER_NAME
                INTO P_NAME
                FROM
                    PLAYER
                WHERE
                    CARD_ID IN (
                        SELECT
                            PLAYER_ID
                        FROM
                            CLUB_CARD
                        WHERE
                            CARD_CODE = ARR_CARD_CODE(I)
                    );

                DBMS_OUTPUT.PUT_LINE('[' || I || '] ' || P_NAME || ' (' || ARR_CARD_CODE(I) || ')' || CHR(10));

            END LOOP;
        END IF;
    --Se <n2 > 0> la squadra ha <n2> player titolari infortunati.
        IF N2 > 0 THEN
            DBMS_OUTPUT.PUT_LINE('ATTENZIONE! Giocatori titolari infortunati!');            
            --Seleziono i codici carta dei player titolari infortunati.
            SELECT
                P_CARD_CODE
            BULK COLLECT
            INTO ARR_CARD_CODE
            FROM
                        STOPS S
                JOIN IS_PART_OF I ON S.P_CARD_CODE = I.PLAYER_CARD_CODE
                                        AND I.SQUAD_NAME = S_NAME
                                        AND I.HOLDER = '1';

            FOR I IN 1..N2 LOOP
                SELECT
                    BODY_PART
                INTO B_PART
                FROM
                    STOPS
                WHERE
                    P_CARD_CODE = ARR_CARD_CODE(I);

                SELECT
                    PLAYER_NAME
                INTO P_NAME
                FROM
                    PLAYER
                WHERE
                    CARD_ID IN (
                        SELECT
                            PLAYER_ID
                        FROM
                            CLUB_CARD
                        WHERE
                            CARD_CODE = ARR_CARD_CODE(I)
                    );

                DBMS_OUTPUT.PUT_LINE('[' || I || '] ' || P_NAME || ' (' || ARR_CARD_CODE(I) || ') - (' || B_PART || ')' || CHR(10));

            END LOOP;
        END IF;
        RAISE_APPLICATION_ERROR('-20008', '>>>>>>>>La partita non puo'' essere disputata!<<<<<<<<');

    --Se <n3 > 0>, la squadra ha player NON titolari infortunati, vengono comunicati i dettagli dai player all'utente che puo'
    -- comunque disputare il match.
    ELSIF N3 > 0 THEN
        DBMS_OUTPUT.PUT_LINE('ATTENZIONE! Giocatori infortunati!');
        
        --Seleziono i codici carta dei player non titolari infortunati.
        SELECT
            P_CARD_CODE
        BULK COLLECT
        INTO ARR_CARD_CODE
        FROM STOPS S
            JOIN IS_PART_OF I
                ON S.P_CARD_CODE = I.PLAYER_CARD_CODE
                    AND I.SQUAD_NAME = S_NAME
                    AND I.HOLDER = '0';

        FOR I IN 1..N3 LOOP
            SELECT
                BODY_PART
            INTO B_PART
            FROM
                STOPS
            WHERE
                P_CARD_CODE = ARR_CARD_CODE(I);

            SELECT
                PLAYER_NAME
            INTO P_NAME
            FROM
                PLAYER
            WHERE
                CARD_ID IN (
                    SELECT
                        PLAYER_ID
                    FROM
                        CLUB_CARD
                    WHERE
                        CARD_CODE = ARR_CARD_CODE(I)
                );

            DBMS_OUTPUT.PUT_LINE('[' || I || '] ' || P_NAME || ' (' || ARR_CARD_CODE(I) || ') - (' || B_PART || ')' || CHR(10));

        END LOOP;
    END IF;
END VERIFY_SQUAD;
/