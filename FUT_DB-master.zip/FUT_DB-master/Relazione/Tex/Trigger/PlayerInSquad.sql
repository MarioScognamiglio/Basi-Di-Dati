-- Tabelle interessate: 1
--  -> IS_PART_OF;

-- Scopo:
--  -> gestisce il caso in cui venga messo in vendita un player che e' schierato in una squadra
--      in questo caso il player verra' rimosso dalla squadra prima di essere messo in vendita.
CREATE OR REPLACE TRIGGER PLAYER_IN_SQUAD BEFORE
INSERT OR UPDATE ON TRANSACTION
FOR EACH ROW

DECLARE
N1 NUMBER(1, 0);
PLAYER_HOLDER EXCEPTION;

BEGIN

SELECT
    COUNT(PLAYER_CARD_CODE)
INTO N1
FROM
    IS_PART_OF
WHERE
    PLAYER_CARD_CODE = :NEW.T_CARD_CODE;

--Se il player che si sta provando a vendere e schierato in una squadra.
IF N1 != 0 THEN
    RAISE PLAYER_HOLDER;
END IF;
EXCEPTION
WHEN PLAYER_HOLDER THEN
--Cancello il player dalla squadra.
    DELETE FROM IS_PART_OF
    WHERE
        PLAYER_CARD_CODE = :NEW.T_CARD_CODE;

END PLAYER_IN_SQUAD;
/