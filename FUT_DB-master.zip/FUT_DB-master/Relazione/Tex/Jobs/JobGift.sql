--Scopo: Ogni giovedi alle 9:00 distribuisce i premi in base alla divisione in cui si trova un club
--              con l'ausilio della procedura GIFT.
BEGIN
DBMS_SCHEDULER.CREATE_JOB (
        job_name => 'job_gift',
        job_type => 'STORED_PROCEDURE',
        job_action => 'GIFT', --Esegue la procedura GIFT.
        start_date => trunc(sysdate),
        repeat_interval => 'FREQ=WEEKLY;BYDAY=THU;BYHOUR=9;', --Ogni giovedi alle 9:00 AM.
        enabled => TRUE ,
        comments => 'Regali in base alla divisione!');
END;
/