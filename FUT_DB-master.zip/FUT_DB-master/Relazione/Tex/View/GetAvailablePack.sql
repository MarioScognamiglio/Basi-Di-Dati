-- Tabelle interessate: 1
    -> PACK;
-- OUTPUT:
--  -> Dettagli dei pacchetti con relativo prezzo, disponibili per l'acquisto.
CREATE OR REPLACE VIEW GET_AVAILABLE_PACKS AS
( SELECT
    PACK_NAME,
    PRICE
FROM
    PACK
WHERE
    AVAILABLE = '1'
);