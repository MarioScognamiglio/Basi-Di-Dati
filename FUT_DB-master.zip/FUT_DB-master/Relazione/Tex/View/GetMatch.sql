-- Tabelle interessate: 3
--  -> MATCH, SQUAD, CLUB;
-- OUTPUT:
--  -> Cronologia delle partite giocate dal club dell'utente.
CREATE OR REPLACE VIEW GET_MATCH AS
( SELECT
    M_DATE,
    HOME_SQUAD_NAME,
    VISITORS_SQUAD_NAME,
    RESULTS,
    HOME_POINTS   AS POINTS,
    HOME_CREDITS  AS CREDITS
FROM
            MATCH M
    JOIN SQUAD S ON M.HOME_SQUAD_NAME = S.NAME
                    AND S.SQUAD_CLUB_NAME IN (
        SELECT
            CLUB_NAME
        FROM
            CLUB
        WHERE
            LOWER(USER_NICK) = LOWER(USER)
    )
UNION
SELECT
    M_DATE,
    HOME_SQUAD_NAME,
    VISITORS_SQUAD_NAME,
    RESULTS,
    VISITORS_POINTS,
    VISITORS_CREDITS
FROM
            MATCH M
    JOIN SQUAD S ON M.VISITORS_SQUAD_NAME = S.NAME
                    AND S.SQUAD_CLUB_NAME IN (
        SELECT
            CLUB_NAME
        FROM
            CLUB
        WHERE
            LOWER(USER_NICK) = LOWER(USER)
    )
);