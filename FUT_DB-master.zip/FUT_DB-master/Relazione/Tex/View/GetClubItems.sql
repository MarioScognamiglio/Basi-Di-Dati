-- Tabelle interessate: 5
--  -> CLUB_ITEM, CLUB_CARD, IS_FOUND, PACK_PURCHASE, TRANSACTION;
-- OUTPUT:
--  -> Dettagli dei club_item posseduti dal club dell'utente.
CREATE OR REPLACE VIEW GET_CLUB_ITEMS AS
( SELECT
    CARD_CODE,
    CARD_ID,
    CATEGORY_ITEM,
    TEAM_NAME,
    RARITY_NAME,
    MIN_PRICE,
    MAX_PRICE
FROM
            CLUB_ITEM C
    JOIN CLUB_CARD CC ON C.CARD_ID = CC.CLUB_ITEM_ID
                            AND CC.CARD_CODE IN (
        SELECT
            CARD_CODE
        FROM IS_FOUND
        WHERE P_ID IN (
                SELECT PURCHASE_ID
                FROM PACK_PURCHASE
                WHERE BUYING_CLUB_NAME IN (
                        SELECT CLUB_NAME
                        FROM CLUB
                        WHERE LOWER(USER_NICK) = LOWER(USER))))
UNION
SELECT
    CARD_CODE,
    CARD_ID,
    CATEGORY_ITEM,
    TEAM_NAME,
    RARITY_NAME,
    MIN_PRICE,
    MAX_PRICE
FROM
            CLUB_ITEM C
    JOIN CLUB_CARD CC ON C.CARD_ID = CC.CLUB_ITEM_ID
                            AND CC.CARD_CODE IN (
        SELECT
            T_CARD_CODE
        FROM TRANSACTION
        WHERE TRANSITION_B_CLUB_NAME IN (
                SELECT CLUB_NAME
                FROM CLUB
                WHERE LOWER(USER_NICK) = LOWER(USER)))
);