-- Tabelle interessate: 6
--  -> CLUB_CARD, CONSUMABLE, IS_FOUND, PACK_PURCHSE, CLUB, TRANSACTION;
-- OUTPUT:
--  -> Dettagli dei consumabili posseduti dal club dell'utente.
CREATE OR REPLACE VIEW GET_CONSUMABLES AS
( SELECT
    CARD_CODE,
    CARD_ID,
    RARITY_NAME,
    TYPE,
    CATEGORY,
    AMOUNT,
    BRONZE_CONTRACT,
    SILVER_CONTRACT,
    GOLD_CONTRACT,
    MIN_PRICE,
    MAX_PRICE
FROM CONSUMABLE C
    JOIN CLUB_CARD CC ON C.CARD_ID = CC.CONSUMABLE_ID
                            AND CC.CARD_CODE IN (
        SELECT
            CARD_CODE
        FROM IS_FOUND
        WHERE P_ID IN (
                SELECT PURCHASE_ID
                FROM PACK_PURCHASE
                WHERE BUYING_CLUB_NAME IN (
                        SELECT CLUB_NAME
                        FROM CLUB
                        WHERE LOWER(USER_NICK) = LOWER(USER))))
UNION
SELECT
    CARD_CODE,
    CARD_ID,
    RARITY_NAME,
    TYPE,
    CATEGORY,
    AMOUNT,
    BRONZE_CONTRACT,
    SILVER_CONTRACT,
    GOLD_CONTRACT,
    MIN_PRICE,
    MAX_PRICE
FROM CONSUMABLE C
    JOIN CLUB_CARD CC ON C.CARD_ID = CC.CONSUMABLE_ID
                            AND CC.CARD_CODE IN (
        SELECT
            T_CARD_CODE
        FROM TRANSACTION
        WHERE TRANSITION_B_CLUB_NAME IN (
                SELECT CLUB_NAME
                FROM CLUB
                WHERE LOWER(USER_NICK) = LOWER(USER)))
);