-- Tabelle interessate: 6
--  -> CLUB_CARD, PLAYER, IS_FOUND, PACK_PURCHSE, CLUB, TRANSACTION;
-- OUTPUT:
--  -> Dettagli dei player posseduti dal club dell'utente.
CREATE OR REPLACE VIEW GET_PLAYERS AS
( SELECT
    CARD_CODE,
    PLAYER_NAME,
    POSITION,
    OVERALL,
    NATIONALITY,
    LEAGUE_NAME,
    CONTRACTS,
    PLAYER_FITNESS,
    ACTIVE_TRAINING AS TRAIN
FROM
            PLAYER P
    JOIN CLUB_CARD C ON P.CARD_ID = C.PLAYER_ID
    JOIN ACTIVE_DATA_PLAYER A ON A.P_CARD_CODE = C.CARD_CODE
                        AND C.CARD_CODE IN (
        SELECT
            CARD_CODE
        FROM
            IS_FOUND
        WHERE
            P_ID IN (
                SELECT
                    PURCHASE_ID
                FROM
                    PACK_PURCHASE
                WHERE
                    BUYING_CLUB_NAME IN (
                        SELECT
                            CLUB_NAME
                        FROM
                            CLUB
                        WHERE
                            LOWER(USER_NICK) = LOWER(USER)
                    )
            )
    )
UNION
SELECT
    CARD_CODE,
    PLAYER_NAME,
    POSITION,
    OVERALL,
    NATIONALITY,
    LEAGUE_NAME,
    CONTRACTS,
    PLAYER_FITNESS,
    ACTIVE_TRAINING AS TRAIN
FROM
            PLAYER P
    JOIN CLUB_CARD C ON P.CARD_ID = C.PLAYER_ID
    JOIN ACTIVE_DATA_PLAYER A ON A.P_CARD_CODE = C.CARD_CODE
                        AND C.CARD_CODE IN (
        SELECT
            T_CARD_CODE
        FROM
            TRANSACTION
        WHERE
            TRANSITION_B_CLUB_NAME IN (
                SELECT
                    CLUB_NAME
                FROM
                    CLUB
                WHERE
                    LOWER(USER_NICK) = LOWER(USER)
            )
    )
);