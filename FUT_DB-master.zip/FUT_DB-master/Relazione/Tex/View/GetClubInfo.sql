-- Tabelle interessate: 1
--  -> CLUB;
-- OUTPUT:
--  -> Dettagli deL club dell'utente.
CREATE OR REPLACE VIEW GET_CLUB_INFO AS
( SELECT
    *
FROM
    CLUB
WHERE
    LOWER(USER_NICK) = LOWER(USER)
);