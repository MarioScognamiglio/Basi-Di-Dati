-- Tabelle interessate: 6
--  -> CLUB_CARD, PLAYER, IS_PART_OF, IS_FOUND, PACK_PURCHSE, CLUB, TRANSACTION;
-- OUTPUT:
--  -> Dettagli dei player infortunati del club dell'utente.
CREATE OR REPLACE VIEW GET_PLAYERS_STOPS AS
( SELECT
    P_CARD_CODE,
    PLAYER_NAME,
    PLAYER_POSITION,
    HOLDER,
    S_DATE,
    BODY_PART,
    DAYS
FROM
            STOPS S
    JOIN CLUB_CARD   C ON S.P_CARD_CODE = C.CARD_CODE
    JOIN PLAYER      P ON C.PLAYER_ID = P.CARD_ID
    JOIN IS_PART_OF  I ON I.PLAYER_CARD_CODE = C.CARD_CODE
                            AND C.CARD_CODE IN (
        SELECT CARD_CODE
        FROM IS_FOUND
        WHERE P_ID IN (
                SELECT PURCHASE_ID
                FROM PACK_PURCHASE
                WHERE BUYING_CLUB_NAME IN (
                        SELECT CLUB_NAME
                        FROM CLUB
                        WHERE LOWER(USER_NICK) = LOWER(USER))))
UNION
SELECT
    P_CARD_CODE,
    PLAYER_NAME,
    PLAYER_POSITION,
    HOLDER,
    S_DATE,
    BODY_PART,
    DAYS
FROM
            STOPS S
    JOIN CLUB_CARD   C ON S.P_CARD_CODE = C.CARD_CODE
    JOIN PLAYER      P ON C.PLAYER_ID = P.CARD_ID
    JOIN IS_PART_OF  I ON I.PLAYER_CARD_CODE = C.CARD_CODE
                            AND C.CARD_CODE IN (
        SELECT T_CARD_CODE
        FROM TRANSACTION
        WHERE TRANSITION_B_CLUB_NAME IN (
                SELECT CLUB_NAME
                FROM CLUB
                WHERE LOWER(USER_NICK) = LOWER(USER)))
);