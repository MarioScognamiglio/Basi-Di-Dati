---------------------------------------------------------------------------------------------------------------------------
-- Admin Function GET_MANAGERS_F
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 8
--  -> CLUB_CARD, MANAGER, ACTIVE_DATA_MANAGER, MANAGES, IS_FOUND, PACK_PURCHSE, CLUB, TRANSACTION;
-- OUTPUT:
--  -> Dettagli dei dati attivi dei manager posseduti dal club fornito in ingresso.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION GET_MANAGERS_F (
    C_NAME CLUB.CLUB_NAME%TYPE
) RETURN SYS_REFCURSOR IS
    G_M_DATA SYS_REFCURSOR;
BEGIN
    OPEN G_M_DATA FOR 
        SELECT
            CARD_CODE,
            F_NAME,
            S_NAME,
            CONTRACTS,
            LEAGUE_NAME     AS PREF_LEAGUE,
            MANAGER_LEAGUE  AS ACTIVE_LEAGUE,
            NATIONALITY
        FROM
                MANAGER M
            JOIN CLUB_CARD            C ON M.CARD_ID = C.MANAGER_ID
            JOIN ACTIVE_DATA_MANAGER  A ON A.M_CARD_CODE = C.CARD_CODE
                                        AND C.CARD_CODE IN (
                SELECT
                    CARD_CODE
                FROM
                    IS_FOUND
                WHERE
                    P_ID IN (
                        SELECT
                            PURCHASE_ID
                        FROM
                            PACK_PURCHASE
                        WHERE
                            BUYING_CLUB_NAME = C_NAME
                    )
            )
        UNION
        SELECT
            CARD_CODE,
            F_NAME,
            S_NAME,
            CONTRACTS,
            LEAGUE_NAME     AS PREF_LEAGUE,
            MANAGER_LEAGUE  AS ACTIVE_LEAGUE,
            NATIONALITY
        FROM
                MANAGER M
            JOIN CLUB_CARD            C ON M.CARD_ID = C.MANAGER_ID
            JOIN ACTIVE_DATA_MANAGER  A ON A.M_CARD_CODE = C.CARD_CODE
                                        AND C.CARD_CODE IN (
                SELECT
                    T_CARD_CODE
                FROM
                    TRANSACTION
                WHERE
                    TRANSITION_B_CLUB_NAME = C_NAME
            )ORDER BY CONTRACTS;

    RETURN G_M_DATA;
END GET_MANAGERS_F;
/