---------------------------------------------------------------------------------------------------------------------------
-- Admin Function GET_PLAYERS_STOPS_F
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 7
--  -> CLUB_CARD, STOPS, PLAYER, IS_PART_OF, IS_FOUND, PACK_PURCHASE, TRANSACTION;
-- INPUT:
--	-> c_name:  nome del club;
-- OUTPUT:
--  -> Dettagli dei player infortunati del club fornito in ingresso.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION GET_PLAYERS_STOPS_F (
    C_NAME CLUB.CLUB_NAME%TYPE
) RETURN SYS_REFCURSOR IS
    G_P_STOPS SYS_REFCURSOR;
BEGIN
    OPEN G_P_STOPS FOR 
        SELECT
            P_CARD_CODE      AS CARD_CODE,
            PLAYER_NAME      AS NAME,
            PLAYER_POSITION  AS POSITION,
            HOLDER,
            S_DATE,
            BODY_PART        AS PART,
            DAYS
        FROM
                STOPS S
            JOIN CLUB_CARD   C ON S.P_CARD_CODE = C.CARD_CODE
            JOIN PLAYER      P ON C.PLAYER_ID = P.CARD_ID
            JOIN IS_PART_OF  I ON I.PLAYER_CARD_CODE = C.CARD_CODE
                                AND C.CARD_CODE IN (
                SELECT
                    CARD_CODE
                FROM
                    IS_FOUND
                WHERE
                    P_ID IN (
                        SELECT
                            PURCHASE_ID
                        FROM
                            PACK_PURCHASE
                        WHERE
                            BUYING_CLUB_NAME = C_NAME
                    )
            )
        UNION
        SELECT
            P_CARD_CODE      AS CARD_CODE,
            PLAYER_NAME      AS NAME,
            PLAYER_POSITION  AS POSITION,
            HOLDER,
            S_DATE,
            BODY_PART        AS PART,
            DAYS
        FROM
                STOPS S
            JOIN CLUB_CARD   C ON S.P_CARD_CODE = C.CARD_CODE
            JOIN PLAYER      P ON C.PLAYER_ID = P.CARD_ID
            JOIN IS_PART_OF  I ON I.PLAYER_CARD_CODE = C.CARD_CODE
                                AND C.CARD_CODE IN (
                SELECT
                    T_CARD_CODE
                FROM
                    TRANSACTION
                WHERE
                    TRANSITION_B_CLUB_NAME = C_NAME
            ) ORDER BY DAYS DESC, POSITION;
    
    RETURN G_P_STOPS;
END GET_PLAYERS_STOPS_F;
/