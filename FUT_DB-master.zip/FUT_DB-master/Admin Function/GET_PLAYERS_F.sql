---------------------------------------------------------------------------------------------------------------------------
-- Admin Function GET_PLAYERS_F
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 5
--  -> CLUB_CARD, PLAYER, IS_FOUND, PACK_PURCHASE, TRANSACTION;
-- INPUT:
--	-> c_name:  nome del club;
-- OUTPUT:
--  -> Dettagli dei player posseduti del club fornito in ingresso.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION GET_PLAYERS_F (
    C_NAME SQUAD.SQUAD_CLUB_NAME%TYPE
) RETURN SYS_REFCURSOR IS
    VIEWPLAYER SYS_REFCURSOR;
BEGIN
    OPEN VIEWPLAYER FOR 
        SELECT
            CARD_CODE,
            CARD_ID,
            PLAYER_NAME,
            VERSION_NAME AS VER,
            OVERALL,
            POSITION,
            NATIONALITY,
            LEAGUE_NAME,
            CONTRACTS,
            PLAYER_FITNESS,
            ACTIVE_TRAINING AS TRAIN
        FROM
                    PLAYER P
            JOIN CLUB_CARD C ON P.CARD_ID = C.PLAYER_ID
            JOIN ACTIVE_DATA_PLAYER A ON A.P_CARD_CODE = C.CARD_CODE
                                AND C.CARD_CODE IN (
                SELECT
                    CARD_CODE
                FROM
                    IS_FOUND
                WHERE
                    P_ID IN (
                        SELECT
                            PURCHASE_ID
                        FROM
                            PACK_PURCHASE
                        WHERE
                            BUYING_CLUB_NAME = C_NAME
                    )
            )
        UNION
        SELECT
            CARD_CODE,
            CARD_ID,
            PLAYER_NAME,
            VERSION_NAME AS VER,
            OVERALL,
            POSITION,
            NATIONALITY,
            LEAGUE_NAME,
            CONTRACTS,
            PLAYER_FITNESS,
            ACTIVE_TRAINING AS TRAIN
        FROM
                    PLAYER P
            JOIN CLUB_CARD C ON P.CARD_ID = C.PLAYER_ID
            JOIN ACTIVE_DATA_PLAYER A ON A.P_CARD_CODE = C.CARD_CODE
                                AND C.CARD_CODE IN (
                SELECT
                    T_CARD_CODE
                FROM
                    TRANSACTION
                WHERE
                    TRANSITION_B_CLUB_NAME = C_NAME
            ) ORDER BY POSITION, OVERALL DESC;

    RETURN VIEWPLAYER;
END GET_PLAYERS_F;
/