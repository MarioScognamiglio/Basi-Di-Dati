---------------------------------------------------------------------------------------------------------------------------
-- Admin Function GET_MANAGES_F
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 8
--  -> CLUB_CARD, MANAGER, ACTIVE_DATA_MANAGER, MANAGES, IS_FOUND, PACK_PURCHSE, CLUB, TRANSACTION;
-- OUTPUT:
--  -> Dettagli dei dati attivi delle carte manager con relativa squadra.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION GET_MANAGES_F (
    C_NAME CLUB.CLUB_NAME%TYPE
) RETURN SYS_REFCURSOR IS
    G_MANAGES SYS_REFCURSOR;
BEGIN 
    OPEN G_MANAGES FOR 
        SELECT
            CARD_CODE,
            F_NAME,
            S_NAME,
            CONTRACTS,
            LEAGUE_NAME     AS PREF_LEAGUE,
            MANAGER_LEAGUE  AS ACTIVE_LEAGUE,
            NATIONALITY,
            SQUAD_NAME      AS SQUAD_MANAGES,
            CLUB_NAME
        FROM
                MANAGER M
            JOIN CLUB_CARD            C ON M.CARD_ID = C.MANAGER_ID
            JOIN ACTIVE_DATA_MANAGER  A ON A.M_CARD_CODE = C.CARD_CODE
            JOIN MANAGES              MM ON MM.MANAGER_CARD_CODE = A.M_CARD_CODE
                            AND C.CARD_CODE IN (
                SELECT
                    CARD_CODE
                FROM IS_FOUND
                WHERE P_ID IN (
                        SELECT PURCHASE_ID
                        FROM PACK_PURCHASE
                        WHERE BUYING_CLUB_NAME = C_NAME))
        UNION
        SELECT
            CARD_CODE,
            F_NAME,
            S_NAME,
            CONTRACTS,
            LEAGUE_NAME     AS PREF_LEAGUE,
            MANAGER_LEAGUE  AS ACTIVE_LEAGUE,
            NATIONALITY,
            SQUAD_NAME      AS SQUAD_MANAGES,
            CLUB_NAME
        FROM
                MANAGER M
            JOIN CLUB_CARD            C ON M.CARD_ID = C.MANAGER_ID
            JOIN ACTIVE_DATA_MANAGER  A ON A.M_CARD_CODE = C.CARD_CODE
            JOIN MANAGES              MM ON MM.MANAGER_CARD_CODE = A.M_CARD_CODE
                            AND C.CARD_CODE IN (
                SELECT
                    T_CARD_CODE
                FROM TRANSACTION
                WHERE TRANSITION_B_CLUB_NAME = C_NAME
            )ORDER BY CONTRACTS, SQUAD_MANAGES;
    RETURN G_MANAGES;
END GET_MANAGES_F;
/
