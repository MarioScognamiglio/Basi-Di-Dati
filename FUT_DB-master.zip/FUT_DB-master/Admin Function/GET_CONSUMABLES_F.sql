---------------------------------------------------------------------------------------------------------------------------
-- Admin Function GET_CONSUMABLES_F
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 5
--  -> CLUB_CARD, CONSUMABLE, IS_FOUND, PACK_PURCHASE, TRANSACTION;
-- INPUT:
--	-> c_name:  nome del club;
--  -> c_category: categoria della carta di tipo consumabile;
--                  ('Contract','Fitness','Training','Healing','GKTraining','Manager League','Positioning').
-- OUTPUT:
--  -> Dettagli dei consumabili in base alla categoria, posseduti dal club fornito in ingresso.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION GET_CONSUMABLES_F (
    C_NAME      SQUAD.SQUAD_CLUB_NAME%TYPE,
    C_CATEGORY  CONSUMABLE.CATEGORY%TYPE
) RETURN SYS_REFCURSOR IS
    G_CONSUMABLES SYS_REFCURSOR;
BEGIN
    OPEN G_CONSUMABLES FOR 
        SELECT
            CARD_CODE,
            CARD_ID,
            RARITY_NAME,
            TYPE,
            CATEGORY,
            AMOUNT,
            BRONZE_CONTRACT,
            SILVER_CONTRACT,
            GOLD_CONTRACT,
            MIN_PRICE,
            MAX_PRICE
        FROM
                CONSUMABLE C
            JOIN CLUB_CARD CC ON C.CARD_ID = CC.CONSUMABLE_ID
                                AND C.CATEGORY = C_CATEGORY
                                AND CC.CARD_CODE IN (
                SELECT
                    CARD_CODE
                FROM
                    IS_FOUND
                WHERE
                    P_ID IN (
                        SELECT
                            PURCHASE_ID
                        FROM
                            PACK_PURCHASE
                        WHERE
                            BUYING_CLUB_NAME = C_NAME
                    )
            )
        UNION
        SELECT
            CARD_CODE,
            CARD_ID,
            RARITY_NAME,
            TYPE,
            CATEGORY,
            AMOUNT,
            BRONZE_CONTRACT,
            SILVER_CONTRACT,
            GOLD_CONTRACT,
            MIN_PRICE,
            MAX_PRICE
        FROM
                CONSUMABLE C
            JOIN CLUB_CARD CC ON C.CARD_ID = CC.CONSUMABLE_ID
                                AND C.CATEGORY = C_CATEGORY
                                AND CC.CARD_CODE IN (
                SELECT
                    T_CARD_CODE
                FROM
                    TRANSACTION
                WHERE
                    TRANSITION_B_CLUB_NAME = C_NAME
            )ORDER BY CATEGORY, AMOUNT DESC, CARD_ID;

    RETURN G_CONSUMABLES;
END GET_CONSUMABLES_F;
/