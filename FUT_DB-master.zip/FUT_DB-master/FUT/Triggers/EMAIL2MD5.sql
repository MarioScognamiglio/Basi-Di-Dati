---------------------------------------------------------------------------------------------------------------------------
-- Trigger EMAIL2MD5
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 1
--  -> USER_FUT;
-- TRIGGER:
--  -> Cripta l'email di un nuovo utente con l'algoritmo MD5.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER EMAIL2MD5 BEFORE
    INSERT ON USER_FUT
    FOR EACH ROW
DECLARE
    MD5RAW     RAW(2000);
    OUT_EMAIL  RAW(16); --Email criptata.

BEGIN
    MD5RAW := UTL_RAW.CAST_TO_RAW(:NEW.EMAIL);
    DBMS_OBFUSCATION_TOOLKIT.MD5(INPUT => MD5RAW, CHECKSUM => OUT_EMAIL);

--Inserisco la nuova email criptata.
    SELECT
        OUT_EMAIL
    INTO :NEW.EMAIL
    FROM
        DUAL;

END EMAIL2MD5;
/