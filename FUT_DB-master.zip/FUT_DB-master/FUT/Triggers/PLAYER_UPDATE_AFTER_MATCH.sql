---------------------------------------------------------------------------------------------------------------------------
-- Trigger PLAYER_UPDATE_AFTER_MATCH
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 4
--  -> SQUAD, IS_PART_OF, ACTIVE_DATA_PLAYER, TMP_MATCH;
-- TRIGGER:
--  -> Aggiorna i dati attivi dei player dopo che il club ha disputato un match.
--     Aggiorna la forma fisica <player_fitness>;
--     Rimuove un contratto, un giorno da eventuali infortuni e training attivi.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER PLAYER_UPDATE_AFTER_MATCH AFTER
UPDATE OF RESULTS ON MATCH
FOR EACH ROW

DECLARE

    N1          NUMBER(5, 0);--Id dell'ultimo match.
    HOME_SQUAD  VARCHAR2(16);--Nome della squadra in casa.
    HOME_CLUB   CLUB.CLUB_NAME%TYPE;--Nome del club della squadra in casa.
    AWAY_SQUAD  VARCHAR2(16);--Nome della squadra fuori casa.
    AWAY_CLUB   CLUB.CLUB_NAME%TYPE;--Nome del club della squadra fuori casa.
    RAND_VALUE  NUMBER(2, 0);--Numero random.

BEGIN
--Seleziono l'id dell'ultimo match in <n1>.
    SELECT
        MAX(MATCH_ID)
    INTO N1
    FROM
        TMP_MATCH;

--Se il match corrente e' l'ultimo disputato.
    IF N1 = :NEW.MATCH_ID THEN

--Seleziono i nomi delle squadre che hanno appena giocato.
        SELECT
            NAME,
            SQUAD_CLUB_NAME
        INTO
            HOME_SQUAD,
            HOME_CLUB
        FROM
            SQUAD
        WHERE
            NAME = :NEW.HOME_SQUAD_NAME;

        SELECT
            NAME,
            SQUAD_CLUB_NAME
        INTO
            AWAY_SQUAD,
            AWAY_CLUB
        FROM
            SQUAD
        WHERE
            NAME = :NEW.VISITORS_SQUAD_NAME;

--Rimuovo i benefici del training (player_rating + 2).
        UPDATE IS_PART_OF
        SET
            PLAYER_RATING = PLAYER_RATING - 2
        WHERE
            ( SQUAD_NAME = HOME_SQUAD
              OR SQUAD_NAME = AWAY_SQUAD )
            AND HOLDER = '1'
            AND PLAYER_CARD_CODE IN (
                SELECT
                    P_CARD_CODE
                FROM
                    ACTIVE_DATA_PLAYER
                WHERE
                    ACTIVE_TRAINING IS NOT NULL
            );

--Aggiorno la nuova valutazione <squad_rating> della squadra in casa.
        UPDATE SQUAD
        SET
            SQUAD_RATING = (
                SELECT
                    GET_SQUAD_RATING(HOME_SQUAD, HOME_CLUB)
                FROM
                    DUAL
            )
        WHERE
                NAME = HOME_SQUAD
            AND SQUAD_CLUB_NAME = HOME_CLUB;

--Aggiorno la nuova valutazione <squad_rating> della squadra fuori casa.
        UPDATE SQUAD
        SET
            SQUAD_RATING = (
                SELECT
                    GET_SQUAD_RATING(AWAY_SQUAD, AWAY_CLUB)
                FROM
                    DUAL
            )
        WHERE
                NAME = AWAY_SQUAD
            AND SQUAD_CLUB_NAME = AWAY_CLUB;

--Aggiorno i contratti e rimuovo i training.
        UPDATE ACTIVE_DATA_PLAYER
        SET
            CONTRACTS = CONTRACTS - 1,
            ACTIVE_TRAINING = NULL
        WHERE
            P_CARD_CODE IN (
                SELECT
                    PLAYER_CARD_CODE
                FROM
                    IS_PART_OF
                WHERE
                    ( SQUAD_NAME = HOME_SQUAD
                      OR SQUAD_NAME = AWAY_SQUAD )
                    AND HOLDER = '1'
            );

--Aggiorno i contratti dei manager.
        UPDATE ACTIVE_DATA_MANAGER
        SET
            CONTRACTS = CONTRACTS - 1
        WHERE
            M_CARD_CODE IN (
                SELECT
                    M_CARD_CODE
                FROM
                    MANAGES
                WHERE
                    ( SQUAD_NAME = HOME_SQUAD
                      OR SQUAD_NAME = AWAY_SQUAD )
            );

--Aggiorno la forma fisica <player_fitness>.
        RAND_VALUE := DBMS_RANDOM.VALUE(LOW => 2, HIGH => 3);
--Posizione player in (GK).
        UPDATE ACTIVE_DATA_PLAYER
        SET
            PLAYER_FITNESS = PLAYER_FITNESS - RAND_VALUE
        WHERE
            PLAYER_FITNESS > RAND_VALUE + 1 AND P_CARD_CODE IN (
                SELECT
                    PLAYER_CARD_CODE
                FROM
                    IS_PART_OF
                WHERE
                    ( SQUAD_NAME = HOME_SQUAD
                      OR SQUAD_NAME = AWAY_SQUAD )
                    AND PLAYER_POSITION = 'GK'
                    AND HOLDER = '1'
            ); 

-- Posizione player in (CB).
        RAND_VALUE := DBMS_RANDOM.VALUE(LOW => 3, HIGH => 5);
        UPDATE ACTIVE_DATA_PLAYER
        SET
            PLAYER_FITNESS = PLAYER_FITNESS - RAND_VALUE
        WHERE
            PLAYER_FITNESS > RAND_VALUE + 1 AND P_CARD_CODE IN (
                SELECT
                    PLAYER_CARD_CODE
                FROM
                    IS_PART_OF
                WHERE
                    ( SQUAD_NAME = HOME_SQUAD
                      OR SQUAD_NAME = AWAY_SQUAD )
                    AND PLAYER_POSITION = 'CB'
                    AND HOLDER = '1'
            );

-- Posizione player in (RB LB LW RW RWB LWB RM LM).
        RAND_VALUE := DBMS_RANDOM.VALUE(LOW => 8, HIGH => 10);
        UPDATE ACTIVE_DATA_PLAYER
        SET
            PLAYER_FITNESS = PLAYER_FITNESS - RAND_VALUE
        WHERE
            PLAYER_FITNESS > RAND_VALUE + 1 AND P_CARD_CODE IN (
                SELECT
                    PLAYER_CARD_CODE
                FROM
                    IS_PART_OF
                WHERE
                    ( ( SQUAD_NAME = HOME_SQUAD
                        OR SQUAD_NAME = AWAY_SQUAD )
                      AND ( PLAYER_POSITION = 'LB'
                            OR PLAYER_POSITION = 'RB'
                            OR PLAYER_POSITION = 'LW'
                            OR PLAYER_POSITION = 'RW'
                            OR PLAYER_POSITION = 'RWB'
                            OR PLAYER_POSITION = 'LWB'
                            OR PLAYER_POSITION = 'LM'
                            OR PLAYER_POSITION = 'RM' )
                      AND HOLDER = '1' )
            );

-- Posizione player in (CM ST CAM CDM CF RF LF).
        RAND_VALUE := DBMS_RANDOM.VALUE(LOW => 5, HIGH => 8);
        UPDATE ACTIVE_DATA_PLAYER
        SET
            PLAYER_FITNESS = PLAYER_FITNESS - RAND_VALUE
        WHERE
            PLAYER_FITNESS > RAND_VALUE + 1 AND P_CARD_CODE IN (
                SELECT
                    PLAYER_CARD_CODE
                FROM
                    IS_PART_OF
                WHERE
                    ( SQUAD_NAME = HOME_SQUAD
                      OR SQUAD_NAME = AWAY_SQUAD )
                    AND ( PLAYER_POSITION = 'CM'
                          OR PLAYER_POSITION = 'ST'
                          OR PLAYER_POSITION = 'CAM'
                          OR PLAYER_POSITION = 'CDM'
                          OR PLAYER_POSITION = 'CF'
                          OR PLAYER_POSITION = 'RF'
                          OR PLAYER_POSITION = 'LF' )
                    AND HOLDER = '1'
            );
    ELSE
        RETURN;
    END IF;

END PLAYER_UPDATE_AFTER_MATCH;
/