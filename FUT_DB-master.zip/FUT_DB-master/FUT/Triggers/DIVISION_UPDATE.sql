---------------------------------------------------------------------------------------------------------------------------
-- Trigger DIVISION_UPDATE
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 3
--  -> SQUAD, CLUB, DIVISION_RIVALS;
-- TRIGGER:
--  -> Gestisce la promozione/retrocessione di un club dopo aver giocato una partita.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER DIVISION_UPDATE AFTER
    UPDATE OF RESULTS ON MATCH
    FOR EACH ROW
DECLARE
    N1              NUMBER(5, 0); --Id dell'ultimo match disputato.
    HOME_POINTS     NUMBER(5, 0); --Punti della squadra in casa.
    AWAY_POINTS     NUMBER(5,0); --Punti della squadra fuori casa.
    TH              NUMBER(4, 0); --Soglia delle divisioni.
    D1              NUMBER(2, 0); --Numero di divisione squadra in casa.
    D2              NUMBER(2, 0); --Numero di divisione squadra fuori casa.
BEGIN
--Seleziono l'id dell'ultimo match.
    SELECT
        MAX(MATCH_ID)
    INTO N1
    FROM
        TMP_MATCH;

--Controllo che sto analizzando l'ultimo match.
    IF N1 = :OLD.MATCH_ID THEN
--Seleziono punti e numero divisione della squadra in casa.
        SELECT
            DR_POINTS,
            DIVISION_NUMBER
        INTO
            HOME_POINTS,
            D1
        FROM
            CLUB
        WHERE
            CLUB_NAME IN 
                (SELECT SQUAD_CLUB_NAME
                FROM SQUAD
                WHERE NAME = :NEW.HOME_SQUAD_NAME);

--Seleziono punti e numero divisione della squadra fuori casa.
        SELECT
            DR_POINTS,
            DIVISION_NUMBER
        INTO
            AWAY_POINTS,
            D2
        FROM
            CLUB
        WHERE
            CLUB_NAME IN
                (SELECT SQUAD_CLUB_NAME
                FROM SQUAD
                WHERE NAME = :NEW.VISITORS_SQUAD_NAME);

--Seleziono la soglia della divisione successiva a quella in cui si trova il club <home_club_name> che gioca in casa.
        SELECT
            THRESHOLD
        INTO TH
        FROM
            DIVISION_RIVALS
        WHERE
            DIVISION_NUMBER = D1 - 1;

--Risultato match
        DBMS_OUTPUT.PUT_LINE('| ATTENZIONE! Risultati match:');
        DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------');
        DBMS_OUTPUT.PUT_LINE('| Risultato   ('
                             || :NEW.HOME_SQUAD_NAME
                             || ') -> '
                             || :NEW.RESULTS
                             || ' <- ('
                             || :NEW.VISITORS_SQUAD_NAME
                             || ')'
                             || CHR(10));

        DBMS_OUTPUT.PUT_LINE('| Punti       ('
                             || :NEW.HOME_POINTS
                             || ')            ('
                             || :NEW.VISITORS_POINTS
                             || ')'
                             || CHR(10));

        DBMS_OUTPUT.PUT_LINE('| Crediti     ('
                             || :NEW.HOME_CREDITS
                             || ')            ('
                             || :NEW.VISITORS_CREDITS
                             || ')');

        DBMS_OUTPUT.PUT_LINE('-----------------------------------------------------');

--Se i punti del club della squadra in casa superano la soglia <th>, si ha una promozione.
        IF HOME_POINTS > TH THEN
            UPDATE CLUB
            SET
                DIVISION_NUMBER = DIVISION_NUMBER - 1
            WHERE
                CLUB_NAME IN
                    (SELECT SQUAD_CLUB_NAME
                    FROM SQUAD
                    WHERE NAME = :NEW.HOME_SQUAD_NAME);

            DBMS_OUTPUT.PUT_LINE('| La squadra '
                                 || :NEW.HOME_SQUAD_NAME
                                 || ' viene promossa in divisione '
                                 ||(D1 - 1)
                                 || ' !');

        END IF;

--Seleziono la soglia della divisione successiva a quella in cui si trova il club <away_club_name>, che gioca fuori casa.
        SELECT
            THRESHOLD
        INTO TH
        FROM
            DIVISION_RIVALS
        WHERE
            DIVISION_NUMBER = D2 - 1;

--Se i punti del club della squadra fuori casa superano la soglia <th>, si ha una promozione.
        IF AWAY_POINTS > TH THEN
            UPDATE CLUB
            SET
                DIVISION_NUMBER = DIVISION_NUMBER - 1
            WHERE
                CLUB_NAME IN
                    (SELECT SQUAD_CLUB_NAME
                    FROM SQUAD
                    WHERE NAME = :NEW.VISITORS_SQUAD_NAME);

            DBMS_OUTPUT.PUT_LINE('| La squadra '
                                 || :NEW.VISITORS_SQUAD_NAME
                                 || ' viene promossa in divisione '
                                 ||(D2 - 1)
                                 || ' !');

        END IF;

--Retrocessione, a meno che non ci si trovi in divisione 10 (Soglia della divisione 9 = 100), si puo' retrocedere.
        IF HOME_POINTS >= 100 THEN

--Seleziono la soglia della divisione del club in casa.
            SELECT
                THRESHOLD
            INTO TH
            FROM
                DIVISION_RIVALS
            WHERE
                DIVISION_NUMBER = D1;

--Se i punti del club in casa sono minori della soglia, viene retrocessa.
            IF HOME_POINTS < TH THEN
                UPDATE CLUB
                SET
                    DIVISION_NUMBER = DIVISION_NUMBER + 1
                WHERE
                    CLUB_NAME IN 
                        (SELECT SQUAD_CLUB_NAME
                        FROM SQUAD
                        WHERE NAME = :NEW.HOME_SQUAD_NAME);

                DBMS_OUTPUT.PUT_LINE('| La squadra '
                                     || :NEW.HOME_SQUAD_NAME
                                     || ' viene retrocessa in divisione '
                                     ||(D1 + 1)
                                     || ' !');

            END IF;

        END IF;

--Retrocessione, a meno che non ci si trovi in divisione 10 (Soglia della divisione 9 = 100), si puo' retrocedere.
        IF AWAY_POINTS >= 100 THEN

--Seleziono la soglia della divisione del club fuori casa.
            SELECT
                THRESHOLD
            INTO TH
            FROM
                DIVISION_RIVALS
            WHERE
                DIVISION_NUMBER = D2;

--Se i punti del club fuori casa sono minori della soglia, viene retrocessa.
            IF AWAY_POINTS < TH THEN
                UPDATE CLUB
                SET
                    DIVISION_NUMBER = DIVISION_NUMBER + 1
                WHERE
                    CLUB_NAME IN 
                        (SELECT SQUAD_CLUB_NAME
                        FROM SQUAD
                        WHERE NAME = :NEW.VISITORS_SQUAD_NAME);

                DBMS_OUTPUT.PUT_LINE('| La squadra '
                                     || :NEW.VISITORS_SQUAD_NAME
                                     || ' viene retrocessa in divisione '
                                     ||(D2 + 1)
                                     || ' !');

            END IF;

        END IF;

    ELSE
        RETURN;
    END IF;

END DIVISION_UPDATE;
/