---------------------------------------------------------------------------------------------------------------------------
-- Job Admin Procedure CHECK_DURATION
---------------------------------------------------------------------------------------------------------------------------
-- SCOPO:
--  -> Viene chiamata dal job JOB_TRANSACTION ogni ora.
--       1. Elimina le transazioni scadute (duration = 0);
--       2. Decremente di 1 la durata della transazione.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE CHECK_DURATION IS
BEGIN
   --Elimina le transazioni con duration = 0.
   DELETE FROM TRANSACTION
   WHERE
         DURATION = 0
      AND TRANSITION_B_CLUB_NAME IS NULL;

   --Decremente duration di 1, poichè è passata un'ora.
   UPDATE TRANSACTION
   SET
      DURATION = DURATION - 1
   WHERE
      DURATION > 0
      AND TRANSITION_B_CLUB_NAME IS NULL;

   COMMIT;
END CHECK_DURATION;
/