---------------------------------------------------------------------------------------------------------------------------
-- User/Admin Procedure CLUB_DELETE
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 2
--  -> CLUB_CARD, CLUB, IS_FOUND, PACK_PURCHASE;
-- Funzioni interessate: 2
--  -> IS_ADMIN;
-- INPUT:
--	-> cc_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
-- OUTPUT:
--  -> Cancella il club.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE CLUB_DELETE (
    CC_NAME USER_FUT.NICKNAME%TYPE
) IS
    N1      NUMBER(2, 0); --Controlla se il club esiste.
    C_NAME  CLUB.CLUB_NAME%TYPE; --Nome del club effettivo (is_admin).

    NO_CLUB_FOUND EXCEPTION; --Nel caso in cui non viene trovato il club da eliminare.

BEGIN
--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione CLUB_DELETE;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <cc_name>
--Altrimenti il nome del club <c_name> sara' quello dell'utente.
--In breve l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
    SELECT
        IS_ADMIN(CC_NAME, USER)
    INTO C_NAME
    FROM
        DUAL;

--Controllo se il club esiste.
    SELECT
        COUNT(*)
    INTO N1
    FROM
        CLUB
    WHERE
        CLUB_NAME = C_NAME;

--Se <n1 = 0>, il club <c_name> non e' stato trovato.
    IF N1 = 0 THEN
        RAISE NO_CLUB_FOUND;
    END IF;

--Elimino tutte le carte del club.
    DELETE FROM CLUB_CARD
    WHERE
        CARD_CODE IN (
            SELECT
                CARD_CODE
            FROM
                IS_FOUND
            WHERE
                P_ID IN (
                    SELECT
                        PURCHASE_ID
                    FROM
                        PACK_PURCHASE
                    WHERE
                        BUYING_CLUB_NAME = C_NAME
                )
        );

--Elimino il club
    DELETE FROM CLUB
    WHERE
        CLUB_NAME = C_NAME;

--Confermo
    COMMIT;
EXCEPTION
    WHEN NO_CLUB_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'Il club '
                                          || C_NAME
                                          || ' non e'' stato trovato');
END CLUB_DELETE;
/