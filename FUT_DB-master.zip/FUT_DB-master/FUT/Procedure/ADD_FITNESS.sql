---------------------------------------------------------------------------------------------------------------------------
-- User/Admin Procedure ADD_FITNESS
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 3
--  -> CLUB_CARD, CONSUMABLE, ACTIVE_DATA_PLAYER;
-- Funzioni interessate: 2
--  -> IS_ADMIN, CARD_IN_CLUB;
-- INPUT:
--  -> s_name: nome della squadra;
--	-> cc_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
--	-> c_code: codice carta del <club_item>;
--	-> p_code:  codice carta del player, oppure NULL, se il consumabile lo si vuole applicare alla squadra;
-- OUTPUT:
--  -> Rende attivo il consumabile di tipo <fitness> sul player <p_car_code>, o sulla squadra <s_name>.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE ADD_FITNESS (
    S_NAME   SQUAD.NAME%TYPE,
    CC_NAME  CLUB.CLUB_NAME%TYPE,
    C_CODE   CLUB_CARD.CARD_CODE%TYPE,
    P_CODE   CLUB_CARD.CARD_CODE%TYPE
) IS

    N1             NUMBER(2, 0); --Controlla che il club possieda la carta <c_code> e <p_code>.
    RESULT         NUMBER(2, 0);  --Di quanto dev'essere incrementata la forma fisica <player_fitness>.
    TOTAL_FITNESS  NUMBER(3, 0); --Valore totale della forma fisica.
    C_NAME         CLUB.CLUB_NAME%TYPE; --Nome effettivo del club (is_admin).

    TYPE ARRAY_CC_T IS
        VARRAY(18) OF VARCHAR(8);
    SQUAD_C_CODE   ARRAY_CC_T; --Array per i codici carta dei player della squdra <s_name>.

BEGIN
--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione ADD_FITNESS;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <cc_name>
--Altrimenti il nome del club <c_name> sara' quello dell'utente.
--In breve l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
    SELECT
        IS_ADMIN(CC_NAME, USER)
    INTO C_NAME
    FROM
        DUAL;

--La funzione card_in_club, controlla che il club identificato dal nome <c_name> possieda la carta identificata dal <c_code>
-- se n1 != 0 il club possiede la carta, altrimenti no.
    SELECT
        CARD_IN_CLUB(C_CODE, C_NAME)
    INTO N1
    FROM
        DUAL;

-- Se n1 e' ancora uguale a 0, il club non possiede la carta oppure e' stato inserito un <c_code> errato!
    IF N1 = 0 THEN
        RAISE NO_DATA_FOUND;
    ELSE
--Seleziono di quanto deve essere aumentata la forma fisica <player_fitness> del player in result.
        SELECT
            AMOUNT
        INTO RESULT
        FROM
            CONSUMABLE
        WHERE
            CARD_ID IN (
                SELECT
                    CONSUMABLE_ID
                FROM
                    CLUB_CARD
                WHERE
                    CARD_CODE = C_CODE
            );
--Se il codice carta <p_code> non e' NULL il consumabile va applicato al player.
        IF P_CODE IS NOT NULL THEN

--Seleziono la forma fisica attuale in <total_fitness>.
            SELECT
                PLAYER_FITNESS
            INTO TOTAL_FITNESS
            FROM
                ACTIVE_DATA_PLAYER
            WHERE
                P_CARD_CODE = P_CODE;

            TOTAL_FITNESS := TOTAL_FITNESS + RESULT;
            IF TOTAL_FITNESS > 99 THEN
                TOTAL_FITNESS := 99;
            END IF;

--Aggiorno il valore di <player_fitness> sommato a <result>.
            UPDATE ACTIVE_DATA_PLAYER
            SET
                PLAYER_FITNESS = TOTAL_FITNESS
            WHERE
                P_CARD_CODE = P_CODE;

--Cancello il consumabile <c_code> appena utilizzato.
            DELETE FROM CLUB_CARD
            WHERE
                CARD_CODE = C_CODE;

--Confermo
            COMMIT;

--Il codice carta del player <p_code> e' NULL, quindi il consumabile va applicato a tutta la squadra.
        ELSE
--Aggiorno la forma fisica di tutti i player della squadra <s_name>.
--Seleziono i codici carta dei player della squadra per controllare che la loro forma fisica non superi il massimo.
            SELECT
                PLAYER_CARD_CODE
            BULK COLLECT
            INTO SQUAD_C_CODE
            FROM
                IS_PART_OF
            WHERE
                    SQUAD_NAME = S_NAME;
                    
            FOR I IN 1..SQUAD_C_CODE.COUNT LOOP
                SELECT
                    PLAYER_FITNESS
                INTO TOTAL_FITNESS
                FROM
                    ACTIVE_DATA_PLAYER
                WHERE
                    P_CARD_CODE = SQUAD_C_CODE(I);

                TOTAL_FITNESS := TOTAL_FITNESS + RESULT;
                IF TOTAL_FITNESS > 99 THEN
                    TOTAL_FITNESS := 99;
                END IF;
                UPDATE ACTIVE_DATA_PLAYER
                SET
                    PLAYER_FITNESS = TOTAL_FITNESS
                WHERE
                    P_CARD_CODE = SQUAD_C_CODE(I);

            END LOOP;

-- Cacello il consumabile <c_code> appena utilizzato.
            DELETE FROM CLUB_CARD
            WHERE
                CARD_CODE = C_CODE;

--Confermo
            COMMIT;
        END IF;

    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'Il consumabile ('
                                          || C_CODE
                                          || ') non e'' stato trovato!');
END ADD_FITNESS;
/