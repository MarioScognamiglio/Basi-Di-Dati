---------------------------------------------------------------------------------------------------------------------------
-- User/Admin Procedure BUY_CARD
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 2
--  ->TRANSACTION, CLUB;
-- Funzioni/Procedure interessate: 2
--  -> IS_ADMIN, NUMBER_OF_CARDS;
-- INPUT:
--	-> b_card_code:  codice della carta da comprare.
--	-> bb_club_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--                   se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
--	-> b_price:  prezzo della carta.
-- OUTPUT:
--  -> Compra la carta identificata da <b_card_code>.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE BUY_CARD (
    B_CARD_CODE   TRANSACTION.T_CARD_CODE%TYPE,
    BB_CLUB_NAME  TRANSACTION.TRANSITION_B_CLUB_NAME%TYPE,
    B_PRICE       TRANSACTION.PRICE%TYPE
) IS 
--Variabili di controllo
    N1           NUMBER(2, 0);
    CRT          CLUB.CREDITS%TYPE;--Crediti del club, da aggiornare dopo aver comprato la carta <b_card_code>.
    S_PRICE      TRANSACTION.PRICE%TYPE; --Prezzo della carta in vendita.
    TR_ID        VARCHAR(8);--Id della transizione
    
    B_CLUB_NAME  CLUB.CLUB_NAME%TYPE; --Nome effettivo del club (is_admin).
    S_CLUB_NAME  TRANSACTION.TRANSITION_S_CLUB_NAME%TYPE; --Nome del club che vende la carta <b_card_code>.
    USR          CLUB.USER_NICK%TYPE; --Nome utente.
    SAME_CLUB EXCEPTION; --Nel caso in cui si cerca di comprare una carta messa in vendita dallo stesso club.
    BUYING_ERROR EXCEPTION; --Nel caso in cui l'operazione non va a buon fine.

BEGIN
--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione BUY_CARD;
--Se e' l'amministratore a chiamare la funzione il nome del club <B_CLUB_NAME> sara' uguale a <BB_CLUB_NAME>
--Altrimenti il nome del club <B_CLUB_NAME> sara' quello dell'utente.
--In breve l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
    SELECT
        IS_ADMIN(BB_CLUB_NAME, USER)
    INTO B_CLUB_NAME
    FROM
        DUAL;
    
    --Seleziono il nome utente del propietario di b_club_name.
    SELECT USER_NICK
    INTO USR
    FROM CLUB
    WHERE CLUB_NAME = B_CLUB_NAME;

    --Controllo sul volume delle carte, massimo 1500.
    ADMINFUT.NUMBER_OF_CARDS(USR);

--Vediamo se il club <b_club_name> ha abbastanza crediti per effettuare l'acquisto.
    SELECT
        CLUB.CREDITS
    INTO CRT
    FROM
        CLUB
    WHERE
        CLUB.CLUB_NAME = B_CLUB_NAME;

--Controllo se la transazione esiste.
    SELECT
        COUNT(T_CARD_CODE),
        MAX(TRANSITION_S_CLUB_NAME),
        MAX(PRICE),
        MAX(TRANSACTION_ID)
    INTO
        N1,
        S_CLUB_NAME,
        S_PRICE,
        TR_ID
    FROM
        TRANSACTION
    WHERE
            T_CARD_CODE = B_CARD_CODE
        AND TRANSITION_B_CLUB_NAME IS NULL; 

--Se il club che vende e' uguale a quello che compra.
    IF S_CLUB_NAME = B_CLUB_NAME THEN
        RAISE SAME_CLUB;
--Se <n1 > 0>, la transazione e' stata trovata
-- e il prezzo alla quale si vuole acquistare e minore o uguale al prezzo della carta in vendita.
    ELSIF
        N1 > 0
        AND S_PRICE <= B_PRICE
    THEN


    DELETE FROM TRANSACTION
            WHERE
                    T_CARD_CODE = B_CARD_CODE
                AND TRANSACTION_ID <> TR_ID;

    DELETE FROM IS_FOUND
            WHERE
                    CARD_CODE = B_CARD_CODE
                AND P_ID IN (
                    SELECT
                        PURCHASE_ID
                    FROM
                        PACK_PURCHASE
                    WHERE
                        BUYING_CLUB_NAME = S_CLUB_NAME
                );

--Aggiorno la transazione impostanto il club che compra uguale a <b_club_name>.                
        UPDATE TRANSACTION
        SET
            TRANSITION_B_CLUB_NAME = B_CLUB_NAME
        WHERE
                T_CARD_CODE = B_CARD_CODE
            AND TRANSITION_B_CLUB_NAME IS NULL
            AND TRANSITION_S_CLUB_NAME <> B_CLUB_NAME;

--Incremento i crediti del club <s_club_name> che ha venduto la carta.
        UPDATE CLUB
        SET
            CREDITS = CREDITS + S_PRICE
        WHERE
            CLUB_NAME = S_CLUB_NAME;

--Decremento i crediti del club <b_club_name> che ha comprato la carta.
        UPDATE CLUB
        SET
            CREDITS = CREDITS - S_PRICE
        WHERE
            CLUB_NAME = B_CLUB_NAME;

--Confermo
        COMMIT;
    ELSE
        RAISE BUYING_ERROR;
    END IF;

EXCEPTION
    WHEN SAME_CLUB THEN
        RAISE_APPLICATION_ERROR(-20005, 'Stai tendando di comprare un carta messa in vendita da te!');
    WHEN BUYING_ERROR THEN
        RAISE_APPLICATION_ERROR(-20002, 'Errore! Acquisto non effettuato!');
END BUY_CARD;
/
