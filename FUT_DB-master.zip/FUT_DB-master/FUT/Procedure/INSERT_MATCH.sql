---------------------------------------------------------------------------------------------------------------------------
-- User/Admin Procedure INSERT_MATCH
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 5
--  -> CLUB, MATCH, IS_PART_OF, SQUAD;
-- Funzioni interessate: 2
--  -> IS_ADMIN;
-- INPUT:
--	-> s_name:  nome della squadra;
--	-> cc_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
-- OUTPUT:
--  -> Aggiunge la squadra <s_name> ad un match.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE INSERT_MATCH (
    S_NAME   SQUAD.NAME%TYPE,
    CC_NAME  CLUB.CLUB_NAME%TYPE
) IS
--Variabili di controllo
    RAND_VALUE      NUMBER(3, 0); --Numero casuale.
    N1              NUMBER(2, 0); 
    N2              NUMBER(2, 0);
    N3              NUMBER(4, 0);
    FLAG            NUMBER(1, 0);

    C_NAME          CLUB.CLUB_NAME%TYPE; --Nome del club effettivo (is_admin).
    USER_SQ         SQUAD%ROWTYPE;  --Tupla squadra utente.
    HOME_SQ         SQUAD%ROWTYPE;  --Tupla squadra in casa.
    AWAY_SQ         SQUAD%ROWTYPE;  --Tupla squadra fuori casa.
    HOME_W_P        NUMBER(2, 0);    --Percentuale vittoria squadra in casa.
    AWAY_W_P        NUMBER(2, 0);    --Percentuale vittoria squadra fuori casa.
    DRAW_P          NUMBER(2, 0);    --Percentuale pareggio.
    RAND_VALUE_2    NUMBER(2, 0);    --Numero casuale.
    NEW_MATCH       MATCH%ROWTYPE;   --Tupla da caricare.
    FF_HOME         NUMBER(4,0);     -- A determinare il risultato del match contribuisce 
    FF_AWAY         NUMBER(4,0);     -- anche la forma fisica delle due squadre  
    
    AWAY_NAME       SQUAD.NAME%TYPE; --Nome della squadra fuori casa.
    AWAY_CLUB_NAME  SQUAD.SQUAD_CLUB_NAME%TYPE; --Nome del club della squadra fuori casa.

    HOME_NAME       SQUAD.NAME%TYPE; --Nome della squadra in casa.
    HOME_CLUB_NAME  SQUAD.SQUAD_CLUB_NAME%TYPE; --Nome del club della squadra in casa.

--ECCEZIONI
    NO_SQUAD EXCEPTION; --Chiamata in causa se la squadra <s_name> non viene trovata.
    PLAYER_MIN EXCEPTION; --Per giocare una partita la squadra deve avere minimo 11 titolari.
    MATCH_EXISTING EXCEPTION; --La squadra <s_name> e' in attesa di disputare un match.
    CLUB_EXISTING EXCEPTION; --Il club ha già un'altra squadra in attesa di disputare un match.
BEGIN
    N1 := 0;
    N2 := 0;
    FLAG := 0;
    USER_SQ := NULL;

--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione INSERT_MATCH;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <cc_name>
--Altrimenti il nome del club <c_name> sara' quello dell'utente.
--In breve l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
    SELECT
        IS_ADMIN(CC_NAME, USER)
    INTO C_NAME
    FROM
        DUAL;

--Controllo che la squadra <s_name> esista.
    SELECT
        COUNT(*)
    INTO N1
    FROM
        SQUAD
    WHERE
            NAME = S_NAME
        AND SQUAD_CLUB_NAME = C_NAME;

--Se <n1 = 0>, la squadra <s_name> non e' stata trovata.
    IF N1 = 0 THEN
        RAISE NO_SQUAD;
    END IF;

--Seleziono i dati relativi alla squadra che vuole disputare la partita in <user_sq>.
    SELECT
        *
    INTO USER_SQ
    FROM
        SQUAD
    WHERE
            NAME = S_NAME
        AND SQUAD_CLUB_NAME = C_NAME;

--Controllo quanti giocatori titolari ci sono nella squadra <s_name>.
    SELECT
        COUNT(*)
    INTO RAND_VALUE
    FROM
        IS_PART_OF
    WHERE
            SQUAD_NAME = S_NAME
        AND HOLDER = '1';

--Se ci sono meno di 11 giocatori titolari la squadra non puo' giocare la partita.
    IF RAND_VALUE < 11 THEN
        RAISE PLAYER_MIN;
    END IF;

--Controllo se ci sono match, con una squadra in casa, in attesa dell'avversario.
    SELECT
        COUNT(NAME)
    INTO N1
    FROM
        SQUAD
    WHERE
            SQUAD_CLUB_NAME <> C_NAME
        AND NAME IN (
            SELECT
                HOME_SQUAD_NAME
            FROM
                MATCH
            WHERE
                    HOME_SQUAD_NAME <> S_NAME
                AND VISITORS_SQUAD_NAME IS NULL
        );

--Se non ci sono match con una squadra in casa,
-- controllo se c'e' ne sono con una squadra fuori casa.
    IF N1 = 0 THEN
        SELECT
            COUNT(NAME)
        INTO N2
        FROM
            SQUAD
        WHERE
                SQUAD_CLUB_NAME <> C_NAME
            AND NAME IN (
                SELECT
                    VISITORS_SQUAD_NAME
                FROM
                    MATCH
                WHERE
                        VISITORS_SQUAD_NAME <> S_NAME
                    AND HOME_SQUAD_NAME IS NULL
            );

    END IF;

--Non ci sono squadre avversarie in attesa. La squadra <s_name> andra' in attesa di un avversario.
    IF
        N1 = 0
        AND N2 = 0
    THEN

--Controllo se la squadra <s_name> è in attesa.
        SELECT
            COUNT(MATCH_ID)
        INTO N1
        FROM
            MATCH
        WHERE
            ( HOME_SQUAD_NAME = S_NAME
              AND VISITORS_SQUAD_NAME IS NULL )
            OR ( VISITORS_SQUAD_NAME = S_NAME
                 AND HOME_SQUAD_NAME IS NULL );

--Controllo se altre squadre dello stesso club sono in attesa (in casa).
        SELECT
            COUNT(NAME)
        INTO N2
        FROM
            SQUAD
        WHERE
                SQUAD_CLUB_NAME = C_NAME
            AND NAME IN (
                SELECT
                    HOME_SQUAD_NAME
                FROM
                    MATCH
                WHERE
                        HOME_SQUAD_NAME <> S_NAME
                    AND VISITORS_SQUAD_NAME IS NULL
            );

--Controllo se altre squadre dello stesso club sono in attesa (fuori casa).
        IF N2 = 0 THEN
            SELECT
                COUNT(NAME)
            INTO N2
            FROM
                SQUAD
            WHERE
                    SQUAD_CLUB_NAME = C_NAME
                AND NAME IN (
                    SELECT
                        VISITORS_SQUAD_NAME
                    FROM
                        MATCH
                    WHERE
                            VISITORS_SQUAD_NAME <> S_NAME
                        AND HOME_SQUAD_NAME IS NULL
                );

        END IF;

--Se ci sono altre squadre dello stesso club in attesa,
-- prima di iniziare una nuova partita deve terminare la vecchia.
        IF N2 <> 0 THEN
            RAISE CLUB_EXISTING;
        END IF;

--Se non e' in attesa la inserisco in attesa.
        IF N1 = 0 THEN

--Se <rand_value = 1> la squadra giochera' in casa altrimenti fuori casa.
            RAND_VALUE := DBMS_RANDOM.VALUE(LOW => 1, HIGH => 2);
            IF RAND_VALUE = 1 THEN
                INSERT INTO MATCH (
                    MATCH_ID,
                    HOME_SQUAD_NAME
                ) VALUES (
                    MATCH_ID_SEQ.NEXTVAL,
                    S_NAME
                );

                INSERT INTO TMP_MATCH (
                    MATCH_ID,
                    HOME_SQUAD_NAME
                ) VALUES (
                    MATCH_ID_SEQ.CURRVAL,
                    S_NAME
                );

                COMMIT;
            ELSE
                INSERT INTO MATCH (
                    MATCH_ID,
                    VISITORS_SQUAD_NAME
                ) VALUES (
                    MATCH_ID_SEQ.NEXTVAL,
                    S_NAME
                );

                INSERT INTO TMP_MATCH (
                    MATCH_ID,
                    VISITORS_SQUAD_NAME
                ) VALUES (
                    MATCH_ID_SEQ.CURRVAL,
                    S_NAME
                );

                COMMIT;
            END IF;

        ELSE-- Altrimenti viene comunicato all'utente che è in attesa di un avversario.
            RAISE MATCH_EXISTING;
        END IF;
--C'e' una partita con un avversario in casa.
    ELSIF
        N1 <> 0
        AND N2 = 0
    THEN
--Mi assicuro che sia l'ultimo match quello che vado ad analizzare.
        SELECT
            MAX(MATCH_ID)
        INTO N3
        FROM
            MATCH;

--Aggiorno il match corrente inserendo la squadra fuori casa.
        UPDATE MATCH
        SET
            VISITORS_SQUAD_NAME = S_NAME
        WHERE
            MATCH_ID = N3;

        UPDATE TMP_MATCH
        SET
            VISITORS_SQUAD_NAME = S_NAME
        WHERE
            MATCH_ID = N3;

--Significa che sto per giocare una partita fuori casa.
        FLAG := 1;
--C'e' una partita con un avversario fuori casa.
    ELSIF
        N1 = 0
        AND N2 <> 0
    THEN
        SELECT
            MAX(MATCH_ID)
        INTO N3
        FROM
            MATCH;

--Aggiorno il match corrente inserendo la squadra in casa.
        UPDATE MATCH
        SET
            HOME_SQUAD_NAME = S_NAME
        WHERE
            MATCH_ID = N3;

        UPDATE TMP_MATCH
        SET
            HOME_SQUAD_NAME = S_NAME
        WHERE
            MATCH_ID = N3;

--Significa che sto per giocare una partita in casa.
        FLAG := 2;
    END IF;

--Se <flag = 1>, giocherà fuori casa.
    IF FLAG = 1 THEN

--La squadra fuori casa (AWAY_SQ) sarà la squadra dell'utente
        AWAY_SQ := USER_SQ;
        SELECT
            MAX(MATCH_ID)
        INTO N3
        FROM
            MATCH;

--Seleziono il nome della squadra e il nome del club avversario in <home_name>, <home_club_name>.
        SELECT
            HOME_SQUAD_NAME
        INTO
            HOME_NAME
        FROM MATCH WHERE MATCH_ID = N3;

--Seleziono i dati della squadra avversaria in <home_sq>.
        SELECT
            *
        INTO HOME_SQ
        FROM
            SQUAD
        WHERE
                NAME = HOME_NAME;

--Calcola il risultato della partita
        FLAG := 3;

--Se flag=2 giochera' in casa
    ELSIF FLAG = 2 THEN

--La squadra che giochera' in casa (HOME_SQ) sara' quella dell'utente.
        HOME_SQ := USER_SQ;
        SELECT
            MAX(MATCH_ID)
        INTO N3
        FROM
            MATCH;

--Seleziono il nome della squadra e il nome del club avversario in <away_name>, <away_club_name>.
        SELECT
            VISITORS_SQUAD_NAME
        INTO
            AWAY_NAME
        FROM MATCH WHERE MATCH_ID = N3;

--Seleziono i dati della squadra avversaria in <away_sq>.
        SELECT
            *
        INTO AWAY_SQ
        FROM
            SQUAD
        WHERE
                NAME = AWAY_NAME;
            
--Significa che posso disputare la partita.
        FLAG := 3;
    END IF;

--Seleziono la forma fisica delle due squadre
--Casa
        SELECT 
            SUM(PLAYER_FITNESS)
        INTO FF_HOME
        FROM
              ACTIVE_DATA_PLAYER 
        WHERE
                P_CARD_CODE IN (SELECT PLAYER_CARD_CODE
                                FROM   
                                    IS_PART_OF
                                WHERE
                                    SQUAD_NAME = HOME_NAME);
--Fuori Casa
        SELECT 
            SUM(PLAYER_FITNESS)
        INTO FF_AWAY
        FROM
              ACTIVE_DATA_PLAYER 
        WHERE
                P_CARD_CODE IN (SELECT PLAYER_CARD_CODE
                                FROM   
                                    IS_PART_OF
                                WHERE
                                    SQUAD_NAME = AWAY_NAME );
        

--Calcolo del risultato
--  i costrutti if interni controllo il dislivello di valutazione della squadra <squad_rating>;
--  quelli interni il dislivello d'intesa <squad_chemistry>;
--  infine il dislivello di forma fisica <player_fitness>.

    IF FLAG = 3 THEN
        IF ABS(HOME_SQ.SQUAD_RATING - AWAY_SQ.SQUAD_RATING) <= 3 THEN
            IF ABS(HOME_SQ.SQUAD_CHEMISTRY - AWAY_SQ.SQUAD_CHEMISTRY) <= 8 THEN 
                --Valutazione <rating>, intesa <chemistry> e forma fisisa sono simili.
                IF ABS(FF_HOME - FF_AWAY) <= 10 THEN
                    DRAW_P := 46;
                    HOME_W_P := 27;
                    AWAY_W_P := 27;
                --Valutazione <rating>, intesa <chemistry> simili, forma fisisa maggiore fuori casa.
                ELSIF (FF_HOME - FF_AWAY) < -10 THEN
                    DRAW_P := 46;
                    HOME_W_P := 25;
                    AWAY_W_P := 29;
                --Valutazione <rating>, intesa <chemistry> simili, forma fisisa maggiore in casa.
                ELSIF (FF_HOME - FF_AWAY) > 10  THEN
                    DRAW_P := 46;
                    HOME_W_P := 29;
                    AWAY_W_P := 25;
                END IF;
            --Valutazione <rating> simile, intesa <chemistry> maggiore fuori casa, forma fisisa simile.
            ELSIF ( HOME_SQ.SQUAD_CHEMISTRY - AWAY_SQ.SQUAD_CHEMISTRY ) < -8 THEN
                IF ABS(FF_HOME - FF_AWAY) <= 10 THEN
                    DRAW_P := 40;
                    HOME_W_P := 23;
                    AWAY_W_P := 37;
                --Valutazione <rating> simile, intesa <chemistry> maggiore fuori casa, forma fisisa maggiore fuori casa.
                ELSIF (FF_HOME - FF_AWAY) < -10 THEN
                    DRAW_P := 40;
                    HOME_W_P := 21;
                    AWAY_W_P := 39;
                --Valutazione <rating> simile, intesa <chemistry> maggiore fuori casa, forma fisisa maggiore in casa. 
                ELSIF (FF_HOME - FF_AWAY) > 10  THEN
                    DRAW_P := 40;
                    HOME_W_P := 25;
                    AWAY_W_P := 35;
                END IF;
            --Valutazione <rating> simile, intesa <chemistry> maggiore casa, forma fisisa simile.
            ELSIF ( HOME_SQ.SQUAD_CHEMISTRY - AWAY_SQ.SQUAD_CHEMISTRY ) > 8 THEN
                IF ABS(FF_HOME - FF_AWAY) <= 10 THEN
                    DRAW_P := 40;
                    HOME_W_P := 37;
                    AWAY_W_P := 23;
            --Valutazione <rating> simile, intesa <chemistry> maggiore casa, forma fisisa maggiore fuori casa.
                ELSIF (FF_HOME - FF_AWAY) < -10 THEN
                    DRAW_P := 40;
                    HOME_W_P := 35;
                    AWAY_W_P := 25;
            --Valutazione <rating> simile, intesa <chemistry> maggiore casa, forma fisisa maggiore casa.
                ELSIF (FF_HOME - FF_AWAY) > 10  THEN
                    DRAW_P := 40;
                    HOME_W_P := 39;
                    AWAY_W_P := 21;
                END IF;
            END IF;
        ELSIF ( HOME_SQ.SQUAD_RATING - AWAY_SQ.SQUAD_RATING ) < -3 THEN
            IF ABS(HOME_SQ.SQUAD_CHEMISTRY - AWAY_SQ.SQUAD_CHEMISTRY) <= 8 THEN
        --Valutazione <rating> maggiore fuori casa, intesa <chemistry> simile, forma fisisa simile.
                IF ABS(FF_HOME - FF_AWAY) <= 10 THEN
                    DRAW_P := 32;
                    HOME_W_P := 18;
                    AWAY_W_P := 50;
            --Valutazione <rating> maggiore fuori casa, intesa <chemistry> simile, forma fisisa maggiore fuori casa.
                ELSIF (FF_HOME - FF_AWAY) < -10 THEN
                    DRAW_P := 32;
                    HOME_W_P := 16;
                    AWAY_W_P := 52;
            --Valutazione <rating> maggiore fuori casa, intesa <chemistry> simile, forma fisisa maggiore casa.
                ELSIF (FF_HOME - FF_AWAY) > 10  THEN
                    DRAW_P := 32;
                    HOME_W_P := 18;
                    AWAY_W_P := 50;
                END IF;
            ELSIF ( HOME_SQ.SQUAD_CHEMISTRY - AWAY_SQ.SQUAD_CHEMISTRY ) < -8 THEN
            --Valutazione <rating> maggiore fuori casa, intesa <chemistry> maggiore fuori casa, forma fisisa simile.
                IF ABS(FF_HOME - FF_AWAY) <= 10 THEN
                    DRAW_P := 22;
                    HOME_W_P := 22;
                    AWAY_W_P := 56;
            --Valutazione <rating> maggiore fuori casa, intesa <chemistry> maggiore fuori casa, forma fisisa maggiore fuori casa.
                ELSIF (FF_HOME - FF_AWAY) < -10 THEN
                    DRAW_P := 22;
                    HOME_W_P := 20;
                    AWAY_W_P := 58;
            --Valutazione <rating> maggiore fuori casa, intesa <chemistry> maggiore fuori casa, forma fisisa maggiore casa.
                ELSIF (FF_HOME - FF_AWAY) > 10  THEN
                    DRAW_P := 22;
                    HOME_W_P := 24;
                    AWAY_W_P := 54;
                END IF;
            ELSIF ( HOME_SQ.SQUAD_CHEMISTRY - AWAY_SQ.SQUAD_CHEMISTRY ) > 8 THEN
            --Valutazione <rating> maggiore fuori casa, intesa <chemistry> maggiore casa, forma fisisa simile.
                IF ABS(FF_HOME - FF_AWAY) <= 10 THEN
                    DRAW_P := 18;
                    HOME_W_P := 32;
                    AWAY_W_P := 50;
            --Valutazione <rating> maggiore fuori casa, intesa <chemistry> maggiore casa, forma fisisa maggiore fuori casa.
                ELSIF (FF_HOME - FF_AWAY) < -10 THEN
                    DRAW_P := 18;
                    HOME_W_P := 30;
                    AWAY_W_P := 52;
            --Valutazione <rating> maggiore fuori casa, intesa <chemistry> maggiore casa, forma fisisa maggiore casa.
                ELSIF (FF_HOME - FF_AWAY) > 10  THEN
                    DRAW_P := 18;
                    HOME_W_P := 34;
                    AWAY_W_P := 48;
                END IF;
            END IF;
        ELSIF ( HOME_SQ.SQUAD_RATING - AWAY_SQ.SQUAD_RATING ) > 3 THEN
            IF ABS(HOME_SQ.SQUAD_CHEMISTRY - AWAY_SQ.SQUAD_CHEMISTRY) <= 8 THEN
            --Valutazione <rating> maggiore casa, intesa <chemistry> simile, forma fisisa simile.
                IF ABS(FF_HOME - FF_AWAY) <= 10 THEN
                    DRAW_P := 32;
                    HOME_W_P := 50;
                    AWAY_W_P := 18;
            --Valutazione <rating> maggiore casa, intesa <chemistry> simile, forma fisisa maggiore fuori casa.
                ELSIF (FF_HOME - FF_AWAY) < -10 THEN
                    DRAW_P := 32;
                    HOME_W_P := 48;
                    AWAY_W_P := 20;
            --Valutazione <rating> maggiore casa, intesa <chemistry> simile, forma fisisa maggiore casa.
                ELSIF (FF_HOME - FF_AWAY) > 10  THEN
                    DRAW_P := 32;
                    HOME_W_P := 52;
                    AWAY_W_P := 16;
                END IF;
            ELSIF ( HOME_SQ.SQUAD_CHEMISTRY - AWAY_SQ.SQUAD_CHEMISTRY ) < -8 THEN
            --Valutazione <rating> maggiore casa, intesa <chemistry> maggiore fuori casa, forma fisisa simile.
                IF ABS(FF_HOME - FF_AWAY) <= 10 THEN 
                    DRAW_P := 18;
                    HOME_W_P := 50;
                    AWAY_W_P := 32;
            --Valutazione <rating> maggiore casa, intesa <chemistry> maggiore fuori casa, forma fisisa maggiore fuori casa.
                ELSIF (FF_HOME - FF_AWAY) < -10 THEN
                    DRAW_P := 18;
                    HOME_W_P := 48;
                    AWAY_W_P := 34;
            --Valutazione <rating> maggiore casa, intesa <chemistry> maggiore fuori casa, forma fisisa maggiore casa.
                ELSIF (FF_HOME - FF_AWAY) > 10  THEN
                    DRAW_P := 18;
                    HOME_W_P := 52;
                    AWAY_W_P := 30;
                END IF;
            ELSIF ( HOME_SQ.SQUAD_CHEMISTRY - AWAY_SQ.SQUAD_CHEMISTRY ) > 8 THEN
            --Valutazione <rating> maggiore casa, intesa <chemistry> maggiore casa, forma fisisa simile.
                IF ABS(FF_HOME - FF_AWAY) <= 10 THEN
                    DRAW_P := 22;
                    HOME_W_P := 56;
                    AWAY_W_P := 22;
            --Valutazione <rating> maggiore casa, intesa <chemistry> maggiore casa, forma fisisa maggiore fuori casa.
                ELSIF (FF_HOME - FF_AWAY) < -10 THEN
                    DRAW_P := 22;
                    HOME_W_P := 54;
                    AWAY_W_P := 24;
            --Valutazione <rating> maggiore casa, intesa <chemistry> maggiore casa, forma fisisa maggiore casa.
                ELSIF (FF_HOME - FF_AWAY) > 10  THEN
                    DRAW_P := 22;
                    HOME_W_P := 58;
                    AWAY_W_P := 20;
                END IF;
            END IF;
        END IF;

        RAND_VALUE := DBMS_RANDOM.VALUE(LOW => 1, HIGH => 100);
        IF RAND_VALUE <= DRAW_P THEN
--Pareggio.
            RAND_VALUE := DBMS_RANDOM.VALUE(LOW => 0, HIGH => 7);
            NEW_MATCH.RESULTS := RAND_VALUE || '-' || RAND_VALUE;
            NEW_MATCH.HOME_POINTS := DBMS_RANDOM.VALUE(LOW => 15, HIGH => 30);
            NEW_MATCH.VISITORS_POINTS := NEW_MATCH.HOME_POINTS;
            NEW_MATCH.HOME_CREDITS := DBMS_RANDOM.VALUE(LOW => 100, HIGH => 130);
            NEW_MATCH.VISITORS_CREDITS := NEW_MATCH.HOME_CREDITS;

        ELSIF RAND_VALUE <= DRAW_P + HOME_W_P THEN
--Vince la squadra in casa.
            RAND_VALUE := DBMS_RANDOM.VALUE(LOW => 1, HIGH => 7);
            RAND_VALUE_2 := DBMS_RANDOM.VALUE(LOW => 0, HIGH => RAND_VALUE - 1);
            NEW_MATCH.RESULTS := RAND_VALUE || '-' || RAND_VALUE_2;
            NEW_MATCH.HOME_POINTS := DBMS_RANDOM.VALUE(LOW => 45, HIGH => 55);
            NEW_MATCH.VISITORS_POINTS := DBMS_RANDOM.VALUE(LOW => - 30, HIGH => - 15);
            NEW_MATCH.HOME_CREDITS := DBMS_RANDOM.VALUE(LOW => 200, HIGH => 230);
            NEW_MATCH.VISITORS_CREDITS := DBMS_RANDOM.VALUE(LOW => 45, HIGH => 55);

        ELSE
--Vince la squadra fuori casa.
            RAND_VALUE := DBMS_RANDOM.VALUE(LOW => 1, HIGH => 7);
            RAND_VALUE_2 := DBMS_RANDOM.VALUE(LOW => 0, HIGH => RAND_VALUE - 1);
            NEW_MATCH.RESULTS := RAND_VALUE_2 || '-' || RAND_VALUE;
            NEW_MATCH.HOME_POINTS := DBMS_RANDOM.VALUE(LOW => - 30, HIGH => - 15);
            NEW_MATCH.VISITORS_POINTS := DBMS_RANDOM.VALUE(LOW => 45, HIGH => 55);
            NEW_MATCH.HOME_CREDITS := DBMS_RANDOM.VALUE(LOW => 45, HIGH => 55);
            NEW_MATCH.VISITORS_CREDITS := DBMS_RANDOM.VALUE(LOW => 200, HIGH => 230);
        END IF;

--Aggiornamento punti e crediti della squadre.
        UPDATE CLUB
        SET
            DR_POINTS = DR_POINTS + NEW_MATCH.HOME_POINTS,
            CREDITS = CREDITS + NEW_MATCH.HOME_CREDITS
        WHERE
            CLUB.CLUB_NAME = HOME_SQ.SQUAD_CLUB_NAME;

        UPDATE CLUB
        SET
            DR_POINTS = DR_POINTS + NEW_MATCH.VISITORS_POINTS,
            CREDITS = CREDITS + NEW_MATCH.VISITORS_CREDITS
        WHERE
            CLUB.CLUB_NAME = AWAY_SQ.SQUAD_CLUB_NAME;

--Controllo che i punti non siano negativi.
        UPDATE CLUB
        SET
            DR_POINTS = 0
        WHERE
            DR_POINTS < 0;

        SELECT
            MAX(MATCH_ID)
        INTO N3
        FROM
            MATCH;

--Inserisco il risultato del match.
        UPDATE MATCH
        SET
            M_DATE = SYSDATE,
            RESULTS = NEW_MATCH.RESULTS,
            HOME_POINTS = NEW_MATCH.HOME_POINTS,
            VISITORS_POINTS = NEW_MATCH.VISITORS_POINTS,
            HOME_CREDITS = NEW_MATCH.HOME_CREDITS,
            VISITORS_CREDITS = NEW_MATCH.VISITORS_CREDITS
        WHERE
                HOME_SQUAD_NAME = HOME_SQ.NAME
            AND VISITORS_SQUAD_NAME = AWAY_SQ.NAME
            AND MATCH_ID = N3;
        
        UPDATE TMP_MATCH
        SET MATCH_DATE = SYSDATE
        WHERE HOME_SQUAD_NAME = HOME_SQ.NAME
            AND VISITORS_SQUAD_NAME = AWAY_SQ.NAME
            AND MATCH_ID = N3;
            

--Se ci sono giocatori non titolari infortunati, sottraggo uno dalle partite di stop.
        UPDATE STOPS
        SET
            DAYS = DAYS - 1
        WHERE
            P_CARD_CODE IN (
                SELECT
                    PLAYER_CARD_CODE
                FROM
                    IS_PART_OF
                WHERE
                    (SQUAD_NAME = HOME_SQ.NAME)
                    OR 
                    (SQUAD_NAME = AWAY_SQ.NAME)
            );
            
--Se un giocatore non ha piu' giornate di stop, elimino la tupla.        
        DELETE 
        FROM    STOPS
        WHERE   DAYS = 0;

--Confermo
        COMMIT;
    END IF;

EXCEPTION
    WHEN NO_SQUAD THEN
        RAISE_APPLICATION_ERROR(-20001, 'Squadra non trovata!');
    WHEN PLAYER_MIN THEN
        RAISE_APPLICATION_ERROR(-20006, 'Non ci sono abbastanza giocatori!');
    WHEN MATCH_EXISTING THEN
        RAISE_APPLICATION_ERROR(-20005, 'La squadra '
                                          || S_NAME
                                          || ' del club '
                                          || C_NAME
                                          || ' e'' in attesa di disputare una partita!');
    WHEN CLUB_EXISTING THEN
        RAISE_APPLICATION_ERROR(-20005, 'Il club '
                                          || C_NAME
                                          || ' e'' in attesa di disputare una partita!');
END INSERT_MATCH;
/
