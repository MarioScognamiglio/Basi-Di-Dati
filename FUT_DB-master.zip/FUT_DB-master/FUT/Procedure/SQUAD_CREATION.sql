---------------------------------------------------------------------------------------------------------------------------
-- User/Admin Procedure SQUAD_CREATION
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 1
--  -> SQUAD;
-- Funzioni interessate: 1
--  -> IS_ADMIN;
-- INPUT:
--	-> s_name:  nome della squadra ;
--	-> s_mod:  modulo della squadra, esempio: ('4-3-3','4-4-2'....etc.)
--	-> cc_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
-- OUTPUT:
--  -> Crea una squadra con nome <s_name>.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SQUAD_CREATION (
    SNAME    SQUAD.NAME%TYPE,
    SMOD     SQUAD.MODULES%TYPE,
    CC_NAME  CLUB.CLUB_NAME%TYPE
) IS
    N1      NUMBER(1, 0); --Controlla se esiste gia' una squadra con quel nome.
    C_NAME  CLUB.CLUB_NAME%TYPE; --Nome del club effettivo (is_admin).

    MAX_SQUADS EXCEPTION; --Controllo sul volume, max 6 squadre per club.

BEGIN
--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione SQUAD_CREATION;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <cc_name>
--Altrimenti il nome del club <c_name> sara' quello dell'utente.
--In breve l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
    SELECT
        IS_ADMIN(CC_NAME, USER)
    INTO C_NAME
    FROM
        DUAL;

--Controlla se esiste una squadra con nome uguale a <s_name>.
    SELECT
        COUNT(NAME)
    INTO N1
    FROM
        SQUAD
    WHERE
        NAME = SNAME AND SQUAD_CLUB_NAME = C_NAME;

--Se <n1 != 0>, esiste una squadra con nome uguale a <s_name>.
    IF N1 != 0 THEN
        DBMS_OUTPUT.PUT_LINE('Stai tentando di aggiungere una squadra gia'' presente!');
    ELSE
        --Controllo sul volume, un club può averer massimo 6 squadre.
        SELECT COUNT(*)
        INTO n1
        FROM SQUAD
        WHERE SQUAD_CLUB_NAME = C_NAME;

        IF N1 > 5 THEN
            RAISE MAX_SQUADS;
        END IF;

--Inserisco la tupla.
        INSERT INTO SQUAD (
            NAME,
            SQUAD_CLUB_NAME,
            MODULES
        )
            SELECT
                SNAME,
                C_NAME,
                SMOD
            FROM
                DUAL;

--Conferma
        COMMIT;
    END IF;
EXCEPTION
    WHEN MAX_SQUADS THEN
        RAISE_APPLICATION_ERROR(-20003,'Hai ' || n1 || ' squadre, il limite massimo e'' 6!');

END SQUAD_CREATION;
/