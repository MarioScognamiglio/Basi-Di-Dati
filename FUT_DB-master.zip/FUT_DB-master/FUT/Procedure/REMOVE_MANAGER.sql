---------------------------------------------------------------------------------------------------------------------------
-- User/Admin Procedure REMOVE_MANAGER
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 2
--  -> CLUB_CARD, MANAGES, MANAGER, IS_PART_OF, PLAYER;
-- Funzioni interessate: 1
--  -> IS_ADMIN;
-- INPUT:
--	-> m_code:  codice carta del manager da rimuovere.
--	-> s_name:  nome della squadra allenata dal manager da rimuovere.
--	-> cc_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
-- OUTPUT:
--  -> Rimuove il manager <m_code> dalla squadra <s_name>.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE REMOVE_MANAGER (
    M_CODE   IN  CLUB_CARD.CARD_CODE%TYPE,
    S_NAME   IN  SQUAD.NAME%TYPE,
    CC_NAME  IN  SQUAD.SQUAD_CLUB_NAME%TYPE
) IS
--Contatori di controllo.
    N1             NUMBER(2, 0);
    N2             NUMBER(2, 0);

    C_NAME         CLUB.CLUB_NAME%TYPE; --Nome effettivo del club (is_admin).

--Bonus intesa del manager
    P_NATION       PLAYER.NATIONALITY%TYPE; --Nazionalità del <player>.
    P_LEAGUE       PLAYER.LEAGUE_NAME%TYPE; --Lega del <player>
    M_NATION       MANAGER.NATIONALITY%TYPE; --Nazionalità del manager <m_code>.
    M_LEAGUE       MANAGER.LEAGUE_NAME%TYPE; --Lega del manager <m_code>.

--Array per i codici carta dei player della squadra <s_name>.
    TYPE ARRAY_CC_T IS VARRAY(18) OF VARCHAR2(8);
    ARR_CARD_CODE  ARRAY_CC_T;
BEGIN
--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione REMOVE_MANAGER;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <cc_name>
--Altrimenti il nome del club <c_name> sara' quello dell'utente.
--In breve l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
    SELECT
        IS_ADMIN(CC_NAME, USER)
    INTO C_NAME
    FROM
        DUAL;

--Controllo se il manager <m_code> allena la squadra <s_name>.
    SELECT
        COUNT(*)
    INTO N1
    FROM
        MANAGES
    WHERE
            SQUAD_NAME = S_NAME
        AND MANAGER_CARD_CODE = M_CODE;

--Se <n1 = 0>, il manager con codice carta <m_code> non e' stato trovato.
    IF N1 = 0 THEN
        RAISE NO_DATA_FOUND;
    ELSE
--Elimino il manager dalla squadra <s_name>.
        DELETE FROM MANAGES
        WHERE
                MANAGER_CARD_CODE = M_CODE
            AND SQUAD_NAME = S_NAME;

--Seleziono i codici carta dei player della squadra <s_name> in <arr_card_code>.
        SELECT
            PLAYER_CARD_CODE
        BULK COLLECT
        INTO ARR_CARD_CODE
        FROM
            IS_PART_OF
        WHERE
                SQUAD_NAME = S_NAME;
--Seleziono nazionalita' e liga del manager <m_code>.
        SELECT
            NATIONALITY,
            LEAGUE_NAME
        INTO
            M_NATION,
            M_LEAGUE
        FROM
                 MANAGER M
            JOIN CLUB_CARD C ON M.CARD_ID = C.MANAGER_ID
                                AND C.CARD_CODE = M_CODE;

--Per ogni player della squadra <s_name> che ha nazionalita' o liga uguale al manager.
-- Cioe' per ogni player che ha ricevuto il bonus sull'intesa <player_chemistry> dal manager, 
--  rimuovo il bonus.
        FOR I IN 1..ARR_CARD_CODE.COUNT LOOP
            SELECT
                NATIONALITY,
                LEAGUE_NAME
            INTO
                P_NATION,
                P_LEAGUE
            FROM
                     PLAYER P
                JOIN CLUB_CARD C ON P.CARD_ID = C.PLAYER_ID
                                    AND C.CARD_CODE = ARR_CARD_CODE(I);

--Aggiorno l'intesa <player_chemistry> dei player che avevano ricevuto il bonus dal manager.
            IF P_NATION = M_NATION OR P_LEAGUE = M_LEAGUE THEN
                UPDATE IS_PART_OF
                SET
                    PLAYER_CHEMISTRY = PLAYER_CHEMISTRY - 1
                WHERE
                        PLAYER_CARD_CODE = ARR_CARD_CODE(I)
                    AND PLAYER_CHEMISTRY > 0;

--Confermo
                COMMIT;
            END IF;

        END LOOP;

    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'La squadra '
                                          || S_NAME
                                          || ' del club '
                                          || C_NAME
                                          || ' non ha un manager attivo!');
END REMOVE_MANAGER;
/