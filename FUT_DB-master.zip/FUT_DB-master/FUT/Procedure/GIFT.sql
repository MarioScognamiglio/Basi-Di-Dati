---------------------------------------------------------------------------------------------------------------------------
-- Job Admin Procedure GIFT
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 2
--  -> USER_FUT, CLUB;
-- Procedure interessate: 1
--  -> PACK_OPENING;
-- SCOPO:
--  -> Viene chimata dal Job JOB_GIFT ogni giovedi alle 9:00 AM;
--       Distribuisce i premi ai club in base al numero di divisione in cui militano.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE GIFT IS
   N1       NUMBER(4, 0);
   TYPE U_ARR_T IS
      VARRAY(100) OF VARCHAR2(16);
   USR_ARR  U_ARR_T;
BEGIN
--Seleziono i nomi utenti di tutti i club.
   SELECT
      USER_NICK
   BULK COLLECT
   INTO USR_ARR
   FROM
      CLUB;

--Per ogni nome utente.
   FOR I IN 1..USR_ARR.COUNT LOOP
--Seleziono il numero di divione in cui si trova l'utente i-esimo.
      SELECT
         DIVISION_NUMBER
      INTO N1
      FROM
         CLUB
      WHERE
         USER_NICK = USR_ARR(I);

--Divione 9;
      IF N1 = 9 THEN
         PACK_OPENING('Bronze Pack', USR_ARR(I));
         PACK_OPENING('Bronze Player Pack', USR_ARR(I));
         UPDATE CLUB
         SET
            CREDITS = CREDITS + 1000
         WHERE
            USER_NICK = USR_ARR(I);
--Divione 8;
      ELSIF N1 = 8 THEN
         PACK_OPENING('Silver Pack', USR_ARR(I));
         PACK_OPENING('Silver Player Pack', USR_ARR(I));
         UPDATE CLUB
         SET
            CREDITS = CREDITS + 2000
         WHERE
            USER_NICK = USR_ARR(I);
--Divione 7;
      ELSIF N1 = 7 THEN
         PACK_OPENING('Silver Pack', USR_ARR(I));
         PACK_OPENING('Silver Player Pack', USR_ARR(I));
         PACK_OPENING('Silver Player Pack', USR_ARR(I));
         UPDATE CLUB
         SET
            CREDITS = CREDITS + 3000
         WHERE
            USER_NICK = USR_ARR(I);
--Divione 6;
      ELSIF N1 = 6 THEN
         PACK_OPENING('Silver Pack', USR_ARR(I));
         PACK_OPENING('Silver Player Pack', USR_ARR(I));
         PACK_OPENING('Silver Player Pack', USR_ARR(I));
         PACK_OPENING('Consumable Pack', USR_ARR(I));
         UPDATE CLUB
         SET
            CREDITS = CREDITS + 4000
         WHERE
            USER_NICK = USR_ARR(I);
--Divione 5;
      ELSIF N1 = 5 THEN
         PACK_OPENING('Gold Pack', USR_ARR(I));
         PACK_OPENING('Silver Player Pack', USR_ARR(I));
         PACK_OPENING('Gold Player Pack', USR_ARR(I));
         PACK_OPENING('Consumable Pack', USR_ARR(I));
         UPDATE CLUB
         SET
            CREDITS = CREDITS + 5000
         WHERE
            USER_NICK = USR_ARR(I);
--Divione 4;
      ELSIF N1 = 4 THEN
         PACK_OPENING('Gold Pack', USR_ARR(I));
         PACK_OPENING('Gold Player Pack', USR_ARR(I));
         PACK_OPENING('Premium Gold Pack', USR_ARR(I));
         PACK_OPENING('Consumable Pack', USR_ARR(I));
         UPDATE CLUB
         SET
            CREDITS = CREDITS + 7000
         WHERE
            USER_NICK = USR_ARR(I);
--Divione 3;
      ELSIF N1 = 3 THEN
         PACK_OPENING('Gold Pack', USR_ARR(I));
         PACK_OPENING('Gold Player Pack', USR_ARR(I));
         PACK_OPENING('Gold Player Pack', USR_ARR(I));
         PACK_OPENING('Consumable Pack', USR_ARR(I));
         PACK_OPENING('Jumbo Gold Pack', USR_ARR(I));
         UPDATE CLUB
         SET
            CREDITS = CREDITS + 9000
         WHERE
            USER_NICK = USR_ARR(I);
--Divione 2;
      ELSIF N1 = 2 THEN
         PACK_OPENING('Gold Pack', USR_ARR(I));
         PACK_OPENING('Gold Player Pack', USR_ARR(I));
         PACK_OPENING('Gold Player Pack', USR_ARR(I));
         PACK_OPENING('Consumable Pack', USR_ARR(I));
         PACK_OPENING('Jumbo Gold Pack', USR_ARR(I));
         PACK_OPENING('Rare Mega Pack', USR_ARR(I));
         UPDATE CLUB
         SET
            CREDITS = CREDITS + 12000
         WHERE
            USER_NICK = USR_ARR(I);
--Divione 1;
      ELSIF N1 = 1 THEN
         PACK_OPENING('Gold Pack', USR_ARR(I));
         PACK_OPENING('Gold Player Pack', USR_ARR(I));
         PACK_OPENING('Gold Player Pack', USR_ARR(I));
         PACK_OPENING('Consumable Pack', USR_ARR(I));
         PACK_OPENING('Jumbo Gold Pack', USR_ARR(I));
         PACK_OPENING('Rare Mega Pack', USR_ARR(I));
         PACK_OPENING('Ultimate Pack', USR_ARR(I));
         UPDATE CLUB
         SET
            CREDITS = CREDITS + 15000
         WHERE
            USER_NICK = USR_ARR(I);

      END IF;

   END LOOP;
   COMMIT;
END GIFT;
/