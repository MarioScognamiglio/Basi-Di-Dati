---------------------------------------------------------------------------------------------------------------------------
-- Admin Procedure NUMBER_OF_CARDS
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 2
--  -> CLUB, CLUB_CARD, IS_FOUND, PACK_PURCHASE, TRANSACTION;
-- INPUT:
--	-> usr_nick: nome utente;
-- SCOPO:
--  -> Gestisce il controllo sul volume delle carte di un club che non superi le 1500.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE NUMBER_OF_CARDS (
   USR CLUB.USER_NICK%TYPE
) IS
   N1  NUMBER(4, 0); --Numero di carte trovate da pacchetti.
   N2  NUMBER(4, 0); --Numero di carte comprate.
   MAX_CARDS EXCEPTION;
BEGIN
   --Controllo quante carte sono state trovate nei pacchetti = N1.
   SELECT
      COUNT(*)
   INTO N1
   FROM
      CLUB_CARD
   WHERE
      CARD_CODE IN (
         SELECT
            CARD_CODE
         FROM
            IS_FOUND
         WHERE
            P_ID IN (
               SELECT
                  PURCHASE_ID
               FROM
                  PACK_PURCHASE
               WHERE
                  BUYING_CLUB_NAME IN (
                     SELECT
                        CLUB_NAME
                     FROM
                        CLUB
                     WHERE
                        LOWER(USER_NICK) = LOWER(USR)
                  )
            )
      );

--Quante carte ha comprato = N2.
   SELECT
      COUNT(*)
   INTO N2
   FROM
      CLUB_CARD
   WHERE
      CARD_CODE IN (
         SELECT
            T_CARD_CODE
         FROM
            TRANSACTION
         WHERE
            TRANSITION_B_CLUB_NAME IN (
               SELECT
                  CLUB_NAME
               FROM
                  CLUB
               WHERE
                  LOWER(USER_NICK) = LOWER(USR)
            )
      );

   --Numero di carte totali = N1.
   N1 := N1 + N2;


   IF N1 > 1500 THEN
      RAISE MAX_CARDS;
   ELSE
      DBMS_OUTPUT.PUT_LINE('Puoi collezionare altre '
                           ||(1500 - N1)
                           || ' carte!');
   END IF;

EXCEPTION
   WHEN MAX_CARDS THEN
      RAISE_APPLICATION_ERROR(-20003, 'Attenzione! Possiedi '
                                        || N1
                                        || ' cards, hai raggiunto il limite massimo!');
END NUMBER_OF_CARDS;
/