---------------------------------------------------------------------------------------------------------------------------
-- User/Admin Procedure ADD_HEALING
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 3
--  -> CLUB_CARD, CONSUMABLE, STOPS;
-- Funzioni interessate: 3
--  -> IS_ADMIN, CARD_IN_CLUB;
-- INPUT:
--	-> c_code: codice carta del <consumable> di tipo <healing>;
--	-> p_code: codice carta del <player>;
--	-> cc_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
-- OUTPUT:
--  -> Applica il consumabile al player.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE ADD_HEALING (
    C_CODE   CLUB_CARD.CARD_CODE%TYPE,
    P_CODE   CLUB_CARD.CARD_CODE%TYPE,
    CC_NAME  CLUB.CLUB_NAME%TYPE
) IS

    N1      NUMBER(2, 0); 
    B_PART  STOPS.BODY_PART%TYPE; --Parte del corpo dove il player e' infortunato.
    C_TYPE  CONSUMABLE.TYPE%TYPE; --Parte del corpo indicata dal consumabile.
    C_NAME  CLUB.CLUB_NAME%TYPE; --Nome del club effettivo (is_admin).

    NO_PLAYER_FOUND EXCEPTION; --Il player <p_code> non e' stato trovato.
    NO_STOPS_FOUND EXCEPTION; --Il player <p_code> non e' infortunato.
    CONSUMABLE_WRONG_TYPE EXCEPTION; --Nel caso in cui la parte del corpo che si vuole curare non corrisponde a quella indicata dal consumabile.

BEGIN
--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione ADD_HEALING;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <cc_name>
--Altrimenti il nome del club <c_name> sara' quello dell'utente.
--In breve l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
    SELECT
        IS_ADMIN(CC_NAME, USER)
    INTO C_NAME
    FROM
        DUAL;

--La funzione card_in_club, controlla che il club identificato dal nome <c_name> possieda la carta identificata dal <c_code>
-- se n1 != 0 il club possiede la carta, altrimenti no.
    SELECT
        CARD_IN_CLUB(C_CODE, C_NAME)
    INTO N1
    FROM
        DUAL;

--Se <n1 = 0> il club non possiede il consumabile, oppure il <c_code> e' errato.
    IF N1 = 0 THEN
        RAISE NO_DATA_FOUND;
    ELSE
--Controllo se il club possiede il <player>.
        SELECT
            CARD_IN_CLUB(P_CODE, C_NAME)
        INTO N1
        FROM
            DUAL;

--Se <n1 = 0> il club non possiede il player, oppure il <p_code> e' errato.
        IF N1 = 0 THEN
            RAISE NO_PLAYER_FOUND;
        END IF;

--Controllo se il player e' infortunato.
        SELECT
            COUNT(P_CARD_CODE)
        INTO N1
        FROM
            STOPS
        WHERE
            P_CARD_CODE = P_CODE;

--Se <n1 = 0> il player non risulta infortunato.
        IF N1 = 0 THEN
            RAISE NO_STOPS_FOUND;
        END IF;

--Seleziono la parte del corpo dov'e' infortunato il <player> in <b_part>;
        SELECT
            BODY_PART
        INTO B_PART
        FROM
            STOPS
        WHERE
            P_CARD_CODE = P_CODE;

--Seleziono la parte del corpo indicata dal consumabile <c_code> in <c_type>.
        SELECT
            TYPE
        INTO C_TYPE
        FROM
                 CONSUMABLE C
            JOIN CLUB_CARD CC ON C.CARD_ID = CC.CONSUMABLE_ID
                                 AND CC.CARD_CODE = C_CODE;

--Se il consumabile non cura tutte le parti del corpo <All> e il <player> e' infortunato in una zona <b_part> diversa da
-- quella indicata dal consumabile <c_type>, si genera un eccezione.
--Esempio:  b_part = 'Head'; c_type = 'Foot';
--Sto cercando di curare un infortunio alla testa <b_part> con un consumabile che cura gli infortuni al piede <c_type>.
        IF
            C_TYPE <> 'All'
            AND C_TYPE <> B_PART
        THEN
            RAISE CONSUMABLE_WRONG_TYPE;
--Se il consumabile cura tutte le parti del corpo, oppure la parte del corpo dove il <player> e' infortunato <b_part>
-- corrisponde a quella indicata dal consumabile.
        ELSIF C_TYPE = 'All' OR C_TYPE = B_PART THEN

--Curo il player, viene quindi eliminato l'infortunio.
            DELETE FROM STOPS
            WHERE
                P_CARD_CODE = P_CODE;

--Cancello il consumabile <c_code> appena utilizzato.
            DELETE FROM CLUB_CARD
            WHERE
                CARD_CODE = C_CODE;

--Confermo.
            COMMIT;
        END IF;

    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'Il consumabile con codice carta ('
                                          || C_CODE
                                          || ') non e'' stato trovato!');
    WHEN NO_PLAYER_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'Il player con codice carta ('
                                          || P_CODE
                                          || ') non e'' stato trovato!');
    WHEN NO_STOPS_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'Il player con codice carta ('
                                          || C_CODE
                                          || ') non e'' infortunato!');
    WHEN CONSUMABLE_WRONG_TYPE THEN
        RAISE_APPLICATION_ERROR(-20004, 'Il consumabile di tipo ('
                                          || C_TYPE
                                          || ') non puo'' essere usato per un infortunio di tipo ('
                                          || B_PART
                                          || ')');
END ADD_HEALING;
/