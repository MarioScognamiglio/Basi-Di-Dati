---------------------------------------------------------------------------------------------------------------------------
-- User/Admin Procedure REMOVE_PLAYER
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 2
--  -> IS_PART_OF, SQUAD;
-- Function interessate: 2
--  -> IS_ADMIN, GET_SQUAD_RATING;
-- INPUT:
--	-> c_code: codice carta del player;
--	-> s_name: nome della squadra in cui è schierato il player <c_code>;
--	-> cc_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
-- OUTPUT:
--  -> Rimuove il player <c_code> dalla squadra <s_name>.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE REMOVE_PLAYER (
    C_CODE   IN  CLUB_CARD.CARD_CODE%TYPE,
    S_NAME   IN  SQUAD.NAME%TYPE,
    CC_NAME  IN  SQUAD.SQUAD_CLUB_NAME%TYPE
) IS
--Contatori di controllo.
    N1           NUMBER(2, 0);
    N2           NUMBER(2, 0);

    C_NAME       CLUB.CLUB_NAME%TYPE; --Nome effettivo del club (is_admin).
    S_RATING     NUMBER(2, 0); --Valutazione della squadra.
    S_CHEMISTRY  NUMBER(3, 0);--Intesa della squadra.

    NO_PLAYER_FOUND EXCEPTION; --Non ci sono player in squadra.

BEGIN
--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione REMOVE_PLAYER;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <cc_name>
--Altrimenti il nome del club <c_name> sara'' quello dell'utente.
--In breve l'amministratore puo'' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
    SELECT
        IS_ADMIN(CC_NAME, USER)
    INTO C_NAME
    FROM
        DUAL;

--Controllo che ci sia almeno un player nella squadra <s_name>
    SELECT
        COUNT(PLAYER_CARD_CODE)
    INTO N2
    FROM
        IS_PART_OF
    WHERE
            S_NAME = SQUAD_NAME;

    IF N2 = 0 THEN
        RAISE NO_PLAYER_FOUND;
    END IF;

--Controllo che il player <c_code> giochi per la squadra <s_name>.
    SELECT
        COUNT(*)
    INTO N1
    FROM
        IS_PART_OF
    WHERE
            SQUAD_NAME = S_NAME
        AND PLAYER_CARD_CODE = C_CODE;

--Se <n1 = 0>, il player con codice carta <c_code> non e' stato trovato.
    IF N1 = 0 THEN
        RAISE NO_DATA_FOUND;
    ELSE
--Elimino il player dalla squadra <s_name>.
        DELETE FROM IS_PART_OF
        WHERE
                PLAYER_CARD_CODE = C_CODE
            AND SQUAD_NAME = S_NAME;
    END IF;  

--Calcolo della nuova valutazione <s_rating> della squadra.
    SELECT
        GET_SQUAD_RATING(S_NAME, C_NAME)
    INTO S_RATING
    FROM
        DUAL;

--Inseirsco la nuova valutazione <s_rating> della squadra.
    UPDATE SQUAD
    SET
        SQUAD_RATING = S_RATING
    WHERE
            NAME = S_NAME
        AND SQUAD_CLUB_NAME = C_NAME;

--Calcolo intesa della squadra come somma dell'intesa di ogni <player>.
    SELECT
        SUM(PLAYER_CHEMISTRY)
    INTO S_CHEMISTRY
    FROM
        IS_PART_OF
    WHERE
            SQUAD_NAME = S_NAME
        AND HOLDER = '1';

--Inseirsco la nuova intesa <s_chemistry> della squadra.
    UPDATE SQUAD
    SET
        SQUAD_CHEMISTRY = S_CHEMISTRY
    WHERE
            NAME = S_NAME
        AND SQUAD_CLUB_NAME = C_NAME;

--Confermo
    COMMIT;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'Giocatore non trovato!'
                                        || CHR(10)
                                        || SQLCODE
                                        || ' - ERROR - '
                                        || SQLERRM);
    WHEN NO_PLAYER_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'Impossibile rimuovere giocatore, la squadra e'' vuota!');
END REMOVE_PLAYER;
/