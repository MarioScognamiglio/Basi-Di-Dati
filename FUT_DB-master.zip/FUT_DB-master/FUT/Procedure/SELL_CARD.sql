---------------------------------------------------------------------------------------------------------------------------
-- User/Admin Procedure SELL_CARD
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 6
--  -> CLUB_CARD, TRANSACTION, PLAYER, CONSUMABLE, CLUB_ITEM, MANAGER;
-- Funzioni interessate: 2
--  -> IS_ADMIN, CARD_IN_CLUB;
-- INPUT:
--	-> s_card_code:  codice della carta da vendere.
--	-> ss_club_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
--	-> s_price:  prezzo dell carta.
--  -> s_duration: durata della vendita.
-- OUTPUT:
--  -> Mette in vendita la carta <s_card_code>.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE PROCEDURE SELL_CARD (
    S_CARD_CODE   TRANSACTION.T_CARD_CODE%TYPE,
    SS_CLUB_NAME  TRANSACTION.TRANSITION_S_CLUB_NAME%TYPE,
    S_PRICE       TRANSACTION.PRICE%TYPE,
    S_DURATION    TRANSACTION.DURATION%TYPE
) IS 
--Nome del club effettivo (is_admin).
    S_CLUB_NAME  CLUB.CLUB_NAME%TYPE;

--Variabili di controllo.
    N1           NUMBER(2, 0);
    N2           NUMBER(2, 0);
    SS_PRICE     PLAYER.MAX_PRICE%TYPE;
    PRICE_MIN    PLAYER.MIN_PRICE%TYPE;
    PRICE_MAX    PLAYER.MAX_PRICE%TYPE;
    TR_ID        VARCHAR(8); --Id transazione.

--Id in base alla tipologia di carta.
    P_ID         NUMBER(1, 0); --Id Player.
    C_ID         NUMBER(1, 0); --Id Consumable.
    CT_ID        NUMBER(1, 0); --Id Club_item.
    M_ID         NUMBER(1, 0); --Id Manager.

    NO_CARD_FOUND EXCEPTION; --Nel caso in cui la carta con codice carta <s_card_code> non viene trovata.

BEGIN    
--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione SELL_CARD;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <ss_club_name>
--Altrimenti il nome del club <s_club_name> sara' quello dell'utente.
--In breve l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
    SELECT
        IS_ADMIN(SS_CLUB_NAME, USER)
    INTO S_CLUB_NAME
    FROM
        DUAL;

--La funzione card_in_club, controlla che il club identificato dal nome <s_club_name> possieda la carta identificata dal <s_card_code>
-- se n1 != 0 il club possiede la carta, altrimenti no.
    SELECT
        CARD_IN_CLUB(S_CARD_CODE, S_CLUB_NAME)
    INTO N1
    FROM
        DUAL;

--Se <n1 = 0>, la carta con codice carta <s_card_code> non e' stata trovata.
    IF N1 = 0 THEN
        RAISE NO_CARD_FOUND;
    ELSE 
--Vediamo di che tipologia e' la carta, per poi vedere se il prezzo e' nel range.
        SELECT
            COUNT(PLAYER_ID),
            COUNT(CONSUMABLE_ID),
            COUNT(CLUB_ITEM_ID),
            COUNT(MANAGER_ID)
        INTO
            P_ID,
            C_ID,
            CT_ID,
            M_ID
        FROM
            CLUB_CARD
        WHERE
            CARD_CODE = S_CARD_CODE;

--Se la carta e' di tipo <player>.
        IF P_ID != 0 THEN
            SELECT
                MIN_PRICE,
                MAX_PRICE
            INTO
                PRICE_MIN,
                PRICE_MAX
            FROM
                PLAYER
            WHERE
                CARD_ID IN (
                    SELECT
                        PLAYER_ID
                    FROM
                        CLUB_CARD
                    WHERE
                        CARD_CODE = S_CARD_CODE
                );

--Se la carta e' di tipo <consumable>.
        ELSIF C_ID != 0 THEN
            SELECT
                MIN_PRICE,
                MAX_PRICE
            INTO
                PRICE_MIN,
                PRICE_MAX
            FROM
                CONSUMABLE
            WHERE
                CARD_ID IN (
                    SELECT
                        CONSUMABLE_ID
                    FROM
                        CLUB_CARD
                    WHERE
                        CARD_CODE = S_CARD_CODE
                );

--Se la carta e' di tipo <club_item>.
        ELSIF CT_ID != 0 THEN
            SELECT
                MIN_PRICE,
                MAX_PRICE
            INTO
                PRICE_MIN,
                PRICE_MAX
            FROM
                CLUB_ITEM
            WHERE
                CARD_ID IN (
                    SELECT
                        CLUB_ITEM_ID
                    FROM
                        CLUB_CARD
                    WHERE
                        CARD_CODE = S_CARD_CODE
                );

--Se la carta e' di tipo <manager>.
        ELSIF M_ID != 0 THEN
            SELECT
                MIN_PRICE,
                MAX_PRICE
            INTO
                PRICE_MIN,
                PRICE_MAX
            FROM
                MANAGER
            WHERE
                CARD_ID IN (
                    SELECT
                        MANAGER_ID
                    FROM
                        CLUB_CARD
                    WHERE
                        CARD_CODE = S_CARD_CODE
                );

        END IF;

--Se il prezzo è minore del minimo, il nuovo prezzo sarà uguale al minimo.
        IF S_PRICE < PRICE_MIN THEN
            SS_PRICE := PRICE_MIN;

--Se il prezzo è maggiore del massimo, il nuovo prezzo sara' uguale al massimo.
        ELSIF S_PRICE > PRICE_MAX THEN
            SS_PRICE := PRICE_MAX;
        ELSE
--Altrimenti il prezzo rimane invariato.
            SS_PRICE := S_PRICE;
        END IF;

--Genero un nuovo id per la transazione.
        TR_ID := DBMS_RANDOM.STRING('a',8);

--Inserisco la carta in vendita.
        INSERT INTO TRANSACTION (
            TRANSACTION_ID,
            T_DATE,
            TRANSITION_S_CLUB_NAME,
            T_CARD_CODE,
            PRICE,
            DURATION
        )
            SELECT
                TR_ID,
                TO_DATE(SYSDATE, 'DD/MM/YYYY HH24:MI:SS'),
                S_CLUB_NAME,
                S_CARD_CODE,
                SS_PRICE,
                S_DURATION
            FROM
                DUAL;        

--Confermo
        COMMIT;
    END IF;

EXCEPTION
    WHEN NO_CARD_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'Selling error!');
END SELL_CARD;
/
