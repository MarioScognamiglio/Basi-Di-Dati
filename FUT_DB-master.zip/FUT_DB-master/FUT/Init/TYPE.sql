--Array usato nella funzione MODULE_POSITIONS come paramentro di output
CREATE OR REPLACE TYPE ARRAY_POS_T IS
    VARRAY(11) OF VARCHAR2(3);
/