
--CLUB_ITEM - 12
INSERT INTO CLUB_ITEM VALUES (1,'Kit','Juventus','Gold',250,5000);
INSERT INTO CLUB_ITEM VALUES (2,'Kit','Crotone','Silver',350,5000);
INSERT INTO CLUB_ITEM VALUES (3,'Kit','Vibonese','Bronze',350,5000);
INSERT INTO CLUB_ITEM VALUES (4,'Ball','Cosmos','Gold',350,5000);
INSERT INTO CLUB_ITEM VALUES (5,'Ball','Adidas UCL Finale 18','Silver',450,5000);
INSERT INTO CLUB_ITEM VALUES (6,'Ball','Molten UEL','Bronze',450,5000);
INSERT INTO CLUB_ITEM VALUES (7,'Badge','Valencia CF','Gold',650,5000);
INSERT INTO CLUB_ITEM VALUES (8,'Badge','LOSC Lille','Silver',650,5000);
INSERT INTO CLUB_ITEM VALUES (9,'Badge','Brescia','Bronze',550,5000);
INSERT INTO CLUB_ITEM VALUES (10,'Stadium','Old Trafford','Gold',150,5000);
INSERT INTO CLUB_ITEM VALUES (11,'Stadium','San Siro','Gold',150,5000);
INSERT INTO CLUB_ITEM VALUES (12,'Stadium','Anfield','Silver',150,5000);

--DIVISION_RIVALS - 10
INSERT INTO DIVISION_RIVALS VALUES (1,2400,500,500);
INSERT INTO DIVISION_RIVALS VALUES (2,2200,400,250);
INSERT INTO DIVISION_RIVALS VALUES (3,1900,300,125);
INSERT INTO DIVISION_RIVALS VALUES (4,1600,250,80);
INSERT INTO DIVISION_RIVALS VALUES (5,1200,200,65);
INSERT INTO DIVISION_RIVALS VALUES (6,800,150,50);
INSERT INTO DIVISION_RIVALS VALUES (7,500,130,40);
INSERT INTO DIVISION_RIVALS VALUES (8,250,110,30);
INSERT INTO DIVISION_RIVALS VALUES (9,100,80,25);
INSERT INTO DIVISION_RIVALS VALUES (10,10,50,20);

--MANAGER
INSERT INTO MANAGER VALUES (1,'Jurgen','Kloop','Germany','ENG1','Gold',250,5000);
INSERT INTO MANAGER VALUES (2,'Roy','Hodgson','Englad','ENG1','Gold',250,5000);
INSERT INTO MANAGER VALUES (3,'Zinedine','Zidane','France','ESP1','Gold',250,5000);
INSERT INTO MANAGER VALUES (4,'Massimo','Allegri','Italy','ITA1','Gold',450,5000);
INSERT INTO MANAGER VALUES (5,'Jose','Mourinho','Portugal','ENG1','Gold',450,5000);
INSERT INTO MANAGER VALUES (6,'Ernesto','Valverde','Spain','ESP1','Gold',450,5000);
INSERT INTO MANAGER VALUES (7,'Gian Piero','Gasperini','Italy','ITA1','Gold',450,5000);
INSERT INTO MANAGER VALUES (8,'Davide','Nicola','Italy','ITA1','Silver',550,5000);
INSERT INTO MANAGER VALUES (9,'Carlo','Ancelotti','Italy','ENG1','Silver',550,5000);
INSERT INTO MANAGER VALUES (10,'Gino','Lettieri','Italy','POL1','Bronze',550,5000);
INSERT INTO MANAGER VALUES (11,'Maurizio','Sarri','Italy','ITA1','Gold',550,5000);
INSERT INTO MANAGER VALUES (12,'Fabio','Cannavaro','Italy','DEN1','Bronze',650,5000);
INSERT INTO MANAGER VALUES (13,'Mauricio','Pochettino','Argentina','ENG1','Gold',650,5000);
INSERT INTO MANAGER VALUES (14,'Thomas','Tuchel','Germany','FRA1','Silver',150,5000);
INSERT INTO MANAGER VALUES (15,'Sergio','Conceicao','Portugal','POR1','Bronze',150,5000);
INSERT INTO MANAGER VALUES (16,'Robert','Moreno','Spain','FRA1','Bronze',150,5000);
INSERT INTO MANAGER VALUES (17,'Sergej','Semak','Russian','RUS1','Bronze',150,5000);
INSERT INTO MANAGER VALUES (18,'Toshio','Matsuura','Japan','JAP1','Bronze',150,5000);
INSERT INTO MANAGER VALUES (19,'Takayuki','Morimoto','Japan','JAP1','Gold',150,5000);
INSERT INTO MANAGER VALUES (20,'Giacomo','Modica','Italy','UKR1','Silver',150,5000);

--PACK
INSERT INTO PACK VALUES ('Bronze Pack',2,3,4,3,0,0,12,1,400);
INSERT INTO PACK VALUES ('Premium Bronze Pack',4,2,4,2,0,0,12,1,750);
INSERT INTO PACK VALUES ('Silver Pack',2,3,4,3,0,12,0,1,2500);
INSERT INTO PACK VALUES ('Premium Silver Pack',4,2,4,2,0,12,0,1,3750);
INSERT INTO PACK VALUES ('Gold Pack',2,3,4,3,12,0,0,1,5000);
INSERT INTO PACK VALUES ('Premium Gold Pack',4,2,4,2,12,0,0,1,7500);
INSERT INTO PACK VALUES ('Bronze Player Pack',12,0,0,0,0,0,12,1,1250);
INSERT INTO PACK VALUES ('Silver Player Pack',12,0,0,0,0,12,0,0,5000);
INSERT INTO PACK VALUES ('Gold Player Pack',12,0,0,0,12,0,0,1,12500);
INSERT INTO PACK VALUES ('Consumable Pack',0,12,0,0,12,0,0,1,3000);
INSERT INTO PACK VALUES ('Ultimate Pack',30,0,0,0,30,0,0,0,125000);
INSERT INTO PACK VALUES ('Rare Mega Pack',9,13,4,4,30,0,0,1,55000);
INSERT INTO PACK VALUES ('Jumbo Gold Pack',6,6,6,6,24,0,0,1,10000);
INSERT INTO PACK VALUES ('TOTY',30,0,0,0,20,10,0,1,125000);
INSERT INTO PACK VALUES ('Rainbow Gold Pack',10,4,2,0,10,4,2,1,10000);
INSERT INTO PACK VALUES ('Lol Silver Pack',10,4,2,0,4,10,2,1,10000);

--CONSUMABLES
INSERT INTO CONSUMABLE VALUES (1,'Bronze','Player','Contract',0,8,2,1,450,5000);
INSERT INTO CONSUMABLE VALUES (2,'Silver','Player','Contract',0,10,10,8,450,5000);
INSERT INTO CONSUMABLE VALUES (3,'Gold','Player','Contract',0,15,11,13,450,5000);
INSERT INTO CONSUMABLE VALUES (4,'Bronze','Player','Contract',0,15,6,3,450,5000);
INSERT INTO CONSUMABLE VALUES (5,'Silver','Player','Contract',0,20,24,18,450,5000);
INSERT INTO CONSUMABLE VALUES (6,'Gold', 'Player','Contract',0,28,24,28,450,5000);
INSERT INTO CONSUMABLE VALUES (7,'Bronze','Manager','Contract',0,8,2,1,450,5000);
INSERT INTO CONSUMABLE VALUES (8,'Silver','Manager','Contract',0,8,10,8,450,5000);
INSERT INTO CONSUMABLE VALUES (9,'Gold','Manager','Contract',0,11,11,13,450,5000);
INSERT INTO CONSUMABLE VALUES (10,'Bronze','Manager','Contract',0,15,6,3,450,5000);
INSERT INTO CONSUMABLE VALUES (11,'Silver','Manager','Contract',0,18,24,18,450,5000);
INSERT INTO CONSUMABLE VALUES (12,'Gold','Manager','Contract',0,24,24,28,450,5000);
INSERT INTO CONSUMABLE VALUES (13,'Bronze','Player','Fitness',20,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (14,'Silver','Player','Fitness',40,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (15,'Gold','Player','Fitness',60,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (16,'Bronze','Squad','Fitness',10,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (17,'Silver','Squad','Fitness',20,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (18,'Gold','Squad','Fitness',30,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (19,'Bronze','Head','Healing',1,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (20,'Silver','Head','Healing',2,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (21,'Gold','Head','Healing',5,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (22,'Bronze','UpperBody','Healing',1,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (23,'Silver','UpperBody','Healing',2,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (24,'Gold','UpperBody','Healing',5,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (25,'Bronze','Arm','Healing',1,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (26,'Silver','Arm','Healing',2,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (27,'Gold','Arm','Healing',5,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (28,'Bronze','Knee','Healing',1,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (29,'Silver','Knee','Healing',2,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (30,'Gold','Knee','Healing',5,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (31,'Bronze','Leg','Healing',1,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (32,'Silver','Leg','Healing',2,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (33,'Gold','Leg','Healing',5,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (34,'Bronze','Foot','Healing',1,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (35,'Silver','Foot','Healing',2,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (36,'Gold','Foot','Healing',5,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (37,'Bronze','All','Healing',1,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (38,'Silver','All','Healing',2,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (39,'Gold','All','Healing',4,0,0,0,450,5000);
INSERT INTO CONSUMABLE VALUES (40,'Bronze','DIV','GKTraining',5,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (41,'Silver','DIV','GKTraining',10,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (42,'Gold','DIV','GKTraining',15,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (43,'Bronze','HAN','GKTraining',5,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (44,'Silver','HAN','GKTraining',10,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (45,'Gold','HAN','GKTraining',15,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (46,'Bronze','KIC','GKTraining',5,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (47,'Silver','KIC','GKTraining',10,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (48,'Gold','KIC','GKTraining',15,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (49,'Bronze','SPD','GKTraining',5,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (50,'Silver','SPD','GKTraining',10,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (51,'Gold','SPD','GKTraining',15,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (52,'Bronze','POS','GKTraining',5,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (53,'Silver','POS','GKTraining',10,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (54,'Gold','POS','GKTraining',15,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (55,'Bronze','REF','GKTraining',5,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (56,'Silver','REF','GKTraining',10,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (57,'Gold','REF','GKTraining',15,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (58,'Bronze','ALL','GKTraining',3,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (59,'Silver','ALL','GKTraining',6,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (60,'Gold','ALL','GKTraining',10,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (61,'Bronze','PAC','Training',5,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (62,'Silver','PAC','Training',10,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (63,'Gold','PAC','Training',15,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (64,'Bronze','SHO','Training',5,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (65,'Silver','SHO','Training',10,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (66,'Gold','SHO','Training',15,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (67,'Bronze','PAS','Training',5,0,0,0,350,5000);
INSERT INTO CONSUMABLE VALUES (68,'Silver','PAS','Training',10,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (69,'Gold','PAS','Training',15,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (70,'Bronze','DRI','Training',5,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (71,'Silver','DRI','Training',10,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (72,'Gold','DRI','Training',15,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (73,'Bronze','PHY','Training',5,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (74,'Silver','PHY','Training',10,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (75,'Gold','PHY','Training',15,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (76,'Bronze','DEF','Training',5,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (77,'Silver','DEF','Training',10,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (78,'Gold','DEF','Training',15,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (79,'Bronze','ALL','Training',3,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (80,'Silver','ALL','Training',6,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (81,'Gold','ALL','Training',10,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (82,'Gold','LWBLB','Positioning',0,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (83,'Gold','LBLWB','Positioning',0,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (84,'Gold','RWBRB','Positioning',0,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (85,'Gold','RBRWB','Positioning',0,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (86,'Gold','LMLW','Positioning',0,0,0,0,650,5000);
INSERT INTO CONSUMABLE VALUES (87,'Gold','RMRW','Positioning',0,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (88,'Gold','LWLM','Positioning',0,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (89,'Gold','RWRM','Positioning',0,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (90,'Gold','LWLF','Positioning',0,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (91,'Gold','RWRF','Positioning',0,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (92,'Gold','LFLW','Positioning',0,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (93,'Gold','RFRW','Positioning',0,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (94,'Gold','CMCAM','Positioning',0,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (95,'Gold','CAMCM','Positioning',0,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (96,'Gold','CDMCM','Positioning',0,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (97,'Gold','CMCDM','Positioning',0,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (98,'Gold','CAMCF','Positioning',0,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (99,'Gold','CFCAM','Positioning',0,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (100,'Gold','CFST','Positioning',0,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (101,'Gold','STCF','Positioning',0,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (102,'Gold','DEN1','Manager League',1,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (103,'Gold','BEL1','Manager League',4,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (104,'Gold','NED1','Manager League',10,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (105,'Gold','ENG1','Manager League',13,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (106,'Gold','ENG2','Manager League',14,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (107,'Gold','FRA1','Manager League',16,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (108,'Gold','FRA2','Manager League',17,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (109,'Gold','GER1','Manager League',19,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (110,'Gold','GER2','Manager League',20,0,0,0,250,5000);
INSERT INTO CONSUMABLE VALUES (111,'Gold','ITA1','Manager League',31,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (112,'Gold','ITA2','Manager League',32,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (113,'Gold','MLS','Manager League',39,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (114,'Gold','NOR1','Manager League',41,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (115,'Gold','SPFL','Manager League',50,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (116,'Gold','ESP1','Manager League',53,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (117,'Gold','ESP2','Manager League',54,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (118,'Gold','SWE1','Manager League',56,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (119,'Gold','ENG3','Manager League',60,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (120,'Gold','ENG4','Manager League',61,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (121,'Gold','GRE1','Manager League',63,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (122,'Gold','IRL1','Manager League',65,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (123,'Gold','POL1','Manager League',66,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (124,'Gold','RUS1','Manager League',67,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (125,'Gold','TUR1','Manager League',68,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (126,'Gold','AUT1','Manager League',80,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (127,'Gold','KOR1','Manager League',83,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (128,'Gold','SUI1','Manager League',10,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (129,'Gold','POR1','Manager League',10,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (130,'Gold','UKR1','Manager League',10,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (131,'Gold','CHI1','Manager League',10,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (132,'Gold','COL1','Manager League',10,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (133,'Gold','MEX1','Manager League',10,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (134,'Gold','RSA1','Manager League',10,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (135,'Gold','SAU1','Manager League',10,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (136,'Gold','AUS1','Manager League',10,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (137,'Gold','ARG1','Manager League',10,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (138,'Gold','LGD','Manager League',10,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (139,'Gold','FIN1','Manager League',10,0,0,0,150,5000);
INSERT INTO CONSUMABLE VALUES (140,'Gold','JPN1','Manager League',10,0,0,0,150,5000);

--PLAYER
INSERT INTO PLAYER VALUES (1,'Pele','Edson Arantes Nascimento','Gold - Rare','Icon',98,'Icons','Icons','Brazil','CAM','1940-10-23',95,96,96,93,60,76,0,0,0,0,0,0,'Right',4,5,70,77,77,79,79,77,91,95,95,96,96,96,96,96,96,95,617000,11700000
);
INSERT INTO PLAYER VALUES (2,'Maradona','Diego Maradona','Gold - Rare','Icon',97,'Icons','Icons','Argentina','CAM','1960-10-30',92,97,93,92,40,76,0,0,0,0,0,0,'Left',3,5,57,66,66,71,71,69,88,93,93,95,94,94,94,94,94,90,400000,7600000
);
INSERT INTO PLAYER VALUES (3,'Ronaldo','Ronaldo Luis Nazario de Lima','Gold - Rare','Icon',96,'Icons','Icons','Brazil','ST','1976-09-22',97,95,95,81,45,76,0,0,0,0,0,0,'Right',5,5,60,67,67,70,70,66,83,90,90,91,94,94,94,92,92,94,1330000,15000000
);
INSERT INTO PLAYER VALUES (4,'Maldini','Paolo Maldini','Gold - Rare','Icon',94,'Icons','Icons','Italy','CB','1968-06-26',86,69,56,75,96,83,0,0,0,0,0,0,'Right',4,2,92,89,89,87,87,88,76,73,73,70,68,68,68,69,69,70,473000,9000000
);
INSERT INTO PLAYER VALUES (5,'Yashin','Lev Yashin','Gold - Rare','Icon',94,'Icons','Icons','Russia','GK','1929-10-22',0,0,0,0,0,0,95,96,89,65,75,95,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,89000,1700000
);
INSERT INTO PLAYER VALUES (6,'Ronaldinho','Ronaldo de Assis Moreira','Gold - Rare','Icon',94,'Icons','Icons','Brazil','LW','1980-03-21',92,95,90,91,37,81,0,0,0,0,0,0,'Right',4,5,55,63,63,69,69,66,86,92,92,93,92,92,92,93,93,88,554000,10500000
);
INSERT INTO PLAYER VALUES (7,'Van Basten','Marco van Basten','Gold - Rare','Icon',93,'Icons','Icons','Holland','ST','1964-10-31',83,89,94,76,39,75,0,0,0,0,0,0,'Right',4,3,56,62,62,65,65,62,79,85,85,86,90,90,90,87,87,92,150000,3000000
);
INSERT INTO PLAYER VALUES (8,'Matthaus','Lothar Matthaus','Gold - Rare','Icon',93,'Icons','Icons','Germany','CM','1961-03-21',89,82,89,90,90,85,0,0,0,0,0,0,'Right',4,3,88,90,90,90,90,91,91,87,87,88,88,88,88,86,86,87,250000,5000000
);
INSERT INTO PLAYER VALUES (9,'Best','George Best','Gold - Rare','Icon',93,'Icons','Icons','Northern Ireland','RW','1946-05-22',93,94,91,84,58,71,0,0,0,0,0,0,'Right',4,4,66,74,74,77,77,72,85,90,90,90,91,91,91,92,92,90,203000,3800000
);
INSERT INTO PLAYER VALUES (10,'Gullit','Ruud Gullit','Gold - Rare','Icon',93,'Icons','Icons','Holland','CF','1962-09-01',86,89,91,91,82,90,0,0,0,0,0,0,'Right',5,4,85,86,86,87,87,88,92,91,91,91,92,92,92,90,90,92,1030000,15000000
);
INSERT INTO PLAYER VALUES (11,'Baresi','Franco Baresi','Gold - Rare','Icon',93,'Icons','Icons','Italy','CB','1960-05-08',70,72,49,76,95,82,0,0,0,0,0,0,'Right',3,2,91,87,87,85,85,89,79,71,71,71,67,67,67,67,67,65,70000,1100000
);
INSERT INTO PLAYER VALUES (12,'Henry','Thierry Henry','Gold - Rare','Icon',93,'Icons','Icons','France','ST','1977-08-17',94,90,91,83,53,80,0,0,0,0,0,0,'Right',4,4,64,71,71,73,73,70,83,89,89,89,91,91,91,90,90,91,271000,5100000
);
INSERT INTO PLAYER VALUES (13,'Puyol','Carles Puyol Saforcada','Gold - Rare','Icon',92,'Icons','Icons','Spain','CB','1978-04-13',70,58,45,68,94,90,0,0,0,0,0,0,'Right',3,2,91,84,84,81,81,84,69,64,64,60,59,59,59,59,59,62,69000,1300000
);
INSERT INTO PLAYER VALUES (14,'Luis Figo','Luis Filipe Madeira Caeiro Figo','Gold - Rare','Icon',92,'Icons','Icons','Portugal','RW','1972-11-04',92,92,88,89,41,80,0,0,0,0,0,0,'Right',4,4,57,66,66,71,71,68,85,91,91,91,90,90,90,92,92,87,117000,2200000
);
INSERT INTO PLAYER VALUES (15,'Del Piero','Alessandro Del Piero','Gold - Rare','Icon',92,'Icons','Icons','Italy','CF','1974-11-09',83,92,92,89,43,67,0,0,0,0,0,0,'Right',5,4,56,65,65,70,70,66,85,90,90,91,92,92,92,91,91,88,132000,2500000
);
INSERT INTO PLAYER VALUES (16,'Lineker','Gary Lineker','Gold - Rare','Icon',92,'Icons','Icons','England','ST','1960-11-30',88,86,91,73,36,76,0,0,0,0,0,0,'Right',4,3,54,60,60,63,63,61,78,84,84,85,88,88,88,85,85,90,75500,1400000
);
INSERT INTO PLAYER VALUES (17,'Moore','Bobby Moore','Gold - Rare','Icon',92,'Icons','Icons','England','CB','1941-04-12',68,78,64,83,93,85,0,0,0,0,0,0,'Right',3,2,90,88,88,87,87,91,85,77,77,78,75,75,75,74,74,74,69000,800000
);
INSERT INTO PLAYER VALUES (18,'Butragueno','Emilio Butragueno Santos','Gold - Rare','Icon',92,'Icons','Icons','Spain','ST','1963-07-22',94,92,90,80,41,68,0,0,0,0,0,0,'Right',5,3,55,64,64,67,67,62,81,88,88,89,91,91,91,90,90,90,175000,3500000
);
INSERT INTO PLAYER VALUES (19,'Cannavaro','Fabio Cannavaro','Gold - Rare','Icon',92,'Icons','Icons','Italy','CB','1973-09-13',80,68,43,63,95,85,0,0,0,0,0,0,'Right',3,2,90,85,85,81,81,83,68,64,64,62,61,61,61,62,62,61,125000,2000000
);
INSERT INTO PLAYER VALUES (20,'Van Nistelrooy','Ruud van Nistelrooy','Gold - Rare','Icon',92,'Icons','Icons','Holland','ST','1976-07-01',86,85,91,74,37,82,0,0,0,0,0,0,'Right',3,3,56,60,60,63,63,59,75,83,83,83,87,87,87,85,85,90,69000,1000000
);
INSERT INTO PLAYER VALUES (21,'Giggs','Ryan Giggs','Gold - Rare','Icon',92,'Icons','Icons','Wales','LM','1973-11-29',90,91,80,90,44,67,0,0,0,0,0,0,'Left',2,3,55,68,68,73,73,68,84,90,90,88,87,87,87,89,89,82,78500,1500000
);
INSERT INTO PLAYER VALUES (22,'Zanetti','Javier Zanetti','Gold - Rare','Icon',92,'Icons','Icons','Argentina','RB','1973-08-10',86,85,63,88,90,81,0,0,0,0,0,0,'Right',4,2,87,91,91,91,91,90,87,86,86,83,81,81,81,83,83,78,80000,1500000
);
INSERT INTO PLAYER VALUES (23,'Bergkamp','Dennis Bergkamp','Gold - Rare','Icon',92,'Icons','Icons','Holland','CF','1969-05-10',84,90,91,86,37,78,0,0,0,0,0,0,'Right',4,4,55,63,63,67,67,65,84,89,89,90,91,91,91,90,90,88,110000,2100000
);
INSERT INTO PLAYER VALUES (24,'Nesta','Alessandro Nesta','Gold - Rare','Icon',92,'Icons','Icons','Italy','CB','1976-03-19',72,67,42,65,94,86,0,0,0,0,0,0,'Right',3,2,90,83,83,81,81,85,71,66,66,64,63,63,63,62,62,62,69000,1200000
);
INSERT INTO PLAYER VALUES (25,'Schmeichel','Peter Schmeichel','Gold - Rare','Icon',92,'Icons','Icons','Denmark','GK','1963-11-18',0,0,0,0,0,0,92,94,87,52,88,90,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,69000,700000
);
INSERT INTO PLAYER VALUES (26,'Stoichkov','Hristo Stoichkov','Gold - Rare','Icon',92,'Icons','Icons','Bulgaria','ST','1966-02-08',92,92,93,86,50,86,0,0,0,0,0,0,'Left',3,4,65,70,70,73,73,72,85,90,90,90,91,91,91,91,91,90,159000,3000000
);
INSERT INTO PLAYER VALUES (27,'Laudrup','Michael Laudrup','Gold - Rare','Icon',91,'Icons','Icons','Denmark','CAM','1964-06-15',85,92,79,90,38,64,0,0,0,0,0,0,'Right',4,4,51,62,62,67,67,63,83,89,89,89,87,87,87,89,89,82,68500,700000
);
INSERT INTO PLAYER VALUES (28,'Scholes','Paul Scholes','Gold - Rare','Icon',91,'Icons','Icons','England','CM','1974-11-16',72,80,87,91,64,82,0,0,0,0,0,0,'Right',3,3,71,74,74,77,77,80,89,86,86,87,86,86,86,84,84,85,68500,800000
);
INSERT INTO PLAYER VALUES (29,'Blanc','Laurent Blanc','Gold - Rare','Icon',91,'Icons','Icons','France','CB','1965-11-19',79,78,69,70,92,86,0,0,0,0,0,0,'Right',3,2,89,85,85,83,83,87,78,75,75,74,74,74,74,73,73,76,125000,2000000
);
INSERT INTO PLAYER VALUES (30,'Ronaldo','C. Ronaldo dos Santos Aveiro','Gold - Rare','Normal',93,'Piemonte Calcio','Serie A TIM','Portugal','ST','1985-02-05',90,89,93,82,35,78,0,0,0,0,0,0,'Right',4,5,54,61,61,65,65,62,81,88,88,89,91,91,91,90,90,91,88500,1700000
);
INSERT INTO PLAYER VALUES (31,'Chiellini','Giorgio Chiellini','Gold - Rare','Normal',89,'Piemonte Calcio','Serie A TIM','Italy','CB','1984-08-14',68,62,46,58,90,82,0,0,0,0,0,0,'Left',3,2,86,77,77,74,74,77,62,58,58,56,56,56,56,56,56,59,4100,75000
);
INSERT INTO PLAYER VALUES (32,'Dybala','Paulo Dybala','Gold - Rare','Normal',88,'Piemonte Calcio','Serie A TIM','Argentina','CAM','1993-11-15',83,90,82,84,43,64,0,0,0,0,0,0,'Left',3,4,54,64,64,68,68,64,81,85,85,86,85,85,85,86,86,81,2900,55000
);
INSERT INTO PLAYER VALUES (33,'Sandro','Alex Sandro Lobo Silva','Gold - Rare','Normal',85,'Piemonte Calcio','Serie A TIM','Brazil','LB','1991-01-26',83,80,65,77,82,82,0,0,0,0,0,0,'Left',3,3,81,83,83,83,83,81,78,78,78,76,76,76,76,77,77,74,3600,65000
);
INSERT INTO PLAYER VALUES (34,'Bonucci','Leonardo Bonucci','Gold - Rare','Normal',86,'Piemonte Calcio','Serie A TIM','Italy','CB','1987-05-01',58,71,58,69,87,79,0,0,0,0,0,0,'Right',4,2,84,76,76,74,74,82,75,65,65,68,65,65,65,63,63,65,1900,35000
);
INSERT INTO PLAYER VALUES (35,'Pjanic','Miralem Pjanic','Gold - Rare','Normal',86,'Piemonte Calcio','Serie A TIM','Bosnia and Herzegovina','CM','1990-04-02',68,85,68,87,75,67,0,0,0,0,0,0,'Right',4,3,73,77,77,79,79,81,84,80,80,82,78,78,78,79,79,72,1900,35000
);
INSERT INTO PLAYER VALUES (36,'Matuidi','Blaise Matuidi','Gold - Rare','Normal',85,'Piemonte Calcio','Serie A TIM','France','CDM','1987-04-09',75,78,66,76,83,81,0,0,0,0,0,0,'Left',2,2,82,82,82,82,82,83,79,77,77,76,75,75,75,75,75,73,1400,25000
);
INSERT INTO PLAYER VALUES (37,'Szczesny','Wojciech Szczesny','Gold - Rare','Normal',86,'Piemonte Calcio','Serie A TIM','Poland','GK','1990-04-18',0,0,0,0,0,0,85,88,82,49,73,86,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1800,32500
);
INSERT INTO PLAYER VALUES (38,'Cancelo','Joao Pedro Cavaco Cancelo','Gold - Rare','Normal',84,'Manchester City','Premier League','Portugal','RB','1994-05-27',90,84,65,80,78,71,0,0,0,0,0,0,'Right',3,4,76,83,83,84,84,79,80,82,82,80,79,79,79,81,81,75,1600,30000
);
INSERT INTO PLAYER VALUES (39,'Reus','Marco Reus','Gold - Rare','Normal',88,'Borussia Dortmund','Bundesliga','Germany','CAM','1989-05-31',85,87,88,84,45,66,0,0,0,0,0,0,'Right',4,4,55,65,65,69,69,66,81,85,85,86,86,86,86,86,86,82,5500,100000
);
INSERT INTO PLAYER VALUES (40,'Witsel','Axel Witsel','Gold - Rare','Normal',85,'Borussia Dortmund','Bundesliga','Belgium','CDM','1989-01-12',73,80,74,80,83,81,0,0,0,0,0,0,'Right',4,4,82,81,81,81,81,83,83,79,79,80,79,79,79,78,78,78,1300,25000
);
INSERT INTO PLAYER VALUES (41,'De Gea','David De Gea Quintana','Gold - Rare','Normal',89,'Manchester United','Premier League','Spain','GK','1990-11-07',0,0,0,0,0,0,90,92,84,57,81,85,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4100,75000
);
INSERT INTO PLAYER VALUES (42,'Pogba','Paul Pogba','Gold - Rare','Normal',88,'Manchester United','Premier League','France','CM','1993-03-15',74,85,81,86,66,86,0,0,0,0,0,0,'Right',4,5,73,74,74,76,76,78,85,84,84,84,83,83,83,82,82,82,17250,330000
);
INSERT INTO PLAYER VALUES (43,'Lukaku','Romelu Lukaku','Gold - Rare','Normal',85,'Inter','Serie A TIM','Belgium','ST','1993-05-13',75,72,82,73,35,84,0,0,0,0,0,0,'Left',4,3,53,55,55,58,58,57,71,76,76,76,78,78,78,76,76,82,1000,19000
);
INSERT INTO PLAYER VALUES (44,'De Bruyne','Kevin De Bruyne','Gold - Rare','Normal',91,'Manchester City','Premier League','Belgium','CAM','1991-06-28',76,87,86,92,61,78,0,0,0,0,0,0,'Right',5,4,67,73,73,77,77,77,88,88,88,89,87,87,87,87,87,83,18000,340000
);
INSERT INTO PLAYER VALUES (45,'Aguero','Sergio Aguero','Gold - Rare','Normal',89,'Manchester City','Premier League','Argentina','ST','1988-06-02',80,88,90,77,33,74,0,0,0,0,0,0,'Right',4,4,51,57,57,61,61,58,77,84,84,86,88,88,88,86,86,87,7900,150000
);
INSERT INTO PLAYER VALUES (46,'Silva','David Josue Jimenez Silva','Gold - Rare','Normal',88,'Manchester City','Premier League','Spain','CAM','1986-01-08',65,89,74,88,52,57,0,0,0,0,0,0,'Left',2,4,57,64,64,69,69,70,84,84,84,86,83,83,83,83,83,76,3300,60000
);
INSERT INTO PLAYER VALUES (47,'Ederson','Ederson Santana de Moraes','Gold - Rare','Normal',88,'Manchester City','Premier League','Brazil','GK','1993-08-17',0,0,0,0,0,0,86,88,82,64,93,86,'Left',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3300,60000
);
INSERT INTO PLAYER VALUES (48,'Fernandinho','Fernando Luiz Rosa','Gold - Rare','Normal',87,'Manchester City','Premier League','Brazil','CDM','1985-05-04',66,79,74,79,84,79,0,0,0,0,0,0,'Right',4,3,82,80,80,80,80,85,82,77,77,78,77,77,77,76,76,75,2500,47500
);
INSERT INTO PLAYER VALUES (49,'Sane','Leroy Sane','Gold - Rare','Normal',86,'Manchester City','Premier League','Germany','LW','1996-01-11',95,86,81,79,38,70,0,0,0,0,0,0,'Left',3,4,52,61,61,65,65,59,75,84,84,83,84,84,84,85,85,83,5400,100000
);
INSERT INTO PLAYER VALUES (50,'Sterling','Raheem Sterling','Gold - Rare','Normal',88,'Manchester City','Premier League','England','RW','1994-12-08',93,89,79,78,45,57,0,0,0,0,0,0,'Right',3,4,52,65,65,69,69,63,78,85,85,86,86,86,86,87,87,79,5100,95000
);
INSERT INTO PLAYER VALUES (51,'Mahrez','Riyad Mahrez','Gold - Rare','Normal',84,'Manchester City','Premier League','Algeria','RW','1991-02-21',84,89,78,79,38,59,0,0,0,0,0,0,'Left',4,5,47,58,58,63,63,60,76,82,82,83,82,82,82,83,83,76,750,14000
);
INSERT INTO PLAYER VALUES (52,'Silva','Bernardo Mota Carvalho e Silva','Gold - Rare','Normal',87,'Manchester City','Premier League','Portugal','RW','1994-08-10',81,92,76,83,51,67,0,0,0,0,0,0,'Left',3,4,58,68,68,72,72,70,82,86,86,86,84,84,84,86,86,78,2600,47500
);
INSERT INTO PLAYER VALUES (53,'Walker','Kyle Walker','Gold - Rare','Normal',84,'Manchester City','Premier League','England','RB','1990-05-28',91,77,63,76,81,81,0,0,0,0,0,0,'Right',2,2,80,83,83,83,83,80,77,78,78,74,75,75,75,76,76,73,2900,55000
);
INSERT INTO PLAYER VALUES (54,'Laporte','Aymeric Laporte','Gold - Rare','Normal',87,'Manchester City','Premier League','France','CB','1994-05-27',64,69,50,71,88,82,0,0,0,0,0,0,'Left',3,2,85,80,80,78,78,83,74,68,68,68,66,66,66,65,65,66,2500,45000
);
INSERT INTO PLAYER VALUES (55,'Jesus','Gabriel Fernando de Jesus','Gold - Rare','Normal',82,'Manchester City','Premier League','Brazil','ST','1997-04-03',85,86,80,72,39,71,0,0,0,0,0,0,'Right',3,4,52,57,57,61,61,59,74,81,81,81,83,83,83,82,82,81,700,10000
);
INSERT INTO PLAYER VALUES (56,'Mendy','Benjamin Mendy','Gold - Rare','Normal',80,'Manchester City','Premier League','France','LB','1994-07-17',81,77,51,77,77,77,0,0,0,0,0,0,'Left',3,3,77,79,79,80,80,77,75,76,76,74,72,72,72,74,74,67,650,10000
);
INSERT INTO PLAYER VALUES (57,'Messi','Lionel Messi','Gold - Rare','Normal',94,'FC Barcelona','LaLiga Santander','Argentina','RW','1987-06-24',87,96,92,92,39,66,0,0,0,0,0,0,'Left',4,4,53,63,63,68,68,66,87,92,92,94,93,93,93,93,93,89,96000,1800000
);
INSERT INTO PLAYER VALUES (58,'Suarez','Luis Suarez','Gold - Rare','Normal',89,'FC Barcelona','LaLiga Santander','Uruguay','ST','1987-01-24',73,84,89,80,51,84,0,0,0,0,0,0,'Right',4,3,63,64,64,67,67,68,79,83,83,84,85,85,85,84,84,86,4100,75000
);
INSERT INTO PLAYER VALUES (59,'Ter Stegen','Marc-Andre ter Stegen','Gold - Rare','Normal',90,'FC Barcelona','LaLiga Santander','Germany','GK','1992-04-30',0,0,0,0,0,0,88,90,85,43,88,88,'Right',4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5100,95000
);
INSERT INTO PLAYER VALUES (60,'Coutinho','Philippe Coutinho Correia','Gold - Rare','Normal',86,'FC Bayern Munchen','Bundesliga','Brazil','LW','1992-06-12',79,90,80,84,52,64,0,0,0,0,0,0,'Right',4,5,58,66,66,70,70,69,82,84,84,86,84,84,84,85,85,78,1900,35000
);
INSERT INTO PLAYER VALUES (61,'Busquets','Sergio Busquets Burgos','Gold - Rare','Normal',89,'FC Barcelona','LaLiga Santander','Spain','CDM','1988-07-16',42,81,62,80,85,80,0,0,0,0,0,0,'Right',3,3,82,78,78,79,79,86,84,76,76,78,75,75,75,73,73,71,4100,75000
);
INSERT INTO PLAYER VALUES (62,'Rakitic','Ivan Rakitic','Gold - Rare','Normal',86,'FC Barcelona','LaLiga Santander','Croatia','CM','1988-03-10',62,81,81,86,74,70,0,0,0,0,0,0,'Right',4,3,72,76,76,78,78,80,83,80,80,82,80,80,80,79,79,77,1800,32500
);
INSERT INTO PLAYER VALUES (63,'Pique','Gerard Pique Bernabeu','Gold - Rare','Normal',88,'FC Barcelona','LaLiga Santander','Spain','CB','1987-02-02',56,69,61,72,88,80,0,0,0,0,0,0,'Right',3,2,85,79,79,77,77,84,77,70,70,71,70,70,70,68,68,70,3500,65000
);
INSERT INTO PLAYER VALUES (64,'Alba','Jordi Alba Ramos','Gold - Rare','Normal',87,'FC Barcelona','LaLiga Santander','Spain','LB','1989-03-21',90,83,69,81,79,73,0,0,0,0,0,0,'Left',3,3,78,84,84,85,85,81,82,84,84,82,81,81,81,83,83,77,3200,60000
);
INSERT INTO PLAYER VALUES (65,'Umtiti','Samuel Umtiti','Gold - Rare','Normal',86,'FC Barcelona','LaLiga Santander','France','CB','1993-11-14',69,70,63,69,86,82,0,0,0,0,0,0,'Left',3,2,84,79,79,78,78,81,73,68,68,68,68,68,68,66,66,69,2000,37500
);
INSERT INTO PLAYER VALUES (66,'Hazard','Eden Hazard','Gold - Rare','Normal',91,'Real Madrid','LaLiga Santander','Belgium','LW','1991-01-07',91,94,83,86,35,66,0,0,0,0,0,0,'Right',4,4,49,61,61,66,66,63,83,89,89,90,89,89,89,89,89,84,21250,400000
);
INSERT INTO PLAYER VALUES (67,'Kante','N''Golo Kante','Gold - Rare','Normal',89,'Chelsea','Premier League','France','CDM','1991-03-29',78,81,65,77,87,83,0,0,0,0,0,0,'Right',3,2,84,85,85,85,85,87,83,79,79,79,77,77,77,77,77,73,26000,490000
);
INSERT INTO PLAYER VALUES (68,'Jorginho','Luiz Frello Filho Jorge','Gold - Rare','Normal',83,'Chelsea','Premier League','Italy','CM','1991-12-20',55,81,63,84,70,73,0,0,0,0,0,0,'Right',3,3,71,73,73,76,76,79,82,77,77,78,74,74,74,74,74,68,700,10000
);
INSERT INTO PLAYER VALUES (69,'Giroud','Olivier Giroud','Gold - Rare','Normal',82,'Chelsea','Premier League','France','ST','1986-09-30',46,73,81,71,42,79,0,0,0,0,0,0,'Left',3,3,57,53,53,55,55,60,71,71,71,75,77,77,77,73,73,80,700,10000
);
INSERT INTO PLAYER VALUES (70,'Emerson','Emerson Palmieri dos Santos','Gold - Non-Rare','Normal',77,'Chelsea','Premier League','Italy','LB','1994-08-03',79,78,59,68,74,62,0,0,0,0,0,0,'Left',3,3,71,76,76,76,76,73,71,73,73,70,71,71,71,72,72,67,350,10000
);
INSERT INTO PLAYER VALUES (71,'Lewandowski','Robert Lewandowski','Gold - Rare','Normal',89,'FC Bayern Munchen','Bundesliga','Poland','ST','1988-08-21',77,85,87,74,41,82,0,0,0,0,0,0,'Right',4,4,58,58,58,61,61,63,77,81,81,83,85,85,85,83,83,86,4200,80000
);
INSERT INTO PLAYER VALUES (72,'Neuer','Manuel Neuer','Gold - Rare','Normal',88,'FC Bayern Munchen','Bundesliga','Germany','GK','1986-03-27',0,0,0,0,0,0,87,87,87,56,91,85,'Right',4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3300,60000
);
INSERT INTO PLAYER VALUES (73,'Hummels','Mats Hummels','Gold - Rare','Normal',87,'Borussia Dortmund','Bundesliga','Germany','CB','1988-12-16',51,73,58,76,89,76,0,0,0,0,0,0,'Right',3,3,85,79,79,77,77,84,77,69,69,71,69,69,69,67,67,68,2600,47500
);
INSERT INTO PLAYER VALUES (74,'Rodriguez','James Rodriguez','Gold - Rare','Normal',85,'Real Madrid','LaLiga Santander','Colombia','CAM','1991-07-12',55,86,86,87,50,63,0,0,0,0,0,0,'Left',2,4,57,63,63,67,67,68,81,81,81,83,82,82,82,82,82,79,1200,21000
);
INSERT INTO PLAYER VALUES (75,'Thiago','Thiago Alcantara','Gold - Rare','Normal',87,'FC Bayern Munchen','Bundesliga','Spain','CM','1991-04-11',69,90,74,85,69,63,0,0,0,0,0,0,'Right',3,5,70,76,76,78,78,79,85,83,83,85,82,82,82,83,83,76,2500,45000
);
INSERT INTO PLAYER VALUES (76,'Muller','Thomas Muller','Gold - Rare','Normal',86,'FC Bayern Munchen','Bundesliga','Germany','CAM','1989-09-13',72,78,83,79,55,71,0,0,0,0,0,0,'Right',4,3,63,68,68,70,70,69,80,81,81,82,83,83,83,81,81,82,1800,35000
);
INSERT INTO PLAYER VALUES (77,'Kimmich','Joshua Kimmich','Gold - Rare','Normal',86,'FC Bayern Munchen','Bundesliga','Germany','RB','1995-02-08',72,84,69,86,79,78,0,0,0,0,0,0,'Right',4,3,79,82,82,83,83,83,84,83,83,82,80,80,80,81,81,76,2000,37500
);
INSERT INTO PLAYER VALUES (78,'Alaba','David Alaba','Gold - Rare','Normal',85,'FC Bayern Munchen','Bundesliga','Austria','LB','1992-06-24',83,80,73,81,80,76,0,0,0,0,0,0,'Left',4,3,79,82,82,82,82,80,80,80,80,79,78,78,78,79,79,77,1900,35000
);
INSERT INTO PLAYER VALUES (79,'Sule','Niklas Sule','Gold - Rare','Normal',85,'FC Bayern Munchen','Bundesliga','Germany','CB','1995-09-03',72,51,42,55,86,82,0,0,0,0,0,0,'Right',3,2,83,75,75,71,71,77,63,54,54,54,54,54,54,51,51,57,1400,27500
);
INSERT INTO PLAYER VALUES (80,'Salah','Mohamed Salah','Gold - Rare','Normal',90,'Liverpool','Premier League','Egypt','RW','1992-06-15',93,89,86,81,45,74,0,0,0,0,0,0,'Left',3,4,58,67,67,71,71,67,82,87,87,88,88,88,88,88,88,85,15500,290000
);
INSERT INTO PLAYER VALUES (81,'Firmino','Roberto Firmino Barbosa de Oliveira','Gold - Rare','Normal',86,'Liverpool','Premier League','Brazil','CF','1991-10-02',77,87,82,80,61,78,0,0,0,0,0,0,'Right',4,4,67,70,70,72,72,73,82,84,84,85,85,85,85,84,84,83,1900,35000
);
INSERT INTO PLAYER VALUES (82,'Mane','Sadio Mane','Gold - Rare','Normal',88,'Liverpool','Premier League','Senegal','LW','1992-04-10',94,88,83,77,44,74,0,0,0,0,0,0,'Right',4,4,58,64,64,67,67,64,79,86,86,86,87,87,87,87,87,86,19250,360000
);
INSERT INTO PLAYER VALUES (83,'Van Dijk','Virgil van Dijk','Gold - Rare','Normal',90,'Liverpool','Premier League','Holland','CB','1991-07-08',77,72,60,70,90,86,0,0,0,0,0,0,'Right',3,2,88,81,81,79,79,84,75,70,70,70,69,69,69,67,67,70,50000,950000
);
INSERT INTO PLAYER VALUES (84,'Fabinho','Fabio Henrique Tavares','Gold - Rare','Normal',85,'Liverpool','Premier League','Brazil','CDM','1993-10-23',68,77,69,78,85,83,0,0,0,0,0,0,'Right',2,3,83,82,82,82,82,84,81,77,77,76,75,75,75,75,75,74,1500,27500
);
INSERT INTO PLAYER VALUES (85,'Alisson','Alisson Ramses Becker','Gold - Rare','Normal',89,'Liverpool','Premier League','Brazil','GK','1992-10-02',0,0,0,0,0,0,85,89,84,52,85,90,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4100,80000
);
INSERT INTO PLAYER VALUES (86,'Robertson','Andrew Robertson','Gold - Rare','Normal',85,'Liverpool','Premier League','Scotland','LB','1994-03-11',85,79,62,77,80,75,0,0,0,0,0,0,'Left',2,3,77,83,83,84,84,80,78,80,80,77,76,76,76,78,78,72,3200,60000
);
INSERT INTO PLAYER VALUES (87,'Kane','Harry Kane','Gold - Rare','Normal',89,'Tottenham Hotspur','Premier League','England','ST','1993-07-28',70,81,91,79,47,83,0,0,0,0,0,0,'Right',4,3,61,62,62,65,65,66,79,82,82,83,85,85,85,82,82,87,4100,75000
);
INSERT INTO PLAYER VALUES (88,'Eriksen','Christian Eriksen','Gold - Rare','Normal',88,'Tottenham Hotspur','Premier League','Denmark','CAM','1992-02-14',73,84,81,90,53,63,0,0,0,0,0,0,'Right',5,4,57,67,67,72,72,72,86,85,85,86,84,84,84,84,84,79,3300,60000
);
INSERT INTO PLAYER VALUES (89,'Lloris','Hugo Lloris','Gold - Rare','Normal',88,'Tottenham Hotspur','Premier League','France','GK','1986-12-26',0,0,0,0,0,0,89,91,82,64,68,84,'Left',1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3200,60000
);
INSERT INTO PLAYER VALUES (90,'Vertonghen','Jan Vertonghen','Gold - Rare','Normal',87,'Tottenham Hotspur','Premier League','Belgium','CB','1987-04-24',63,73,63,74,87,79,0,0,0,0,0,0,'Left',3,3,85,81,81,80,80,82,75,71,71,70,70,70,70,69,69,69,2600,47500
);
INSERT INTO PLAYER VALUES (91,'Alderweireld','Toby Alderweireld','Gold - Rare','Normal',87,'Tottenham Hotspur','Premier League','Belgium','CB','1989-03-02',64,67,55,72,88,79,0,0,0,0,0,0,'Right',3,2,85,80,80,79,79,83,74,68,68,67,66,66,66,65,65,66,2500,47500
);
INSERT INTO PLAYER VALUES (92,'Son','Heung Min Son','Gold - Rare','Normal',87,'Tottenham Hotspur','Premier League','Korea Republic','CF','1992-07-08',88,87,86,80,42,68,0,0,0,0,0,0,'Right',5,4,54,63,63,67,67,63,79,85,85,85,86,86,86,86,86,84,28000,550000
);
INSERT INTO PLAYER VALUES (93,'Sanchez','Davinson Sanchez','Gold - Rare','Normal',83,'Tottenham Hotspur','Premier League','Colombia','CB','1996-06-12',74,67,45,57,83,81,0,0,0,0,0,0,'Right',3,2,82,76,76,73,73,78,66,62,62,61,60,60,60,59,59,61,700,10000
);
INSERT INTO PLAYER VALUES (94,'Aubameyang','Pierre-Emerick Aubameyang','Gold - Rare','Normal',88,'Arsenal','Premier League','Gabon','ST','1989-06-18',94,80,85,75,37,69,0,0,0,0,0,0,'Right',4,4,52,61,61,64,64,58,74,82,82,81,84,84,84,83,83,85,10250,190000
);
INSERT INTO PLAYER VALUES (95,'Lacazette','Alexandre Lacazette','Gold - Rare','Normal',86,'Arsenal','Premier League','France','ST','1991-05-28',82,86,85,75,40,74,0,0,0,0,0,0,'Right',4,4,55,60,60,63,63,62,77,82,82,83,84,84,84,83,83,84,1900,35000
);
INSERT INTO PLAYER VALUES (96,'Modric','Luka Modric','Gold - Rare','Normal',90,'Real Madrid','LaLiga Santander','Croatia','CM','1985-09-09',74,90,76,89,72,66,0,0,0,0,0,0,'Right',4,4,72,79,79,82,82,82,87,85,85,87,83,83,83,85,85,77,5100,95000
);
INSERT INTO PLAYER VALUES (97,'Ramos','Sergio Ramos Garcia','Gold - Rare','Normal',89,'Real Madrid','LaLiga Santander','Spain','CB','1986-03-30',72,74,68,75,87,85,0,0,0,0,0,0,'Right',3,3,87,83,83,81,81,84,78,74,74,74,73,73,73,72,72,75,7000,130000
);
INSERT INTO PLAYER VALUES (98,'Courtois','Thibaut Courtois','Gold - Rare','Normal',88,'Real Madrid','LaLiga Santander','Belgium','GK','1992-05-11',0,0,0,0,0,0,85,87,89,48,72,85,'Left',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3200,60000
);
INSERT INTO PLAYER VALUES (99,'Kroos','Toni Kroos','Gold - Rare','Normal',88,'Real Madrid','LaLiga Santander','Germany','CM','1990-01-04',45,81,80,90,70,69,0,0,0,0,0,0,'Right',5,3,70,72,72,75,75,79,85,79,79,82,79,79,79,78,78,76,3300,60000
);
INSERT INTO PLAYER VALUES (100,'Isco','Francisco Roman Alarcon Suarez','Gold - Rare','Normal',86,'Real Madrid','LaLiga Santander','Spain','CAM','1992-04-21',71,90,77,83,59,60,0,0,0,0,0,0,'Right',3,4,62,67,67,70,70,71,81,82,82,84,82,82,82,83,83,76,1900,35000
);
INSERT INTO PLAYER VALUES (101,'Marcelo','Marcelo Vieira da Silva','Gold - Rare','Normal',85,'Real Madrid','LaLiga Santander','Brazil','LB','1988-05-12',81,89,74,83,77,79,0,0,0,0,0,0,'Left',4,5,79,82,82,83,83,81,83,84,84,84,83,83,83,84,84,81,1600,30000
);
INSERT INTO PLAYER VALUES (102,'Casemiro','Carlos Henrique Venancio Casimiro','Gold - Rare','Normal',87,'Real Madrid','LaLiga Santander','Brazil','CDM','1992-02-23',62,72,72,75,85,89,0,0,0,0,0,0,'Right',3,2,85,80,80,79,79,84,80,73,73,75,74,74,74,71,71,74,2500,47500
);
INSERT INTO PLAYER VALUES (103,'Navas','Keylor Navas','Gold - Rare','Normal',87,'Real Madrid','LaLiga Santander','Costa Rica','GK','1986-12-15',0,0,0,0,0,0,90,90,81,54,75,82,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2500,50000
);
INSERT INTO PLAYER VALUES (104,'Varane','Raphael Varane','Gold - Rare','Normal',85,'Real Madrid','LaLiga Santander','France','CB','1993-04-25',83,64,45,62,85,80,0,0,0,0,0,0,'Right',3,2,83,78,78,75,75,79,70,64,64,65,63,63,63,62,62,63,14750,280000
);
INSERT INTO PLAYER VALUES (105,'Carvajal','Daniel Carvajal Ramos','Gold - Rare','Normal',85,'Real Madrid','LaLiga Santander','Spain','RB','1992-01-11',81,81,47,78,82,80,0,0,0,0,0,0,'Right',3,3,81,83,83,84,84,82,78,78,78,75,73,73,73,75,75,68,1800,32500
);
INSERT INTO PLAYER VALUES (106,'Benzema','Karim Benzema','Gold - Rare','Normal',87,'Real Madrid','LaLiga Santander','France','CF','1987-12-19',76,86,82,80,39,77,0,0,0,0,0,0,'Right',4,4,54,58,58,62,62,62,78,83,83,84,85,85,85,83,83,84,2500,45000
);
INSERT INTO PLAYER VALUES (107,'Fernandez','Jose Ignacio Fernandez Iglesias','Gold - Rare','Normal',82,'Real Madrid','LaLiga Santander','Spain','CB','1990-01-18',74,65,37,66,81,79,0,0,0,0,0,0,'Right',4,2,80,79,79,77,77,77,66,64,64,60,59,59,59,61,61,58,700,10000
);
INSERT INTO PLAYER VALUES (108,'Vazquez','Lucas Vazquez Iglesias','Gold - Rare','Normal',81,'Real Madrid','LaLiga Santander','Spain','RW','1991-07-01',82,81,73,79,58,69,0,0,0,0,0,0,'Right',4,4,63,71,71,74,74,71,78,81,81,80,80,80,80,80,80,76,650,10000
);
INSERT INTO PLAYER VALUES (109,'Donnarumma','Gianluigi Donnarumma','Gold - Rare','Normal',85,'Milan','Serie A TIM','Italy','GK','1999-02-25',0,0,0,0,0,0,90,90,80,49,74,80,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1500,27500
);
INSERT INTO PLAYER VALUES (110,'Fernandes','Bruno Miguel Borges Fernandes','Gold - Rare','Normal',85,'Sporting CP','Liga NOS','Portugal','CAM','1994-09-08',77,85,83,87,65,74,0,0,0,0,0,0,'Right',4,4,68,75,75,78,78,77,85,84,84,84,83,83,83,83,83,79,1300,24000
);
INSERT INTO PLAYER VALUES (111,'Insigne','Lorenzo Insigne','Gold - Rare','Normal',87,'Napoli','Serie A TIM','Italy','CF','1991-06-04',89,91,79,85,35,47,0,0,0,0,0,0,'Right',4,4,44,59,59,64,64,58,79,86,86,87,86,86,86,87,87,79,2600,47500
);
INSERT INTO PLAYER VALUES (112,'Mertens','Dries Mertens','Gold - Rare','Normal',87,'Napoli','Serie A TIM','Belgium','CF','1987-05-06',88,90,83,80,35,53,0,0,0,0,0,0,'Right',4,4,47,60,60,65,65,60,79,85,85,86,86,86,86,87,87,79,2400,45000
);
INSERT INTO PLAYER VALUES (113,'Koulibaly','Kalidou Koulibaly','Gold - Rare','Normal',89,'Napoli','Serie A TIM','Senegal','CB','1991-06-20',71,68,28,54,89,87,0,0,0,0,0,0,'Right',3,2,87,77,77,74,74,80,65,60,60,59,58,58,58,56,56,57,3500,65000
);
INSERT INTO PLAYER VALUES (114,'Allan','Allan Marques Loureiro','Gold - Rare','Normal',85,'Napoli','Serie A TIM','Brazil','CM','1991-01-08',75,84,71,78,85,84,0,0,0,0,0,0,'Right',3,4,83,84,84,84,84,86,84,81,81,81,80,80,80,80,80,76,1400,25000
);
INSERT INTO PLAYER VALUES (115,'Manolas','Kostas Manolas','Gold - Rare','Normal',85,'Napoli','Serie A TIM','Greece','CB','1991-06-14',82,62,25,42,86,81,0,0,0,0,0,0,'Right',2,2,83,76,76,72,72,74,56,54,54,50,50,50,50,51,51,52,1200,23000
);
INSERT INTO PLAYER VALUES (116,'Neymar','Neymar da Silva Santos Jr.','Gold - Rare','Normal',92,'Paris Saint-Germain','Ligue 1 Conforama','Brazil','LW','1992-02-05',91,95,85,87,32,58,0,0,0,0,0,0,'Right',5,5,47,61,61,67,67,61,83,90,90,90,90,90,90,91,91,84,69000,1300000
);
INSERT INTO PLAYER VALUES (117,'Cavani','Edinson Cavani','Gold - Rare','Normal',88,'Paris Saint-Germain','Ligue 1 Conforama','Uruguay','ST','1987-02-14',75,79,86,72,55,83,0,0,0,0,0,0,'Right',4,3,66,66,66,68,68,67,75,79,79,80,83,83,83,81,81,85,3100,60000
);
INSERT INTO PLAYER VALUES (118,'Silva','Thiago Emiliano da Silva','Gold - Rare','Normal',87,'Paris Saint-Germain','Ligue 1 Conforama','Brazil','CB','1984-09-22',62,73,54,72,87,78,0,0,0,0,0,0,'Right',3,2,84,79,79,78,78,82,76,69,69,70,68,68,68,66,66,66,2600,47500
);
INSERT INTO PLAYER VALUES (119,'Mbappe','Kylian Mbappe','Gold - Rare','Normal',89,'Paris Saint-Germain','Ligue 1 Conforama','France','ST','1998-12-20',96,90,84,78,39,75,0,0,0,0,0,0,'Right',4,5,55,63,63,67,67,62,78,87,87,86,88,88,88,88,88,87,81000,1500000
);
INSERT INTO PLAYER VALUES (120,'Verratti','Marco Verratti','Gold - Rare','Normal',86,'Paris Saint-Germain','Ligue 1 Conforama','Italy','CM','1992-11-05',65,90,60,84,79,66,0,0,0,0,0,0,'Right',4,4,76,79,79,81,81,84,84,81,81,82,77,77,77,79,79,69,1800,32500
);
INSERT INTO PLAYER VALUES (121,'Marquinhos','Marcos Aoas Correa','Gold - Rare','Normal',86,'Paris Saint-Germain','Ligue 1 Conforama','Brazil','CB','1994-05-14',74,71,41,73,86,77,0,0,0,0,0,0,'Right',3,3,84,82,82,80,80,82,75,71,71,69,66,66,66,67,67,63,2100,40000
);
INSERT INTO PLAYER VALUES (122,'Di Maria','angel Di Maria','Gold - Rare','Normal',86,'Paris Saint-Germain','Ligue 1 Conforama','Argentina','RW','1988-02-14',84,87,79,84,48,68,0,0,0,0,0,0,'Left',2,5,57,66,66,70,70,67,80,84,84,84,83,83,83,84,84,78,1900,35000
);
INSERT INTO PLAYER VALUES (123,'Draxler','Julian Draxler','Gold - Rare','Normal',83,'Paris Saint-Germain','Ligue 1 Conforama','Germany','CAM','1993-09-20',77,86,79,81,55,63,0,0,0,0,0,0,'Right',5,4,61,67,67,70,70,69,80,81,81,82,82,82,82,82,82,79,700,10000
);
INSERT INTO PLAYER VALUES (124,'Godin','Diego Godin','Gold - Rare','Normal',88,'Inter','Serie A TIM','Uruguay','CB','1986-02-16',60,63,48,64,89,83,0,0,0,0,0,0,'Right',3,2,86,77,77,75,75,80,68,62,62,62,61,61,61,59,59,63,3200,60000
);
INSERT INTO PLAYER VALUES (125,'Oblak','Jan Oblak','Gold - Rare','Normal',91,'Atletico Madrid','LaLiga Santander','Slovenia','GK','1993-01-07',0,0,0,0,0,0,87,89,92,50,78,90,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5800,110000
);
INSERT INTO PLAYER VALUES (126,'Griezmann','Antoine Griezmann','Gold - Rare','Normal',89,'FC Barcelona','LaLiga Santander','France','CF','1991-03-21',81,89,86,84,57,72,0,0,0,0,0,0,'Left',3,4,65,71,71,73,73,71,83,87,87,87,87,87,87,87,87,86,7300,140000
);
INSERT INTO PLAYER VALUES (127,'Koke','Jorge Resurreccion','Gold - Rare','Normal',85,'Atletico Madrid','LaLiga Santander','Spain','RM','1992-01-08',68,82,75,86,74,79,0,0,0,0,0,0,'Right',4,3,75,78,78,80,80,82,85,83,83,83,81,81,81,81,81,77,1200,22000
);
INSERT INTO PLAYER VALUES (128,'Saul','Saul niguez Esclapez','Gold - Rare','Normal',85,'Atletico Madrid','LaLiga Santander','Spain','CM','1994-11-21',70,81,78,79,78,78,0,0,0,0,0,0,'Left',4,3,78,78,78,79,79,81,83,80,80,81,81,81,81,79,79,80,1700,30000
);
INSERT INTO PLAYER VALUES (129,'Gimenez','Jose Maria Gimenez','Gold - Rare','Normal',85,'Atletico Madrid','LaLiga Santander','Uruguay','CB','1995-01-20',69,56,45,52,86,82,0,0,0,0,0,0,'Right',3,2,84,75,75,72,72,75,58,54,54,52,53,53,53,52,52,57,1300,24000
);
INSERT INTO PLAYER VALUES (130,'Adan','Antonio Adan Garrido','Gold - Non-Rare','Normal',81,'Atletico Madrid','LaLiga Santander','Spain','GK','1987-05-13',0,0,0,0,0,0,79,81,82,55,78,82,'Left',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (131,'Savic','Stefan Savic','Gold - Rare','Normal',82,'Atletico Madrid','LaLiga Santander','Montenegro','CB','1991-01-08',55,58,35,54,84,72,0,0,0,0,0,0,'Right',3,2,81,71,71,68,68,75,61,53,53,54,52,52,52,51,51,53,700,10000
);
INSERT INTO PLAYER VALUES (132,'Rodri','Rodrigo Hernandez Cascante','Gold - Rare','Normal',85,'Manchester City','Premier League','Spain','CDM','1996-06-22',67,78,68,77,82,80,0,0,0,0,0,0,'Right',4,3,80,78,78,78,78,82,81,76,76,78,76,76,76,75,75,74,1200,22000
);
INSERT INTO PLAYER VALUES (133,'Immobile','Ciro Immobile','Gold - Rare','Normal',86,'Lazio','Serie A TIM','Italy','ST','1990-02-20',80,81,85,63,39,76,0,0,0,0,0,0,'Right',4,3,55,58,58,60,60,58,71,77,77,78,82,82,82,79,79,84,1700,30000
);
INSERT INTO PLAYER VALUES (134,'Milinkovic-Savic','Sergej Milinkovic-Savic','Gold - Rare','Normal',85,'Lazio','Serie A TIM','Serbia','CM','1995-02-27',67,82,79,80,77,84,0,0,0,0,0,0,'Right',4,4,79,76,76,77,77,81,84,80,80,82,82,82,82,79,79,81,1300,23000
);
INSERT INTO PLAYER VALUES (135,'Kjaer','Simon Kjaer','Gold - Non-Rare','Normal',82,'Sevilla FC','LaLiga Santander','Denmark','CB','1989-03-26',65,56,55,63,81,78,0,0,0,0,0,0,'Right',3,2,80,74,74,71,71,76,64,59,59,58,58,58,58,56,56,62,350,10000
);
INSERT INTO PLAYER VALUES (136,'Gomez','Sergi Gomez Sola','Gold - Non-Rare','Normal',80,'Sevilla FC','LaLiga Santander','Spain','CB','1992-03-28',64,64,41,65,81,75,0,0,0,0,0,0,'Right',2,2,79,73,73,72,72,77,70,63,63,64,61,61,61,60,60,59,350,10000
);
INSERT INTO PLAYER VALUES (137,'Asenjo','Sergio Asenjo Andres','Gold - Rare','Normal',82,'Villarreal CF','LaLiga Santander','Spain','GK','1989-06-28',0,0,0,0,0,0,84,81,82,57,77,80,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,700,10000
);
INSERT INTO PLAYER VALUES (138,'Falcao','Radamel Falcao Garcia Zarate','Gold - Rare','Normal',83,'AS Monaco Football Club SA','Ligue 1 Conforama','Colombia','ST','1986-02-10',65,77,82,69,43,72,0,0,0,0,0,0,'Right',4,3,56,55,55,57,57,59,71,73,73,77,79,79,79,76,76,81,1900,35000
);
INSERT INTO PLAYER VALUES (139,'Handanovic','Samir Handanovic','Gold - Rare','Normal',88,'Inter','Serie A TIM','Slovenia','GK','1984-07-14',0,0,0,0,0,0,88,89,85,53,69,89,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3300,60000
);
INSERT INTO PLAYER VALUES (140,'Icardi','Mauro Icardi','Gold - Rare','Normal',85,'Inter','Serie A TIM','Argentina','ST','1993-02-19',75,77,84,61,36,69,0,0,0,0,0,0,'Right',4,3,51,51,51,53,53,53,67,73,73,76,80,80,80,76,76,83,3500,70000
);
INSERT INTO PLAYER VALUES (141,'Skriniar','Milan Skriniar','Gold - Rare','Normal',86,'Inter','Serie A TIM','Slovakia','CB','1995-02-11',69,66,41,59,87,82,0,0,0,0,0,0,'Right',4,2,84,77,77,74,74,79,67,62,62,61,59,59,59,58,58,59,1800,35000
);
INSERT INTO PLAYER VALUES (142,'Hermoso','Mario Hermoso Canseco','Gold - Rare','Normal',80,'Atletico Madrid','LaLiga Santander','Spain','CB','1995-06-18',79,71,49,72,79,77,0,0,0,0,0,0,'Left',3,2,79,78,78,77,77,78,72,71,71,69,67,67,67,68,68,65,650,10000
);
INSERT INTO PLAYER VALUES (143,'Mandi','Aissa Mandi','Gold - Rare','Normal',80,'Real Betis','LaLiga Santander','Algeria','CB','1991-10-22',66,71,46,74,81,72,0,0,0,0,0,0,'Right',3,2,79,77,77,76,76,77,73,70,70,69,66,66,66,68,68,64,650,10000
);
INSERT INTO PLAYER VALUES (144,'Sidnei','Sidnei Rechel da Silva Junior','Gold - Rare','Normal',80,'Real Betis','LaLiga Santander','Brazil','CB','1989-08-23',70,65,55,61,78,82,0,0,0,0,0,0,'Right',2,2,79,73,73,72,72,75,67,65,65,63,64,64,64,63,63,66,650,10000
);
INSERT INTO PLAYER VALUES (145,'Parejo','Daniel Parejo Munoz','Gold - Rare','Normal',86,'Valencia CF','LaLiga Santander','Spain','CM','1989-04-16',41,79,80,88,70,69,0,0,0,0,0,0,'Right',4,3,70,71,71,74,74,78,84,78,78,81,78,78,78,77,77,75,1800,35000
);
INSERT INTO PLAYER VALUES (146,'Ziyech','Hakim Ziyech','Gold - Rare','Normal',85,'Ajax','Eredivisie','Morocco','CAM','1993-03-19',80,83,75,86,50,66,0,0,0,0,0,0,'Left',2,4,57,66,66,70,70,70,82,83,83,83,81,81,81,82,82,76,1100,20000
);
INSERT INTO PLAYER VALUES (147,'De Ligt','Matthijs de Ligt','Gold - Rare','Normal',85,'Piemonte Calcio','Serie A TIM','Holland','CB','1999-08-12',67,69,58,66,83,84,0,0,0,0,0,0,'Right',4,2,83,76,76,75,75,79,71,66,66,66,66,66,66,64,64,67,1400,27500
);
INSERT INTO PLAYER VALUES (148,'De Jong','Frenkie de Jong','Gold - Rare','Normal',85,'FC Barcelona','LaLiga Santander','Holland','CM','1997-05-12',79,88,64,84,76,76,0,0,0,0,0,0,'Right',3,4,77,80,80,81,81,82,84,82,82,83,80,80,80,81,81,75,1200,22000
);
INSERT INTO PLAYER VALUES (149,'Pacheco','Fernando Pacheco Flores','Gold - Rare','Normal',82,'D. Alaves','LaLiga Santander','Spain','GK','1992-05-18',0,0,0,0,0,0,81,83,79,46,70,83,'Left',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,700,10000
);
INSERT INTO PLAYER VALUES (150,'Gomez','Alejandro Gomez','Gold - Rare','Normal',85,'Atalanta','Serie A TIM','Argentina','CAM','1988-02-15',89,86,78,81,39,55,0,0,0,0,0,0,'Right',4,4,48,60,60,65,65,61,76,83,83,83,82,82,82,84,84,75,1200,23000
);
INSERT INTO PLAYER VALUES (151,'Soria','David Soria Solis','Gold - Non-Rare','Normal',82,'Getafe CF','LaLiga Santander','Spain','GK','1993-04-04',0,0,0,0,0,0,83,83,81,43,71,82,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (152,'Ibrahimovic','Zlatan Ibrahimovic','Gold - Rare','Normal',85,'LA Galaxy','Major League Soccer','Sweden','ST','1981-10-03',56,78,88,77,34,78,0,0,0,0,0,0,'Right',4,5,53,51,51,54,54,58,74,76,76,80,81,81,81,78,78,83,950,18000
);
INSERT INTO PLAYER VALUES (153,'Masip','Jordi Masip Lopez','Gold - Rare','Normal',81,'R. Valladolid CF','LaLiga Santander','Spain','GK','1989-01-03',0,0,0,0,0,0,82,84,82,65,72,77,'Right',4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,650,10000
);
INSERT INTO PLAYER VALUES (154,'Dier','Eric Dier','Gold - Rare','Normal',79,'Tottenham Hotspur','Premier League','England','CDM','1994-01-15',54,65,63,71,80,84,0,0,0,0,0,0,'Right',3,2,81,74,74,72,72,78,71,65,65,66,65,65,65,64,64,67,650,10000
);
INSERT INTO PLAYER VALUES (155,'Vinicius','Vinicius Jose de Oliveira Junior','Gold - Rare','Normal',79,'Real Madrid','LaLiga Santander','Brazil','LW','2000-07-12',93,84,70,71,29,63,0,0,0,0,0,0,'Right',4,5,43,54,54,59,59,53,70,79,79,78,78,78,78,79,79,73,650,10000
);
INSERT INTO PLAYER VALUES (156,'Militao','eder Gabriel Militao','Gold - Rare','Normal',81,'Real Madrid','LaLiga Santander','Brazil','CB','1998-01-18',79,71,50,66,81,81,0,0,0,0,0,0,'Right',2,2,80,79,79,78,78,77,70,70,70,66,66,66,66,68,68,66,650,10000
);
INSERT INTO PLAYER VALUES (157,'Sancho','Jadon Sancho','Gold - Rare','Normal',84,'Borussia Dortmund','Bundesliga','England','RM','2000-03-25',88,90,72,77,36,60,0,0,0,0,0,0,'Right',4,5,47,60,60,65,65,59,75,83,83,83,82,82,82,84,84,75,700,13000
);
INSERT INTO PLAYER VALUES (158,'Wan-Bissaka','Aaron Wan-Bissaka','Gold - Rare','Normal',79,'Manchester United','Premier League','England','RB','1997-11-26',87,78,50,63,80,72,0,0,0,0,0,0,'Right',2,4,76,78,78,78,78,75,69,72,72,69,69,69,69,71,71,65,650,10000
);
INSERT INTO PLAYER VALUES (159,'Jovic','Luka Jovic','Gold - Rare','Normal',83,'Real Madrid','LaLiga Santander','Serbia','ST','1997-12-23',77,81,82,68,29,74,0,0,0,0,0,0,'Right',5,3,48,52,52,56,56,53,70,77,77,78,80,80,80,79,79,82,700,10000
);
INSERT INTO PLAYER VALUES (160,'Felix','Joao Felix Sequeira','Gold - Rare','Normal',80,'Atletico Madrid','LaLiga Santander','Portugal','CF','1999-11-10',82,81,80,74,40,70,0,0,0,0,0,0,'Right',4,5,53,60,60,63,63,60,74,79,79,79,80,80,80,80,80,79,650,10000
);
INSERT INTO PLAYER VALUES (161,'Pepe','Nicolas Pepe','Gold - Rare','Normal',83,'Arsenal','Premier League','Cote d''Ivoire','RM','1995-05-29',91,85,81,75,33,67,0,0,0,0,0,0,'Left',3,4,46,57,57,62,62,56,74,82,82,81,82,82,82,83,83,79,700,13000
);
INSERT INTO PLAYER VALUES (162,'Pukki','Teemu Pukki','Gold - Non-Rare','Normal',77,'Norwich City','Premier League','Finland','ST','1990-03-29',77,75,75,58,33,69,0,0,0,0,0,0,'Right',3,3,47,51,51,54,54,52,65,71,71,73,76,76,76,73,73,76,350,10000
);
INSERT INTO PLAYER VALUES (163,'Alonso','Marcos Alonso Mendoza','Gold - Rare','Normal',81,'Chelsea','Premier League','Spain','LB','1990-12-28',66,77,73,79,79,79,0,0,0,0,0,0,'Left',3,3,79,80,80,80,80,79,79,78,78,76,77,77,77,76,76,77,650,10000
);
INSERT INTO PLAYER VALUES (164,'Shaw','Luke Shaw','Gold - Rare','Normal',81,'Manchester United','Premier League','England','LB','1995-07-12',82,80,54,75,80,78,0,0,0,0,0,0,'Left',2,3,79,80,80,80,80,79,76,77,77,74,73,73,73,75,75,70,650,10000
);
INSERT INTO PLAYER VALUES (165,'Rose','Danny Rose','Gold - Rare','Normal',80,'Tottenham Hotspur','Premier League','England','LB','1990-07-02',77,79,62,74,80,75,0,0,0,0,0,0,'Left',3,3,79,79,79,80,80,78,75,76,76,74,73,73,73,75,75,70,650,10000
);
INSERT INTO PLAYER VALUES (166,'Monreal','Ignacio Monreal Eraso','Gold - Rare','Normal',79,'Arsenal','Premier League','Spain','LB','1986-02-26',63,74,61,71,80,68,0,0,0,0,0,0,'Left',3,3,77,77,77,76,76,76,72,71,71,70,70,70,70,70,70,68,1000,18000
);
INSERT INTO PLAYER VALUES (167,'KolaSinac','Sead KolaSinac','Gold - Rare','Normal',79,'Arsenal','Premier League','Bosnia and Herzegovina','LB','1993-06-20',75,72,62,72,75,87,0,0,0,0,0,0,'Left',2,3,78,77,77,77,77,76,73,74,74,72,72,72,72,72,72,72,650,10000
);
INSERT INTO PLAYER VALUES (168,'Angelino','Jose angel Esmoris Tasende','Gold - Rare','Normal',79,'Manchester City','Premier League','Spain','LB','1997-01-04',85,80,64,79,72,78,0,0,0,0,0,0,'Left',3,4,73,78,78,79,79,77,77,79,79,77,76,76,76,78,78,72,650,10000
);
INSERT INTO PLAYER VALUES (169,'Davies','Ben Davies','Gold - Non-Rare','Normal',79,'Tottenham Hotspur','Premier League','Wales','LB','1993-04-24',73,75,58,75,78,74,0,0,0,0,0,0,'Left',3,3,77,78,78,79,79,78,75,74,74,72,71,71,71,72,72,68,350,10000
);
INSERT INTO PLAYER VALUES (170,'Chilwell','Ben Chilwell','Gold - Non-Rare','Normal',79,'Leicester City','Premier League','England','LB','1996-12-21',78,77,49,71,76,75,0,0,0,0,0,0,'Left',3,3,75,78,78,78,78,75,72,74,74,69,69,69,69,70,70,66,350,10000
);
INSERT INTO PLAYER VALUES (171,'Bertrand','Ryan Bertrand','Gold - Non-Rare','Normal',78,'Southampton','Premier League','England','LB','1989-08-05',76,76,53,70,76,70,0,0,0,0,0,0,'Left',3,3,75,77,77,77,77,74,70,72,72,68,68,68,68,70,70,66,350,10000
);
INSERT INTO PLAYER VALUES (172,'Belozoglu','Emre Belozoglu','Gold - Rare','Normal',78,'Fenerbahce SK','Super Lig','Turkey','CM','1980-09-07',44,78,72,84,63,67,0,0,0,0,0,0,'Left',4,4,66,65,65,68,68,73,77,73,73,76,72,72,72,72,72,67,650,10000
);
INSERT INTO PLAYER VALUES (173,'Penneteau','Nicolas Penneteau','Silver - Rare','Normal',73,'Sporting Charleroi','Belgium Pro League','France','GK','1981-02-28',0,0,0,0,0,0,70,66,76,26,66,81,'Left',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (174,'Quaresma','Ricardo Andrade Quaresma Bernardo','Gold - Rare','Normal',81,'Besiktas JK','Super Lig','Portugal','RM','1983-09-26',77,86,73,82,24,63,0,0,0,0,0,0,'Right',4,5,41,50,50,57,57,54,73,80,80,80,79,79,79,81,81,73,650,10000
);
INSERT INTO PLAYER VALUES (175,'Defoe','Jermain Defoe','Gold - Rare','Normal',76,'Rangers FC','Scottish Premiership','England','ST','1982-10-07',67,76,82,60,26,56,0,0,0,0,0,0,'Right',4,3,41,44,44,47,47,46,62,69,69,72,75,75,75,72,72,75,650,10000
);
INSERT INTO PLAYER VALUES (176,'De Rossi','Daniele De Rossi','Gold - Rare','Normal',82,'Buenos Aires','SAF','Italy','CDM','1983-07-24',59,70,64,73,85,77,0,0,0,0,0,0,'Right',4,2,82,76,76,75,75,81,75,68,68,70,68,68,68,66,66,68,700,10000
);
INSERT INTO PLAYER VALUES (177,'Rodriguez','Maximiliano Rodriguez','Silver - Rare','Normal',74,'Newell''s Old Boys','SAF','Argentina','LM','1981-01-02',67,75,75,75,44,66,0,0,0,0,0,0,'Right',4,4,54,55,55,58,58,60,70,73,73,75,74,74,74,74,74,73,300,10000
);
INSERT INTO PLAYER VALUES (178,'Cifuentes','Alberto Cifuentes Martinez','Silver - Rare','Normal',73,'Cadiz CF','LaLiga 1 I 2 I 3','Spain','GK','1979-05-29',0,0,0,0,0,0,67,71,74,47,65,82,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (179,'Schweinsteiger','Bastian Schweinsteiger','Gold - Rare','Normal',76,'Chicago Fire Soccer Club','Major League Soccer','Germany','CB','1984-08-01',34,72,71,79,74,73,0,0,0,0,0,0,'Right',3,3,74,69,69,70,70,77,77,69,69,73,71,71,71,68,68,70,1800,32500
);
INSERT INTO PLAYER VALUES (180,'Yilmaz','Burak Yilmaz','Gold - Rare','Normal',79,'Besiktas JK','Super Lig','Turkey','ST','1985-07-15',80,69,81,65,34,77,0,0,0,0,0,0,'Right',3,3,51,53,53,56,56,54,65,72,72,72,75,75,75,74,74,78,650,10000
);
INSERT INTO PLAYER VALUES (181,'Kaldirim','Hasan Ali Kaldirim','Gold - Non-Rare','Normal',76,'Fenerbahce SK','Super Lig','Turkey','LB','1989-12-09',74,71,56,68,74,72,0,0,0,0,0,0,'Left',2,3,72,75,75,75,75,73,70,70,70,67,67,67,67,68,68,64,350,10000
);
INSERT INTO PLAYER VALUES (182,'Hutchinson','Atiba Hutchinson','Gold - Non-Rare','Normal',76,'Besiktas JK','Super Lig','Canada','CDM','1983-02-08',65,71,64,73,75,75,0,0,0,0,0,0,'Right',4,2,74,73,73,73,73,75,73,71,71,70,69,69,69,69,69,69,350,10000
);
INSERT INTO PLAYER VALUES (183,'Francis','Simon Francis','Gold - Non-Rare','Normal',75,'Bournemouth','Premier League','England','CB','1985-02-16',51,64,44,67,75,71,0,0,0,0,0,0,'Right',4,2,74,69,69,69,69,72,66,61,61,61,59,59,59,59,59,57,300,10000
);
INSERT INTO PLAYER VALUES (184,'Angulo','Igor Angulo Alboniga','Silver - Non-Rare','Normal',73,'Gornik Zabrze','Ekstraklasa','Spain','ST','1984-01-26',79,71,70,61,37,68,0,0,0,0,0,0,'Left',3,3,49,52,52,55,55,52,63,69,69,69,71,71,71,70,70,72,150,10000
);
INSERT INTO PLAYER VALUES (185,'Milner','James Milner','Gold - Rare','Normal',81,'Liverpool','Premier League','England','CM','1986-01-04',61,78,70,82,77,78,0,0,0,0,0,0,'Right',4,3,77,79,79,80,80,81,80,77,77,76,75,75,75,75,75,72,650,10000
);
INSERT INTO PLAYER VALUES (186,'Nani','Luis Carlos Almeida da Cunha','Gold - Rare','Normal',80,'Orlando City Soccer Club','Major League Soccer','Portugal','LW','1986-11-17',72,86,75,79,37,62,0,0,0,0,0,0,'Right',5,5,48,54,54,59,59,59,74,79,79,80,79,79,79,80,80,75,650,10000
);
INSERT INTO PLAYER VALUES (187,'Kompany','Vincent Kompany','Gold - Rare','Normal',83,'RSC Anderlecht','Belgium Pro League','Belgium','CB','1986-04-10',50,64,53,65,84,79,0,0,0,0,0,0,'Right',3,2,81,74,74,72,72,77,67,61,61,61,61,61,61,59,59,62,700,10000
);
INSERT INTO PLAYER VALUES (188,'Mirante','Antonio Mirante','Gold - Non-Rare','Normal',79,'Roma','Serie A TIM','Italy','GK','1983-07-08',0,0,0,0,0,0,80,78,78,44,65,79,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (189,'Mascherano','Javier Mascherano','Gold - Rare','Normal',80,'Hebei China Fortune FC','CSL','Argentina','CDM','1984-06-08',66,69,53,72,79,75,0,0,0,0,0,0,'Right',3,2,78,77,77,76,76,79,73,68,68,67,65,65,65,65,65,63,650,10000
);
INSERT INTO PLAYER VALUES (190,'Zabaleta','Pablo Zabaleta','Gold - Non-Rare','Normal',75,'West Ham United','Premier League','Argentina','RB','1985-01-16',49,72,56,70,79,70,0,0,0,0,0,0,'Right',3,3,77,73,73,72,72,75,70,67,67,67,66,66,66,66,66,65,300,10000
);
INSERT INTO PLAYER VALUES (191,'Pyatov','Andriy Pyatov','Gold - Non-Rare','Normal',77,'Shakhtar Donetsk','Ukraine Liga','Ukraine','GK','1984-06-28',0,0,0,0,0,0,75,78,69,44,82,80,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (192,'Barbosa','Mariano Barbosa','Gold - Non-Rare','Normal',75,'Villarreal CF','LaLiga Santander','Argentina','GK','1984-07-27',0,0,0,0,0,0,76,75,72,42,76,74,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (193,'Datolo','Jesus Datolo','Gold - Non-Rare','Normal',76,'Club Atletico Banfield','SAF','Argentina','CM','1984-05-19',61,77,76,80,51,60,0,0,0,0,0,0,'Left',3,4,56,61,61,65,65,65,75,75,75,77,76,76,76,75,75,73,350,10000
);
INSERT INTO PLAYER VALUES (194,'Tevez','Carlos Tevez','Gold - Non-Rare','Normal',78,'Buenos Aires','SAF','Argentina','CAM','1984-02-05',68,78,77,74,45,71,0,0,0,0,0,0,'Right',3,4,56,59,59,62,62,62,72,74,74,76,76,76,76,75,75,74,350,10000
);
INSERT INTO PLAYER VALUES (195,'Akinfeev','Igor Akinfeev','Gold - Rare','Normal',80,'CSKA Moscow','League of Russia','Russia','GK','1986-04-08',0,0,0,0,0,0,77,84,72,51,78,82,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,650,10000
);
INSERT INTO PLAYER VALUES (196,'Verhaegh','Paul Verhaegh','Silver - Rare','Normal',73,'FC Twente','Eredivisie','Holland','RB','1983-09-01',66,71,51,68,75,69,0,0,0,0,0,0,'Right',3,2,73,72,72,73,73,72,67,66,66,65,63,63,63,65,65,60,300,10000
);
INSERT INTO PLAYER VALUES (197,'ozcan','Ramazan ozcan','Gold - Non-Rare','Normal',75,'Bayer 04 Leverkusen','Bundesliga','Austria','GK','1984-06-28',0,0,0,0,0,0,73,75,71,52,71,76,'Left',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (198,'Clichy','Gael Clichy','Gold - Non-Rare','Normal',77,'Medipol Basaksehir FK','Super Lig','France','LB','1985-07-26',78,75,43,70,75,68,0,0,0,0,0,0,'Left',4,4,72,76,76,76,76,74,71,72,72,68,66,66,66,68,68,62,350,10000
);
INSERT INTO PLAYER VALUES (199,'Sand','Jose Sand','Gold - Non-Rare','Normal',76,'Club Atletico Lanus','SAF','Argentina','ST','1980-07-17',46,66,79,61,36,74,0,0,0,0,0,0,'Right',4,3,51,48,48,50,50,53,64,65,65,69,72,72,72,67,67,75,350,10000
);
INSERT INTO PLAYER VALUES (200,'Cvitanich','Dario Cvitanich','Gold - Non-Rare','Normal',77,'Racing Club','SAF','Argentina','ST','1984-05-16',60,75,76,71,37,69,0,0,0,0,0,0,'Right',3,3,52,53,53,56,56,57,70,72,72,75,76,76,76,74,74,76,350,10000
);
INSERT INTO PLAYER VALUES (201,'Eikrem','Magnus Wolff Eikrem','Gold - Non-Rare','Normal',75,'Molde FK','Eliteserien','Norway','CAM','1990-08-08',65,74,69,77,47,51,0,0,0,0,0,0,'Right',4,3,51,61,61,64,64,61,72,73,73,74,72,72,72,73,73,67,300,10000
);
INSERT INTO PLAYER VALUES (202,'Gignac','Andre-Pierre Gignac','Gold - Rare','Normal',80,'Tigres U.A.N.L.','LIGA Bancomer MX','France','ST','1985-12-05',69,72,82,71,43,83,0,0,0,0,0,0,'Right',3,3,57,56,56,59,59,60,70,73,73,74,76,76,76,74,74,78,650,10000
);
INSERT INTO PLAYER VALUES (203,'Lee Chung Yong','Chung Yong Lee','Silver - Rare','Normal',73,'VfL Bochum 1848','Bundesliga 2','Korea Republic','CAM','1988-07-02',68,75,64,71,53,61,0,0,0,0,0,0,'Right',3,3,56,62,62,64,64,63,70,72,72,72,71,71,71,71,71,67,300,10000
);
INSERT INTO PLAYER VALUES (204,'Snodgrass','Robert Snodgrass','Gold - Non-Rare','Normal',76,'West Ham United','Premier League','Scotland','RM','1987-09-07',61,77,74,77,47,71,0,0,0,0,0,0,'Left',3,3,56,60,60,63,63,64,73,75,75,75,74,74,74,75,75,71,350,10000
);
INSERT INTO PLAYER VALUES (205,'Talavera','Alfredo Talavera','Silver - Rare','Normal',74,'Deportivo Toluca','LIGA Bancomer MX','Mexico','GK','1982-09-18',0,0,0,0,0,0,79,77,70,58,70,70,'Right',4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (206,'Herrera','Hector Herrera','Gold - Rare','Normal',82,'Atletico Madrid','LaLiga Santander','Mexico','CM','1990-04-19',72,76,75,75,78,81,0,0,0,0,0,0,'Right',4,3,77,77,77,78,78,80,80,77,77,78,77,77,77,76,76,75,700,10000
);
INSERT INTO PLAYER VALUES (207,'Albiol','Raul Albiol Tortajada','Gold - Rare','Normal',83,'Villarreal CF','LaLiga Santander','Spain','CB','1985-09-04',48,64,41,61,86,72,0,0,0,0,0,0,'Right',3,2,82,71,71,69,69,77,66,56,56,59,56,56,56,54,54,55,700,10000
);
INSERT INTO PLAYER VALUES (208,'Farfan','Jefferson Farfan','Gold - Rare','Normal',77,'Lokomotiv Moscow','League of Russia','Peru','RM','1984-10-26',84,76,73,75,36,75,0,0,0,0,0,0,'Right',3,4,52,57,57,60,60,59,72,76,76,76,76,76,76,76,76,75,650,10000
);
INSERT INTO PLAYER VALUES (209,'Afellay','Ibrahim Afellay','Silver - Rare','Normal',74,'PSV','Eredivisie','Holland','CAM','1986-04-02',68,77,69,75,54,57,0,0,0,0,0,0,'Right',4,4,59,63,63,65,65,64,71,72,72,73,72,72,72,73,73,68,300,10000
);
INSERT INTO PLAYER VALUES (210,'Peralta','Oribe Peralta','Silver - Rare','Normal',74,'Guadalajara','LIGA Bancomer MX','Mexico','ST','1984-01-12',68,72,72,66,41,74,0,0,0,0,0,0,'Right',4,3,55,56,56,58,58,58,67,70,70,71,72,72,72,71,71,73,300,10000
);
INSERT INTO PLAYER VALUES (211,'Janssen','Willem Janssen','Silver - Rare','Normal',74,'FC Utrecht','Eredivisie','Holland','CB','1986-07-04',40,68,64,69,72,75,0,0,0,0,0,0,'Right',4,2,73,68,68,68,68,72,70,65,65,66,64,64,64,63,63,65,300,10000
);
INSERT INTO PLAYER VALUES (212,'Inler','Gokhan Inler','Silver - Rare','Normal',74,'Medipol Basaksehir FK','Super Lig','Switzerland','CDM','1984-06-27',41,69,66,72,73,70,0,0,0,0,0,0,'Right',5,2,72,67,67,67,67,72,71,65,65,67,66,66,66,64,64,65,300,10000
);
INSERT INTO PLAYER VALUES (213,'Leo Matos','Leonardo de Matos Cruz','Gold - Non-Rare','Normal',76,'PAOK','Hellas Liga','Brazil','RB','1986-04-02',84,75,69,71,72,76,0,0,0,0,0,0,'Right',3,4,73,75,75,75,75,73,73,76,76,74,74,74,74,75,75,74,350,10000
);
INSERT INTO PLAYER VALUES (214,'Lavezzi','Ezequiel Lavezzi','Gold - Rare','Normal',79,'Hebei China Fortune FC','CSL','Argentina','ST','1985-05-03',84,83,79,78,40,71,0,0,0,0,0,0,'Right',4,4,54,59,59,63,63,60,74,80,80,81,81,81,81,82,82,78,650,10000
);
INSERT INTO PLAYER VALUES (215,'Gomis','Bafetimbi Gomis','Gold - Rare','Normal',81,'Al Hilal','Saudi Professional League','France','ST','1985-08-06',70,76,82,66,36,74,0,0,0,0,0,0,'Right',3,4,52,55,55,57,57,54,68,73,73,75,78,78,78,75,75,80,650,10000
);
INSERT INTO PLAYER VALUES (216,'Jurado','Jose Manuel Jurado Marin','Silver - Rare','Normal',74,'Cadiz CF','LaLiga 1 I 2 I 3','Spain','CAM','1986-06-29',64,75,72,75,32,55,0,0,0,0,0,0,'Right',4,4,44,51,51,55,55,54,69,72,72,73,72,72,72,73,73,69,300,10000
);
INSERT INTO PLAYER VALUES (217,'Quagliarella','Fabio Quagliarella','Gold - Rare','Normal',83,'Sampdoria','Serie A TIM','Italy','ST','1983-01-31',69,80,89,75,30,65,0,0,0,0,0,0,'Right',4,4,46,51,51,55,55,55,74,78,78,81,82,82,82,79,79,82,700,10000
);
INSERT INTO PLAYER VALUES (218,'Behrami','Valon Behrami','Gold - Non-Rare','Normal',75,'FC Sion','Raiffeisen Super League','Switzerland','CDM','1985-04-19',62,71,64,71,74,74,0,0,0,0,0,0,'Right',3,3,74,72,72,72,72,74,72,69,69,69,68,68,68,68,68,67,300,10000
);
INSERT INTO PLAYER VALUES (219,'Moutinho','Joao Filipe Moutinho','Gold - Rare','Normal',84,'Wolverhampton Wanderers','Premier League','Portugal','CM','1986-09-08',56,82,75,85,71,67,0,0,0,0,0,0,'Right',4,3,71,73,73,75,75,77,82,78,78,80,77,77,77,77,77,74,700,10000
);
INSERT INTO PLAYER VALUES (220,'Fabregas','Francesc Fabregas i Soler','Gold - Rare','Normal',81,'AS Monaco Football Club SA','Ligue 1 Conforama','Spain','CM','1987-05-04',53,78,73,87,60,56,0,0,0,0,0,0,'Right',3,3,62,65,65,67,67,69,78,76,76,78,75,75,75,75,75,73,650,10000
);
INSERT INTO PLAYER VALUES (221,'Orozco','Jonathan Orozco','Gold - Non-Rare','Normal',76,'Santos Laguna','LIGA Bancomer MX','Mexico','GK','1986-05-12',0,0,0,0,0,0,76,76,71,59,82,77,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (222,'Baines','Leighton Baines','Gold - Non-Rare','Normal',75,'Everton','Premier League','England','LB','1984-12-11',56,76,68,77,76,59,0,0,0,0,0,0,'Left',3,3,73,73,73,73,73,74,74,71,71,72,71,71,71,71,71,70,300,10000
);
INSERT INTO PLAYER VALUES (223,'Sessegnon','Stephane Sessegnon','Gold - Non-Rare','Normal',76,'Genclerbirligi','Super Lig','Benin','CAM','1984-06-01',74,79,71,75,60,72,0,0,0,0,0,0,'Right',3,4,66,69,69,71,71,69,74,75,75,75,74,74,74,75,75,73,350,10000
);
INSERT INTO PLAYER VALUES (224,'Sergio','Sergio alvarez Conde','Gold - Non-Rare','Normal',75,'RC Celta','LaLiga Santander','Spain','GK','1986-08-03',0,0,0,0,0,0,75,81,65,44,75,76,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (225,'Diamanti','Alessandro Diamanti','Gold - Non-Rare','Normal',76,'Western United FC','Hyundai A-League','Italy','CAM','1983-05-02',64,78,70,78,33,60,0,0,0,0,0,0,'Left',2,4,45,52,52,56,56,56,71,74,74,75,74,74,74,74,74,70,350,10000
);
INSERT INTO PLAYER VALUES (226,'Mikel','John Obi Mikel','Silver - Rare','Normal',73,'Trabzonspor','Super Lig','Nigeria','CM','1987-04-22',54,68,59,71,78,79,0,0,0,0,0,0,'Right',3,3,77,73,73,73,73,77,72,67,67,67,65,65,65,64,64,65,300,10000
);
INSERT INTO PLAYER VALUES (227,'Walcott','Theo Walcott','Gold - Rare','Normal',77,'Everton','Premier League','England','RM','1989-03-16',87,78,72,70,39,61,0,0,0,0,0,0,'Right',3,3,50,58,58,60,60,56,68,75,75,75,76,76,76,76,76,73,650,10000
);
INSERT INTO PLAYER VALUES (228,'Veigneau','Olivier Veigneau','Silver - Rare','Normal',73,'Kasimpasa SK','Super Lig','France','LB','1985-07-16',66,70,44,68,75,68,0,0,0,0,0,0,'Left',3,3,72,72,72,72,72,73,68,65,65,64,60,60,60,62,62,56,300,10000
);
INSERT INTO PLAYER VALUES (229,'Cabral','Gustavo Cabral','Gold - Non-Rare','Normal',75,'Pachuca','LIGA Bancomer MX','Argentina','CB','1985-10-14',33,57,33,52,76,73,0,0,0,0,0,0,'Right',3,2,74,64,64,62,62,69,58,49,49,51,49,49,49,47,47,49,300,10000
);
INSERT INTO PLAYER VALUES (230,'Ulloa','Leonardo Ulloa','Silver - Rare','Normal',73,'Pachuca','LIGA Bancomer MX','Argentina','ST','1986-07-26',36,68,72,62,50,79,0,0,0,0,0,0,'Right',3,2,60,53,53,54,54,59,66,64,64,67,68,68,68,64,64,72,300,10000
);
INSERT INTO PLAYER VALUES (231,'Basta','DuSan Basta','Gold - Non-Rare','Normal',76,'Lazio','Serie A TIM','Serbia','RB','1984-08-18',69,74,66,70,76,70,0,0,0,0,0,0,'Right',3,3,74,75,75,75,75,75,72,71,71,70,70,70,70,70,70,70,750,14000
);
INSERT INTO PLAYER VALUES (232,'Domingo','Nicolas Domingo','Gold - Non-Rare','Normal',75,'Independiente','SAF','Argentina','CDM','1985-04-08',51,69,61,67,74,71,0,0,0,0,0,0,'Right',3,3,71,69,69,70,70,74,71,65,65,67,65,65,65,64,64,63,300,10000
);
INSERT INTO PLAYER VALUES (233,'Higuain','Federico Higuain','Gold - Non-Rare','Normal',76,'Columbus Crew SC','Major League Soccer','Argentina','CAM','1984-10-25',56,74,71,78,49,61,0,0,0,0,0,0,'Right',4,3,56,58,58,60,60,62,72,72,72,75,73,73,73,73,73,71,350,10000
);
INSERT INTO PLAYER VALUES (234,'Bocchetti','Salvatore Bocchetti','Gold - Non-Rare','Normal',76,'Hellas Verona','Serie A TIM','Italy','CB','1986-11-30',66,62,51,55,76,79,0,0,0,0,0,0,'Left',2,2,75,69,69,67,67,70,60,58,58,56,56,56,56,56,56,59,350,10000
);
INSERT INTO PLAYER VALUES (235,'Sirigu','Salvatore Sirigu','Gold - Rare','Normal',84,'Torino','Serie A TIM','Italy','GK','1987-01-12',0,0,0,0,0,0,84,82,80,50,76,84,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,700,10000
);
INSERT INTO PLAYER VALUES (236,'Rodallega','Hugo Rodallega','Gold - Non-Rare','Normal',75,'Yukatel Denizlispor','Super Lig','Colombia','ST','1985-07-25',75,75,73,68,43,71,0,0,0,0,0,0,'Right',3,3,54,58,58,60,60,57,68,72,72,72,74,74,74,73,73,74,300,10000
);
INSERT INTO PLAYER VALUES (237,'Zeca','Jose Carlos Goncalves Rodrigues','Gold - Non-Rare','Normal',75,'FC Kobenhavn','Superliga','Greece','CM','1988-08-31',75,74,61,71,73,78,0,0,0,0,0,0,'Right',3,3,73,75,75,76,76,76,74,73,73,72,71,71,71,71,71,68,300,10000
);
INSERT INTO PLAYER VALUES (238,'Augusto','Renato Augusto','Gold - Non-Rare','Normal',81,'Beijing Guoan','CSL','Brazil','CM','1988-02-08',67,79,73,79,71,72,0,0,0,0,0,0,'Right',4,4,70,73,73,75,75,76,80,77,77,78,77,77,77,76,76,73,350,10000
);
INSERT INTO PLAYER VALUES (239,'Vela','Carlos Vela','Gold - Rare','Normal',83,'Los Angeles Football Club','Major League Soccer','Mexico','RW','1989-03-01',80,84,82,78,31,67,0,0,0,0,0,0,'Left',2,4,47,55,55,60,60,57,75,81,81,82,83,83,83,83,83,80,700,10000
);
INSERT INTO PLAYER VALUES (240,'Evans','Jonny Evans','Gold - Non-Rare','Normal',79,'Leicester City','Premier League','Northern Ireland','CB','1988-01-03',56,55,32,59,80,75,0,0,0,0,0,0,'Right',4,2,78,72,72,69,69,74,62,55,55,54,51,51,51,51,51,51,350,10000
);
INSERT INTO PLAYER VALUES (241,'Hennessey','Wayne Hennessey','Gold - Rare','Normal',75,'Crystal Palace','Premier League','Wales','GK','1987-01-24',0,0,0,0,0,0,75,71,75,40,80,75,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,600,10000
);
INSERT INTO PLAYER VALUES (242,'Lamela','Erik Lamela','Gold - Rare','Normal',80,'Tottenham Hotspur','Premier League','Argentina','RM','1992-03-04',75,82,77,79,51,72,0,0,0,0,0,0,'Left',2,4,60,64,64,67,67,66,76,79,79,80,80,80,80,79,79,77,650,10000
);
INSERT INTO PLAYER VALUES (243,'Dos Santos','Giovani dos Santos','Gold - Rare','Normal',76,'Club America','LIGA Bancomer MX','Mexico','CAM','1989-05-11',84,79,73,73,33,51,0,0,0,0,0,0,'Left',4,4,44,53,53,56,56,53,68,75,75,75,75,75,75,76,76,72,650,10000
);
INSERT INTO PLAYER VALUES (244,'Eschenko','Andrey Eschenko','Silver - Non-Rare','Normal',73,'Spartak Moscow','League of Russia','Russia','RB','1984-02-09',76,69,57,68,71,69,0,0,0,0,0,0,'Right',3,2,71,72,72,72,72,72,69,69,69,68,67,67,67,68,68,65,150,10000
);
INSERT INTO PLAYER VALUES (245,'Aguilar','Paul Aguilar','Silver - Rare','Normal',74,'Club America','LIGA Bancomer MX','Mexico','RB','1986-03-06',82,69,63,68,70,75,0,0,0,0,0,0,'Right',3,3,70,73,73,73,73,71,69,71,71,68,68,68,68,69,69,67,300,10000
);
INSERT INTO PLAYER VALUES (246,'Erkin','Caner Erkin','Gold - Non-Rare','Normal',75,'Besiktas JK','Super Lig','Turkey','LB','1988-10-04',79,79,73,75,69,74,0,0,0,0,0,0,'Left',2,4,72,74,74,75,75,74,75,76,76,76,76,76,76,76,76,74,300,10000
);
INSERT INTO PLAYER VALUES (247,'Mouche','Pablo Mouche','Silver - Rare','Normal',74,'CD Vinazur','Campeonato Scotiabank','Argentina','LM','1987-10-11',77,74,70,70,27,64,0,0,0,0,0,0,'Left',4,3,42,50,50,54,54,50,66,73,73,72,72,72,72,73,73,72,300,10000
);
INSERT INTO PLAYER VALUES (248,'Sow','Moussa Sow','Silver - Rare','Normal',74,'Gazisehir Gaziantep F.K.','Super Lig','Senegal','ST','1986-01-19',77,73,73,66,34,74,0,0,0,0,0,0,'Right',4,3,50,54,54,56,56,54,66,71,71,71,72,72,72,72,72,73,300,10000
);
INSERT INTO PLAYER VALUES (249,'Alfonso','Enrico Alfonso','Silver - Non-Rare','Normal',73,'Brescia','Serie A TIM','Italy','GK','1988-05-04',0,0,0,0,0,0,72,73,72,50,63,73,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,650,12000
);
INSERT INTO PLAYER VALUES (250,'Sokratis','Sokratis Papastathopoulos','Gold - Rare','Normal',84,'Arsenal','Premier League','Greece','CB','1988-06-09',72,61,51,52,84,83,0,0,0,0,0,0,'Right',2,2,82,74,74,71,71,73,61,59,59,58,60,60,60,58,58,63,750,13000
);
INSERT INTO PLAYER VALUES (251,'Murray','Glenn Murray','Gold - Non-Rare','Normal',77,'Brighton e Hove Albion','Premier League','England','ST','1983-09-25',31,68,78,61,42,72,0,0,0,0,0,0,'Right',3,2,55,48,48,50,50,56,66,64,64,69,71,71,71,66,66,75,350,10000
);
INSERT INTO PLAYER VALUES (252,'Cigarini','Luca Cigarini','Silver - Rare','Normal',74,'Cagliari','Serie A TIM','Italy','CM','1986-06-20',57,73,66,78,67,61,0,0,0,0,0,0,'Right',4,3,65,67,67,69,69,71,73,70,70,72,69,69,69,69,69,65,300,10000
);
INSERT INTO PLAYER VALUES (253,'Criscito','Domenico Criscito','Gold - Non-Rare','Normal',79,'Genoa','Serie A TIM','Italy','LB','1986-12-30',74,72,61,76,79,75,0,0,0,0,0,0,'Left',3,3,77,78,78,78,78,78,74,74,74,72,70,70,70,71,71,68,350,10000
);
INSERT INTO PLAYER VALUES (254,'Candreva','Antonio Candreva','Gold - Rare','Normal',79,'Inter','Serie A TIM','Italy','RM','1987-02-28',74,79,78,76,61,67,0,0,0,0,0,0,'Right',4,4,63,69,69,72,72,70,76,78,78,77,77,77,77,77,77,75,650,10000
);
INSERT INTO PLAYER VALUES (255,'Bale','Gareth Bale','Gold - Rare','Normal',85,'Real Madrid','LaLiga Santander','Wales','RW','1989-07-16',91,82,87,82,58,76,0,0,0,0,0,0,'Left',3,4,67,70,70,72,72,70,79,83,83,83,84,84,84,84,84,85,2500,47500
);
INSERT INTO PLAYER VALUES (256,'Piszczek','Lukasz Piszczek','Gold - Rare','Normal',81,'Borussia Dortmund','Bundesliga','Poland','RB','1985-06-03',77,73,68,75,82,78,0,0,0,0,0,0,'Right',4,2,81,80,80,79,79,79,75,75,75,73,74,74,74,74,74,74,650,10000
);
INSERT INTO PLAYER VALUES (257,'Andujar','Mariano Andujar','Silver - Rare','Normal',74,'Estudiantes de La Plata','SAF','Argentina','GK','1983-07-30',0,0,0,0,0,0,73,77,73,45,62,75,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (258,'Fernandez','Matias Fernandez','Gold - Rare','Normal',75,'Junior FC','Liga Dimayor','Chile','CM','1986-05-15',70,78,69,77,58,62,0,0,0,0,0,0,'Right',4,5,61,65,65,68,68,67,74,74,74,75,73,73,73,74,74,69,600,10000
);
INSERT INTO PLAYER VALUES (259,'Baiano','Wanderson Souza Carneiro','Silver - Rare','Normal',74,'Alanyaspor','Super Lig','Brazil','RB','1987-02-23',76,74,61,62,72,73,0,0,0,0,0,0,'Right',2,3,72,73,73,73,73,71,67,70,70,67,68,68,68,69,69,67,300,10000
);
INSERT INTO PLAYER VALUES (260,'Kamara','Kei Kamara','Silver - Rare','Normal',74,'Colorado Rapids','Major League Soccer','Sierra Leone','ST','1984-09-01',73,70,72,61,35,78,0,0,0,0,0,0,'Right',3,3,50,51,51,54,54,52,61,69,69,68,71,71,71,70,70,73,300,10000
);
INSERT INTO PLAYER VALUES (261,'Mccarty','Dax McCarty','Silver - Non-Rare','Normal',73,'Chicago Fire Soccer Club','Major League Soccer','United States','CDM','1987-04-30',50,69,54,67,70,74,0,0,0,0,0,0,'Right',3,3,69,68,68,69,69,72,69,65,65,65,63,63,63,62,62,61,150,10000
);
INSERT INTO PLAYER VALUES (262,'Altidore','Jozy Altidore','Gold - Rare','Normal',76,'Toronto FC','Major League Soccer','United States','ST','1989-11-06',70,69,76,61,32,81,0,0,0,0,0,0,'Right',4,3,50,48,48,50,50,52,63,67,67,69,72,72,72,69,69,75,650,10000
);
INSERT INTO PLAYER VALUES (263,'Leiva','Lucas Pezzini Leiva','Gold - Rare','Normal',84,'Lazio','Serie A TIM','Brazil','CDM','1987-01-09',62,78,66,76,83,73,0,0,0,0,0,0,'Right',3,3,79,78,78,78,78,82,79,74,74,76,73,73,73,72,72,71,700,13000
);
INSERT INTO PLAYER VALUES (264,'Ospina','David Ospina','Gold - Non-Rare','Normal',80,'Napoli','Serie A TIM','Colombia','GK','1988-08-31',0,0,0,0,0,0,83,85,73,34,78,78,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (265,'Missiroli','Simone Missiroli','Silver - Rare','Normal',74,'SPAL','Serie A TIM','Italy','CM','1986-05-23',61,71,65,73,68,63,0,0,0,0,0,0,'Right',3,3,67,69,69,70,70,72,73,71,71,72,71,71,71,70,70,68,300,10000
);
INSERT INTO PLAYER VALUES (266,'ozil','Mesut ozil','Gold - Rare','Normal',84,'Arsenal','Premier League','Germany','CAM','1988-10-15',70,84,72,86,24,56,0,0,0,0,0,0,'Left',2,4,40,52,52,58,58,56,78,82,82,83,81,81,81,81,81,74,700,10000
);
INSERT INTO PLAYER VALUES (267,'Wernbloom','Pontus Wernbloom','Gold - Non-Rare','Normal',77,'PAOK','Hellas Liga','Sweden','CDM','1986-06-25',54,67,71,66,77,81,0,0,0,0,0,0,'Right',3,3,77,72,72,71,71,76,73,68,68,70,70,70,70,67,67,72,350,10000
);
INSERT INTO PLAYER VALUES (268,'Guzman','Nahuel Guzman','Gold - Non-Rare','Normal',79,'Tigres U.A.N.L.','LIGA Bancomer MX','Argentina','GK','1986-02-10',0,0,0,0,0,0,78,79,76,51,70,80,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (269,'Diaz','Marcelo Diaz','Gold - Rare','Normal',80,'Racing Club','SAF','Chile','CDM','1986-12-30',59,75,67,81,74,75,0,0,0,0,0,0,'Right',3,3,74,74,74,75,75,79,78,73,73,74,72,72,72,71,71,69,650,10000
);
INSERT INTO PLAYER VALUES (270,'Lustenberger','Fabian Lustenberger','Gold - Non-Rare','Normal',76,'BSC Young Boys','Raiffeisen Super League','Switzerland','CB','1988-05-02',58,65,37,60,78,70,0,0,0,0,0,0,'Right',3,2,75,71,71,69,69,74,65,59,59,59,56,56,56,56,56,53,350,10000
);
INSERT INTO PLAYER VALUES (271,'Ba','Demba Ba','Silver - Rare','Normal',73,'Medipol Basaksehir FK','Super Lig','Senegal','ST','1985-05-25',70,68,73,68,45,70,0,0,0,0,0,0,'Right',3,3,55,58,58,59,59,58,67,70,70,70,71,71,71,70,70,72,300,10000
);
INSERT INTO PLAYER VALUES (272,'Valbuena','Mathieu Valbuena','Gold - Non-Rare','Normal',80,'Olympiacos CFP','Hellas Liga','France','LM','1984-09-28',77,82,75,80,34,48,0,0,0,0,0,0,'Right',3,3,44,56,56,61,61,57,74,78,78,79,78,78,78,79,79,72,350,10000
);
INSERT INTO PLAYER VALUES (273,'Payet','Dimitri Payet','Gold - Rare','Normal',81,'Olympique de Marseille','Ligue 1 Conforama','France','CAM','1987-03-29',71,81,77,82,38,67,0,0,0,0,0,0,'Right',4,4,50,58,58,62,62,61,76,79,79,80,78,78,78,79,79,75,650,10000
);
INSERT INTO PLAYER VALUES (274,'Medunjanin','Haris Medunjanin','Silver - Rare','Normal',74,'Philadelphia Union','Major League Soccer','Bosnia and Herzegovina','CM','1985-03-08',56,72,71,75,62,70,0,0,0,0,0,0,'Left',4,4,65,65,65,67,67,70,73,70,70,72,71,71,71,70,70,68,300,10000
);
INSERT INTO PLAYER VALUES (275,'Dirar','Nabil Dirar','Gold - Non-Rare','Normal',75,'Fenerbahce SK','Super Lig','Morocco','RM','1986-02-25',79,76,65,71,53,74,0,0,0,0,0,0,'Right',4,3,61,64,64,67,67,65,70,74,74,73,73,73,73,74,74,70,300,10000
);
INSERT INTO PLAYER VALUES (276,'Bertolo','Nicolas Bertolo','Silver - Rare','Normal',74,'Club Atletico Banfield','SAF','Argentina','LM','1986-01-02',65,75,70,74,38,67,0,0,0,0,0,0,'Right',3,3,50,55,55,59,59,59,70,73,73,73,73,73,73,73,73,70,300,10000
);
INSERT INTO PLAYER VALUES (277,'Vieirinha','Adelino Andre Vieira de Freitas','Gold - Rare','Normal',76,'PAOK','Hellas Liga','Portugal','LB','1986-01-24',77,81,77,75,70,64,0,0,0,0,0,0,'Right',4,4,69,74,74,75,75,73,76,77,77,77,77,77,77,78,78,74,650,10000
);
INSERT INTO PLAYER VALUES (278,'Cisse','Papiss Demba Cisse','Gold - Non-Rare','Normal',75,'Alanyaspor','Super Lig','Senegal','ST','1985-06-03',61,74,77,66,38,66,0,0,0,0,0,0,'Right',4,3,48,51,51,54,54,54,66,71,71,72,74,74,74,72,72,74,300,10000
);
INSERT INTO PLAYER VALUES (279,'Bong','Gaetan Bong','Silver - Rare','Normal',74,'Brighton e Hove Albion','Premier League','Cameroon','LB','1988-04-25',63,70,41,69,76,71,0,0,0,0,0,0,'Left',3,3,73,73,73,73,73,74,69,67,67,65,63,63,63,64,64,58,300,10000
);
INSERT INTO PLAYER VALUES (280,'Vrancic','Mario Vrancic','Silver - Rare','Normal',73,'Norwich City','Premier League','Bosnia and Herzegovina','CM','1989-05-23',55,73,70,73,59,70,0,0,0,0,0,0,'Left',3,3,62,63,63,65,65,68,72,70,70,72,70,70,70,69,69,68,300,10000
);
INSERT INTO PLAYER VALUES (281,'Grosicki','Kamil Grosicki','Silver - Rare','Normal',74,'Hull City','EFL Championship','Poland','LM','1988-06-08',83,74,72,71,38,60,0,0,0,0,0,0,'Right',3,3,48,54,54,57,57,55,68,73,73,73,73,73,73,74,74,72,300,10000
);
INSERT INTO PLAYER VALUES (282,'Miguel Veloso','Miguel Luis Pinto Veloso','Gold - Rare','Normal',77,'Hellas Verona','Serie A TIM','Portugal','CM','1986-05-11',49,76,70,82,64,65,0,0,0,0,0,0,'Left',3,3,68,67,67,68,68,72,76,71,71,74,71,71,71,71,71,69,650,10000
);
INSERT INTO PLAYER VALUES (283,'Mata','Juan Manuel Mata Garcia','Gold - Rare','Normal',82,'Manchester United','Premier League','Spain','CAM','1988-04-28',62,83,74,83,36,47,0,0,0,0,0,0,'Left',3,4,45,55,55,60,60,59,77,79,79,81,79,79,79,79,79,73,700,10000
);
INSERT INTO PLAYER VALUES (284,'Okaka','Stefano Okaka','Gold - Non-Rare','Normal',75,'Watford','Premier League','Italy','ST','1989-08-09',64,70,72,59,30,82,0,0,0,0,0,0,'Right',3,2,49,47,47,50,50,50,61,67,67,68,71,71,71,68,68,74,300,10000
);
INSERT INTO PLAYER VALUES (285,'Ivo','Olivio da Rosa','Silver - Rare','Normal',74,'Henan Jianye FC','CSL','Brazil','CM','1986-10-02',72,73,65,77,48,66,0,0,0,0,0,0,'Left',3,3,55,61,61,65,65,64,73,74,74,73,71,71,71,72,72,67,300,10000
);
INSERT INTO PLAYER VALUES (286,'Donk','Ryan Donk','Gold - Rare','Normal',76,'Galatasaray SK','Super Lig','Holland','CDM','1986-03-30',60,70,64,68,74,85,0,0,0,0,0,0,'Right',2,3,75,71,71,72,72,75,73,69,69,70,70,70,70,68,68,69,650,10000
);
INSERT INTO PLAYER VALUES (287,'Nguyen','Lee Nguyen','Silver - Rare','Normal',73,'Los Angeles Football Club','Major League Soccer','United States','CAM','1986-10-07',69,74,70,72,46,62,0,0,0,0,0,0,'Right',3,4,52,57,57,60,60,61,69,71,71,72,71,71,71,71,71,67,300,10000
);
INSERT INTO PLAYER VALUES (288,'Layun','Miguel Layun','Gold - Rare','Normal',77,'Monterrey','LIGA Bancomer MX','Mexico','RB','1988-06-25',76,75,72,75,75,69,0,0,0,0,0,0,'Right',5,3,73,75,75,76,76,75,74,75,75,74,74,74,74,74,74,72,650,10000
);
INSERT INTO PLAYER VALUES (289,'Varela','Fernando Lopes dos Santos Varela','Gold - Non-Rare','Normal',77,'PAOK','Hellas Liga','Cape Verde Islands','CB','1987-11-26',67,60,44,54,76,82,0,0,0,0,0,0,'Right',3,2,76,71,71,69,69,69,59,58,58,55,56,56,56,57,57,57,350,10000
);
INSERT INTO PLAYER VALUES (290,'Forestieri','Fernando Forestieri','Silver - Rare','Normal',73,'Sheffield Wednesday','EFL Championship','Italy','ST','1990-01-15',78,79,73,68,48,67,0,0,0,0,0,0,'Right',3,4,56,58,58,60,60,60,69,73,73,74,74,74,74,74,74,72,300,10000
);
INSERT INTO PLAYER VALUES (291,'Pablo Hernandez','Pablo Hernandez Dominguez','Gold - Non-Rare','Normal',76,'Leeds United','EFL Championship','Spain','RM','1985-04-11',70,78,73,76,46,60,0,0,0,0,0,0,'Right',3,4,53,62,62,65,65,62,72,75,75,75,74,74,74,75,75,70,350,10000
);
INSERT INTO PLAYER VALUES (292,'Howedes','Benedikt Howedes','Gold - Non-Rare','Normal',81,'Lokomotiv Moscow','League of Russia','Germany','CB','1988-02-29',52,65,48,62,82,74,0,0,0,0,0,0,'Right',3,2,79,72,72,70,70,74,65,61,61,60,60,60,60,59,59,61,350,10000
);
INSERT INTO PLAYER VALUES (293,'Robles','Luis Robles','Silver - Rare','Normal',74,'New York Red Bulls','Major League Soccer','United States','GK','1984-05-11',0,0,0,0,0,0,75,77,71,41,70,73,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (294,'N''Doye','Dame N''Doye','Gold - Non-Rare','Normal',75,'FC Kobenhavn','Superliga','Senegal','ST','1985-02-21',71,70,73,60,39,80,0,0,0,0,0,0,'Right',3,3,53,52,52,54,54,54,63,67,67,69,71,71,71,69,69,74,300,10000
);
INSERT INTO PLAYER VALUES (295,'Ki Sung Yueng','Sung Yueng Ki','Gold - Non-Rare','Normal',76,'Newcastle United','Premier League','Korea Republic','CM','1989-01-24',58,74,72,79,64,69,0,0,0,0,0,0,'Right',4,4,67,67,67,68,68,70,75,73,73,75,73,73,73,72,72,72,350,10000
);
INSERT INTO PLAYER VALUES (296,'Dzeko','Edin Dzeko','Gold - Rare','Normal',84,'Roma','Serie A TIM','Bosnia and Herzegovina','ST','1986-03-17',60,75,84,71,46,73,0,0,0,0,0,0,'Right',5,2,56,56,56,59,59,62,75,76,76,78,80,80,80,76,76,82,700,10000
);
INSERT INTO PLAYER VALUES (297,'Horava','TomaS Horava','Silver - Non-Rare','Normal',73,'Viktoria Plzen','Ceska Liga','Czech Republic','CM','1988-05-29',65,73,67,71,60,64,0,0,0,0,0,0,'Right',4,3,62,65,65,67,67,68,72,70,70,71,70,70,70,69,69,67,150,10000
);
INSERT INTO PLAYER VALUES (298,'DoCkal','Borek DoCkal','Gold - Non-Rare','Normal',76,'Sparta Praha','Ceska Liga','Czech Republic','CAM','1988-09-30',65,75,74,79,49,59,0,0,0,0,0,0,'Right',5,4,55,60,60,63,63,62,72,74,74,75,74,74,74,75,75,71,350,10000
);
INSERT INTO PLAYER VALUES (299,'Ekdal','Albin Ekdal','Gold - Non-Rare','Normal',76,'Sampdoria','Serie A TIM','Sweden','CM','1989-07-28',49,73,65,75,71,73,0,0,0,0,0,0,'Right',3,3,71,69,69,70,70,75,75,70,70,72,70,70,70,69,69,68,350,10000
);
INSERT INTO PLAYER VALUES (300,'Akhmedov','Odil Akhmedov','Gold - Non-Rare','Normal',75,'Shanghai SIPG FC','CSL','Uzbekistan','CM','1987-11-25',70,71,71,72,71,72,0,0,0,0,0,0,'Right',3,3,71,72,72,73,73,73,74,72,72,72,72,72,72,72,72,70,300,10000
);
INSERT INTO PLAYER VALUES (301,'Corluka','Vedran Corluka','Gold - Non-Rare','Normal',82,'Lokomotiv Moscow','League of Russia','Croatia','CB','1986-02-05',58,68,49,65,81,82,0,0,0,0,0,0,'Right',3,3,80,74,74,73,73,75,67,64,64,62,61,61,61,61,61,61,350,10000
);
INSERT INTO PLAYER VALUES (302,'Vidal','Arturo Vidal','Gold - Rare','Normal',84,'FC Barcelona','LaLiga Santander','Chile','CM','1987-05-22',67,79,79,80,85,86,0,0,0,0,0,0,'Right',4,3,85,82,82,82,82,84,82,79,79,80,80,80,80,78,78,80,700,10000
);
INSERT INTO PLAYER VALUES (303,'Stephens','Dale Stephens','Gold - Non-Rare','Normal',76,'Brighton e Hove Albion','Premier League','England','CM','1989-06-12',57,70,64,74,71,78,0,0,0,0,0,0,'Right',3,3,73,72,72,73,73,75,75,70,70,71,69,69,69,69,69,67,350,10000
);
INSERT INTO PLAYER VALUES (304,'Tekdemir','Mahmut Tekdemir','Gold - Non-Rare','Normal',75,'Medipol Basaksehir FK','Super Lig','Turkey','CB','1988-01-20',60,70,59,65,74,74,0,0,0,0,0,0,'Right',3,2,74,71,71,71,71,74,70,66,66,66,65,65,65,64,64,64,300,10000
);
INSERT INTO PLAYER VALUES (305,'Gradel','Max-Alain Gradel','Gold - Non-Rare','Normal',79,'Toulouse Football Club','Ligue 1 Conforama','Cote d''Ivoire','LW','1987-11-30',84,81,78,73,42,62,0,0,0,0,0,0,'Right',4,4,52,60,60,63,63,60,73,78,78,79,79,79,79,79,79,77,350,10000
);
INSERT INTO PLAYER VALUES (306,'Clark','Ciaran Clark','Gold - Non-Rare','Normal',75,'Newcastle United','Premier League','Republic of Ireland','CB','1989-09-26',52,55,52,53,76,73,0,0,0,0,0,0,'Left',2,2,74,65,65,63,63,68,59,53,53,54,54,54,54,52,52,58,300,10000
);
INSERT INTO PLAYER VALUES (307,'Stocker','Valentin Stocker','Silver - Rare','Normal',73,'FC Basel','Raiffeisen Super League','Switzerland','LM','1989-04-12',68,74,67,76,48,63,0,0,0,0,0,0,'Left',4,3,55,56,56,59,59,61,70,72,72,74,72,72,72,73,73,69,300,10000
);
INSERT INTO PLAYER VALUES (308,'Saivet','Henri Saivet','Silver - Rare','Normal',74,'Newcastle United','Premier League','Senegal','CAM','1990-10-26',68,75,70,74,64,64,0,0,0,0,0,0,'Right',4,3,66,67,67,68,68,68,72,73,73,73,73,73,73,73,73,72,300,10000
);
INSERT INTO PLAYER VALUES (309,'Chedjou','Aurelien Chedjou','Silver - Rare','Normal',74,'Medipol Basaksehir FK','Super Lig','Cameroon','CB','1985-06-20',65,62,49,60,73,74,0,0,0,0,0,0,'Right',3,3,72,67,67,65,65,70,64,59,59,61,59,59,59,57,57,58,300,10000
);
INSERT INTO PLAYER VALUES (310,'Sakho','Mamadou Sakho','Gold - Rare','Normal',79,'Crystal Palace','Premier League','France','CB','1990-02-13',53,57,33,65,78,83,0,0,0,0,0,0,'Left',2,2,78,71,71,69,69,75,64,57,57,56,53,53,53,53,53,51,650,10000
);
INSERT INTO PLAYER VALUES (311,'Sio','Giovanni Sio','Gold - Rare','Normal',77,'Genclerbirligi','Super Lig','Cote d''Ivoire','ST','1989-03-31',82,76,76,71,29,75,0,0,0,0,0,0,'Left',3,3,46,50,50,54,54,53,68,75,75,75,76,76,76,75,75,76,650,10000
);
INSERT INTO PLAYER VALUES (312,'Sissoko','Moussa Sissoko','Gold - Rare','Normal',81,'Tottenham Hotspur','Premier League','France','CM','1989-08-16',80,79,70,78,79,89,0,0,0,0,0,0,'Right',3,3,80,80,80,81,81,81,80,79,79,78,78,78,78,77,77,77,650,10000
);
INSERT INTO PLAYER VALUES (313,'Howson','Jonny Howson','Silver - Rare','Normal',73,'Middlesbrough','EFL Championship','England','CM','1988-05-21',65,71,70,69,65,72,0,0,0,0,0,0,'Right',4,3,65,68,68,69,69,70,72,70,70,71,70,70,70,69,69,67,300,10000
);
INSERT INTO PLAYER VALUES (314,'Hogg','Jonathan Hogg','Gold - Non-Rare','Normal',75,'Huddersfield Town','EFL Championship','England','CDM','1988-12-06',67,68,55,65,75,79,0,0,0,0,0,0,'Right',3,3,74,73,73,73,73,74,69,67,67,66,64,64,64,64,64,63,300,10000
);
INSERT INTO PLAYER VALUES (315,'Subotic','Neven Subotic','Gold - Non-Rare','Normal',77,'1. FC Union Berlin','Bundesliga','Serbia','CB','1988-12-10',50,48,45,52,80,76,0,0,0,0,0,0,'Right',3,2,76,68,68,65,65,69,57,51,51,50,51,51,51,48,48,55,350,10000
);
INSERT INTO PLAYER VALUES (316,'Choupo-Moting','Eric Maxim Choupo-Moting','Gold - Non-Rare','Normal',76,'Paris Saint-Germain','Ligue 1 Conforama','Cameroon','ST','1989-03-23',76,77,71,68,37,71,0,0,0,0,0,0,'Right',4,4,50,54,54,57,57,56,68,74,74,73,75,75,75,74,74,75,350,10000
);
INSERT INTO PLAYER VALUES (317,'Kruse','Max Kruse','Gold - Rare','Normal',83,'Fenerbahce SK','Super Lig','Germany','CF','1988-03-19',66,83,83,83,45,70,0,0,0,0,0,0,'Left',4,4,55,59,59,63,63,64,79,81,81,83,82,82,82,81,81,80,700,10000
);
INSERT INTO PLAYER VALUES (318,'Henderson','Jordan Henderson','Gold - Rare','Normal',83,'Liverpool','Premier League','England','CDM','1990-06-17',64,77,70,83,78,80,0,0,0,0,0,0,'Right',3,3,78,79,79,80,80,82,81,78,78,78,76,76,76,76,76,73,700,10000
);
INSERT INTO PLAYER VALUES (319,'Dossevi','Matthieu Dossevi','Gold - Non-Rare','Normal',77,'Toulouse Football Club','Ligue 1 Conforama','Togo','RW','1988-02-12',79,78,68,77,36,59,0,0,0,0,0,0,'Right',3,3,46,55,55,60,60,56,71,77,77,76,75,75,75,77,77,71,350,10000
);
INSERT INTO PLAYER VALUES (320,'Perotti','Diego Perotti','Gold - Non-Rare','Normal',80,'Roma','Serie A TIM','Argentina','LW','1988-07-26',75,86,70,77,42,57,0,0,0,0,0,0,'Right',4,4,50,57,57,61,61,59,74,79,79,80,79,79,79,80,80,73,350,10000
);
INSERT INTO PLAYER VALUES (321,'Pied','Jeremy Pied','Silver - Rare','Normal',73,'LOSC Lille','Ligue 1 Conforama','France','RB','1989-02-23',66,74,67,73,73,68,0,0,0,0,0,0,'Right',3,3,72,72,72,72,72,72,72,71,71,71,70,70,70,70,70,69,300,10000
);
INSERT INTO PLAYER VALUES (322,'Donald','Mitchell Donald','Silver - Rare','Normal',73,'Evkur Yeni Malatyaspor','Super Lig','Holland','CDM','1988-12-10',70,67,67,67,68,81,0,0,0,0,0,0,'Right',3,3,71,69,69,69,69,72,71,68,68,69,69,69,69,67,67,70,300,10000
);
INSERT INTO PLAYER VALUES (323,'Kelly','Martin Kelly','Gold - Non-Rare','Normal',75,'Crystal Palace','Premier League','England','CB','1990-04-27',50,62,44,60,75,71,0,0,0,0,0,0,'Right',3,2,74,69,69,68,68,69,60,58,58,55,55,55,55,56,56,56,300,10000
);
INSERT INTO PLAYER VALUES (324,'Carcela-Gonzalez','Mehdi Carcela-Gonzalez','Gold - Rare','Normal',77,'Standard de Liege','Belgium Pro League','Morocco','CAM','1989-07-01',85,83,74,73,34,58,0,0,0,0,0,0,'Left',3,4,45,56,56,60,60,55,70,77,77,76,76,76,76,78,78,71,650,10000
);
INSERT INTO PLAYER VALUES (325,'Castro','Andre Castro Pereira','Silver - Rare','Normal',73,'Goztepe SK','Super Lig','Portugal','CAM','1988-04-02',67,74,71,71,64,76,0,0,0,0,0,0,'Right',2,3,67,67,67,69,69,71,73,71,71,72,72,72,72,71,71,70,300,10000
);
INSERT INTO PLAYER VALUES (326,'Fernando','Fernando Reges','Gold - Rare','Normal',81,'Sevilla FC','LaLiga Santander','Brazil','CDM','1987-07-25',61,71,62,71,81,82,0,0,0,0,0,0,'Right',2,3,80,76,76,76,76,80,74,69,69,70,68,68,68,67,67,67,650,10000
);
INSERT INTO PLAYER VALUES (327,'Gaitan','Nicolas Gaitan','Gold - Non-Rare','Normal',81,'Chicago Fire Soccer Club','Major League Soccer','Argentina','CAM','1988-02-23',78,82,72,80,41,58,0,0,0,0,0,0,'Left',2,4,52,60,60,64,64,61,75,79,79,79,78,78,78,79,79,73,350,10000
);
INSERT INTO PLAYER VALUES (328,'Sankhare','Younousse Sankhare','Gold - Non-Rare','Normal',75,'FC Girondins de Bordeaux','Ligue 1 Conforama','Senegal','CM','1989-09-10',63,73,70,72,72,79,0,0,0,0,0,0,'Left',3,3,74,72,72,72,72,74,74,72,72,72,72,72,72,71,71,72,300,10000
);
INSERT INTO PLAYER VALUES (329,'Sergio Tejera','Sergio Tejera Rodriguez','Silver - Rare','Normal',74,'R. Oviedo','LaLiga 1 I 2 I 3','Spain','CM','1990-05-28',69,72,69,74,68,76,0,0,0,0,0,0,'Left',2,3,69,71,71,72,72,73,73,72,72,72,71,71,71,71,71,69,300,10000
);
INSERT INTO PLAYER VALUES (330,'Giovinco','Sebastian Giovinco','Gold - Rare','Normal',81,'Al Hilal','Saudi Professional League','Italy','CF','1987-01-26',81,87,79,79,27,56,0,0,0,0,0,0,'Right',4,4,41,54,54,59,59,57,75,81,81,82,81,81,81,82,82,75,650,10000
);
INSERT INTO PLAYER VALUES (331,'Van Wolfswinkel','Ricky van Wolfswinkel','Gold - Non-Rare','Normal',75,'FC Basel','Raiffeisen Super League','Holland','ST','1989-01-27',63,71,74,70,43,69,0,0,0,0,0,0,'Right',4,3,53,55,55,58,58,58,69,72,72,72,73,73,73,72,72,74,300,10000
);
INSERT INTO PLAYER VALUES (332,'Alessandrini','Romain Alessandrini','Gold - Non-Rare','Normal',77,'LA Galaxy','Major League Soccer','France','RM','1989-04-03',84,78,76,73,48,66,0,0,0,0,0,0,'Left',4,4,55,60,60,63,63,61,71,76,76,76,76,76,76,77,77,74,350,10000
);
INSERT INTO PLAYER VALUES (333,'Gosling','Dan Gosling','Gold - Non-Rare','Normal',75,'Bournemouth','Premier League','England','CM','1990-02-01',55,70,68,73,70,69,0,0,0,0,0,0,'Right',3,3,70,69,69,70,70,73,74,70,70,72,70,70,70,69,69,69,300,10000
);
INSERT INTO PLAYER VALUES (334,'Djalma','Djalma Braume Manuel Abel Campos','Silver - Rare','Normal',73,'Alanyaspor','Super Lig','Angola','LM','1987-05-30',81,73,69,68,46,75,0,0,0,0,0,0,'Right',3,3,56,58,58,61,61,59,67,72,72,71,71,71,71,72,72,71,300,10000
);
INSERT INTO PLAYER VALUES (335,'Giuliano','Giuliano Victor de Paula','Gold - Rare','Normal',82,'Al Nassr','Saudi Professional League','Brazil','CAM','1990-05-31',81,83,77,79,46,75,0,0,0,0,0,0,'Right',3,4,57,63,63,66,66,66,77,81,81,81,80,80,80,81,81,77,700,10000
);
INSERT INTO PLAYER VALUES (336,'Mauricio','Mauricio Jose da Silveira Junior','Gold - Non-Rare','Normal',77,'PAOK','Hellas Liga','Brazil','CDM','1988-10-21',74,76,70,75,74,72,0,0,0,0,0,0,'Right',4,3,73,74,74,74,74,76,76,74,74,75,74,74,74,74,74,72,350,10000
);
INSERT INTO PLAYER VALUES (337,'Russell','Johnny Russell','Silver - Rare','Normal',74,'Sporting Kansas City','Major League Soccer','Scotland','RW','1990-04-08',78,75,73,70,48,77,0,0,0,0,0,0,'Left',3,3,58,61,61,63,63,62,70,74,74,73,74,74,74,74,74,74,300,10000
);
INSERT INTO PLAYER VALUES (338,'Poli','Andrea Poli','Gold - Non-Rare','Normal',77,'Bologna','Serie A TIM','Italy','CM','1989-09-29',70,78,65,75,72,66,0,0,0,0,0,0,'Right',3,3,71,73,73,74,74,75,76,74,74,76,74,74,74,74,74,69,350,10000
);
INSERT INTO PLAYER VALUES (339,'Ribas','Sebastian Ribas','Silver - Rare','Normal',73,'Rosario Central','SAF','Uruguay','ST','1988-03-11',66,66,74,51,30,74,0,0,0,0,0,0,'Right',4,3,46,44,44,46,46,45,56,62,62,64,68,68,68,64,64,72,300,10000
);
INSERT INTO PLAYER VALUES (340,'King','Joshua King','Gold - Rare','Normal',79,'Bournemouth','Premier League','Norway','CF','1992-01-15',88,79,79,69,38,75,0,0,0,0,0,0,'Right',3,4,52,57,57,60,60,58,71,77,77,78,79,79,79,78,78,79,650,10000
);
INSERT INTO PLAYER VALUES (341,'Gibbs','Kieran Gibbs','Gold - Non-Rare','Normal',75,'West Bromwich Albion','EFL Championship','England','LB','1989-09-26',77,73,56,69,73,71,0,0,0,0,0,0,'Left',2,3,72,74,74,74,74,72,70,71,71,69,68,68,68,69,69,66,300,10000
);
INSERT INTO PLAYER VALUES (342,'Stoch','Miroslav Stoch','Gold - Rare','Normal',76,'PAOK','Hellas Liga','Slovakia','LM','1989-10-19',84,80,77,73,37,55,0,0,0,0,0,0,'Right',5,3,45,55,55,59,59,56,70,75,75,76,76,76,76,77,77,71,650,10000
);
INSERT INTO PLAYER VALUES (343,'Macheda','Federico Macheda','Silver - Rare','Normal',73,'Panathinaikos FC','Hellas Liga','Italy','ST','1991-08-22',69,70,73,58,30,62,0,0,0,0,0,0,'Right',3,3,43,47,47,50,50,46,58,66,66,68,71,71,71,69,69,72,300,10000
);
INSERT INTO PLAYER VALUES (344,'Norwood','Oliver Norwood','Gold - Non-Rare','Normal',75,'Sheffield United','Premier League','Northern Ireland','CM','1991-04-12',57,68,66,78,70,62,0,0,0,0,0,0,'Right',3,2,69,70,70,71,71,74,74,69,69,70,67,67,67,68,68,65,300,10000
);
INSERT INTO PLAYER VALUES (345,'Borini','Fabio Borini','Gold - Non-Rare','Normal',76,'Milan','Serie A TIM','Italy','LW','1991-03-23',74,78,74,72,45,69,0,0,0,0,0,0,'Right',3,3,54,58,58,61,61,59,70,76,76,76,76,76,76,76,76,75,350,10000
);
INSERT INTO PLAYER VALUES (346,'Fabian','Marco Fabian','Gold - Non-Rare','Normal',75,'Philadelphia Union','Major League Soccer','Mexico','CAM','1989-07-21',63,78,75,75,34,63,0,0,0,0,0,0,'Right',4,4,48,52,52,56,56,55,70,72,72,74,73,73,73,73,73,71,300,10000
);
INSERT INTO PLAYER VALUES (347,'Trippier','Kieran Trippier','Gold - Rare','Normal',80,'Atletico Madrid','LaLiga Santander','England','RB','1990-09-19',74,76,60,81,78,72,0,0,0,0,0,0,'Right',4,3,76,79,79,80,80,78,78,76,76,75,73,73,73,74,74,69,650,10000
);
INSERT INTO PLAYER VALUES (348,'Fer','Leroy Fer','Silver - Rare','Normal',73,'Feyenoord','Eredivisie','Holland','CDM','1990-01-05',68,72,72,68,69,81,0,0,0,0,0,0,'Right',4,3,72,71,71,71,71,72,72,71,71,71,71,71,71,70,70,72,300,10000
);
INSERT INTO PLAYER VALUES (349,'Ward','Joel Ward','Silver - Rare','Normal',73,'Crystal Palace','Premier League','England','RB','1989-10-29',58,66,52,66,76,71,0,0,0,0,0,0,'Right',3,3,74,72,72,71,71,72,68,65,65,65,64,64,64,64,64,62,300,10000
);
INSERT INTO PLAYER VALUES (350,'Navarro','Fernando Navarro','Silver - Rare','Normal',74,'Club Leon','LIGA Bancomer MX','Mexico','RB','1989-04-18',86,70,58,65,70,65,0,0,0,0,0,0,'Right',2,3,68,73,73,73,73,69,67,69,69,66,66,66,66,68,68,63,300,10000
);
INSERT INTO PLAYER VALUES (351,'Dentinho','Bruno Ferreira Bonfim','Silver - Rare','Normal',74,'Shakhtar Donetsk','Ukraine Liga','Brazil','CAM','1989-01-19',77,76,68,67,48,71,0,0,0,0,0,0,'Right',4,4,57,60,60,62,62,61,69,72,72,73,72,72,72,73,73,71,300,10000
);
INSERT INTO PLAYER VALUES (352,'Kadar','Tamas Kadar','Gold - Non-Rare','Normal',75,'FC Dynamo Kyiv','Ukraine Liga','Hungary','CB','1990-03-14',70,62,34,65,76,79,0,0,0,0,0,0,'Left',2,2,74,74,74,73,73,73,66,64,64,60,57,57,57,59,59,55,300,10000
);
INSERT INTO PLAYER VALUES (353,'Alustiza','Matias Alustiza','Silver - Rare','Normal',74,'Puebla','LIGA Bancomer MX','Argentina','ST','1984-05-31',70,74,76,69,35,61,0,0,0,0,0,0,'Left',4,4,48,51,51,53,53,53,67,71,71,73,73,73,73,72,72,73,300,10000
);
INSERT INTO PLAYER VALUES (354,'Kouyate','Cheikhou Kouyate','Gold - Rare','Normal',76,'Crystal Palace','Premier League','Senegal','CDM','1989-12-21',69,69,65,61,76,85,0,0,0,0,0,0,'Right',3,3,77,74,74,73,73,75,70,69,69,68,70,70,70,68,68,71,650,10000
);
INSERT INTO PLAYER VALUES (355,'Asamoah','Kwadwo Asamoah','Gold - Rare','Normal',79,'Inter','Serie A TIM','Ghana','LB','1988-12-09',74,82,68,78,79,74,0,0,0,0,0,0,'Left',3,4,78,78,78,78,78,79,78,77,77,77,76,76,76,76,76,73,650,10000
);
INSERT INTO PLAYER VALUES (356,'Gundogan','Ilkay Gundogan','Gold - Rare','Normal',84,'Manchester City','Premier League','Germany','CM','1990-10-24',66,84,74,84,72,71,0,0,0,0,0,0,'Right',4,4,72,75,75,77,77,79,83,80,80,82,80,80,80,80,80,75,700,10000
);
INSERT INTO PLAYER VALUES (357,'Paloschi','Alberto Paloschi','Gold - Non-Rare','Normal',75,'SPAL','Serie A TIM','Italy','ST','1990-01-04',69,73,69,58,28,75,0,0,0,0,0,0,'Right',4,3,46,46,46,49,49,48,60,68,68,68,71,71,71,69,69,74,300,10000
);
INSERT INTO PLAYER VALUES (358,'Johansen','Stefan Johansen','Silver - Rare','Normal',73,'Fulham','EFL Championship','Norway','CM','1991-01-08',68,73,70,72,66,74,0,0,0,0,0,0,'Left',3,3,68,69,69,70,70,71,72,71,71,71,70,70,70,71,71,68,300,10000
);
INSERT INTO PLAYER VALUES (359,'Moreno','Dayro Moreno','Silver - Rare','Normal',73,'Club Atletico Talleres','SAF','Colombia','ST','1985-09-16',64,72,75,67,42,65,0,0,0,0,0,0,'Right',4,3,50,53,53,56,56,56,66,69,69,70,71,71,71,70,70,72,300,10000
);
INSERT INTO PLAYER VALUES (360,'Smolov','Fedor Smolov','Gold - Rare','Normal',80,'Lokomotiv Moscow','League of Russia','Russia','ST','1990-02-09',86,76,81,70,32,73,0,0,0,0,0,0,'Right',4,4,48,53,53,56,56,55,70,76,76,78,79,79,79,77,77,79,650,10000
);
INSERT INTO PLAYER VALUES (361,'El Kaddouri','Omar El Kaddouri','Gold - Non-Rare','Normal',76,'PAOK','Hellas Liga','Morocco','CAM','1990-08-21',74,76,71,76,57,71,0,0,0,0,0,0,'Right',4,3,63,66,66,68,68,67,74,75,75,75,75,75,75,75,75,73,350,10000
);
INSERT INTO PLAYER VALUES (362,'Dzagoev','Alan Dzagoev','Gold - Non-Rare','Normal',77,'CSKA Moscow','League of Russia','Russia','CM','1990-06-17',74,76,72,74,70,68,0,0,0,0,0,0,'Right',3,4,70,72,72,73,73,73,75,75,75,76,76,76,76,75,75,73,350,10000
);
INSERT INTO PLAYER VALUES (363,'Marlos','Marlos Romero Bonfim','Gold - Rare','Normal',82,'Shakhtar Donetsk','Ukraine Liga','Ukraine','RM','1988-06-07',83,86,78,79,46,73,0,0,0,0,0,0,'Left',3,5,57,64,64,67,67,65,77,81,81,82,81,81,81,82,82,77,700,10000
);
INSERT INTO PLAYER VALUES (364,'Isla','Mauricio Isla','Gold - Non-Rare','Normal',75,'Fenerbahce SK','Super Lig','Chile','RB','1988-06-12',77,75,54,73,72,72,0,0,0,0,0,0,'Right',3,3,72,74,74,75,75,74,72,72,72,71,69,69,69,71,71,64,300,10000
);
INSERT INTO PLAYER VALUES (365,'Mpoku','Paul-Jose Mpoku','Silver - Rare','Normal',73,'Standard de Liege','Belgium Pro League','Congo DR','RM','1992-04-19',69,73,74,74,46,69,0,0,0,0,0,0,'Right',4,4,55,59,59,61,61,62,71,72,72,73,72,72,72,72,72,71,300,10000
);
INSERT INTO PLAYER VALUES (366,'Chahechouhe','Aatif Chahechouhe','Silver - Rare','Normal',74,'Antalyaspor','Super Lig','Morocco','LM','1986-07-02',75,76,72,69,32,60,0,0,0,0,0,0,'Right',4,4,44,53,53,57,57,54,68,73,73,73,73,73,73,73,73,72,300,10000
);
INSERT INTO PLAYER VALUES (367,'Juanfran','Juan Francisco Moreno Fuertes','Silver - Rare','Normal',74,'Alanyaspor','Super Lig','Spain','RB','1988-09-11',75,74,67,69,70,73,0,0,0,0,0,0,'Right',3,3,71,73,73,73,73,71,71,71,71,71,71,71,71,71,71,70,300,10000
);
INSERT INTO PLAYER VALUES (368,'Balogun','Leon Balogun','Silver - Rare','Normal',74,'Brighton e Hove Albion','Premier League','Nigeria','CB','1988-06-28',57,60,45,60,74,72,0,0,0,0,0,0,'Right',3,2,73,68,68,67,67,68,60,58,58,56,56,56,56,57,57,57,300,10000
);
INSERT INTO PLAYER VALUES (369,'Acosta','Lautaro Acosta','Gold - Rare','Normal',76,'Club Atletico Lanus','SAF','Argentina','LW','1988-03-14',92,80,70,67,45,63,0,0,0,0,0,0,'Right',4,4,55,61,61,64,64,60,70,76,76,75,76,76,76,76,76,73,650,10000
);
INSERT INTO PLAYER VALUES (370,'Lulic','Senad Lulic','Gold - Rare','Normal',79,'Lazio','Serie A TIM','Bosnia and Herzegovina','LM','1986-01-18',78,78,72,77,75,76,0,0,0,0,0,0,'Right',4,3,75,78,78,79,79,77,78,78,78,76,77,77,77,77,77,75,650,10000
);
INSERT INTO PLAYER VALUES (371,'Taison','Taison Barcellos Freda','Gold - Rare','Normal',82,'Shakhtar Donetsk','Ukraine Liga','Brazil','CAM','1988-01-13',92,86,79,75,47,69,0,0,0,0,0,0,'Right',3,4,56,65,65,68,68,65,77,81,81,81,81,81,81,82,82,78,700,10000
);
INSERT INTO PLAYER VALUES (372,'Miguel Lopes','Hugo Miguel Almeida Costa Lopes','Gold - Non-Rare','Normal',76,'Kayserispor','Super Lig','Portugal','RB','1986-12-19',77,71,50,68,74,78,0,0,0,0,0,0,'Right',4,3,73,75,75,75,75,73,68,70,70,66,66,66,66,67,67,64,350,10000
);
INSERT INTO PLAYER VALUES (373,'Bou','Gustavo Bou','Gold - Non-Rare','Normal',77,'New England Revolution','Major League Soccer','Argentina','ST','1990-02-18',78,77,76,69,30,72,0,0,0,0,0,0,'Right',4,4,46,53,53,56,56,53,68,74,74,74,76,76,76,75,75,76,350,10000
);
INSERT INTO PLAYER VALUES (374,'Bonaventura','Giacomo Bonaventura','Gold - Rare','Normal',82,'Milan','Serie A TIM','Italy','CM','1989-08-22',73,82,77,82,72,69,0,0,0,0,0,0,'Right',3,4,72,76,76,77,77,77,81,80,80,81,80,80,80,80,80,77,700,10000
);
INSERT INTO PLAYER VALUES (375,'Aziz','Serdar Aziz','Gold - Rare','Normal',77,'Fenerbahce SK','Super Lig','Turkey','CB','1990-10-23',73,58,32,56,76,78,0,0,0,0,0,0,'Right',3,2,76,71,71,68,68,71,60,56,56,54,51,51,51,52,52,51,650,10000
);
INSERT INTO PLAYER VALUES (376,'Shelvey','Jonjo Shelvey','Gold - Non-Rare','Normal',77,'Newcastle United','Premier League','England','CM','1992-02-27',62,73,72,79,62,74,0,0,0,0,0,0,'Right',3,3,67,67,67,68,68,72,76,73,73,74,72,72,72,72,72,70,350,10000
);
INSERT INTO PLAYER VALUES (377,'Fleck','John Fleck','Silver - Rare','Normal',73,'Sheffield United','Premier League','Scotland','CM','1991-08-24',72,75,64,73,66,74,0,0,0,0,0,0,'Left',2,3,67,70,70,72,72,72,72,72,72,71,69,69,69,71,71,65,300,10000
);
INSERT INTO PLAYER VALUES (378,'Durmaz','Jimmy Durmaz','Gold - Non-Rare','Normal',75,'Galatasaray SK','Super Lig','Sweden','CAM','1989-03-22',70,77,70,75,34,60,0,0,0,0,0,0,'Left',4,3,44,52,52,57,57,57,70,73,73,74,72,72,72,73,73,65,300,10000
);
INSERT INTO PLAYER VALUES (379,'Saul Berjon','Saul Berjon Perez','Silver - Rare','Normal',73,'R. Oviedo','LaLiga 1 I 2 I 3','Spain','LM','1986-05-24',76,73,72,74,43,64,0,0,0,0,0,0,'Right',4,3,51,58,58,61,61,59,70,72,72,72,72,72,72,73,73,69,300,10000
);
INSERT INTO PLAYER VALUES (380,'Berisha','Etrit Berisha','Gold - Non-Rare','Normal',76,'SPAL','Serie A TIM','Albania','GK','1989-03-10',0,0,0,0,0,0,76,78,76,28,67,75,'Left',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (381,'Nelson Oliveira','Nelson Miguel Castro Oliveira','Silver - Rare','Normal',73,'AEK Athens','Hellas Liga','Portugal','ST','1991-08-08',70,70,73,61,37,74,0,0,0,0,0,0,'Right',4,3,51,51,51,53,53,54,63,67,67,68,70,70,70,68,68,72,300,10000
);
INSERT INTO PLAYER VALUES (382,'Oczipka','Bastian Oczipka','Gold - Non-Rare','Normal',75,'FC Schalke 04','Bundesliga','Germany','LWB','1989-01-12',67,71,59,72,74,75,0,0,0,0,0,0,'Left',2,2,74,74,74,74,74,74,71,70,70,69,68,68,68,69,69,66,300,10000
);
INSERT INTO PLAYER VALUES (383,'Latza','Danny Latza','Gold - Non-Rare','Normal',77,'1. FSV Mainz 05','Bundesliga','Germany','CM','1989-12-07',66,75,57,75,72,76,0,0,0,0,0,0,'Right',4,3,72,73,73,75,75,76,76,72,72,73,70,70,70,70,70,65,350,10000
);
INSERT INTO PLAYER VALUES (384,'Cooper','Liam Cooper','Silver - Rare','Normal',74,'Leeds United','EFL Championship','Scotland','CB','1991-08-30',51,58,35,54,74,77,0,0,0,0,0,0,'Left',2,2,73,67,67,65,65,70,60,54,54,53,52,52,52,51,51,52,300,10000
);
INSERT INTO PLAYER VALUES (385,'Wilshere','Jack Wilshere','Gold - Non-Rare','Normal',79,'West Ham United','Premier League','England','CM','1992-01-01',64,81,68,80,63,66,0,0,0,0,0,0,'Left',2,3,66,68,68,70,70,72,78,76,76,78,76,76,76,76,76,71,350,10000
);
INSERT INTO PLAYER VALUES (386,'Hoilett','Junior Hoilett','Silver - Rare','Normal',74,'Cardiff City','EFL Championship','Canada','LM','1990-06-05',87,77,71,69,35,64,0,0,0,0,0,0,'Right',3,3,48,55,55,58,58,55,67,73,73,73,74,74,74,75,75,71,300,10000
);
INSERT INTO PLAYER VALUES (387,'Daniel Candeias','Daniel Joao Santos Candeias','Silver - Rare','Normal',73,'Genclerbirligi','Super Lig','Portugal','RW','1988-02-25',86,75,64,70,54,68,0,0,0,0,0,0,'Right',4,4,59,65,65,67,67,64,69,73,73,72,71,71,71,73,73,68,300,10000
);
INSERT INTO PLAYER VALUES (388,'Santon','Davide Santon','Gold - Non-Rare','Normal',75,'Roma','Serie A TIM','Italy','RB','1991-01-02',67,73,58,71,74,69,0,0,0,0,0,0,'Right',3,3,73,74,74,74,74,74,71,70,70,69,68,68,68,69,69,66,300,10000
);
INSERT INTO PLAYER VALUES (389,'Pedro','Pedro Rodriguez Ledesma','Gold - Rare','Normal',82,'Chelsea','Premier League','Spain','RW','1987-07-28',75,83,77,77,43,56,0,0,0,0,0,0,'Right',5,4,51,60,60,64,64,61,75,80,80,80,80,80,80,81,81,76,700,10000
);
INSERT INTO PLAYER VALUES (390,'Ekici','Mehmet Ekici','Silver - Rare','Normal',74,'Fenerbahce SK','Super Lig','Turkey','CAM','1990-03-25',65,74,72,75,54,63,0,0,0,0,0,0,'Right',5,3,59,61,61,63,63,65,72,71,71,73,72,72,72,71,71,70,300,10000
);
INSERT INTO PLAYER VALUES (391,'Kovarik','Jan Kovarik','Silver - Rare','Normal',73,'Viktoria Plzen','Ceska Liga','Czech Republic','LM','1988-06-19',67,70,72,77,56,64,0,0,0,0,0,0,'Left',2,3,60,66,66,68,68,66,72,72,72,72,71,71,71,72,72,68,300,10000
);
INSERT INTO PLAYER VALUES (392,'Mee','Ben Mee','Gold - Non-Rare','Normal',78,'Burnley','Premier League','England','CB','1989-09-23',61,62,42,58,79,80,0,0,0,0,0,0,'Left',3,2,77,71,71,69,69,72,62,59,59,57,56,56,56,56,56,56,350,10000
);
INSERT INTO PLAYER VALUES (393,'Guaita','Vicente Guaita Panadero','Gold - Non-Rare','Normal',79,'Crystal Palace','Premier League','Spain','GK','1987-01-10',0,0,0,0,0,0,80,80,80,51,77,76,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (394,'Cleverley','Tom Cleverley','Gold - Non-Rare','Normal',76,'Watford','Premier League','England','CM','1989-08-12',64,73,69,75,61,62,0,0,0,0,0,0,'Right',3,3,63,66,66,68,68,70,75,73,73,74,72,72,72,72,72,68,350,10000
);
INSERT INTO PLAYER VALUES (395,'eder','eder Macedo Lopes','Gold - Non-Rare','Normal',75,'Lokomotiv Moscow','League of Russia','Portugal','ST','1987-12-22',76,68,73,59,41,79,0,0,0,0,0,0,'Right',4,3,54,53,53,55,55,56,64,67,67,69,71,71,71,68,68,74,300,10000
);
INSERT INTO PLAYER VALUES (396,'De Jong','Luuk de Jong','Gold - Non-Rare','Normal',82,'Sevilla FC','LaLiga Santander','Holland','ST','1990-08-27',56,70,79,71,51,78,0,0,0,0,0,0,'Right',3,2,61,60,60,62,62,63,72,72,72,73,75,75,75,72,72,80,350,10000
);
INSERT INTO PLAYER VALUES (397,'Skorupski','Lukasz Skorupski','Gold - Non-Rare','Normal',76,'Bologna','Serie A TIM','Poland','GK','1991-05-05',0,0,0,0,0,0,80,81,75,51,54,75,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (398,'Zuber','Steven Zuber','Gold - Non-Rare','Normal',76,'TSG 1899 Hoffenheim','Bundesliga','Switzerland','CM','1991-08-17',78,77,74,73,71,75,0,0,0,0,0,0,'Right',4,3,72,74,74,75,75,74,75,75,75,75,76,76,76,76,76,75,350,10000
);
INSERT INTO PLAYER VALUES (399,'Johnsson','Karl-Johan Johnsson','Silver - Rare','Normal',73,'FC Kobenhavn','Superliga','Sweden','GK','1990-01-28',0,0,0,0,0,0,74,76,70,50,73,74,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (400,'Falque','Iago Falque Silva','Gold - Rare','Normal',79,'Torino','Serie A TIM','Spain','CF','1990-01-04',75,84,74,79,41,54,0,0,0,0,0,0,'Left',3,4,48,57,57,62,62,59,74,79,79,80,79,79,79,80,80,74,650,10000
);
INSERT INTO PLAYER VALUES (401,'Kabasele','Christian Kabasele','Gold - Non-Rare','Normal',78,'Watford','Premier League','Belgium','CB','1991-02-24',70,62,50,51,78,77,0,0,0,0,0,0,'Right',3,2,77,71,71,69,69,70,60,59,59,57,59,59,59,58,58,61,350,10000
);
INSERT INTO PLAYER VALUES (402,'KrstiCic','Nenad KrstiCic','Silver - Non-Rare','Normal',73,'AEK Athens','Hellas Liga','Serbia','CM','1990-07-03',71,71,62,70,68,72,0,0,0,0,0,0,'Left',4,3,70,69,69,69,69,72,72,69,69,71,69,69,69,69,69,67,150,10000
);
INSERT INTO PLAYER VALUES (403,'Ljajic','Adem Ljajic','Gold - Rare','Normal',81,'Besiktas JK','Super Lig','Serbia','CAM','1991-09-29',78,84,75,80,37,61,0,0,0,0,0,0,'Right',4,4,48,58,58,62,62,59,75,79,79,80,78,78,78,80,80,73,650,10000
);
INSERT INTO PLAYER VALUES (404,'Quintero','Darwin Quintero','Gold - Rare','Normal',76,'Minnesota United FC','Major League Soccer','Colombia','CF','1987-09-19',86,80,73,70,28,65,0,0,0,0,0,0,'Right',3,4,44,51,51,55,55,53,68,76,76,76,76,76,76,77,77,73,650,10000
);
INSERT INTO PLAYER VALUES (405,'Rios','Antonio Rios','Silver - Non-Rare','Normal',73,'Deportivo Toluca','LIGA Bancomer MX','Mexico','CDM','1988-10-24',65,61,55,67,70,77,0,0,0,0,0,0,'Right',4,2,70,68,68,68,68,72,69,63,63,65,63,63,63,61,61,60,150,10000
);
INSERT INTO PLAYER VALUES (406,'Gulde','Manuel Gulde','Gold - Non-Rare','Normal',75,'Sport-Club Freiburg','Bundesliga','Germany','CB','1991-02-12',65,59,40,53,77,70,0,0,0,0,0,0,'Right',2,2,74,69,69,67,67,69,59,56,56,55,54,54,54,54,54,55,300,10000
);
INSERT INTO PLAYER VALUES (407,'Andre','Benjamin Andre','Gold - Rare','Normal',78,'LOSC Lille','Ligue 1 Conforama','France','CM','1990-08-03',70,75,64,75,77,82,0,0,0,0,0,0,'Right',3,3,77,76,76,76,76,78,77,75,75,74,72,72,72,72,72,71,650,10000
);
INSERT INTO PLAYER VALUES (408,'Arslan','Tolgay Arslan','Gold - Non-Rare','Normal',75,'Fenerbahce SK','Super Lig','Germany','CDM','1990-08-16',73,78,69,74,71,70,0,0,0,0,0,0,'Right',4,3,70,72,72,73,73,74,75,73,73,74,73,73,73,73,73,70,300,10000
);
INSERT INTO PLAYER VALUES (409,'Sandro','Sandro R. G. Cordeiro','Silver - Rare','Normal',74,'Genoa','Serie A TIM','Brazil','CDM','1989-03-15',54,68,69,67,75,72,0,0,0,0,0,0,'Right',3,3,74,68,68,67,67,73,69,65,65,68,68,68,68,65,65,68,300,10000
);
INSERT INTO PLAYER VALUES (410,'Elabdellaoui','Omar Elabdellaoui','Gold - Non-Rare','Normal',75,'Olympiacos CFP','Hellas Liga','Norway','RB','1991-12-05',83,76,55,71,69,73,0,0,0,0,0,0,'Right',3,3,70,74,74,75,75,72,72,73,73,72,71,71,71,72,72,67,300,10000
);
INSERT INTO PLAYER VALUES (411,'Theophile-Catherine','Kevin Theophile-Catherine','Gold - Non-Rare','Normal',76,'GNK Dinamo Zagreb','Croatia Liga','France','CB','1989-10-28',69,65,50,68,74,78,0,0,0,0,0,0,'Right',3,3,75,73,73,73,73,74,67,64,64,63,60,60,60,62,62,60,350,10000
);
INSERT INTO PLAYER VALUES (412,'Kucka','Juraj Kucka','Gold - Rare','Normal',77,'Parma','Serie A TIM','Slovakia','CM','1987-02-26',60,74,72,72,77,88,0,0,0,0,0,0,'Right',3,3,79,75,75,75,75,78,76,72,72,73,73,73,73,71,71,74,650,10000
);
INSERT INTO PLAYER VALUES (413,'Montero','Fredy Montero','Gold - Non-Rare','Normal',75,'Vancouver Whitecaps FC','Major League Soccer','Colombia','ST','1987-07-26',68,76,76,72,48,61,0,0,0,0,0,0,'Right',4,4,54,57,57,60,60,60,71,73,73,75,75,75,75,74,74,74,300,10000
);
INSERT INTO PLAYER VALUES (414,'Alonso','Osvaldo Alonso','Gold - Non-Rare','Normal',75,'Minnesota United FC','Major League Soccer','Cuba','CDM','1985-11-11',62,73,65,68,70,77,0,0,0,0,0,0,'Right',4,2,72,69,69,69,69,74,72,68,68,70,69,69,69,67,67,68,300,10000
);
INSERT INTO PLAYER VALUES (415,'Salvio','Eduardo Salvio','Gold - Rare','Normal',80,'Buenos Aires','SAF','Argentina','RM','1990-07-13',86,84,75,73,58,68,0,0,0,0,0,0,'Right',4,4,64,69,69,70,70,67,74,79,79,79,80,80,80,80,80,78,650,10000
);
INSERT INTO PLAYER VALUES (416,'Guomundsson','Johann Berg Guomundsson','Gold - Non-Rare','Normal',78,'Burnley','Premier League','Iceland','RM','1990-10-27',75,77,74,78,61,70,0,0,0,0,0,0,'Left',4,4,65,69,69,71,71,69,75,77,77,76,76,76,76,76,76,74,350,10000
);
INSERT INTO PLAYER VALUES (417,'Pastore','Javier Pastore','Gold - Rare','Normal',79,'Roma','Serie A TIM','Argentina','CM','1989-06-20',62,81,73,81,56,58,0,0,0,0,0,0,'Right',4,4,61,64,64,67,67,69,77,76,76,79,77,77,77,77,77,73,650,10000
);
INSERT INTO PLAYER VALUES (418,'Herrera','Ander Herrera Aguera','Gold - Rare','Normal',82,'Paris Saint-Germain','Ligue 1 Conforama','Spain','CM','1989-08-14',70,80,72,78,82,77,0,0,0,0,0,0,'Right',4,3,80,80,80,81,81,83,81,78,78,78,77,77,77,77,77,74,700,10000
);
INSERT INTO PLAYER VALUES (419,'Schennikov','Georgiy Schennikov','Silver - Rare','Normal',74,'CSKA Moscow','League of Russia','Russia','LWB','1991-04-27',79,70,54,69,71,71,0,0,0,0,0,0,'Left',2,3,71,73,73,73,73,71,69,70,70,68,67,67,67,68,68,64,300,10000
);
INSERT INTO PLAYER VALUES (420,'Hult','Niklas Hult','Silver - Rare','Normal',74,'AEK Athens','Hellas Liga','Sweden','LB','1990-02-13',84,74,59,71,68,67,0,0,0,0,0,0,'Left',3,3,68,73,73,74,74,71,71,73,73,71,70,70,70,72,72,66,300,10000
);
INSERT INTO PLAYER VALUES (421,'Wood','Chris Wood','Gold - Non-Rare','Normal',77,'Burnley','Premier League','New Zealand','ST','1991-12-07',70,69,76,59,40,79,0,0,0,0,0,0,'Right',3,2,54,53,53,54,54,55,63,67,67,69,72,72,72,68,68,76,350,10000
);
INSERT INTO PLAYER VALUES (422,'Arlauskis','Giedrius Arlauskis','Silver - Rare','Normal',73,'CFR Cluj','Romania Liga I','Lithuania','GK','1987-12-01',0,0,0,0,0,0,75,79,68,33,72,68,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (423,'Gotze','Mario Gotze','Gold - Rare','Normal',82,'Borussia Dortmund','Bundesliga','Germany','CF','1992-06-03',71,86,78,85,56,70,0,0,0,0,0,0,'Right',4,4,62,69,69,73,73,73,82,83,83,84,82,82,82,83,83,78,700,10000
);
INSERT INTO PLAYER VALUES (424,'Sane','Lamine Sane','Silver - Rare','Normal',74,'Orlando City Soccer Club','Major League Soccer','Senegal','CB','1987-03-22',54,60,44,59,72,76,0,0,0,0,0,0,'Right',2,2,73,66,66,65,65,69,63,57,57,58,56,56,56,55,55,56,300,10000
);
INSERT INTO PLAYER VALUES (425,'Rinaudo','Fabian Rinaudo','Silver - Rare','Normal',74,'Rosario Central','SAF','Argentina','CDM','1987-05-08',66,70,64,67,71,76,0,0,0,0,0,0,'Right',3,3,72,70,70,70,70,73,70,67,67,68,67,67,67,66,66,66,300,10000
);
INSERT INTO PLAYER VALUES (426,'Junior Caicara','Uilson de Souza Paula Junior','Gold - Non-Rare','Normal',76,'Medipol Basaksehir FK','Super Lig','Brazil','RB','1989-04-27',80,75,56,74,72,65,0,0,0,0,0,0,'Right',4,3,70,75,75,76,76,74,73,74,74,72,70,70,70,72,72,65,350,10000
);
INSERT INTO PLAYER VALUES (427,'Badu','Emmanuel Badu','Gold - Non-Rare','Normal',75,'Hellas Verona','Serie A TIM','Ghana','CDM','1990-12-02',78,77,67,70,72,72,0,0,0,0,0,0,'Right',3,3,72,75,75,75,75,74,74,74,74,74,73,73,73,74,74,71,300,10000
);
INSERT INTO PLAYER VALUES (428,'Jajalo','Mato Jajalo','Gold - Non-Rare','Normal',76,'Udinese','Serie A TIM','Bosnia and Herzegovina','CM','1988-05-25',66,78,66,74,73,79,0,0,0,0,0,0,'Right',3,3,73,73,73,74,74,76,75,73,73,73,71,71,71,71,71,69,350,10000
);
INSERT INTO PLAYER VALUES (429,'Badstuber','Holger Badstuber','Gold - Non-Rare','Normal',75,'VfB Stuttgart','Bundesliga 2','Germany','CB','1989-03-13',35,55,50,70,77,67,0,0,0,0,0,0,'Left',3,2,74,67,67,66,66,72,65,56,56,58,55,55,55,54,54,56,300,10000
);
INSERT INTO PLAYER VALUES (430,'Duffy','Shane Duffy','Gold - Non-Rare','Normal',78,'Brighton e Hove Albion','Premier League','Republic of Ireland','CB','1992-01-01',47,49,45,51,78,80,0,0,0,0,0,0,'Right',3,2,77,66,66,63,63,70,59,52,52,52,53,53,53,50,50,56,350,10000
);
INSERT INTO PLAYER VALUES (431,'Nyom','Allan Nyom','Silver - Rare','Normal',74,'Getafe CF','LaLiga Santander','Cameroon','RWB','1988-05-10',70,65,47,62,75,82,0,0,0,0,0,0,'Right',3,3,74,73,73,73,73,72,65,64,64,60,61,61,61,62,62,60,300,10000
);
INSERT INTO PLAYER VALUES (432,'Carlos Eduardo','Carlos Eduardo de Oliveira Alves','Gold - Non-Rare','Normal',77,'Al Hilal','Saudi Professional League','Brazil','CAM','1989-10-17',70,73,77,76,61,74,0,0,0,0,0,0,'Right',4,3,66,66,66,67,67,69,74,75,75,76,76,76,76,75,75,77,350,10000
);
INSERT INTO PLAYER VALUES (433,'Hamouma','Romain Hamouma','Gold - Non-Rare','Normal',76,'AS Saint-etienne','Ligue 1 Conforama','France','RM','1987-03-29',67,78,73,76,42,63,0,0,0,0,0,0,'Right',4,3,52,58,58,61,61,59,72,75,75,76,75,75,75,75,75,72,350,10000
);
INSERT INTO PLAYER VALUES (434,'Pulido','Alan Pulido','Silver - Non-Rare','Normal',73,'Guadalajara','LIGA Bancomer MX','Mexico','ST','1991-03-08',77,71,70,63,36,73,0,0,0,0,0,0,'Right',2,3,50,53,53,55,55,54,65,69,69,69,71,71,71,70,70,72,150,10000
);
INSERT INTO PLAYER VALUES (435,'Cook','Steve Cook','Gold - Non-Rare','Normal',78,'Bournemouth','Premier League','England','CB','1991-04-19',53,61,34,55,78,75,0,0,0,0,0,0,'Right',3,2,77,69,69,67,67,72,61,55,55,54,52,52,52,52,52,53,350,10000
);
INSERT INTO PLAYER VALUES (436,'Gonalons','Maxime Gonalons','Gold - Non-Rare','Normal',75,'Roma','Serie A TIM','France','CDM','1989-03-10',52,69,61,68,75,75,0,0,0,0,0,0,'Right',4,3,75,70,70,69,69,74,70,66,66,67,66,66,66,65,65,66,300,10000
);
INSERT INTO PLAYER VALUES (437,'Le Goff','Vincent Le Goff','Silver - Non-Rare','Normal',73,'FC Lorient','Domino''s Ligue 2','France','LB','1989-10-15',71,71,61,67,70,68,0,0,0,0,0,0,'Left',3,3,68,72,72,73,73,72,70,70,70,69,67,67,67,69,69,64,150,10000
);
INSERT INTO PLAYER VALUES (438,'Propper','Davy Propper','Gold - Non-Rare','Normal',77,'Brighton e Hove Albion','Premier League','Holland','CM','1991-09-02',62,76,70,73,67,75,0,0,0,0,0,0,'Right',3,4,69,69,69,70,70,73,76,72,72,75,73,73,73,71,71,71,350,10000
);
INSERT INTO PLAYER VALUES (439,'Corona','Jesus Corona','Gold - Rare','Normal',81,'FC Porto','Liga NOS','Mexico','RM','1993-01-06',83,88,70,75,62,54,0,0,0,0,0,0,'Right',5,5,63,70,70,72,72,68,76,80,80,80,80,80,80,81,81,75,650,10000
);
INSERT INTO PLAYER VALUES (440,'Gudelj','Nemanja Gudelj','Gold - Rare','Normal',77,'Sevilla FC','LaLiga Santander','Serbia','CDM','1991-11-16',63,68,70,75,73,85,0,0,0,0,0,0,'Right',2,3,75,74,74,74,74,76,74,70,70,70,69,69,69,69,69,70,650,10000
);
INSERT INTO PLAYER VALUES (441,'Pisacane','Fabio Pisacane','Silver - Rare','Normal',73,'Cagliari','Serie A TIM','Italy','CB','1986-01-28',64,62,26,51,74,68,0,0,0,0,0,0,'Right',3,2,72,68,68,67,67,66,56,56,56,53,52,52,52,55,55,49,300,10000
);
INSERT INTO PLAYER VALUES (442,'Delaney','Thomas Delaney','Gold - Rare','Normal',82,'Borussia Dortmund','Bundesliga','Denmark','CDM','1991-09-03',77,75,73,74,83,82,0,0,0,0,0,0,'Left',4,3,82,81,81,80,80,81,78,76,76,76,76,76,76,75,75,76,700,10000
);
INSERT INTO PLAYER VALUES (443,'Destro','Mattia Destro','Gold - Non-Rare','Normal',75,'Bologna','Serie A TIM','Italy','ST','1991-03-20',70,74,72,59,29,62,0,0,0,0,0,0,'Right',3,4,44,46,46,49,49,46,60,68,68,69,72,72,72,70,70,74,300,10000
);
INSERT INTO PLAYER VALUES (444,'Rodriguez','Ricardo Rodriguez','Gold - Rare','Normal',80,'Milan','Serie A TIM','Switzerland','LB','1992-08-25',70,76,67,79,78,74,0,0,0,0,0,0,'Left',3,3,76,78,78,78,78,78,76,75,75,74,73,73,73,74,74,71,650,10000
);
INSERT INTO PLAYER VALUES (445,'Soriano','Roberto Soriano','Gold - Non-Rare','Normal',78,'Bologna','Serie A TIM','Italy','CAM','1991-02-08',71,79,74,77,67,68,0,0,0,0,0,0,'Right',4,4,69,70,70,71,71,72,76,76,76,77,76,76,76,76,76,74,350,10000
);
INSERT INTO PLAYER VALUES (446,'Gueye','Idrissa Gueye','Gold - Rare','Normal',83,'Paris Saint-Germain','Ligue 1 Conforama','Senegal','CDM','1989-09-26',73,78,59,70,85,78,0,0,0,0,0,0,'Right',3,3,82,81,81,80,80,82,77,73,73,73,72,72,72,71,71,69,700,10000
);
INSERT INTO PLAYER VALUES (447,'Fernandes','Mario Figueira Fernandes','Gold - Rare','Normal',82,'CSKA Moscow','League of Russia','Russia','RWB','1990-09-19',82,78,60,74,81,79,0,0,0,0,0,0,'Right',3,3,80,81,81,81,81,80,77,77,77,76,75,75,75,76,76,72,700,10000
);
INSERT INTO PLAYER VALUES (448,'Belhanda','Younes Belhanda','Gold - Rare','Normal',80,'Galatasaray SK','Super Lig','Morocco','CAM','1990-02-25',73,83,76,78,57,71,0,0,0,0,0,0,'Right',4,4,63,68,68,71,71,70,77,79,79,79,78,78,78,79,79,75,650,10000
);
INSERT INTO PLAYER VALUES (449,'Romulo','Romulo Souza Orestes Caldeira','Gold - Non-Rare','Normal',77,'Genoa','Serie A TIM','Italy','RM','1987-05-22',78,79,66,76,70,71,0,0,0,0,0,0,'Right',2,4,70,75,75,76,76,74,76,76,76,75,74,74,74,75,75,70,350,10000
);
INSERT INTO PLAYER VALUES (450,'DuriCic','Filip DuriCic','Silver - Rare','Normal',74,'Sassuolo','Serie A TIM','Serbia','CAM','1992-01-30',73,77,65,72,42,57,0,0,0,0,0,0,'Right',4,4,50,56,56,59,59,58,69,72,72,73,72,72,72,72,72,67,300,10000
);
INSERT INTO PLAYER VALUES (451,'Didavi','Daniel Didavi','Gold - Rare','Normal',78,'VfB Stuttgart','Bundesliga 2','Germany','CAM','1990-02-21',67,79,79,76,49,70,0,0,0,0,0,0,'Left',3,3,59,62,62,64,64,65,74,75,75,77,77,77,77,76,76,76,650,10000
);
INSERT INTO PLAYER VALUES (452,'Ananidze','Jano Ananidze','Silver - Rare','Normal',74,'Spartak Moscow','League of Russia','Georgia','CAM','1992-10-10',75,76,70,73,39,44,0,0,0,0,0,0,'Right',4,3,45,55,55,58,58,54,68,72,72,73,72,72,72,73,73,67,300,10000
);
INSERT INTO PLAYER VALUES (453,'Delort','Andy Delort','Gold - Non-Rare','Normal',78,'Montpellier Herault SC','Ligue 1 Conforama','Algeria','ST','1991-10-09',73,73,78,70,33,80,0,0,0,0,0,0,'Right',3,3,50,52,52,55,55,54,68,73,73,74,75,75,75,74,74,77,350,10000
);
INSERT INTO PLAYER VALUES (454,'Almeida','Andre Gomes Magalhaes Almeida','Gold - Rare','Normal',81,'SL Benfica','Liga NOS','Portugal','RB','1990-09-10',68,75,63,76,82,82,0,0,0,0,0,0,'Right',3,3,80,80,80,80,80,80,77,75,75,73,73,73,73,73,73,71,650,10000
);
INSERT INTO PLAYER VALUES (455,'Diagne','Fallou Diagne','Silver - Rare','Normal',73,'Atiker Konyaspor','Super Lig','Senegal','CB','1989-08-14',64,65,42,58,70,77,0,0,0,0,0,0,'Right',3,2,72,67,67,66,66,68,62,60,60,58,57,57,57,58,58,57,300,10000
);
INSERT INTO PLAYER VALUES (456,'El Arabi','Youssef El Arabi','Gold - Non-Rare','Normal',77,'Olympiacos CFP','Hellas Liga','Morocco','ST','1987-02-03',71,81,78,67,37,66,0,0,0,0,0,0,'Right',4,3,51,55,55,57,57,55,69,73,73,75,76,76,76,76,76,76,350,10000
);
INSERT INTO PLAYER VALUES (457,'Daniel Ayala','Daniel Sanchez Ayala','Silver - Rare','Normal',74,'Middlesbrough','EFL Championship','Spain','CB','1990-11-07',66,65,41,52,74,78,0,0,0,0,0,0,'Right',3,2,73,66,66,65,65,69,62,59,59,59,58,58,58,57,57,58,300,10000
);
INSERT INTO PLAYER VALUES (458,'Dawson','Craig Dawson','Gold - Non-Rare','Normal',75,'Watford','Premier League','England','CB','1990-05-06',62,60,43,58,75,77,0,0,0,0,0,0,'Right',2,2,74,71,71,70,70,70,61,61,61,57,58,58,58,58,58,59,300,10000
);
INSERT INTO PLAYER VALUES (459,'Hanin','Florent Hanin','Silver - Rare','Normal',74,'Vitoria Guimaraes','Liga NOS','France','LB','1990-02-04',85,74,44,69,69,68,0,0,0,0,0,0,'Left',3,3,68,73,73,74,74,71,68,71,71,67,66,66,66,69,69,61,300,10000
);
INSERT INTO PLAYER VALUES (460,'Hamid','Bill Hamid','Silver - Rare','Normal',74,'D.C. United','Major League Soccer','United States','GK','1990-11-25',0,0,0,0,0,0,75,76,70,42,70,73,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (461,'Jones','Phil Jones','Gold - Non-Rare','Normal',79,'Manchester United','Premier League','England','CB','1992-02-21',55,58,51,61,78,76,0,0,0,0,0,0,'Right',3,2,78,71,71,69,69,73,63,59,59,58,57,57,57,57,57,59,350,10000
);
INSERT INTO PLAYER VALUES (462,'Borja Baston','Borja Gonzalez Tomas','Gold - Non-Rare','Normal',75,'Swansea City','EFL Championship','Spain','ST','1992-08-25',51,67,77,61,41,76,0,0,0,0,0,0,'Right',4,3,52,49,49,51,51,54,64,65,65,69,71,71,71,67,67,74,300,10000
);
INSERT INTO PLAYER VALUES (463,'Lovren','Dejan Lovren','Gold - Non-Rare','Normal',80,'Liverpool','Premier League','Croatia','CB','1989-07-05',54,63,40,59,80,78,0,0,0,0,0,0,'Right',4,2,79,72,72,70,70,74,62,58,58,56,54,54,54,55,55,54,350,10000
);
INSERT INTO PLAYER VALUES (464,'Ninkovic','MiloS Ninkovic','Gold - Non-Rare','Normal',75,'Sydney FC','Hyundai A-League','Serbia','CAM','1984-12-25',68,76,69,73,47,67,0,0,0,0,0,0,'Right',3,4,56,61,61,63,63,63,72,72,72,74,72,72,72,73,73,69,300,10000
);
INSERT INTO PLAYER VALUES (465,'Kampl','Kevin Kampl','Gold - Rare','Normal',83,'RB Leipzig','Bundesliga','Slovenia','CM','1990-10-09',76,85,67,80,63,62,0,0,0,0,0,0,'Right',4,3,63,72,72,76,76,75,81,80,80,80,77,77,77,79,79,69,700,10000
);
INSERT INTO PLAYER VALUES (466,'Tavernier','James Tavernier','Gold - Rare','Normal',75,'Rangers FC','Scottish Premiership','England','RB','1991-10-31',86,76,67,73,68,79,0,0,0,0,0,0,'Right',3,3,71,74,74,75,75,71,72,75,75,73,72,72,72,74,74,71,600,10000
);
INSERT INTO PLAYER VALUES (467,'Suk Hyun Jun','Hyun Jun Suk','Silver - Rare','Normal',73,'Stade de Reims','Ligue 1 Conforama','Korea Republic','ST','1991-06-29',62,69,74,58,39,78,0,0,0,0,0,0,'Right',4,3,52,50,50,52,52,52,61,65,65,66,69,69,69,67,67,72,300,10000
);
INSERT INTO PLAYER VALUES (468,'Gutierrez','Teofilo Gutierrez','Gold - Non-Rare','Normal',76,'Junior FC','Liga Dimayor','Colombia','ST','1985-05-17',57,77,75,72,28,72,0,0,0,0,0,0,'Right',3,4,47,47,47,51,51,53,69,72,72,75,75,75,75,74,74,75,350,10000
);
INSERT INTO PLAYER VALUES (469,'Gurler','Serdar Gurler','Silver - Non-Rare','Normal',73,'Goztepe SK','Super Lig','Turkey','RM','1991-09-14',80,74,67,68,44,51,0,0,0,0,0,0,'Right',4,3,49,57,57,59,59,55,66,72,72,71,72,72,72,73,73,69,150,10000
);
INSERT INTO PLAYER VALUES (470,'Verdi','Simone Verdi','Gold - Rare','Normal',80,'Napoli','Serie A TIM','Italy','LM','1992-07-12',86,83,73,80,48,53,0,0,0,0,0,0,'Left',5,4,53,65,65,68,68,63,75,79,79,79,78,78,78,80,80,72,650,10000
);
INSERT INTO PLAYER VALUES (471,'ozyakup','Oguzhan ozyakup','Gold - Non-Rare','Normal',77,'Besiktas JK','Super Lig','Turkey','CM','1992-09-23',69,79,70,79,62,68,0,0,0,0,0,0,'Right',4,4,65,69,69,72,72,71,76,76,76,76,74,74,74,75,75,70,350,10000
);
INSERT INTO PLAYER VALUES (472,'Lodeiro','Nicolas Lodeiro','Gold - Non-Rare','Normal',78,'Seattle Sounders FC','Major League Soccer','Uruguay','CAM','1989-03-21',68,79,70,79,49,70,0,0,0,0,0,0,'Left',4,4,56,63,63,67,67,66,76,77,77,77,75,75,75,76,76,69,350,10000
);
INSERT INTO PLAYER VALUES (473,'Krychowiak','Grzegorz Krychowiak','Gold - Non-Rare','Normal',78,'Lokomotiv Moscow','League of Russia','Poland','CDM','1990-01-29',65,69,57,71,75,80,0,0,0,0,0,0,'Right',3,3,76,72,72,72,72,76,73,67,67,68,66,66,66,65,65,65,350,10000
);
INSERT INTO PLAYER VALUES (474,'Anselmo','Anselmo de Moraes','Silver - Rare','Normal',74,'Al Wehda','Saudi Professional League','Brazil','CDM','1989-02-20',67,66,63,64,73,79,0,0,0,0,0,0,'Right',2,3,73,71,71,70,70,73,70,67,67,67,66,66,66,65,65,66,300,10000
);
INSERT INTO PLAYER VALUES (475,'Gabriel Silva','Gabriel Moises Antunes da Silva','Silver - Rare','Normal',73,'AS Saint-etienne','Ligue 1 Conforama','Brazil','LB','1991-05-13',75,71,60,71,69,67,0,0,0,0,0,0,'Left',2,3,68,72,72,72,72,71,70,71,71,69,68,68,68,69,69,65,300,10000
);
INSERT INTO PLAYER VALUES (476,'Ayew','Jordan Ayew','Gold - Non-Rare','Normal',75,'Crystal Palace','Premier League','Ghana','ST','1991-09-11',76,75,74,70,45,72,0,0,0,0,0,0,'Right',3,4,56,59,59,61,61,59,69,73,73,73,74,74,74,74,74,74,300,10000
);
INSERT INTO PLAYER VALUES (477,'Boyata','Dedryck Boyata','Gold - Rare','Normal',76,'Hertha BSC','Bundesliga','Belgium','CB','1990-11-28',68,60,30,51,74,85,0,0,0,0,0,0,'Right',3,2,75,69,69,67,67,69,57,55,55,52,51,51,51,52,52,53,650,10000
);
INSERT INTO PLAYER VALUES (478,'Aurier','Serge Aurier','Gold - Non-Rare','Normal',79,'Tottenham Hotspur','Premier League','Cote d''Ivoire','RB','1992-12-24',77,76,59,73,77,76,0,0,0,0,0,0,'Right',3,3,78,78,78,78,78,77,73,74,74,72,72,72,72,73,73,69,350,10000
);
INSERT INTO PLAYER VALUES (479,'Kasami','Pajtim Kasami','Silver - Rare','Normal',73,'FC Sion','Raiffeisen Super League','Switzerland','CAM','1992-06-02',67,71,71,70,56,78,0,0,0,0,0,0,'Left',4,3,64,65,65,67,67,68,73,72,72,72,72,72,72,71,71,71,300,10000
);
INSERT INTO PLAYER VALUES (480,'Lejeune','Florian Lejeune','Gold - Non-Rare','Normal',78,'Newcastle United','Premier League','France','CB','1991-05-20',49,66,57,61,78,79,0,0,0,0,0,0,'Right',3,2,77,70,70,69,69,75,67,60,60,61,61,61,61,59,59,62,350,10000
);
INSERT INTO PLAYER VALUES (481,'Herrmann','Patrick Herrmann','Gold - Non-Rare','Normal',77,'Borussia Monchengladbach','Bundesliga','Germany','RM','1991-02-12',79,77,70,74,33,58,0,0,0,0,0,0,'Right',2,3,47,56,56,60,60,54,69,76,76,76,76,76,76,76,76,72,350,10000
);
INSERT INTO PLAYER VALUES (482,'Funes Mori','Rogelio Funes Mori','Gold - Non-Rare','Normal',77,'Monterrey','LIGA Bancomer MX','Argentina','ST','1991-03-05',76,74,74,68,43,78,0,0,0,0,0,0,'Right',4,3,57,60,60,61,61,60,70,74,74,74,75,75,75,74,74,76,350,10000
);
INSERT INTO PLAYER VALUES (483,'Guerrero','Miguel angel Guerrero Martin','Silver - Rare','Normal',73,'Olympiacos CFP','Hellas Liga','Spain','ST','1990-07-12',70,70,72,66,42,69,0,0,0,0,0,0,'Right',3,3,54,54,54,56,56,58,68,69,69,70,71,71,71,68,68,72,300,10000
);
INSERT INTO PLAYER VALUES (484,'Drmic','Josip Drmic','Gold - Non-Rare','Normal',75,'Norwich City','Premier League','Switzerland','ST','1992-08-08',76,73,75,67,38,70,0,0,0,0,0,0,'Right',4,3,52,55,55,58,58,55,65,71,71,71,72,72,72,72,72,74,300,10000
);
INSERT INTO PLAYER VALUES (485,'Murillo','oscar Murillo','Gold - Non-Rare','Normal',75,'Pachuca','LIGA Bancomer MX','Colombia','CB','1988-04-18',69,52,39,55,74,77,0,0,0,0,0,0,'Left',4,2,74,69,69,66,66,68,57,55,55,51,50,50,50,52,52,52,300,10000
);
INSERT INTO PLAYER VALUES (486,'Svensson','Jonas Svensson','Gold - Non-Rare','Normal',75,'AZ','Eredivisie','Norway','RB','1993-03-06',77,73,60,72,70,81,0,0,0,0,0,0,'Right',3,3,72,74,74,75,75,73,72,73,73,71,70,70,70,71,71,68,300,10000
);
INSERT INTO PLAYER VALUES (487,'Midtsjo','Fredrik Midtsjo','Gold - Non-Rare','Normal',75,'AZ','Eredivisie','Norway','CM','1993-08-11',73,74,62,73,67,76,0,0,0,0,0,0,'Right',3,3,69,71,71,73,73,73,74,73,73,72,70,70,70,71,71,67,300,10000
);
INSERT INTO PLAYER VALUES (488,'Gabbiadini','Manolo Gabbiadini','Gold - Non-Rare','Normal',76,'Sampdoria','Serie A TIM','Italy','ST','1991-11-26',66,75,79,71,26,64,0,0,0,0,0,0,'Left',3,3,43,47,47,51,51,50,67,73,73,74,76,76,76,74,74,75,350,10000
);
INSERT INTO PLAYER VALUES (489,'Malcuit','Kevin Malcuit','Gold - Rare','Normal',78,'Napoli','Serie A TIM','France','RB','1991-07-31',85,78,63,73,74,75,0,0,0,0,0,0,'Right',3,3,74,77,77,77,77,75,73,76,76,73,73,73,73,75,75,71,650,10000
);
INSERT INTO PLAYER VALUES (490,'Sarabia','Pablo Sarabia Garcia','Gold - Rare','Normal',83,'Paris Saint-Germain','Ligue 1 Conforama','Spain','CAM','1992-05-11',75,84,76,82,57,57,0,0,0,0,0,0,'Left',4,4,59,67,67,70,70,68,79,81,81,82,81,81,81,81,81,76,700,10000
);
INSERT INTO PLAYER VALUES (491,'Ryan','Mathew Ryan','Gold - Non-Rare','Normal',80,'Brighton e Hove Albion','Premier League','Australia','GK','1992-04-08',0,0,0,0,0,0,81,83,75,53,82,78,'Right',4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (492,'Tzavellas','Georgios Tzavellas','Silver - Rare','Normal',74,'Alanyaspor','Super Lig','Greece','CB','1987-11-26',67,62,62,66,73,77,0,0,0,0,0,0,'Left',3,2,73,70,70,70,70,71,64,63,63,61,60,60,60,62,62,62,300,10000
);
INSERT INTO PLAYER VALUES (493,'Dabo','Bryan Dabo','Silver - Rare','Normal',74,'Fiorentina','Serie A TIM','Burkina Faso','CM','1992-02-18',64,73,67,71,73,78,0,0,0,0,0,0,'Right',3,4,74,71,71,72,72,74,73,70,70,71,70,70,70,70,70,70,300,10000
);
INSERT INTO PLAYER VALUES (494,'Barkley','Ross Barkley','Gold - Non-Rare','Normal',79,'Chelsea','Premier League','England','CAM','1993-12-05',70,80,73,77,56,73,0,0,0,0,0,0,'Right',5,4,63,64,64,66,66,69,77,76,76,78,77,77,77,76,76,74,350,10000
);
INSERT INTO PLAYER VALUES (495,'Vida','Domagoj Vida','Gold - Rare','Normal',80,'Besiktas JK','Super Lig','Croatia','CB','1989-04-29',75,61,40,59,82,79,0,0,0,0,0,0,'Right',3,2,79,76,76,74,74,74,61,61,61,57,57,57,57,58,58,58,650,10000
);
INSERT INTO PLAYER VALUES (496,'Joao Pedro','Joao Pedro G. Santos Galvao','Gold - Non-Rare','Normal',76,'Cagliari','Serie A TIM','Brazil','CF','1992-03-09',72,74,75,72,40,67,0,0,0,0,0,0,'Right',4,4,52,56,56,59,59,59,72,74,74,75,76,76,76,75,75,74,350,10000
);
INSERT INTO PLAYER VALUES (497,'Bamba','Abdoulaye Bamba','Silver - Non-Rare','Normal',73,'Angers SCO','Ligue 1 Conforama','Cote d''Ivoire','RB','1990-04-25',78,66,41,65,70,73,0,0,0,0,0,0,'Right',3,2,70,72,72,72,72,70,66,66,66,63,60,60,60,63,63,57,150,10000
);
INSERT INTO PLAYER VALUES (498,'Lucas Perez','Lucas Perez Martinez','Gold - Non-Rare','Normal',77,'D. Alaves','LaLiga Santander','Spain','ST','1988-09-10',72,77,78,75,32,68,0,0,0,0,0,0,'Left',4,4,48,53,53,57,57,56,71,76,76,76,77,77,77,76,76,76,350,10000
);
INSERT INTO PLAYER VALUES (499,'Aguirregaray','Matias Aguirregaray','Silver - Non-Rare','Normal',73,'Al Fateh','Saudi Professional League','Uruguay','RB','1989-04-01',76,72,54,68,69,77,0,0,0,0,0,0,'Right',3,3,71,72,72,73,73,71,69,70,70,68,68,68,68,68,68,65,150,10000
);
INSERT INTO PLAYER VALUES (500,'Clasie','Jordy Clasie','Gold - Non-Rare','Normal',76,'AZ','Eredivisie','Holland','CM','1991-06-27',63,75,64,77,67,69,0,0,0,0,0,0,'Right',3,3,67,69,69,71,71,75,75,71,71,73,70,70,70,70,70,65,350,10000
);
INSERT INTO PLAYER VALUES (501,'Lopes','Anthony Lopes','Gold - Rare','Normal',85,'Olympique Lyonnais','Ligue 1 Conforama','Portugal','GK','1990-10-01',0,0,0,0,0,0,87,89,80,63,75,84,'Left',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1000,18000
);
INSERT INTO PLAYER VALUES (502,'Xhaka','Granit Xhaka','Gold - Rare','Normal',81,'Arsenal','Premier League','Switzerland','CM','1992-09-27',51,71,67,81,69,78,0,0,0,0,0,0,'Left',3,3,71,70,70,72,72,77,79,73,73,74,72,72,72,70,70,69,650,10000
);
INSERT INTO PLAYER VALUES (503,'Ilie Sanchez','Ilie Sanchez Farres','Silver - Rare','Normal',74,'Sporting Kansas City','Major League Soccer','Spain','CDM','1990-11-21',55,71,47,67,69,76,0,0,0,0,0,0,'Right',3,3,70,68,68,68,68,73,71,65,65,66,63,63,63,63,63,59,300,10000
);
INSERT INTO PLAYER VALUES (504,'Roberto','Sergi Roberto Carnicer','Gold - Rare','Normal',82,'FC Barcelona','LaLiga Santander','Spain','RB','1992-02-07',78,78,63,81,77,73,0,0,0,0,0,0,'Right',3,4,75,80,80,81,81,79,80,79,79,78,76,76,76,77,77,72,700,10000
);
INSERT INTO PLAYER VALUES (505,'Gonzalez Pirez','Leandro Gonzalez Pirez','Gold - Non-Rare','Normal',75,'Atlanta United','Major League Soccer','Argentina','CB','1992-02-26',72,66,48,62,73,78,0,0,0,0,0,0,'Right',3,2,74,71,71,70,70,74,69,65,65,65,64,64,64,62,62,62,300,10000
);
INSERT INTO PLAYER VALUES (506,'Royer','Daniel Royer','Gold - Non-Rare','Normal',75,'New York Red Bulls','Major League Soccer','Austria','LM','1990-05-22',83,76,73,68,48,73,0,0,0,0,0,0,'Right',3,4,56,60,60,63,63,60,68,74,74,73,74,74,74,74,74,72,300,10000
);
INSERT INTO PLAYER VALUES (507,'Wilson Eduardo','Wilson Bruno Naval Costa Eduardo','Gold - Non-Rare','Normal',77,'SC Braga','Liga NOS','Angola','RW','1990-07-08',79,77,79,72,31,67,0,0,0,0,0,0,'Right',3,4,46,53,53,57,57,53,69,76,76,76,77,77,77,77,77,76,350,10000
);
INSERT INTO PLAYER VALUES (508,'Kaminski','Marcin Kaminski','Silver - Rare','Normal',73,'VfB Stuttgart','Bundesliga 2','Poland','CB','1992-01-15',71,61,56,64,73,71,0,0,0,0,0,0,'Left',2,2,72,69,69,68,68,71,66,64,64,64,64,64,64,63,63,64,300,10000
);
INSERT INTO PLAYER VALUES (509,'Bereszynski','Bartosz Bereszynski','Silver - Rare','Normal',73,'Sampdoria','Serie A TIM','Poland','RB','1992-07-12',85,70,56,65,70,72,0,0,0,0,0,0,'Right',3,3,70,72,72,72,72,70,67,69,69,66,66,66,66,68,68,64,300,10000
);
INSERT INTO PLAYER VALUES (510,'Christiansen','Anders Christiansen','Silver - Rare','Normal',74,'Malmo FF','Allsvenskan','Denmark','CM','1990-06-08',74,75,70,70,63,71,0,0,0,0,0,0,'Right',3,3,66,69,69,70,70,70,73,72,72,73,72,72,72,72,72,69,300,10000
);
INSERT INTO PLAYER VALUES (511,'Pedro Obiang','Pedro Mba Obiang Avomo','Gold - Non-Rare','Normal',77,'Sassuolo','Serie A TIM','Equatorial Guinea','CDM','1992-03-27',62,73,59,74,75,74,0,0,0,0,0,0,'Right',3,3,74,73,73,73,73,76,74,70,70,71,68,68,68,68,68,66,350,10000
);
INSERT INTO PLAYER VALUES (512,'Alan Patrick','Alan Patrick Lourenco','Silver - Rare','Normal',74,'Shakhtar Donetsk','Ukraine Liga','Brazil','CAM','1991-05-13',75,78,71,73,53,59,0,0,0,0,0,0,'Right',3,4,56,63,63,66,66,64,71,73,73,73,72,72,72,73,73,69,300,10000
);
INSERT INTO PLAYER VALUES (513,'Rode','Sebastian Rode','Gold - Non-Rare','Normal',78,'Eintracht Frankfurt','Bundesliga','Germany','CDM','1990-10-11',67,73,62,71,76,77,0,0,0,0,0,0,'Right',3,3,76,74,74,74,74,77,74,71,71,72,71,71,71,70,70,68,350,10000
);
INSERT INTO PLAYER VALUES (514,'Berghuis','Steven Berghuis','Gold - Non-Rare','Normal',80,'Feyenoord','Eredivisie','Holland','RW','1991-12-19',78,81,77,81,36,62,0,0,0,0,0,0,'Left',2,3,48,57,57,62,62,60,76,79,79,80,79,79,79,80,80,74,350,10000
);
INSERT INTO PLAYER VALUES (515,'Garcia','Santiago Garcia','Silver - Non-Rare','Normal',73,'Deportivo Toluca','LIGA Bancomer MX','Argentina','CB','1988-07-08',52,61,53,63,72,77,0,0,0,0,0,0,'Left',3,2,72,68,68,67,67,68,63,61,61,59,59,59,59,59,59,61,150,10000
);
INSERT INTO PLAYER VALUES (516,'Uth','Mark Uth','Gold - Non-Rare','Normal',78,'FC Schalke 04','Bundesliga','Germany','ST','1991-08-24',76,77,80,69,40,68,0,0,0,0,0,0,'Left',3,3,52,58,58,60,60,59,71,75,75,76,78,78,78,76,76,77,350,10000
);
INSERT INTO PLAYER VALUES (517,'Camilo','Camilo da Silva Sanvezzo','Silver - Rare','Normal',74,'Club Tijuana','LIGA Bancomer MX','Brazil','ST','1988-07-21',78,76,74,67,34,65,0,0,0,0,0,0,'Right',4,4,47,53,53,56,56,52,65,72,72,71,72,72,72,73,73,73,300,10000
);
INSERT INTO PLAYER VALUES (518,'Schindler','Christopher Schindler','Gold - Non-Rare','Normal',76,'Huddersfield Town','EFL Championship','Germany','CB','1990-04-29',63,56,32,57,77,75,0,0,0,0,0,0,'Right',3,2,75,71,71,68,68,72,60,55,55,53,51,51,51,51,51,51,350,10000
);
INSERT INTO PLAYER VALUES (519,'Forrest','James Forrest','Gold - Rare','Normal',77,'Celtic','Scottish Premiership','Scotland','RM','1991-07-07',93,79,72,69,48,65,0,0,0,0,0,0,'Right',3,4,54,63,63,65,65,59,69,76,76,75,76,76,76,78,78,72,650,10000
);
INSERT INTO PLAYER VALUES (520,'Juan Jesus','Juan Guilherme Nunes Jesus','Gold - Rare','Normal',76,'Roma','Serie A TIM','Brazil','CB','1991-06-10',74,60,33,52,76,78,0,0,0,0,0,0,'Left',2,2,75,71,71,69,69,68,55,56,56,51,51,51,51,53,53,52,650,10000
);
INSERT INTO PLAYER VALUES (521,'Wakaso','Alhassan Wakaso','Gold - Non-Rare','Normal',76,'Vitoria Guimaraes','Liga NOS','Ghana','CDM','1992-01-07',67,66,49,60,77,83,0,0,0,0,0,0,'Right',3,2,77,72,72,71,71,75,68,62,62,63,61,61,61,60,60,60,350,10000
);
INSERT INTO PLAYER VALUES (522,'Marafona','Jose Carlos Coentrao Marafona','Silver - Rare','Normal',74,'Alanyaspor','Super Lig','Portugal','GK','1987-05-08',0,0,0,0,0,0,76,74,73,36,66,75,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (523,'Leitner','Moritz Leitner','Silver - Rare','Normal',73,'Norwich City','Premier League','Germany','CM','1992-12-08',69,74,65,74,59,58,0,0,0,0,0,0,'Right',4,3,60,65,65,68,68,68,72,71,71,72,70,70,70,71,71,64,300,10000
);
INSERT INTO PLAYER VALUES (524,'Lucas','Lucas Rodrigues Moura Silva','Gold - Rare','Normal',83,'Tottenham Hotspur','Premier League','Brazil','CF','1992-08-13',92,87,79,76,42,66,0,0,0,0,0,0,'Right',4,4,54,63,63,67,67,63,76,82,82,82,82,82,82,83,83,78,700,10000
);
INSERT INTO PLAYER VALUES (525,'Sorg','Oliver Sorg','Silver - Rare','Normal',73,'1. FC Nurnberg','Bundesliga 2','Germany','RB','1990-05-29',72,71,55,66,73,69,0,0,0,0,0,0,'Right',4,2,71,72,72,72,72,71,67,66,66,65,64,64,64,65,65,61,300,10000
);
INSERT INTO PLAYER VALUES (526,'Cedric','Cedric Ricardo Alves Soares','Gold - Non-Rare','Normal',76,'Southampton','Premier League','Portugal','RB','1991-08-31',77,75,66,70,73,70,0,0,0,0,0,0,'Right',4,3,72,75,75,76,76,74,73,73,73,72,72,72,72,72,72,70,350,10000
);
INSERT INTO PLAYER VALUES (527,'Ismaily','Ismaily Goncalves dos S.','Gold - Rare','Normal',80,'Shakhtar Donetsk','Ukraine Liga','Brazil','LB','1990-01-11',82,81,66,74,75,75,0,0,0,0,0,0,'Left',2,4,74,79,79,80,80,77,77,79,79,77,77,77,77,78,78,74,650,10000
);
INSERT INTO PLAYER VALUES (528,'Morrison','Ravel Morrison','Gold - Non-Rare','Normal',76,'Sheffield United','Premier League','England','CAM','1993-02-02',78,78,69,75,50,57,0,0,0,0,0,0,'Right',4,3,54,60,60,63,63,62,71,74,74,75,73,73,73,74,74,69,350,10000
);
INSERT INTO PLAYER VALUES (529,'Krejci','Ladislav Krejci','Silver - Rare','Normal',74,'Bologna','Serie A TIM','Czech Republic','LW','1992-07-05',78,76,68,75,50,57,0,0,0,0,0,0,'Left',2,4,55,62,62,65,65,63,71,74,74,74,73,73,73,74,74,67,300,10000
);
INSERT INTO PLAYER VALUES (530,'Falk','Rasmus Falk','Gold - Rare','Normal',75,'FC Kobenhavn','Superliga','Denmark','CM','1992-01-15',84,80,64,71,58,72,0,0,0,0,0,0,'Right',4,4,63,68,68,70,70,69,74,76,76,75,74,74,74,75,75,71,600,10000
);
INSERT INTO PLAYER VALUES (531,'Pablo','Pablo Nascimento Castro','Gold - Non-Rare','Normal',77,'FC Girondins de Bordeaux','Ligue 1 Conforama','Brazil','CB','1991-06-21',58,60,52,48,79,77,0,0,0,0,0,0,'Right',2,2,76,68,68,65,65,69,58,54,54,55,56,56,56,53,53,59,350,10000
);
INSERT INTO PLAYER VALUES (532,'Santander','Federico Santander','Gold - Non-Rare','Normal',75,'Bologna','Serie A TIM','Paraguay','ST','1991-06-04',69,70,74,63,32,79,0,0,0,0,0,0,'Right',2,3,49,49,49,52,52,52,64,68,68,70,72,72,72,70,70,74,300,10000
);
INSERT INTO PLAYER VALUES (533,'Murillo','Jeison Murillo','Gold - Rare','Normal',79,'Sampdoria','Serie A TIM','Colombia','CB','1992-05-27',75,64,40,59,79,80,0,0,0,0,0,0,'Right',3,2,78,74,74,72,72,73,63,61,61,58,58,58,58,58,58,59,650,10000
);
INSERT INTO PLAYER VALUES (534,'Ghoulam','Faouzi Ghoulam','Gold - Non-Rare','Normal',80,'Napoli','Serie A TIM','Algeria','LB','1991-02-01',75,77,64,77,78,73,0,0,0,0,0,0,'Left',4,3,76,79,79,80,80,78,76,76,76,74,73,73,73,74,74,71,350,10000
);
INSERT INTO PLAYER VALUES (535,'Ramirez','Gaston Ramirez','Gold - Non-Rare','Normal',78,'Sampdoria','Serie A TIM','Uruguay','CAM','1990-12-02',63,79,75,78,39,58,0,0,0,0,0,0,'Left',3,4,50,55,55,59,59,59,73,75,75,77,76,76,76,76,76,72,350,10000
);
INSERT INTO PLAYER VALUES (536,'Sansone','Nicola Sansone','Gold - Non-Rare','Normal',75,'Bologna','Serie A TIM','Italy','ST','1991-09-10',78,79,76,72,44,59,0,0,0,0,0,0,'Right',3,3,52,57,57,60,60,58,70,75,75,76,77,77,77,77,77,74,300,10000
);
INSERT INTO PLAYER VALUES (537,'Eysseric','Valentin Eysseric','Gold - Non-Rare','Normal',75,'Fiorentina','Serie A TIM','France','LW','1992-03-25',69,76,72,78,43,63,0,0,0,0,0,0,'Right',4,3,51,55,55,59,59,59,71,74,74,75,74,74,74,75,75,71,300,10000
);
INSERT INTO PLAYER VALUES (538,'Limbombe','Anthony Limbombe','Silver - Rare','Normal',73,'Standard de Liege','Belgium Pro League','Belgium','LW','1994-07-15',83,77,69,68,54,61,0,0,0,0,0,0,'Right',5,4,57,64,64,67,67,61,65,72,72,70,71,71,71,73,73,68,300,10000
);
INSERT INTO PLAYER VALUES (539,'Sanchez Mino','Juan Sanchez Mino','Silver - Rare','Normal',74,'Independiente','SAF','Argentina','LB','1990-01-01',70,76,73,77,71,72,0,0,0,0,0,0,'Left',2,4,71,73,73,74,74,74,76,75,75,75,74,74,74,75,75,72,300,10000
);
INSERT INTO PLAYER VALUES (540,'Coady','Conor Coady','Gold - Rare','Normal',77,'Wolverhampton Wanderers','Premier League','England','CB','1993-02-25',47,66,59,73,78,74,0,0,0,0,0,0,'Right',3,2,76,72,72,72,72,77,74,66,66,67,65,65,65,63,63,63,650,10000
);
INSERT INTO PLAYER VALUES (541,'Kurtic','Jasmin Kurtic','Gold - Non-Rare','Normal',75,'SPAL','Serie A TIM','Slovenia','CM','1989-01-10',61,71,69,73,71,78,0,0,0,0,0,0,'Right',3,3,73,71,71,71,71,74,74,71,71,72,71,71,71,70,70,71,300,10000
);
INSERT INTO PLAYER VALUES (542,'Nagbe','Darlington Nagbe','Gold - Non-Rare','Normal',75,'Atlanta United','Major League Soccer','United States','CM','1990-07-19',80,81,64,70,63,70,0,0,0,0,0,0,'Right',3,4,66,69,69,70,70,71,74,73,73,74,73,73,73,72,72,70,300,10000
);
INSERT INTO PLAYER VALUES (543,'Sturaro','Stefano Sturaro','Gold - Non-Rare','Normal',75,'Genoa','Serie A TIM','Italy','CM','1993-03-09',70,75,67,72,76,78,0,0,0,0,0,0,'Right',3,3,76,74,74,74,74,76,74,72,72,73,72,72,72,71,71,70,300,10000
);
INSERT INTO PLAYER VALUES (544,'Meunier','Thomas Meunier','Gold - Rare','Normal',82,'Paris Saint-Germain','Ligue 1 Conforama','Belgium','RB','1991-09-12',79,75,75,77,78,84,0,0,0,0,0,0,'Right',4,3,79,81,81,81,81,79,79,79,79,77,78,78,78,78,78,78,700,10000
);
INSERT INTO PLAYER VALUES (545,'Patric','Anderson Patric Aguiar Oliveira','Silver - Rare','Normal',73,'Gamba Osaka','Meiji Yasuda J1 League','Brazil','ST','1987-10-26',63,65,71,56,33,78,0,0,0,0,0,0,'Right',3,3,50,47,47,48,48,50,60,63,63,65,68,68,68,64,64,72,300,10000
);
INSERT INTO PLAYER VALUES (546,'Da Costa','Danny da Costa','Gold - Rare','Normal',79,'Eintracht Frankfurt','Bundesliga','Germany','RWB','1993-07-13',81,72,50,70,76,81,0,0,0,0,0,0,'Right',3,3,76,78,78,78,78,75,72,73,73,69,68,68,68,69,69,66,650,10000
);
INSERT INTO PLAYER VALUES (547,'Deulofeu','Gerard Deulofeu Lazaro','Gold - Rare','Normal',80,'Watford','Premier League','Spain','RF','1994-03-13',88,87,73,75,30,56,0,0,0,0,0,0,'Right',4,4,42,54,54,59,59,54,71,80,80,80,80,80,80,81,81,74,650,10000
);
INSERT INTO PLAYER VALUES (548,'Aleix Vidal','Aleix Vidal Parreu','Gold - Rare','Normal',76,'D. Alaves','LaLiga Santander','Spain','RB','1989-08-21',85,78,66,71,72,71,0,0,0,0,0,0,'Right',4,3,73,75,75,75,75,73,72,75,75,74,74,74,74,75,75,72,650,10000
);
INSERT INTO PLAYER VALUES (549,'Jese','Jese Rodriguez Ruiz','Gold - Non-Rare','Normal',75,'Paris Saint-Germain','Ligue 1 Conforama','Spain','LW','1993-02-26',80,78,71,72,25,62,0,0,0,0,0,0,'Right',4,4,40,49,49,53,53,51,68,74,74,74,74,74,74,75,75,71,300,10000
);
INSERT INTO PLAYER VALUES (550,'Griffiths','Leigh Griffiths','Silver - Rare','Normal',74,'Celtic','Scottish Premiership','Scotland','ST','1990-08-20',79,71,74,64,24,70,0,0,0,0,0,0,'Left',3,3,42,47,47,51,51,46,61,70,70,69,72,72,72,71,71,73,300,10000
);
INSERT INTO PLAYER VALUES (551,'Depay','Memphis Depay','Gold - Rare','Normal',84,'Olympique Lyonnais','Ligue 1 Conforama','Holland','CF','1994-02-13',87,83,80,81,32,78,0,0,0,0,0,0,'Right',3,5,50,57,57,61,61,59,76,83,83,82,83,83,83,83,83,80,700,10000
);
INSERT INTO PLAYER VALUES (552,'Ceppelini','Pablo Ceppelini','Silver - Rare','Normal',73,'Atletico Nacional','Liga Dimayor','Uruguay','CAM','1991-09-11',71,76,64,73,42,66,0,0,0,0,0,0,'Right',3,3,49,56,56,60,60,59,70,72,72,72,70,70,70,71,71,65,300,10000
);
INSERT INTO PLAYER VALUES (553,'Roussillon','Jerome Roussillon','Gold - Rare','Normal',82,'VfL Wolfsburg','Bundesliga','France','LB','1993-01-06',89,80,65,76,78,78,0,0,0,0,0,0,'Left',3,3,78,81,81,81,81,78,76,79,79,76,76,76,76,78,78,74,700,10000
);
INSERT INTO PLAYER VALUES (554,'Suso','Jesus Joaquin Fernandez Saez','Gold - Rare','Normal',82,'Milan','Serie A TIM','Spain','RW','1993-11-19',78,87,76,83,33,53,0,0,0,0,0,0,'Left',3,4,42,55,55,61,61,56,76,82,82,83,81,81,81,82,82,75,700,10000
);
INSERT INTO PLAYER VALUES (555,'Zaza','Simone Zaza','Gold - Non-Rare','Normal',80,'Torino','Serie A TIM','Italy','ST','1991-06-25',76,77,79,62,50,84,0,0,0,0,0,0,'Left',3,4,62,60,60,61,61,61,67,72,72,74,77,77,77,74,74,79,350,10000
);
INSERT INTO PLAYER VALUES (556,'Tarkowski','James Tarkowski','Gold - Non-Rare','Normal',79,'Burnley','Premier League','England','CB','1992-11-19',58,64,45,66,79,78,0,0,0,0,0,0,'Right',4,2,78,73,73,71,71,75,67,62,62,61,59,59,59,59,59,59,350,10000
);
INSERT INTO PLAYER VALUES (557,'Caprari','Gianluca Caprari','Silver - Rare','Normal',74,'Sampdoria','Serie A TIM','Italy','CF','1993-07-30',85,81,68,70,20,51,0,0,0,0,0,0,'Right',3,3,34,47,47,52,52,46,66,74,74,75,74,74,74,75,75,69,300,10000
);
INSERT INTO PLAYER VALUES (558,'Defrel','Gregoire Defrel','Gold - Rare','Normal',78,'Roma','Serie A TIM','France','ST','1991-06-17',86,81,78,68,36,55,0,0,0,0,0,0,'Left',3,4,46,53,53,56,56,52,68,76,76,77,79,79,79,79,79,77,650,10000
);
INSERT INTO PLAYER VALUES (559,'Spinazzola','Leonardo Spinazzola','Gold - Rare','Normal',79,'Roma','Serie A TIM','Italy','LM','1993-03-25',81,79,64,74,76,73,0,0,0,0,0,0,'Right',4,3,74,79,79,80,80,77,77,78,78,76,75,75,75,77,77,71,650,10000
);
INSERT INTO PLAYER VALUES (560,'Onazi','Ogenyi Onazi','Gold - Non-Rare','Normal',76,'Trabzonspor','Super Lig','Nigeria','CDM','1992-12-25',80,76,66,71,75,72,0,0,0,0,0,0,'Right',3,3,73,76,76,76,76,75,74,73,73,73,72,72,72,72,72,69,350,10000
);
INSERT INTO PLAYER VALUES (561,'Germain','Valere Germain','Gold - Non-Rare','Normal',75,'Olympique de Marseille','Ligue 1 Conforama','France','ST','1990-04-17',75,73,75,71,38,67,0,0,0,0,0,0,'Right',4,3,50,54,54,57,57,56,69,73,73,74,74,74,74,74,74,74,300,10000
);
INSERT INTO PLAYER VALUES (562,'Elyounoussi','Mohamed Elyounoussi','Gold - Non-Rare','Normal',76,'Southampton','Premier League','Norway','LM','1994-08-04',78,76,71,75,39,63,0,0,0,0,0,0,'Right',4,4,50,58,58,61,61,58,71,75,75,75,74,74,74,75,75,72,350,10000
);
INSERT INTO PLAYER VALUES (563,'Lascelles','Jamaal Lascelles','Gold - Non-Rare','Normal',78,'Newcastle United','Premier League','England','CB','1993-11-11',59,58,28,51,78,80,0,0,0,0,0,0,'Right',3,2,77,70,70,67,67,71,57,53,53,51,48,48,48,50,50,49,350,10000
);
INSERT INTO PLAYER VALUES (564,'Stones','John Stones','Gold - Rare','Normal',83,'Manchester City','Premier League','England','CB','1994-05-28',68,72,36,70,84,77,0,0,0,0,0,0,'Right',4,3,82,79,79,77,77,80,73,68,68,67,64,64,64,64,64,60,700,10000
);
INSERT INTO PLAYER VALUES (565,'Donnarumma','Alfredo Donnarumma','Gold - Rare','Normal',75,'Brescia','Serie A TIM','Italy','ST','1990-11-30',84,73,76,59,36,62,0,0,0,0,0,0,'Right',3,3,47,54,54,56,56,51,63,70,70,70,73,73,73,72,72,74,600,10000
);
INSERT INTO PLAYER VALUES (566,'Delaine','Thomas Delaine','Silver - Rare','Normal',74,'Football Club de Metz','Ligue 1 Conforama','France','LB','1992-03-24',83,73,50,71,67,78,0,0,0,0,0,0,'Right',5,3,70,73,73,74,74,71,71,73,73,70,69,69,69,71,71,65,300,10000
);
INSERT INTO PLAYER VALUES (567,'Bellerin','Hector Bellerin Moruno','Gold - Rare','Normal',80,'Arsenal','Premier League','Spain','RB','1995-03-19',92,77,51,70,76,66,0,0,0,0,0,0,'Right',3,3,73,79,79,79,79,74,71,75,75,72,71,71,71,74,74,66,650,10000
);
INSERT INTO PLAYER VALUES (568,'Ze Luis','Jose Luis Mendes Andrade','Gold - Rare','Normal',79,'FC Porto','Liga NOS','Cape Verde Islands','ST','1991-01-24',82,77,73,60,33,78,0,0,0,0,0,0,'Left',4,4,51,51,51,53,53,52,65,72,72,74,77,77,77,74,74,78,650,10000
);
INSERT INTO PLAYER VALUES (569,'Karius','Loris Karius','Gold - Non-Rare','Normal',79,'Besiktas JK','Super Lig','Germany','GK','1993-06-22',0,0,0,0,0,0,82,82,74,55,78,76,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (570,'Gutierrez','Felipe Gutierrez','Gold - Non-Rare','Normal',75,'Sporting Kansas City','Major League Soccer','Chile','CM','1990-10-08',66,75,70,75,60,65,0,0,0,0,0,0,'Left',4,3,62,67,67,69,69,69,74,73,73,74,73,73,73,73,73,69,300,10000
);
INSERT INTO PLAYER VALUES (571,'Zuculini','Bruno Zuculini','Gold - Non-Rare','Normal',75,'Nunez','SAF','Argentina','CDM','1993-04-02',66,72,58,69,70,77,0,0,0,0,0,0,'Right',3,3,72,69,69,70,70,74,72,68,68,69,67,67,67,67,67,65,300,10000
);
INSERT INTO PLAYER VALUES (572,'Vrsaljko','Sime Vrsaljko','Gold - Rare','Normal',80,'Atletico Madrid','LaLiga Santander','Croatia','RB','1992-01-10',77,75,55,74,79,77,0,0,0,0,0,0,'Right',3,3,78,79,79,80,80,78,74,74,74,71,70,70,70,71,71,68,650,10000
);
INSERT INTO PLAYER VALUES (573,'Knockaert','Anthony Knockaert','Gold - Non-Rare','Normal',76,'Fulham','EFL Championship','France','RW','1991-11-20',73,82,70,72,49,65,0,0,0,0,0,0,'Left',3,4,56,60,60,64,64,62,71,75,75,76,75,75,75,76,76,71,350,10000
);
INSERT INTO PLAYER VALUES (574,'Fortounis','Konstantinos Fortounis','Gold - Non-Rare','Normal',78,'Olympiacos CFP','Hellas Liga','Greece','CAM','1992-10-16',77,80,74,77,40,67,0,0,0,0,0,0,'Right',4,3,51,58,58,61,61,59,72,77,77,77,77,77,77,78,78,74,350,10000
);
INSERT INTO PLAYER VALUES (575,'Dilaver','Emir Dilaver','Silver - Rare','Normal',74,'GNK Dinamo Zagreb','Croatia Liga','Austria','CB','1991-05-07',71,61,46,59,74,76,0,0,0,0,0,0,'Right',3,2,73,70,70,68,68,71,63,61,61,59,58,58,58,58,58,59,300,10000
);
INSERT INTO PLAYER VALUES (576,'Niang','M''Baye Niang','Gold - Rare','Normal',77,'Stade Rennais FC','Ligue 1 Conforama','Senegal','ST','1994-12-19',89,80,76,68,31,65,0,0,0,0,0,0,'Right',4,3,45,52,52,56,56,51,67,75,75,76,78,78,78,77,77,76,650,10000
);
INSERT INTO PLAYER VALUES (577,'Ayoub','Yassin Ayoub','Silver - Rare','Normal',74,'Feyenoord','Eredivisie','Morocco','CM','1994-03-06',69,77,67,75,67,70,0,0,0,0,0,0,'Left',3,3,67,71,71,73,73,72,73,74,74,73,72,72,72,73,73,68,300,10000
);
INSERT INTO PLAYER VALUES (578,'Lala','Kenny Lala','Gold - Non-Rare','Normal',79,'RC Strasbourg Alsace','Ligue 1 Conforama','France','RWB','1991-10-03',79,77,54,76,74,76,0,0,0,0,0,0,'Right',3,3,74,77,77,78,78,76,75,76,76,73,72,72,72,73,73,68,350,10000
);
INSERT INTO PLAYER VALUES (579,'Vaclik','TomaS Vaclik','Gold - Non-Rare','Normal',81,'Sevilla FC','LaLiga Santander','Czech Republic','GK','1989-03-29',0,0,0,0,0,0,82,85,72,36,74,82,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (580,'Reynet','Baptiste Reynet','Gold - Non-Rare','Normal',77,'Toulouse Football Club','Ligue 1 Conforama','France','GK','1990-10-28',0,0,0,0,0,0,76,80,73,45,75,77,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (581,'Luis Neto','Luis Carlos Novo Neto','Gold - Non-Rare','Normal',77,'Sporting CP','Liga NOS','Portugal','CB','1988-05-26',58,54,37,59,79,74,0,0,0,0,0,0,'Right',3,2,76,70,70,67,67,72,61,55,55,54,52,52,52,51,51,53,350,10000
);
INSERT INTO PLAYER VALUES (582,'Garcia','Santiago Garcia','Gold - Non-Rare','Normal',78,'Godoy Cruz','SAF','Uruguay','ST','1990-09-14',66,71,80,62,27,84,0,0,0,0,0,0,'Right',4,3,47,46,46,49,49,51,64,69,69,71,74,74,74,71,71,77,350,10000
);
INSERT INTO PLAYER VALUES (583,'Ralls','Joe Ralls','Silver - Rare','Normal',74,'Cardiff City','EFL Championship','England','CM','1993-10-13',64,72,68,73,68,66,0,0,0,0,0,0,'Left',2,3,66,70,70,72,72,72,73,71,71,71,69,69,69,70,70,65,300,10000
);
INSERT INTO PLAYER VALUES (584,'Hervias','Pablo Hervias Rubio','Silver - Rare','Normal',73,'R. Valladolid CF','LaLiga Santander','Spain','RM','1993-03-08',81,77,64,69,40,50,0,0,0,0,0,0,'Right',3,4,45,56,56,60,60,55,66,72,72,71,71,71,71,73,73,65,300,10000
);
INSERT INTO PLAYER VALUES (585,'Ruidiaz','Raul Ruidiaz','Gold - Non-Rare','Normal',76,'Seattle Sounders FC','Major League Soccer','Peru','ST','1990-07-25',80,76,77,64,32,61,0,0,0,0,0,0,'Right',4,4,45,52,52,55,55,50,64,72,72,72,75,75,75,74,74,75,350,10000
);
INSERT INTO PLAYER VALUES (586,'Orban','Willi Orban','Gold - Non-Rare','Normal',81,'RB Leipzig','Bundesliga','Hungary','CB','1992-11-03',52,56,37,52,82,80,0,0,0,0,0,0,'Right',3,2,80,70,70,67,67,72,59,54,54,53,52,52,52,51,51,54,350,10000
);
INSERT INTO PLAYER VALUES (587,'Zahid','Ghayas Zahid','Silver - Rare','Normal',73,'Panathinaikos FC','Hellas Liga','Norway','CAM','1994-11-18',78,75,63,69,35,65,0,0,0,0,0,0,'Right',4,3,47,55,55,58,58,56,68,72,72,72,71,71,71,72,72,66,300,10000
);
INSERT INTO PLAYER VALUES (588,'Melgarejo','Lorenzo Melgarejo','Silver - Rare','Normal',74,'Spartak Moscow','League of Russia','Paraguay','RW','1990-08-10',84,76,69,66,55,69,0,0,0,0,0,0,'Left',2,4,62,68,68,68,68,64,69,73,73,72,73,73,73,74,74,73,300,10000
);
INSERT INTO PLAYER VALUES (589,'Campbell','Joel Campbell','Gold - Rare','Normal',76,'Club Leon','LIGA Bancomer MX','Costa Rica','ST','1992-06-26',88,78,74,74,40,72,0,0,0,0,0,0,'Left',2,4,54,59,59,63,63,60,71,77,77,76,76,76,76,77,77,75,650,10000
);
INSERT INTO PLAYER VALUES (590,'Ibarra','Renato Ibarra','Gold - Rare','Normal',76,'Club America','LIGA Bancomer MX','Ecuador','RM','1991-01-20',92,76,65,70,53,74,0,0,0,0,0,0,'Right',3,3,59,66,66,68,68,64,69,75,75,72,72,72,72,75,75,69,650,10000
);
INSERT INTO PLAYER VALUES (591,'Jimenez','Raul Jimenez','Gold - Rare','Normal',80,'Wolverhampton Wanderers','Premier League','Mexico','ST','1991-05-05',78,75,78,71,47,79,0,0,0,0,0,0,'Right',4,3,59,60,60,63,63,63,72,76,76,76,77,77,77,76,76,79,650,10000
);
INSERT INTO PLAYER VALUES (592,'Katai','Aleksandar Katai','Gold - Non-Rare','Normal',75,'Chicago Fire Soccer Club','Major League Soccer','Serbia','LM','1991-02-06',66,77,75,73,43,67,0,0,0,0,0,0,'Right',4,4,53,56,56,60,60,59,70,74,74,75,75,75,75,74,74,73,300,10000
);
INSERT INTO PLAYER VALUES (593,'Egan','John Egan','Silver - Rare','Normal',74,'Sheffield United','Premier League','Republic of Ireland','CB','1992-10-20',65,59,49,50,73,76,0,0,0,0,0,0,'Right',3,2,73,66,66,64,64,69,60,55,55,55,55,55,55,53,53,57,300,10000
);
INSERT INTO PLAYER VALUES (594,'Klement','Philipp Klement','Gold - Non-Rare','Normal',75,'VfB Stuttgart','Bundesliga 2','Germany','CAM','1992-09-09',69,76,70,74,40,57,0,0,0,0,0,0,'Left',3,3,49,56,56,60,60,59,70,72,72,74,72,72,72,73,73,68,300,10000
);
INSERT INTO PLAYER VALUES (595,'Inui','Takashi Inui','Gold - Non-Rare','Normal',79,'SD Eibar','LaLiga Santander','Japan','LM','1988-06-02',81,84,72,75,46,54,0,0,0,0,0,0,'Right',4,4,50,60,60,64,64,61,73,78,78,78,77,77,77,79,79,71,350,10000
);
INSERT INTO PLAYER VALUES (596,'Alioui','Rachid Alioui','Silver - Rare','Normal',73,'Angers SCO','Ligue 1 Conforama','Morocco','ST','1992-06-18',71,68,73,62,33,68,0,0,0,0,0,0,'Right',3,3,46,48,48,51,51,49,61,67,67,68,70,70,70,69,69,72,300,10000
);
INSERT INTO PLAYER VALUES (597,'Denis Suarez','Denis Suarez Fernandez','Gold - Non-Rare','Normal',78,'RC Celta','LaLiga Santander','Spain','CM','1994-01-06',76,82,72,79,59,56,0,0,0,0,0,0,'Right',3,3,60,67,67,70,70,69,77,79,79,80,78,78,78,79,79,73,350,10000
);
INSERT INTO PLAYER VALUES (598,'Soudani','Hillal Soudani','Gold - Non-Rare','Normal',75,'Olympiacos CFP','Hellas Liga','Algeria','ST','1987-11-25',72,75,75,69,43,67,0,0,0,0,0,0,'Left',4,4,54,55,55,57,57,57,67,72,72,73,74,74,74,74,74,74,300,10000
);
INSERT INTO PLAYER VALUES (599,'Pritchard','Alex Pritchard','Silver - Rare','Normal',73,'Huddersfield Town','EFL Championship','England','CAM','1993-05-03',69,75,68,74,46,48,0,0,0,0,0,0,'Right',4,3,50,58,58,61,61,59,69,71,71,72,71,71,71,71,71,65,300,10000
);
INSERT INTO PLAYER VALUES (600,'Nastasic','Matija Nastasic','Gold - Non-Rare','Normal',80,'FC Schalke 04','Bundesliga','Serbia','CB','1993-03-28',71,56,32,63,82,74,0,0,0,0,0,0,'Left',2,2,79,74,74,71,71,75,62,57,57,56,53,53,53,53,53,53,350,10000
);
INSERT INTO PLAYER VALUES (601,'Novak','Filip Novak','Gold - Non-Rare','Normal',75,'Trabzonspor','Super Lig','Czech Republic','LB','1990-06-26',79,73,65,69,73,75,0,0,0,0,0,0,'Left',3,3,72,74,74,74,74,72,71,73,73,71,71,71,71,72,72,71,300,10000
);
INSERT INTO PLAYER VALUES (602,'Boetius','Jean-Paul Boetius','Gold - Rare','Normal',78,'1. FSV Mainz 05','Bundesliga','Holland','CAM','1994-03-22',85,80,70,74,42,64,0,0,0,0,0,0,'Right',4,4,51,60,60,63,63,59,72,78,78,77,77,77,77,78,78,73,650,10000
);
INSERT INTO PLAYER VALUES (603,'Baselli','Daniele Baselli','Gold - Non-Rare','Normal',79,'Torino','Serie A TIM','Italy','CM','1992-03-12',71,81,73,79,66,68,0,0,0,0,0,0,'Right',3,4,68,71,71,73,73,73,78,77,77,79,77,77,77,77,77,74,350,10000
);
INSERT INTO PLAYER VALUES (604,'Djaniny','Jorge Djaniny Tavares Semedo','Gold - Rare','Normal',78,'Al Ahli','Saudi Professional League','Cape Verde Islands','ST','1991-03-21',83,77,74,68,35,76,0,0,0,0,0,0,'Right',4,4,50,55,55,59,59,56,70,76,76,75,76,76,76,76,76,77,650,10000
);
INSERT INTO PLAYER VALUES (605,'Fullkrug','Niclas Fullkrug','Gold - Non-Rare','Normal',77,'SV Werder Bremen','Bundesliga','Germany','ST','1993-02-09',64,70,77,62,38,75,0,0,0,0,0,0,'Right',4,3,51,50,50,52,52,52,63,69,69,69,73,73,73,70,70,76,350,10000
);
INSERT INTO PLAYER VALUES (606,'Rudiger','Antonio Rudiger','Gold - Rare','Normal',82,'Chelsea','Premier League','Germany','CB','1993-03-03',72,64,43,67,82,78,0,0,0,0,0,0,'Right',3,2,81,76,76,75,75,77,67,64,64,61,60,60,60,61,61,60,700,10000
);
INSERT INTO PLAYER VALUES (607,'Kverkvelia','Solomon Kverkvelia','Gold - Rare','Normal',76,'Lokomotiv Moscow','League of Russia','Georgia','CB','1992-02-06',72,42,38,53,78,81,0,0,0,0,0,0,'Right',2,2,75,70,70,66,66,70,57,51,51,49,47,47,47,47,47,50,650,10000
);
INSERT INTO PLAYER VALUES (608,'Krmencik','Michael Krmencik','Gold - Non-Rare','Normal',75,'Viktoria Plzen','Ceska Liga','Czech Republic','ST','1993-03-15',76,70,72,58,27,76,0,0,0,0,0,0,'Right',4,3,46,47,47,49,49,47,60,67,67,68,71,71,71,70,70,74,300,10000
);
INSERT INTO PLAYER VALUES (609,'Bernard','Bernard Anicio Caldeira Duarte','Gold - Rare','Normal',80,'Everton','Premier League','Brazil','LM','1992-09-08',87,85,69,76,38,44,0,0,0,0,0,0,'Right',4,4,45,59,59,63,63,57,72,79,79,78,78,78,78,80,80,73,650,10000
);
INSERT INTO PLAYER VALUES (610,'Alberto Moreno','Alberto Moreno Perez','Gold - Non-Rare','Normal',76,'Villarreal CF','LaLiga Santander','Spain','LB','1992-07-05',85,77,65,68,70,70,0,0,0,0,0,0,'Left',2,3,71,75,75,75,75,71,71,74,74,72,72,72,72,74,74,70,350,10000
);
INSERT INTO PLAYER VALUES (611,'Ocampos','Lucas Ocampos','Gold - Rare','Normal',77,'Sevilla FC','LaLiga Santander','Argentina','LM','1994-07-11',83,75,73,72,61,84,0,0,0,0,0,0,'Right',3,4,68,70,70,72,72,71,74,76,76,75,75,75,75,76,76,76,650,10000
);
INSERT INTO PLAYER VALUES (612,'Castro','Lucas Castro','Gold - Non-Rare','Normal',77,'Cagliari','Serie A TIM','Argentina','CM','1989-04-09',71,80,67,78,64,66,0,0,0,0,0,0,'Right',3,4,67,71,71,73,73,72,76,76,76,76,75,75,75,75,75,71,350,10000
);
INSERT INTO PLAYER VALUES (613,'ViSca','Edin ViSca','Gold - Rare','Normal',84,'Medipol Basaksehir FK','Super Lig','Bosnia and Herzegovina','RM','1990-02-17',88,84,79,79,47,64,0,0,0,0,0,0,'Right',4,4,54,66,66,70,70,65,77,83,83,82,81,81,81,83,83,77,700,10000
);
INSERT INTO PLAYER VALUES (614,'Haller','Sebastien Haller','Gold - Rare','Normal',83,'West Ham United','Premier League','France','ST','1994-06-22',72,76,81,62,51,82,0,0,0,0,0,0,'Right',2,3,64,61,61,61,61,62,70,72,72,76,79,79,79,74,74,81,700,10000
);
INSERT INTO PLAYER VALUES (615,'Denswil','Stefano Denswil','Gold - Non-Rare','Normal',76,'Bologna','Serie A TIM','Holland','CB','1993-05-07',46,65,57,66,76,74,0,0,0,0,0,0,'Left',4,3,75,67,67,66,66,73,67,59,59,63,61,61,61,58,58,61,350,10000
);
INSERT INTO PLAYER VALUES (616,'Pavoletti','Leonardo Pavoletti','Gold - Non-Rare','Normal',78,'Cagliari','Serie A TIM','Italy','ST','1988-11-26',60,69,76,51,37,78,0,0,0,0,0,0,'Right',3,3,52,47,47,48,48,50,60,64,64,67,72,72,72,66,66,77,350,10000
);
INSERT INTO PLAYER VALUES (617,'Livaja','Marko Livaja','Gold - Non-Rare','Normal',76,'AEK Athens','Hellas Liga','Croatia','ST','1993-08-26',74,75,73,60,32,77,0,0,0,0,0,0,'Right',5,3,50,49,49,52,52,52,64,70,70,72,75,75,75,72,72,75,350,10000
);
INSERT INTO PLAYER VALUES (618,'Kapino','Stefanos Kapino','Silver - Rare','Normal',73,'SV Werder Bremen','Bundesliga','Greece','GK','1994-03-18',0,0,0,0,0,0,74,79,67,41,66,72,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (619,'Ring','Alexander Ring','Gold - Non-Rare','Normal',75,'New York City FC','Major League Soccer','Finland','CDM','1991-04-09',74,73,65,70,73,76,0,0,0,0,0,0,'Right',3,3,73,72,72,73,73,74,71,71,71,70,69,69,69,70,70,68,300,10000
);
INSERT INTO PLAYER VALUES (620,'Murru','Nicola Murru','Silver - Rare','Normal',73,'Sampdoria','Serie A TIM','Italy','LB','1994-12-16',73,69,40,61,72,68,0,0,0,0,0,0,'Left',3,3,70,72,72,72,72,69,63,64,64,60,59,59,59,62,62,57,300,10000
);
INSERT INTO PLAYER VALUES (621,'Chiriches','Vlad Chiriches','Gold - Non-Rare','Normal',77,'Napoli','Serie A TIM','Romania','CB','1989-11-14',63,63,64,56,80,69,0,0,0,0,0,0,'Right',3,2,76,71,71,69,69,73,64,59,59,60,60,60,60,59,59,63,350,10000
);
INSERT INTO PLAYER VALUES (622,'Younes','Amin Younes','Gold - Rare','Normal',77,'Napoli','Serie A TIM','Germany','LM','1993-08-06',76,86,58,70,37,56,0,0,0,0,0,0,'Right',2,4,46,56,56,60,60,58,72,76,76,77,75,75,75,76,76,67,650,10000
);
INSERT INTO PLAYER VALUES (623,'Chambers','Calum Chambers','Gold - Non-Rare','Normal',75,'Arsenal','Premier League','England','CDM','1995-01-20',63,68,49,65,74,76,0,0,0,0,0,0,'Right',3,2,74,71,71,71,71,74,68,65,65,64,62,62,62,63,63,60,300,10000
);
INSERT INTO PLAYER VALUES (624,'Canteros','Hector Canteros','Silver - Rare','Normal',74,'MKE Ankaragucu','Super Lig','Argentina','CM','1989-03-15',68,71,69,73,68,74,0,0,0,0,0,0,'Right',3,3,69,70,70,71,71,72,73,71,71,71,71,71,71,70,70,69,300,10000
);
INSERT INTO PLAYER VALUES (625,'Heintz','Dominique Heintz','Gold - Non-Rare','Normal',76,'Sport-Club Freiburg','Bundesliga','Germany','CB','1993-08-15',59,60,36,60,74,79,0,0,0,0,0,0,'Left',3,2,75,69,69,67,67,71,63,56,56,56,53,53,53,53,53,51,350,10000
);
INSERT INTO PLAYER VALUES (626,'Ferri','Jordan Ferri','Silver - Rare','Normal',74,'Montpellier Herault SC','Ligue 1 Conforama','France','CM','1992-03-12',64,73,67,71,66,74,0,0,0,0,0,0,'Right',2,3,68,68,68,69,69,72,73,70,70,72,70,70,70,70,70,68,300,10000
);
INSERT INTO PLAYER VALUES (627,'Joao Pereira','Joao Pedro da Silva Pereira','Silver - Rare','Normal',74,'Trabzonspor','Super Lig','Portugal','RB','1984-02-25',71,74,61,71,74,64,0,0,0,0,0,0,'Right',3,3,71,73,73,74,74,73,71,71,71,70,69,69,69,71,71,66,300,10000
);
INSERT INTO PLAYER VALUES (628,'Stepanenko','Taras Stepanenko','Gold - Non-Rare','Normal',80,'Shakhtar Donetsk','Ukraine Liga','Ukraine','CDM','1989-08-08',67,70,61,72,78,80,0,0,0,0,0,0,'Left',3,3,78,76,76,76,76,79,75,70,70,70,69,69,69,68,68,67,350,10000
);
INSERT INTO PLAYER VALUES (629,'Kryvtsov','Sergiy Kryvtsov','Gold - Non-Rare','Normal',75,'Shakhtar Donetsk','Ukraine Liga','Ukraine','CB','1991-03-15',65,51,44,51,75,79,0,0,0,0,0,0,'Right',3,2,74,68,68,65,65,69,58,54,54,53,54,54,54,51,51,57,300,10000
);
INSERT INTO PLAYER VALUES (630,'Morozyuk','Mykola Morozyuk','Silver - Rare','Normal',74,'caykur Rizespor','Super Lig','Ukraine','RB','1988-01-17',75,70,62,75,69,50,0,0,0,0,0,0,'Right',4,3,63,73,73,75,75,71,71,70,70,69,66,66,66,69,69,61,300,10000
);
INSERT INTO PLAYER VALUES (631,'Benzia','Yassine Benzia','Silver - Rare','Normal',73,'LOSC Lille','Ligue 1 Conforama','Algeria','CAM','1994-09-08',70,75,71,70,45,63,0,0,0,0,0,0,'Right',4,4,53,58,58,60,60,59,69,72,72,72,72,72,72,72,72,70,300,10000
);
INSERT INTO PLAYER VALUES (632,'Arnold','Maximilian Arnold','Gold - Rare','Normal',79,'VfL Wolfsburg','Bundesliga','Germany','CM','1994-05-27',65,77,80,76,70,69,0,0,0,0,0,0,'Left',2,3,69,72,72,73,73,75,78,76,76,77,77,77,77,76,76,75,650,10000
);
INSERT INTO PLAYER VALUES (633,'Hughes','Will Hughes','Gold - Non-Rare','Normal',77,'Watford','Premier League','England','RM','1995-04-17',64,78,64,78,68,64,0,0,0,0,0,0,'Left',3,4,68,71,71,73,73,74,77,76,76,76,74,74,74,75,75,69,350,10000
);
INSERT INTO PLAYER VALUES (634,'Robinson','Callum Robinson','Silver - Rare','Normal',73,'Sheffield United','Premier League','Republic of Ireland','ST','1995-02-02',85,74,72,65,34,60,0,0,0,0,0,0,'Right',3,3,44,51,51,55,55,50,63,72,72,72,73,73,73,74,74,72,300,10000
);
INSERT INTO PLAYER VALUES (635,'Kepa','Kepa Arrizabalaga','Gold - Rare','Normal',84,'Chelsea','Premier League','Spain','GK','1994-10-03',0,0,0,0,0,0,84,85,82,34,86,80,'Right',4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,700,10000
);
INSERT INTO PLAYER VALUES (636,'Trossard','Leandro Trossard','Gold - Rare','Normal',79,'Brighton e Hove Albion','Premier League','Belgium','LW','1994-12-04',83,82,80,76,30,62,0,0,0,0,0,0,'Right',4,4,44,52,52,56,56,53,72,78,78,79,78,78,78,79,79,76,650,10000
);
INSERT INTO PLAYER VALUES (637,'Paredes','Leandro Paredes','Gold - Rare','Normal',80,'Paris Saint-Germain','Ligue 1 Conforama','Argentina','CM','1994-06-29',71,79,67,81,72,74,0,0,0,0,0,0,'Right',4,4,73,75,75,76,76,78,79,77,77,78,75,75,75,75,75,71,650,10000
);
INSERT INTO PLAYER VALUES (638,'Vietto','Luciano Vietto','Silver - Rare','Normal',74,'Sporting CP','Liga NOS','Argentina','ST','1993-12-05',76,76,73,68,43,61,0,0,0,0,0,0,'Right',3,3,52,56,56,58,58,57,68,72,72,74,74,74,74,74,74,73,300,10000
);
INSERT INTO PLAYER VALUES (639,'Lukaku','Jordan Lukaku','Gold - Rare','Normal',77,'Lazio','Serie A TIM','Belgium','LM','1994-07-25',91,79,61,70,71,78,0,0,0,0,0,0,'Left',4,3,73,76,76,77,77,74,72,76,76,73,73,73,73,75,75,70,650,10000
);
INSERT INTO PLAYER VALUES (640,'Ayhan','Kaan Ayhan','Gold - Non-Rare','Normal',77,'Fortuna Dusseldorf','Bundesliga','Turkey','CB','1994-11-10',64,68,53,71,77,75,0,0,0,0,0,0,'Right',4,3,76,73,73,72,72,75,70,65,65,66,64,64,64,64,64,63,350,10000
);
INSERT INTO PLAYER VALUES (641,'Poulsen','Yussuf Poulsen','Gold - Rare','Normal',81,'RB Leipzig','Bundesliga','Denmark','ST','1994-06-15',83,75,74,67,56,82,0,0,0,0,0,0,'Right',3,3,65,65,65,66,66,64,70,76,76,75,78,78,78,77,77,79,650,10000
);
INSERT INTO PLAYER VALUES (642,'Fraser','Ryan Fraser','Gold - Rare','Normal',81,'Bournemouth','Premier League','Scotland','LM','1994-02-24',90,83,73,78,46,61,0,0,0,0,0,0,'Right',4,3,52,64,64,68,68,64,75,80,80,80,78,78,78,81,81,72,650,10000
);
INSERT INTO PLAYER VALUES (643,'Felipe','Felipe Augusto de Almeida Monteiro','Gold - Rare','Normal',84,'Atletico Madrid','LaLiga Santander','Brazil','CB','1989-05-16',64,61,41,57,84,87,0,0,0,0,0,0,'Right',3,2,83,74,74,72,72,77,64,59,59,58,56,56,56,56,56,57,700,12000
);
INSERT INTO PLAYER VALUES (644,'Martinez','Josef Martinez','Gold - Rare','Normal',81,'Atlanta United','Major League Soccer','Venezuela','ST','1993-05-19',89,79,79,61,25,73,0,0,0,0,0,0,'Right',4,3,45,49,49,52,52,49,65,74,74,75,78,78,78,76,76,80,650,10000
);
INSERT INTO PLAYER VALUES (645,'Strobl','Tobias Strobl','Gold - Non-Rare','Normal',77,'Borussia Monchengladbach','Bundesliga','Germany','CDM','1990-05-12',53,58,49,66,79,77,0,0,0,0,0,0,'Right',3,2,76,71,71,69,69,76,69,60,60,61,59,59,59,57,57,58,350,10000
);
INSERT INTO PLAYER VALUES (646,'Lucas Lima','Lucas Pedro Alves de Lima','Gold - Non-Rare','Normal',75,'FC Nantes','Ligue 1 Conforama','Brazil','LB','1991-10-10',73,72,57,72,71,71,0,0,0,0,0,0,'Left',1,3,69,74,74,75,75,73,71,71,71,69,68,68,68,69,69,63,300,10000
);
INSERT INTO PLAYER VALUES (647,'Traore','Bertrand Traore','Gold - Rare','Normal',78,'Olympique Lyonnais','Ligue 1 Conforama','Burkina Faso','RW','1995-09-06',87,83,73,71,43,66,0,0,0,0,0,0,'Left',1,4,54,60,60,62,62,60,72,77,77,78,78,78,78,78,78,76,650,10000
);
INSERT INTO PLAYER VALUES (648,'Pelkas','Dimitrios Pelkas','Gold - Non-Rare','Normal',75,'PAOK','Hellas Liga','Greece','CAM','1993-10-26',80,76,69,74,37,49,0,0,0,0,0,0,'Right',3,4,43,53,53,57,57,54,69,73,73,74,73,73,73,74,74,68,300,10000
);
INSERT INTO PLAYER VALUES (649,'Gabriel','Gabriel Appelt Pires','Gold - Rare','Normal',80,'SL Benfica','Liga NOS','Brazil','CM','1993-09-18',63,79,74,77,76,83,0,0,0,0,0,0,'Left',5,3,77,75,75,76,76,80,79,76,76,77,76,76,76,74,74,75,650,10000
);
INSERT INTO PLAYER VALUES (650,'Mantalos','Petros Mantalos','Gold - Non-Rare','Normal',75,'AEK Athens','Hellas Liga','Greece','CAM','1991-08-31',73,78,69,75,50,61,0,0,0,0,0,0,'Right',4,3,55,60,60,63,63,63,72,74,74,74,73,73,73,74,74,69,300,10000
);
INSERT INTO PLAYER VALUES (651,'Bakasetas','Anastasios Bakasetas','Silver - Rare','Normal',73,'Alanyaspor','Super Lig','Greece','CAM','1993-06-28',69,69,73,74,43,70,0,0,0,0,0,0,'Left',4,3,54,57,57,59,59,59,69,71,71,72,71,71,71,71,71,71,300,10000
);
INSERT INTO PLAYER VALUES (652,'Kourmpelis','Dimitrios Kourmpelis','Silver - Rare','Normal',74,'Panathinaikos FC','Hellas Liga','Greece','CDM','1993-11-02',75,66,52,63,73,77,0,0,0,0,0,0,'Right',3,3,72,71,71,71,71,73,66,63,63,62,59,59,59,61,61,57,300,10000
);
INSERT INTO PLAYER VALUES (653,'Cristante','Bryan Cristante','Gold - Non-Rare','Normal',78,'Roma','Serie A TIM','Italy','CM','1995-03-03',58,75,72,75,74,76,0,0,0,0,0,0,'Right',3,3,74,73,73,73,73,76,77,73,73,75,74,74,74,73,73,73,350,10000
);
INSERT INTO PLAYER VALUES (654,'Saiss','Romain Saiss','Gold - Non-Rare','Normal',77,'Wolverhampton Wanderers','Premier League','Morocco','CDM','1990-03-26',62,69,53,70,76,74,0,0,0,0,0,0,'Left',3,3,76,72,72,71,71,76,72,66,66,68,65,65,65,64,64,63,350,10000
);
INSERT INTO PLAYER VALUES (655,'Herelle','Christophe Herelle','Gold - Non-Rare','Normal',78,'OGC Nice','Ligue 1 Conforama','France','CB','1992-08-22',64,63,46,63,78,74,0,0,0,0,0,0,'Right',3,2,77,74,74,72,72,74,65,62,62,60,59,59,59,60,60,60,350,10000
);
INSERT INTO PLAYER VALUES (656,'Dabbur','Munas Dabbur','Gold - Non-Rare','Normal',80,'Sevilla FC','LaLiga Santander','Israel','ST','1992-05-14',75,77,78,65,32,72,0,0,0,0,0,0,'Right',4,4,48,52,52,54,54,53,69,74,74,76,78,78,78,75,75,79,350,10000
);
INSERT INTO PLAYER VALUES (657,'Foket','Thomas Foket','Gold - Non-Rare','Normal',75,'Stade de Reims','Ligue 1 Conforama','Belgium','RB','1994-09-25',77,71,57,69,72,72,0,0,0,0,0,0,'Right',3,3,71,74,74,74,74,72,70,71,71,69,68,68,68,69,69,65,300,10000
);
INSERT INTO PLAYER VALUES (658,'Sakai','Hiroki Sakai','Gold - Non-Rare','Normal',78,'Olympique de Marseille','Ligue 1 Conforama','Japan','RB','1990-04-12',78,68,54,68,76,79,0,0,0,0,0,0,'Right',3,2,76,77,77,76,76,74,69,70,70,67,67,67,67,68,68,67,350,10000
);
INSERT INTO PLAYER VALUES (659,'Magnusson','Horour Magnusson','Silver - Rare','Normal',73,'CSKA Moscow','League of Russia','Iceland','CB','1993-02-11',66,61,48,66,73,73,0,0,0,0,0,0,'Left',2,2,72,70,70,69,69,70,62,60,60,57,55,55,55,57,57,56,300,10000
);
INSERT INTO PLAYER VALUES (660,'Duncan','Alfred Duncan','Gold - Non-Rare','Normal',75,'Sassuolo','Serie A TIM','Ghana','CM','1993-03-10',71,73,63,73,76,76,0,0,0,0,0,0,'Left',3,3,76,76,76,76,76,77,74,72,72,72,71,71,71,71,71,69,300,10000
);
INSERT INTO PLAYER VALUES (661,'Vaulks','Will Vaulks','Silver - Rare','Normal',73,'Cardiff City','EFL Championship','Wales','CDM','1993-09-13',59,64,62,66,71,77,0,0,0,0,0,0,'Right',3,2,71,69,69,69,69,72,69,65,65,65,64,64,64,64,64,63,300,10000
);
INSERT INTO PLAYER VALUES (662,'oliver Torres','oliver Torres Munoz','Gold - Non-Rare','Normal',78,'Sevilla FC','LaLiga Santander','Spain','CM','1994-11-10',67,82,66,78,63,52,0,0,0,0,0,0,'Right',4,3,61,69,69,71,71,71,77,77,77,78,75,75,75,76,76,69,350,10000
);
INSERT INTO PLAYER VALUES (663,'Thomasson','Adrien Thomasson','Gold - Non-Rare','Normal',76,'RC Strasbourg Alsace','Ligue 1 Conforama','France','CM','1993-12-10',73,76,70,75,64,63,0,0,0,0,0,0,'Right',4,4,65,68,68,70,70,70,75,74,74,75,74,74,74,74,74,71,350,10000
);
INSERT INTO PLAYER VALUES (664,'Guilherme','Guilherme dos Santos Torres','Gold - Non-Rare','Normal',76,'Olympiacos CFP','Hellas Liga','Brazil','CDM','1991-04-05',67,69,64,72,72,78,0,0,0,0,0,0,'Right',4,3,74,73,73,73,73,75,73,69,69,70,69,69,69,68,68,68,350,10000
);
INSERT INTO PLAYER VALUES (665,'Mollet','Florent Mollet','Gold - Non-Rare','Normal',78,'Montpellier Herault SC','Ligue 1 Conforama','France','CAM','1991-11-19',76,79,74,78,50,59,0,0,0,0,0,0,'Right',4,4,55,62,62,66,66,65,75,76,76,77,76,76,76,76,76,71,350,10000
);
INSERT INTO PLAYER VALUES (666,'Fred','Frederico R. de Paula Santos','Gold - Non-Rare','Normal',79,'Manchester United','Premier League','Brazil','CM','1993-03-05',76,80,73,75,74,69,0,0,0,0,0,0,'Left',4,4,73,75,75,76,76,78,78,76,76,77,76,76,76,76,76,72,350,10000
);
INSERT INTO PLAYER VALUES (667,'Gerso','Gerso Fernandes','Silver - Rare','Normal',73,'Sporting Kansas City','Major League Soccer','Guinea-Bissau','LW','1991-02-23',93,76,66,62,41,50,0,0,0,0,0,0,'Left',2,3,47,58,58,60,60,55,65,72,72,71,72,72,72,73,73,67,300,10000
);
INSERT INTO PLAYER VALUES (668,'Laborde','Gaetan Laborde','Gold - Non-Rare','Normal',78,'Montpellier Herault SC','Ligue 1 Conforama','France','ST','1994-05-03',72,74,76,67,34,79,0,0,0,0,0,0,'Left',3,3,51,52,52,55,55,55,68,73,73,73,75,75,75,74,74,77,350,10000
);
INSERT INTO PLAYER VALUES (669,'Mena','Eugenio Mena','Gold - Non-Rare','Normal',76,'Racing Club','SAF','Chile','LB','1988-07-18',78,73,48,69,73,73,0,0,0,0,0,0,'Left',3,3,72,75,75,76,76,73,70,72,72,69,67,67,67,69,69,62,350,10000
);
INSERT INTO PLAYER VALUES (670,'Larsson','Sam Larsson','Gold - Non-Rare','Normal',75,'Feyenoord','Eredivisie','Sweden','LW','1993-04-10',74,80,71,73,38,61,0,0,0,0,0,0,'Right',2,5,48,56,56,60,60,59,72,74,74,76,74,74,74,75,75,69,300,10000
);
INSERT INTO PLAYER VALUES (671,'Fernandes','Junior Fernandes','Gold - Rare','Normal',75,'Alanyaspor','Super Lig','Chile','LM','1988-10-04',78,76,74,69,35,75,0,0,0,0,0,0,'Right',4,4,50,54,54,57,57,55,68,74,74,74,75,75,75,75,75,76,600,10000
);
INSERT INTO PLAYER VALUES (672,'Letschert','Timo Letschert','Silver - Rare','Normal',74,'Hamburger SV','Bundesliga 2','Holland','CB','1993-05-25',62,61,58,64,72,77,0,0,0,0,0,0,'Right',2,2,73,68,68,67,67,69,63,61,61,60,60,60,60,60,60,62,300,10000
);
INSERT INTO PLAYER VALUES (673,'Gunter','Christian Gunter','Gold - Non-Rare','Normal',75,'Sport-Club Freiburg','Bundesliga','Germany','LB','1993-02-28',82,69,48,67,71,79,0,0,0,0,0,0,'Left',2,3,71,74,74,75,75,71,66,69,69,64,64,64,64,66,66,62,300,10000
);
INSERT INTO PLAYER VALUES (674,'Van Overeem','Joris van Overeem','Silver - Rare','Normal',74,'FC Utrecht','Eredivisie','Holland','CM','1994-06-01',70,76,62,72,61,59,0,0,0,0,0,0,'Right',3,3,61,66,66,67,67,68,73,71,71,72,70,70,70,71,71,66,300,10000
);
INSERT INTO PLAYER VALUES (675,'Grimaldo','Alejandro Grimaldo Garcia','Gold - Rare','Normal',83,'SL Benfica','Liga NOS','Spain','LB','1995-09-20',85,84,63,79,77,71,0,0,0,0,0,0,'Left',2,3,75,81,81,82,82,79,79,80,80,78,77,77,77,78,78,72,700,10000
);
INSERT INTO PLAYER VALUES (676,'Schar','Fabian Schar','Gold - Non-Rare','Normal',79,'Newcastle United','Premier League','Switzerland','CB','1991-12-20',62,69,66,71,80,75,0,0,0,0,0,0,'Right',4,2,78,74,74,73,73,76,72,68,68,69,68,68,68,67,67,69,350,10000
);
INSERT INTO PLAYER VALUES (677,'Kedziora','Tomasz Kedziora','Gold - Non-Rare','Normal',75,'FC Dynamo Kyiv','Ukraine Liga','Poland','RB','1994-06-11',77,64,45,66,74,73,0,0,0,0,0,0,'Right',3,2,73,74,74,73,73,70,65,67,67,63,62,62,62,64,64,60,300,10000
);
INSERT INTO PLAYER VALUES (678,'Garry Rodrigues','Garry Mendes Rodrigues','Gold - Non-Rare','Normal',76,'Fenerbahce SK','Super Lig','Cape Verde Islands','LM','1990-11-27',83,76,72,71,43,69,0,0,0,0,0,0,'Right',3,4,53,61,61,64,64,60,70,75,75,74,74,74,74,75,75,72,350,10000
);
INSERT INTO PLAYER VALUES (679,'Pereira','Ricardo Barbosa Pereira','Gold - Rare','Normal',82,'Leicester City','Premier League','Portugal','RB','1993-10-06',86,81,64,77,79,73,0,0,0,0,0,0,'Right',4,3,77,81,81,81,81,80,79,79,79,77,77,77,77,78,78,73,700,10000
);
INSERT INTO PLAYER VALUES (680,'De Tomas','Raul de Tomas Gomez','Gold - Non-Rare','Normal',79,'SL Benfica','Liga NOS','Spain','ST','1994-10-17',72,74,81,60,35,71,0,0,0,0,0,0,'Right',3,3,49,49,49,52,52,51,63,69,69,71,74,74,74,72,72,78,350,10000
);
INSERT INTO PLAYER VALUES (681,'Mbaye','Ibrahima Mbaye','Silver - Rare','Normal',73,'Bologna','Serie A TIM','Senegal','RB','1994-11-19',70,68,49,65,72,69,0,0,0,0,0,0,'Right',3,3,70,72,72,72,72,70,65,65,65,62,62,62,62,63,63,61,300,10000
);
INSERT INTO PLAYER VALUES (682,'Hofmann','Jonas Hofmann','Gold - Non-Rare','Normal',78,'Borussia Monchengladbach','Bundesliga','Germany','CAM','1992-07-14',76,77,69,76,47,62,0,0,0,0,0,0,'Right',4,3,53,62,62,66,66,63,74,77,77,76,75,75,75,76,76,70,350,10000
);
INSERT INTO PLAYER VALUES (683,'Haps','Ridgeciano Haps','Gold - Rare','Normal',75,'Feyenoord','Eredivisie','Holland','LB','1993-06-12',89,75,53,66,69,71,0,0,0,0,0,0,'Left',3,3,69,74,74,75,75,70,68,72,72,69,69,69,69,71,71,65,600,10000
);
INSERT INTO PLAYER VALUES (684,'Zielinski','Piotr Zielinski','Gold - Rare','Normal',81,'Napoli','Serie A TIM','Poland','CM','1994-05-20',81,83,72,81,70,61,0,0,0,0,0,0,'Right',5,4,68,75,75,77,77,75,80,80,80,81,79,79,79,80,80,74,650,10000
);
INSERT INTO PLAYER VALUES (685,'Otavio','Otavio Edmilson da Silva Monteiro','Gold - Non-Rare','Normal',79,'FC Porto','Liga NOS','Brazil','RM','1995-02-09',75,84,69,77,45,62,0,0,0,0,0,0,'Right',3,4,53,59,59,63,63,63,74,78,78,78,77,77,77,78,78,72,350,10000
);
INSERT INTO PLAYER VALUES (686,'Rusnak','Albert Rusnak','Gold - Non-Rare','Normal',76,'Real Salt Lake','Major League Soccer','Slovakia','CAM','1994-07-07',72,75,75,75,45,60,0,0,0,0,0,0,'Right',4,3,51,59,59,62,62,61,72,74,74,75,74,74,74,74,74,70,350,10000
);
INSERT INTO PLAYER VALUES (687,'Boulaya','Farid Boulaya','Silver - Rare','Normal',73,'Football Club de Metz','Ligue 1 Conforama','Algeria','RW','1993-02-25',76,78,65,70,25,52,0,0,0,0,0,0,'Right',4,5,38,49,49,53,53,49,65,72,72,72,71,71,71,73,73,66,300,10000
);
INSERT INTO PLAYER VALUES (688,'Fran Sol','Francisco Sol Ortiz','Gold - Non-Rare','Normal',75,'FC Dynamo Kyiv','Ukraine Liga','Spain','ST','1992-03-13',68,67,77,55,34,68,0,0,0,0,0,0,'Right',3,3,47,47,47,49,49,49,61,64,64,67,70,70,70,66,66,74,300,10000
);
INSERT INTO PLAYER VALUES (689,'Castillejo','Samuel Castillejo Azuaga','Gold - Non-Rare','Normal',80,'Milan','Serie A TIM','Spain','RM','1995-01-18',82,81,73,78,43,52,0,0,0,0,0,0,'Left',2,4,50,59,59,63,63,61,74,79,79,79,79,79,79,80,80,73,350,10000
);
INSERT INTO PLAYER VALUES (690,'Mbabu','Kevin Mbabu','Gold - Rare','Normal',77,'VfL Wolfsburg','Bundesliga','Switzerland','RB','1995-04-19',91,73,51,69,72,82,0,0,0,0,0,0,'Right',3,3,73,76,76,76,76,73,70,74,74,70,70,70,70,71,71,67,650,10000
);
INSERT INTO PLAYER VALUES (691,'Hegazi','Ahmed Hegazi','Gold - Non-Rare','Normal',75,'West Bromwich Albion','EFL Championship','Egypt','CB','1991-01-25',52,54,20,44,75,80,0,0,0,0,0,0,'Right',2,2,74,64,64,61,61,68,54,47,47,46,44,44,44,43,43,44,300,10000
);
INSERT INTO PLAYER VALUES (692,'Engels','Bjorn Engels','Gold - Non-Rare','Normal',76,'Aston Villa','Premier League','Belgium','CB','1994-09-15',60,57,44,61,75,76,0,0,0,0,0,0,'Right',3,2,75,69,69,67,67,72,65,60,60,59,58,58,58,57,57,58,350,10000
);
INSERT INTO PLAYER VALUES (693,'Laurini','Vincent Laurini','Silver - Rare','Normal',73,'Parma','Serie A TIM','France','RB','1989-06-10',75,68,33,60,72,68,0,0,0,0,0,0,'Right',3,3,71,72,72,72,72,69,61,62,62,58,56,56,56,59,59,52,300,10000
);
INSERT INTO PLAYER VALUES (694,'Hysaj','Elseid Hysaj','Gold - Non-Rare','Normal',80,'Napoli','Serie A TIM','Albania','RB','1994-02-02',79,75,51,68,78,74,0,0,0,0,0,0,'Right',3,3,76,79,79,79,79,77,72,73,73,69,68,68,68,70,70,66,350,10000
);
INSERT INTO PLAYER VALUES (695,'Sanson','Morgan Sanson','Gold - Non-Rare','Normal',79,'Olympique de Marseille','Ligue 1 Conforama','France','CM','1994-08-18',75,77,73,78,70,75,0,0,0,0,0,0,'Right',4,4,72,74,74,75,75,75,78,77,77,77,76,76,76,76,76,75,350,10000
);
INSERT INTO PLAYER VALUES (696,'Fernandinho','Da Conceicao Fernando Henrique','Gold - Non-Rare','Normal',76,'Hebei China Fortune FC','CSL','Brazil','CAM','1993-03-16',80,77,69,72,51,67,0,0,0,0,0,0,'Left',3,4,58,63,63,66,66,64,72,75,75,75,75,75,75,75,75,71,350,10000
);
INSERT INTO PLAYER VALUES (697,'Lazaro','Valentino Lazaro','Gold - Rare','Normal',75,'Inter','Serie A TIM','Austria','RB','1996-03-24',84,80,70,76,69,67,0,0,0,0,0,0,'Right',3,4,68,74,74,76,76,73,75,78,78,77,76,76,76,78,78,72,600,10000
);
INSERT INTO PLAYER VALUES (698,'Centurion','Ricardo Centurion','Gold - Non-Rare','Normal',77,'Atletico de San Luis','LIGA Bancomer MX','Argentina','LM','1993-01-19',90,81,70,69,37,66,0,0,0,0,0,0,'Right',3,4,49,58,58,62,62,57,69,76,76,75,75,75,75,76,76,72,350,10000
);
INSERT INTO PLAYER VALUES (699,'Fernandez','Guillermo Fernandez','Gold - Non-Rare','Normal',75,'Cruz Azul','LIGA Bancomer MX','Argentina','CAM','1991-10-11',72,75,70,74,65,70,0,0,0,0,0,0,'Right',3,3,66,69,69,71,71,70,74,74,74,74,73,73,73,74,74,70,300,10000
);
INSERT INTO PLAYER VALUES (700,'Martial','Anthony Martial','Gold - Rare','Normal',83,'Manchester United','Premier League','France','LW','1995-12-05',89,85,81,72,41,71,0,0,0,0,0,0,'Right',3,4,54,61,61,64,64,60,73,80,80,81,82,82,82,82,82,81,700,11000
);
INSERT INTO PLAYER VALUES (701,'Lapadula','Gianluca Lapadula','Silver - Non-Rare','Normal',73,'Lecce','Serie A TIM','Italy','ST','1990-02-07',73,73,71,57,24,64,0,0,0,0,0,0,'Left',3,3,42,45,45,48,48,44,58,67,67,68,71,71,71,69,69,72,150,10000
);
INSERT INTO PLAYER VALUES (702,'Benassi','Marco Benassi','Gold - Non-Rare','Normal',77,'Fiorentina','Serie A TIM','Italy','CM','1994-09-08',64,76,71,75,72,74,0,0,0,0,0,0,'Right',3,3,72,72,72,73,73,75,76,74,74,75,74,74,74,73,73,73,350,10000
);
INSERT INTO PLAYER VALUES (703,'Bruma','Armindo Tue Na Bangna','Gold - Rare','Normal',78,'PSV','Eredivisie','Portugal','LW','1994-10-24',90,83,72,71,32,63,0,0,0,0,0,0,'Right',4,4,46,55,55,60,60,55,69,77,77,76,77,77,77,78,78,73,650,10000
);
INSERT INTO PLAYER VALUES (704,'Linetty','Karol Linetty','Gold - Non-Rare','Normal',76,'Sampdoria','Serie A TIM','Poland','CM','1995-02-02',69,75,63,71,72,70,0,0,0,0,0,0,'Right',3,3,71,72,72,72,72,75,75,72,72,73,71,71,71,71,71,68,350,10000
);
INSERT INTO PLAYER VALUES (705,'Luiz Phellype','Luiz Phellype Luciano Silva','Gold - Non-Rare','Normal',76,'Sporting CP','Liga NOS','Brazil','ST','1993-09-27',54,70,78,59,30,81,0,0,0,0,0,0,'Right',3,3,49,48,48,51,51,50,62,66,66,67,71,71,71,68,68,75,350,10000
);
INSERT INTO PLAYER VALUES (706,'Boyd','Tyler Boyd','Gold - Non-Rare','Normal',75,'Besiktas JK','Super Lig','United States','RM','1994-12-30',86,77,73,66,18,66,0,0,0,0,0,0,'Right',4,3,37,47,47,52,52,46,63,74,74,73,75,75,75,76,76,72,300,10000
);
INSERT INTO PLAYER VALUES (707,'Kwon Chang Hoon','Chang Hoon Kwon','Gold - Non-Rare','Normal',75,'Sport-Club Freiburg','Bundesliga','Korea Republic','RM','1994-06-30',73,76,72,73,52,60,0,0,0,0,0,0,'Left',3,4,58,64,64,66,66,65,72,74,74,74,74,74,74,74,74,71,300,10000
);
INSERT INTO PLAYER VALUES (708,'Beric','Robert Beric','Gold - Non-Rare','Normal',75,'AS Saint-etienne','Ligue 1 Conforama','Slovenia','ST','1991-06-17',57,68,76,65,38,72,0,0,0,0,0,0,'Right',3,3,51,50,50,52,52,56,67,68,68,71,72,72,72,69,69,74,300,10000
);
INSERT INTO PLAYER VALUES (709,'Jahovic','Adis Jahovic','Silver - Rare','Normal',73,'Evkur Yeni Malatyaspor','Super Lig','FYR Macedonia','ST','1987-03-18',63,64,73,48,33,76,0,0,0,0,0,0,'Right',3,3,48,43,43,44,44,46,55,60,60,63,67,67,67,63,63,72,300,10000
);
INSERT INTO PLAYER VALUES (710,'Gagliardini','Roberto Gagliardini','Gold - Non-Rare','Normal',78,'Inter','Serie A TIM','Italy','CDM','1994-04-07',61,74,63,71,77,73,0,0,0,0,0,0,'Right',2,3,75,74,74,74,74,77,75,71,71,72,70,70,70,69,69,69,350,10000
);
INSERT INTO PLAYER VALUES (711,'Nacho','Jose Ignacio Martinez Garcia','Gold - Rare','Normal',77,'R. Valladolid CF','LaLiga Santander','Spain','LB','1989-03-07',84,70,55,66,75,70,0,0,0,0,0,0,'Left',3,3,72,76,76,75,75,72,67,69,69,65,65,65,65,67,67,64,650,10000
);
INSERT INTO PLAYER VALUES (712,'Solari','Augusto Solari','Gold - Non-Rare','Normal',75,'Racing Club','SAF','Argentina','RM','1992-01-03',90,75,63,72,56,75,0,0,0,0,0,0,'Right',4,3,63,68,68,70,70,67,71,74,74,73,72,72,72,74,74,69,300,10000
);
INSERT INTO PLAYER VALUES (713,'Ivan Cavaleiro','Ivan Ricardo Cavaleiro','Gold - Non-Rare','Normal',75,'Fulham','EFL Championship','Portugal','LW','1993-10-18',86,76,71,69,38,68,0,0,0,0,0,0,'Right',4,4,51,56,56,59,59,56,67,74,74,73,74,74,74,75,75,73,300,10000
);
INSERT INTO PLAYER VALUES (714,'Bazoer','Riechedly Bazoer','Silver - Rare','Normal',73,'Vitesse','Eredivisie','Holland','CM','1996-10-12',74,75,64,72,63,73,0,0,0,0,0,0,'Right',4,3,67,68,68,69,69,70,72,73,73,73,72,72,72,72,72,69,300,10000
);
INSERT INTO PLAYER VALUES (715,'Diony','Lois Diony','Silver - Rare','Normal',74,'AS Saint-etienne','Ligue 1 Conforama','France','ST','1992-12-20',77,71,73,63,25,74,0,0,0,0,0,0,'Right',3,3,43,48,48,51,51,47,62,70,70,69,72,72,72,71,71,73,300,10000
);
INSERT INTO PLAYER VALUES (716,'Mings','Tyrone Mings','Silver - Rare','Normal',74,'Aston Villa','Premier League','England','CB','1993-03-13',69,65,44,63,73,78,0,0,0,0,0,0,'Left',3,3,73,71,71,71,71,70,64,64,64,61,60,60,60,62,62,60,300,10000
);
INSERT INTO PLAYER VALUES (717,'Cho Hyun Woo','Hyun Woo Cho','Silver - Rare','Normal',74,'Daegu FC','K LEAGUE Classic','Korea Republic','GK','1991-09-25',0,0,0,0,0,0,75,78,71,51,59,74,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (718,'Hurtado','Aviles Hurtado','Gold - Rare','Normal',75,'Monterrey','LIGA Bancomer MX','Colombia','ST','1987-04-20',91,78,73,68,47,70,0,0,0,0,0,0,'Right',4,3,56,61,61,63,63,60,69,75,75,74,75,75,75,76,76,74,600,10000
);
INSERT INTO PLAYER VALUES (719,'Telles','Alex Nicolao Telles','Gold - Rare','Normal',84,'FC Porto','Liga NOS','Brazil','LB','1992-12-15',85,81,72,84,80,76,0,0,0,0,0,0,'Left',2,3,79,83,83,84,84,82,82,82,82,80,79,79,79,80,80,76,700,13000
);
INSERT INTO PLAYER VALUES (720,'Masuaku','Arthur Masuaku','Gold - Rare','Normal',76,'West Ham United','Premier League','Congo DR','LB','1993-11-07',86,80,63,72,70,70,0,0,0,0,0,0,'Left',2,4,70,75,75,75,75,72,73,76,76,74,73,73,73,75,75,70,650,10000
);
INSERT INTO PLAYER VALUES (721,'Dendoncker','Leander Dendoncker','Gold - Rare','Normal',78,'Wolverhampton Wanderers','Premier League','Belgium','CM','1995-04-15',67,71,72,77,78,83,0,0,0,0,0,0,'Right',4,2,78,76,76,76,76,78,77,74,74,74,74,74,74,72,72,74,650,10000
);
INSERT INTO PLAYER VALUES (722,'Vangioni','Leonel Vangioni','Gold - Non-Rare','Normal',75,'Monterrey','LIGA Bancomer MX','Argentina','LB','1987-05-05',83,72,63,69,72,75,0,0,0,0,0,0,'Left',3,3,72,74,74,74,74,72,70,71,71,69,69,69,69,71,71,67,300,10000
);
INSERT INTO PLAYER VALUES (723,'De Paul','Rodrigo Javier De Paul','Gold - Non-Rare','Normal',78,'Udinese','Serie A TIM','Argentina','CF','1994-05-24',75,82,73,78,35,63,0,0,0,0,0,0,'Right',3,4,48,56,56,60,60,58,74,78,78,79,78,78,78,78,78,73,350,10000
);
INSERT INTO PLAYER VALUES (724,'Yedlin','DeAndre Yedlin','Gold - Rare','Normal',76,'Newcastle United','Premier League','United States','RWB','1993-07-09',92,75,51,65,71,70,0,0,0,0,0,0,'Right',3,3,71,75,75,75,75,70,68,72,72,69,69,69,69,71,71,66,650,10000
);
INSERT INTO PLAYER VALUES (725,'Cyprien','Wylan Cyprien','Gold - Rare','Normal',77,'OGC Nice','Ligue 1 Conforama','France','CM','1995-01-28',76,78,75,76,74,78,0,0,0,0,0,0,'Right',3,4,75,74,74,75,75,76,76,76,76,76,76,76,76,76,76,75,650,10000
);
INSERT INTO PLAYER VALUES (726,'Stark','Niklas Stark','Gold - Rare','Normal',79,'Hertha BSC','Bundesliga','Germany','CB','1995-04-14',78,67,53,66,80,75,0,0,0,0,0,0,'Right',3,2,78,75,75,73,73,75,70,67,67,67,66,66,66,65,65,65,650,10000
);
INSERT INTO PLAYER VALUES (727,'Elneny','Mohamed Elneny','Gold - Non-Rare','Normal',77,'Arsenal','Premier League','Egypt','CDM','1992-07-11',59,71,63,72,74,74,0,0,0,0,0,0,'Right',3,3,72,73,73,73,73,76,74,70,70,70,68,68,68,68,68,66,350,10000
);
INSERT INTO PLAYER VALUES (728,'Origi','Divock Origi','Gold - Rare','Normal',78,'Liverpool','Premier League','Belgium','ST','1995-04-18',82,75,76,67,27,74,0,0,0,0,0,0,'Right',4,4,46,51,51,55,55,52,67,74,74,74,76,76,76,75,75,77,650,10000
);
INSERT INTO PLAYER VALUES (729,'Zobnin','Roman Zobnin','Gold - Non-Rare','Normal',79,'Spartak Moscow','League of Russia','Russia','CDM','1994-02-11',76,80,64,75,78,73,0,0,0,0,0,0,'Right',3,4,75,78,78,79,79,78,78,77,77,76,74,74,74,75,75,71,350,10000
);
INSERT INTO PLAYER VALUES (730,'Tameze','Adrien Tameze','Gold - Non-Rare','Normal',75,'OGC Nice','Ligue 1 Conforama','France','CM','1994-02-04',68,74,59,66,73,73,0,0,0,0,0,0,'Right',3,3,73,72,72,72,72,74,74,70,70,71,70,70,70,69,69,68,300,10000
);
INSERT INTO PLAYER VALUES (731,'Coman','Kingsley Coman','Gold - Rare','Normal',84,'FC Bayern Munchen','Bundesliga','France','LM','1996-06-13',92,86,76,77,29,60,0,0,0,0,0,0,'Right',3,4,43,55,55,60,60,54,74,83,83,82,82,82,82,84,84,78,700,13000
);
INSERT INTO PLAYER VALUES (732,'Tait','Flavien Tait','Gold - Non-Rare','Normal',78,'Stade Rennais FC','Ligue 1 Conforama','France','LM','1993-02-02',75,80,71,76,33,58,0,0,0,0,0,0,'Right',3,3,45,55,55,60,60,57,73,77,77,77,76,76,76,77,77,71,350,10000
);
INSERT INTO PLAYER VALUES (733,'Laxalt','Diego Laxalt','Gold - Non-Rare','Normal',78,'Milan','Serie A TIM','Uruguay','LM','1993-02-07',88,78,63,74,62,69,0,0,0,0,0,0,'Left',3,4,64,73,73,75,75,71,74,77,77,74,73,73,73,75,75,68,350,10000
);
INSERT INTO PLAYER VALUES (734,'Mora','Felipe Mora','Silver - Rare','Normal',74,'U.N.A.M.','LIGA Bancomer MX','Chile','ST','1993-08-02',81,72,74,55,27,65,0,0,0,0,0,0,'Right',3,3,42,45,45,47,47,47,63,67,67,69,72,72,72,69,69,73,300,10000
);
INSERT INTO PLAYER VALUES (735,'Hojbjerg','Pierre-Emile Hojbjerg','Gold - Non-Rare','Normal',77,'Southampton','Premier League','Denmark','CM','1995-08-05',61,74,70,74,73,79,0,0,0,0,0,0,'Right',4,3,73,71,71,72,72,76,76,72,72,73,72,72,72,71,71,71,350,10000
);
INSERT INTO PLAYER VALUES (736,'Christensen','Andreas Christensen','Gold - Non-Rare','Normal',80,'Chelsea','Premier League','Denmark','CB','1996-04-10',68,69,31,63,82,72,0,0,0,0,0,0,'Right',3,2,79,75,75,73,73,77,67,63,63,62,58,58,58,59,59,55,350,10000
);
INSERT INTO PLAYER VALUES (737,'Pearson','Ben Pearson','Gold - Rare','Normal',75,'Preston North End','EFL Championship','England','CDM','1995-01-04',70,71,50,63,72,85,0,0,0,0,0,0,'Right',3,3,73,71,71,71,71,74,68,66,66,65,64,64,64,64,64,60,600,10000
);
INSERT INTO PLAYER VALUES (738,'Di Francesco','Federico Di Francesco','Gold - Non-Rare','Normal',76,'SPAL','Serie A TIM','Italy','LW','1994-06-14',81,81,67,73,40,61,0,0,0,0,0,0,'Right',4,4,48,58,58,63,63,58,70,76,76,75,74,74,74,76,76,69,350,10000
);
INSERT INTO PLAYER VALUES (739,'Mendes','Thiago Henrique Mendes Ribeiro','Gold - Rare','Normal',81,'Olympique Lyonnais','Ligue 1 Conforama','Brazil','CDM','1992-03-15',78,79,70,78,77,74,0,0,0,0,0,0,'Right',3,4,76,78,78,79,79,80,80,77,77,78,76,76,76,76,76,73,650,10000
);
INSERT INTO PLAYER VALUES (740,'Lerma','Jefferson Lerma','Gold - Non-Rare','Normal',79,'Bournemouth','Premier League','Colombia','CDM','1994-10-25',73,73,64,72,78,80,0,0,0,0,0,0,'Right',4,3,77,77,77,77,77,78,74,71,71,71,70,70,70,70,70,68,350,10000
);
INSERT INTO PLAYER VALUES (741,'Miranchuk','Alexey Miranchuk','Gold - Non-Rare','Normal',78,'Lokomotiv Moscow','League of Russia','Russia','CAM','1995-10-17',74,79,66,78,31,62,0,0,0,0,0,0,'Left',2,3,45,54,54,59,59,56,73,76,76,77,75,75,75,76,76,70,350,10000
);
INSERT INTO PLAYER VALUES (742,'Bourigeaud','Benjamin Bourigeaud','Gold - Non-Rare','Normal',77,'Stade Rennais FC','Ligue 1 Conforama','France','LM','1994-01-14',69,77,73,78,61,70,0,0,0,0,0,0,'Right',3,4,65,70,70,72,72,72,77,76,76,77,76,76,76,76,76,72,350,10000
);
INSERT INTO PLAYER VALUES (743,'Bocanegra','Daniel Bocanegra','Silver - Rare','Normal',74,'Atletico Nacional','Liga Dimayor','Colombia','CB','1987-04-23',71,65,55,69,73,76,0,0,0,0,0,0,'Right',2,2,73,72,72,72,72,72,68,66,66,65,64,64,64,65,65,63,300,10000
);
INSERT INTO PLAYER VALUES (744,'Cano','German Cano','Gold - Non-Rare','Normal',78,'Independiente Medellin','Liga Dimayor','Argentina','ST','1988-01-02',69,75,80,62,36,66,0,0,0,0,0,0,'Right',4,3,48,50,50,53,53,54,67,70,70,73,75,75,75,72,72,77,350,10000
);
INSERT INTO PLAYER VALUES (745,'Quinones','Luis Quinones','Gold - Rare','Normal',75,'Tigres U.A.N.L.','LIGA Bancomer MX','Colombia','LM','1991-06-26',91,77,70,67,33,62,0,0,0,0,0,0,'Left',4,4,45,52,52,56,56,52,66,74,74,74,74,74,74,76,76,72,600,10000
);
INSERT INTO PLAYER VALUES (746,'Izquierdoz','Carlos Izquierdoz','Gold - Non-Rare','Normal',78,'Buenos Aires','SAF','Argentina','CB','1988-11-03',50,54,51,54,78,81,0,0,0,0,0,0,'Right',2,2,77,70,70,68,68,72,60,54,54,53,54,54,54,52,52,58,350,10000
);
INSERT INTO PLAYER VALUES (747,'Mas','Emmanuel Mas','Gold - Non-Rare','Normal',75,'Buenos Aires','SAF','Argentina','LB','1989-01-15',78,72,61,67,71,80,0,0,0,0,0,0,'Left',2,3,73,74,74,74,74,73,72,71,71,70,70,70,70,70,70,69,300,10000
);
INSERT INTO PLAYER VALUES (748,'Mancuello','Federico Mancuello','Gold - Non-Rare','Normal',76,'Deportivo Toluca','LIGA Bancomer MX','Argentina','CAM','1989-03-26',75,74,72,77,62,71,0,0,0,0,0,0,'Left',2,4,66,69,69,71,71,70,75,75,75,75,75,75,75,75,75,72,350,10000
);
INSERT INTO PLAYER VALUES (749,'Miranda','Leonel Miranda','Gold - Non-Rare','Normal',77,'Club Tijuana','LIGA Bancomer MX','Argentina','CM','1994-01-07',76,77,67,76,70,69,0,0,0,0,0,0,'Right',3,3,68,73,73,75,75,75,76,74,74,74,72,72,72,73,73,68,350,10000
);
INSERT INTO PLAYER VALUES (750,'Lezcano','Gaston Lezcano','Silver - Non-Rare','Normal',73,'Monarcas Morelia','LIGA Bancomer MX','Argentina','RM','1986-11-21',80,74,70,66,24,69,0,0,0,0,0,0,'Right',4,3,42,49,49,53,53,49,64,72,72,71,72,72,72,72,72,72,150,10000
);
INSERT INTO PLAYER VALUES (751,'Lopez','Lisandro Lopez','Gold - Non-Rare','Normal',77,'Buenos Aires','SAF','Argentina','CB','1989-09-01',63,62,51,50,77,72,0,0,0,0,0,0,'Right',3,2,76,67,67,65,65,69,58,55,55,56,57,57,57,55,55,59,350,10000
);
INSERT INTO PLAYER VALUES (752,'Perez','Pablo Perez','Gold - Non-Rare','Normal',77,'Independiente','SAF','Argentina','CM','1985-08-10',63,75,68,77,70,80,0,0,0,0,0,0,'Right',3,3,73,72,72,73,73,76,76,73,73,75,73,73,73,72,72,70,350,10000
);
INSERT INTO PLAYER VALUES (753,'Kalinski','Enzo Kalinski','Silver - Rare','Normal',74,'Estudiantes de La Plata','SAF','Argentina','CDM','1987-03-10',65,70,51,71,70,82,0,0,0,0,0,0,'Right',4,3,72,70,70,70,70,73,73,69,69,69,67,67,67,67,67,65,300,10000
);
INSERT INTO PLAYER VALUES (754,'Buffarini','Julio Buffarini','Gold - Rare','Normal',75,'Buenos Aires','SAF','Argentina','RB','1988-08-18',87,73,62,66,69,81,0,0,0,0,0,0,'Right',3,3,72,74,74,74,74,72,70,72,72,70,70,70,70,71,71,69,600,10000
);
INSERT INTO PLAYER VALUES (755,'Sigali','Leonardo Sigali','Gold - Non-Rare','Normal',79,'Racing Club','SAF','Argentina','CB','1987-05-29',68,59,41,44,80,74,0,0,0,0,0,0,'Right',3,2,78,69,69,66,66,68,54,54,54,52,54,54,54,54,54,57,350,10000
);
INSERT INTO PLAYER VALUES (756,'Lertora','Federico Lertora','Silver - Rare','Normal',73,'Colon de Santa Fe','SAF','Argentina','CDM','1990-07-05',64,65,51,63,77,76,0,0,0,0,0,0,'Right',3,2,76,73,73,72,72,72,65,64,64,62,62,62,62,62,62,62,300,10000
);
INSERT INTO PLAYER VALUES (757,'Angileri','Fabrizio Angileri','Silver - Rare','Normal',73,'Nunez','SAF','Argentina','LB','1994-03-15',81,73,67,68,68,77,0,0,0,0,0,0,'Left',3,3,69,72,72,73,73,70,69,73,73,70,71,71,71,72,72,70,300,10000
);
INSERT INTO PLAYER VALUES (758,'Donatti','Alejandro Donatti','Gold - Non-Rare','Normal',78,'Racing Club','SAF','Argentina','CB','1986-10-24',50,54,60,57,78,79,0,0,0,0,0,0,'Right',4,2,77,68,68,65,65,71,62,55,55,57,58,58,58,54,54,64,350,10000
);
INSERT INTO PLAYER VALUES (759,'Rius','Ciro Rius','Silver - Rare','Normal',74,'Rosario Central','SAF','Argentina','RW','1988-10-27',81,76,65,72,54,72,0,0,0,0,0,0,'Right',3,3,60,66,66,68,68,65,71,75,75,73,73,73,73,74,74,70,300,10000
);
INSERT INTO PLAYER VALUES (760,'Felipe','Felipe Dal Bello','Silver - Rare','Normal',74,'SPAL','Serie A TIM','Brazil','CB','1984-07-31',34,53,35,51,78,59,0,0,0,0,0,0,'Left',3,2,73,63,63,60,60,68,56,46,46,49,47,47,47,44,44,47,300,10000
);
INSERT INTO PLAYER VALUES (761,'Tarantini','Ricardo Jose Monteiro','Silver - Rare','Normal',74,'Rio Ave FC','Liga NOS','Portugal','CM','1983-10-07',47,71,68,71,72,68,0,0,0,0,0,0,'Right',3,3,72,66,66,66,66,72,73,67,67,71,70,70,70,68,68,70,300,10000
);
INSERT INTO PLAYER VALUES (762,'Nuzzolo','Raphael Nuzzolo','Silver - Rare','Normal',74,'Neuchatel Xamax','Raiffeisen Super League','Switzerland','ST','1983-07-05',73,74,76,74,41,66,0,0,0,0,0,0,'Left',4,3,52,59,59,62,62,59,70,74,74,74,74,74,74,75,75,73,300,10000
);
INSERT INTO PLAYER VALUES (763,'Ricardo Costa','Ricardo Miguel Moreira Costa','Silver - Rare','Normal',74,'Boavista FC','Liga NOS','Portugal','CB','1981-05-16',41,54,37,47,74,73,0,0,0,0,0,0,'Right',3,2,73,62,62,59,59,64,53,48,48,49,49,49,49,47,47,51,300,10000
);
INSERT INTO PLAYER VALUES (764,'Butelle','Ludovic Butelle','Silver - Rare','Normal',74,'Angers SCO','Ligue 1 Conforama','France','GK','1983-04-03',0,0,0,0,0,0,75,75,73,32,65,74,'Left',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (765,'Pele','Yohann Pele','Silver - Rare','Normal',74,'Olympique de Marseille','Ligue 1 Conforama','France','GK','1982-11-04',0,0,0,0,0,0,75,74,75,38,67,73,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (766,'Benaglio','Diego Benaglio','Silver - Rare','Normal',74,'AS Monaco Football Club SA','Ligue 1 Conforama','Switzerland','GK','1983-09-08',0,0,0,0,0,0,71,71,79,39,61,77,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (767,'Hansen','Jesper Hansen','Gold - Non-Rare','Normal',75,'FC Midtjylland','Superliga','Denmark','GK','1985-05-31',0,0,0,0,0,0,75,75,71,41,75,74,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (768,'Hubnik','Roman Hubnik','Silver - Rare','Normal',74,'Viktoria Plzen','Ceska Liga','Czech Republic','CB','1984-06-06',64,57,53,60,71,76,0,0,0,0,0,0,'Right',3,2,73,67,67,66,66,69,62,59,59,59,58,58,58,58,58,60,300,10000
);
INSERT INTO PLAYER VALUES (769,'Belluschi','Fernando Belluschi','Silver - Rare','Normal',74,'San Lorenzo de Almagro','SAF','Argentina','CAM','1983-09-10',55,74,74,76,65,64,0,0,0,0,0,0,'Right',4,4,66,65,65,66,66,69,73,70,70,73,72,72,72,71,71,70,300,10000
);
INSERT INTO PLAYER VALUES (770,'Dani Gimenez','Daniel Gimenez Hernandez','Silver - Rare','Normal',74,'RC Deportivo','LaLiga 1 I 2 I 3','Spain','GK','1983-07-30',0,0,0,0,0,0,72,79,70,33,69,71,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (771,'Maggio','Christian Maggio','Silver - Rare','Normal',74,'Benevento','Calcio B','Italy','RB','1982-02-11',70,73,69,69,72,77,0,0,0,0,0,0,'Right',2,3,73,73,73,73,73,72,71,72,72,70,71,71,71,71,71,72,300,10000
);
INSERT INTO PLAYER VALUES (772,'Magnanelli','Francesco Magnanelli','Silver - Rare','Normal',74,'Sassuolo','Serie A TIM','Italy','CDM','1984-11-12',62,63,55,68,76,68,0,0,0,0,0,0,'Right',3,2,73,71,71,70,70,73,68,63,63,64,62,62,62,62,62,60,300,10000
);
INSERT INTO PLAYER VALUES (773,'Salin','Romain Salin','Silver - Rare','Normal',74,'Stade Rennais FC','Ligue 1 Conforama','France','GK','1984-07-29',0,0,0,0,0,0,78,78,64,30,68,74,'Left',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (774,'Demarconnay','Vincent Demarconnay','Silver - Rare','Normal',73,'Paris FC','Domino''s Ligue 2','France','GK','1983-04-05',0,0,0,0,0,0,72,72,71,42,75,75,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (775,'Davis','Steven Davis','Silver - Rare','Normal',74,'Rangers FC','Scottish Premiership','Northern Ireland','CM','1985-01-01',54,75,61,75,63,63,0,0,0,0,0,0,'Right',3,3,65,66,66,68,68,70,73,70,70,72,69,69,69,69,69,64,300,10000
);
INSERT INTO PLAYER VALUES (776,'Lennon','Aaron Lennon','Silver - Rare','Normal',74,'Burnley','Premier League','England','RM','1987-04-16',79,78,63,69,49,58,0,0,0,0,0,0,'Right',3,3,54,61,61,64,64,61,69,73,73,73,72,72,72,74,74,66,300,10000
);
INSERT INTO PLAYER VALUES (777,'Tschauner','Philipp Tschauner','Silver - Rare','Normal',73,'RB Leipzig','Bundesliga','Germany','GK','1985-11-03',0,0,0,0,0,0,72,74,71,41,66,71,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (778,'Gentner','Christian Gentner','Silver - Rare','Normal',73,'1. FC Union Berlin','Bundesliga','Germany','CM','1985-08-14',34,67,72,71,72,73,0,0,0,0,0,0,'Right',4,2,72,67,67,67,67,72,72,66,66,69,68,68,68,66,66,70,300,10000
);
INSERT INTO PLAYER VALUES (779,'Schwegler','Pirmin Schwegler','Silver - Rare','Normal',74,'Western Sydney Wanderers','Hyundai A-League','Switzerland','CDM','1987-03-09',40,72,67,73,73,66,0,0,0,0,0,0,'Right',4,3,71,69,69,69,69,73,73,68,68,70,68,68,68,67,67,67,300,10000
);
INSERT INTO PLAYER VALUES (780,'Padelli','Daniele Padelli','Silver - Rare','Normal',74,'Inter','Serie A TIM','Italy','GK','1985-10-25',0,0,0,0,0,0,74,74,74,45,63,76,'Left',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (781,'Angeleri','Marcos Angeleri','Silver - Rare','Normal',73,'Argentinos Juniors','SAF','Argentina','RB','1983-04-07',61,59,49,64,76,77,0,0,0,0,0,0,'Right',3,2,76,72,72,71,71,72,63,61,61,57,57,57,57,58,58,59,300,10000
);
INSERT INTO PLAYER VALUES (782,'Sharp','Billy Sharp','Silver - Rare','Normal',74,'Sheffield United','Premier League','England','ST','1986-02-05',58,65,74,62,42,68,0,0,0,0,0,0,'Right',3,2,52,52,52,54,54,54,63,66,66,68,70,70,70,67,67,73,300,10000
);
INSERT INTO PLAYER VALUES (783,'Limbersky','David Limbersky','Silver - Rare','Normal',74,'Viktoria Plzen','Ceska Liga','Czech Republic','LB','1983-10-06',75,72,63,70,73,77,0,0,0,0,0,0,'Right',3,3,73,73,73,73,73,73,70,70,70,69,69,69,69,70,70,67,300,10000
);
INSERT INTO PLAYER VALUES (784,'Larsson','Sebastian Larsson','Silver - Rare','Normal',74,'AIK','Allsvenskan','Sweden','CM','1985-06-06',55,69,69,77,66,72,0,0,0,0,0,0,'Right',3,3,67,69,69,71,71,72,73,70,70,70,69,69,69,68,68,68,300,10000
);
INSERT INTO PLAYER VALUES (785,'M''Bia','Stephane M''Bia','Silver - Rare','Normal',74,'Wuhan Zall','CSL','Cameroon','CDM','1986-05-20',68,66,62,66,74,81,0,0,0,0,0,0,'Right',3,2,75,71,71,70,70,73,70,66,66,67,67,67,67,65,65,68,300,10000
);
INSERT INTO PLAYER VALUES (786,'BLaszczykowski','Jakub BLaszczykowski','Gold - Non-Rare','Normal',75,'WisLa Krakow','Ekstraklasa','Poland','RM','1985-12-14',72,77,70,75,60,67,0,0,0,0,0,0,'Right',4,3,64,67,67,69,69,68,72,74,74,75,74,74,74,75,75,71,300,10000
);
INSERT INTO PLAYER VALUES (787,'Bebe','Tiago Manuel Dias Correia','Silver - Rare','Normal',73,'Rayo Vallecano','LaLiga 1 I 2 I 3','Portugal','LM','1990-07-12',83,72,74,69,41,82,0,0,0,0,0,0,'Right',4,3,53,55,55,58,58,58,66,72,72,71,72,72,72,72,72,73,300,10000
);
INSERT INTO PLAYER VALUES (788,'Vlaar','Ron Vlaar','Silver - Rare','Normal',74,'AZ','Eredivisie','Holland','CB','1985-02-16',31,53,57,57,75,77,0,0,0,0,0,0,'Right',4,2,73,61,61,59,59,70,62,51,51,55,54,54,54,49,49,57,300,10000
);
INSERT INTO PLAYER VALUES (789,'Sinclair','Scott Sinclair','Silver - Rare','Normal',74,'Celtic','Scottish Premiership','England','LM','1989-03-25',88,75,72,65,41,65,0,0,0,0,0,0,'Right',4,4,50,58,58,61,61,55,66,73,73,72,74,74,74,74,74,72,300,10000
);
INSERT INTO PLAYER VALUES (790,'Long','Shane Long','Silver - Rare','Normal',74,'Southampton','Premier League','Republic of Ireland','ST','1987-01-22',80,71,72,61,36,69,0,0,0,0,0,0,'Right',2,3,50,53,53,56,56,52,62,70,70,69,71,71,71,71,71,73,300,10000
);
INSERT INTO PLAYER VALUES (791,'Ulmer','Andreas Ulmer','Silver - Rare','Normal',74,'FC Red Bull Salzburg','osterreichische Fubball-Bundesliga','Austria','LB','1985-10-30',69,71,62,70,70,74,0,0,0,0,0,0,'Left',3,3,70,73,73,74,74,72,71,71,71,69,69,69,69,69,69,67,300,10000
);
INSERT INTO PLAYER VALUES (792,'Bastians','Felix Bastians','Silver - Rare','Normal',74,'Tianjin TEDA FC','CSL','Germany','CB','1988-05-09',61,58,60,68,75,77,0,0,0,0,0,0,'Left',3,2,73,72,72,71,71,71,65,63,63,61,61,61,61,61,61,63,300,10000
);
INSERT INTO PLAYER VALUES (793,'De Silvestri','Lorenzo De Silvestri','Gold - Rare','Normal',75,'Torino','Serie A TIM','Italy','RM','1988-05-23',71,73,68,73,76,75,0,0,0,0,0,0,'Right',3,4,76,76,76,76,76,75,74,74,74,73,73,73,73,74,74,74,600,10000
);
INSERT INTO PLAYER VALUES (794,'Hetemaj','Perparim Hetemaj','Silver - Rare','Normal',74,'Chievo Verona','Calcio B','Finland','CM','1986-12-12',75,74,64,73,70,77,0,0,0,0,0,0,'Right',4,3,72,74,74,74,74,74,73,73,73,72,70,70,70,71,71,68,300,10000
);
INSERT INTO PLAYER VALUES (795,'Jensen','Mike Jensen','Silver - Rare','Normal',73,'Rosenborg BK','Eliteserien','Denmark','CM','1988-02-19',73,75,68,72,63,79,0,0,0,0,0,0,'Right',4,3,67,69,69,71,71,71,72,73,73,72,72,72,72,72,72,70,300,10000
);
INSERT INTO PLAYER VALUES (796,'Crespo','Jose angel Crespo Rincon','Silver - Rare','Normal',74,'PAOK','Hellas Liga','Spain','CB','1987-02-09',69,62,39,64,73,75,0,0,0,0,0,0,'Right',3,2,73,72,72,72,72,72,65,64,64,60,58,58,58,60,60,56,300,10000
);
INSERT INTO PLAYER VALUES (797,'Antonelli','Luca Antonelli','Silver - Rare','Normal',74,'Empoli','Calcio B','Italy','LB','1987-02-11',71,72,58,69,76,72,0,0,0,0,0,0,'Left',3,3,74,73,73,73,73,73,70,70,70,68,68,68,68,69,69,67,300,10000
);
INSERT INTO PLAYER VALUES (798,'Joselu','Jose Luis Sanmartin Mato','Silver - Rare','Normal',74,'D. Alaves','LaLiga Santander','Spain','ST','1990-03-27',54,69,73,64,30,67,0,0,0,0,0,0,'Right',3,3,46,46,46,49,49,49,63,66,66,69,71,71,71,68,68,73,300,10000
);
INSERT INTO PLAYER VALUES (799,'Erdinc','Mevlut Erdinc','Silver - Rare','Normal',74,'Medipol Basaksehir FK','Super Lig','Turkey','ST','1987-02-25',69,70,75,64,44,74,0,0,0,0,0,0,'Right',3,3,55,56,56,57,57,57,66,69,69,70,71,71,71,70,70,73,300,10000
);
INSERT INTO PLAYER VALUES (800,'Gonzalez','Federico Gonzalez','Silver - Rare','Normal',74,'Estudiantes de La Plata','SAF','Argentina','ST','1987-01-06',70,74,74,66,39,74,0,0,0,0,0,0,'Right',3,3,52,55,55,58,58,57,68,72,72,72,73,73,73,73,73,73,300,10000
);
INSERT INTO PLAYER VALUES (801,'Reginiussen','Tore Reginiussen','Silver - Rare','Normal',74,'Rosenborg BK','Eliteserien','Norway','CB','1986-04-10',63,52,42,54,73,77,0,0,0,0,0,0,'Right',3,2,73,67,67,65,65,67,58,55,55,53,53,53,53,53,53,55,300,10000
);
INSERT INTO PLAYER VALUES (802,'Svensson','Gustav Svensson','Silver - Rare','Normal',74,'Seattle Sounders FC','Major League Soccer','Sweden','CDM','1987-02-07',42,65,45,64,71,80,0,0,0,0,0,0,'Right',2,3,72,67,67,67,67,73,68,61,61,61,59,59,59,57,57,57,300,10000
);
INSERT INTO PLAYER VALUES (803,'Sippel','Tobias Sippel','Silver - Rare','Normal',74,'Borussia Monchengladbach','Bundesliga','Germany','GK','1988-03-22',0,0,0,0,0,0,75,78,69,47,79,70,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (804,'Aguilar','Abel Aguilar','Silver - Rare','Normal',74,'Union Magdalena','Liga Dimayor','Colombia','CDM','1985-01-06',32,64,61,67,74,81,0,0,0,0,0,0,'Right',3,3,74,65,65,65,65,73,70,62,62,65,63,63,63,61,61,64,300,10000
);
INSERT INTO PLAYER VALUES (805,'Baysse','Paul Baysse','Silver - Rare','Normal',74,'FC Girondins de Bordeaux','Ligue 1 Conforama','France','CB','1988-05-18',51,62,46,62,73,80,0,0,0,0,0,0,'Right',3,2,73,68,68,67,67,70,63,59,59,59,57,57,57,57,57,58,300,10000
);
INSERT INTO PLAYER VALUES (806,'Christodoulopoulos','Lazaros Christodoulopoulos','Silver - Rare','Normal',74,'Olympiacos CFP','Hellas Liga','Greece','LM','1986-12-19',73,77,74,72,52,64,0,0,0,0,0,0,'Right',4,3,59,62,62,64,64,62,70,73,73,74,74,74,74,75,75,74,300,10000
);
INSERT INTO PLAYER VALUES (807,'Arfield','Scott Arfield','Silver - Rare','Normal',74,'Rangers FC','Scottish Premiership','Canada','CM','1988-11-01',67,74,68,72,62,72,0,0,0,0,0,0,'Right',3,3,65,68,68,69,69,69,73,72,72,72,72,72,72,71,71,70,300,10000
);
INSERT INTO PLAYER VALUES (808,'Adrian Gonzalez','Adrian Gonzalez Morales','Silver - Rare','Normal',74,'Malaga CF','LaLiga 1 I 2 I 3','Spain','CM','1988-05-25',65,74,73,72,71,73,0,0,0,0,0,0,'Left',3,3,72,72,72,73,73,73,73,73,73,73,73,73,73,73,73,72,300,10000
);
INSERT INTO PLAYER VALUES (809,'Hennings','Rouwen Hennings','Silver - Rare','Normal',74,'Fortuna Dusseldorf','Bundesliga','Germany','ST','1987-08-28',65,67,76,62,40,77,0,0,0,0,0,0,'Left',3,3,53,53,53,55,55,55,63,67,67,67,70,70,70,68,68,73,300,10000
);
INSERT INTO PLAYER VALUES (810,'Taarabt','Adel Taarabt','Gold - Non-Rare','Normal',75,'SL Benfica','Liga NOS','Morocco','CAM','1989-05-24',67,82,68,71,37,61,0,0,0,0,0,0,'Right',4,4,48,52,52,56,56,57,69,73,73,74,74,74,74,74,74,69,300,10000
);
INSERT INTO PLAYER VALUES (811,'Insua','Emiliano Insua','Silver - Rare','Normal',73,'VfB Stuttgart','Bundesliga 2','Argentina','LB','1989-01-07',66,73,64,71,71,77,0,0,0,0,0,0,'Left',2,3,73,72,72,73,73,73,72,70,70,70,69,69,69,69,69,69,300,10000
);
INSERT INTO PLAYER VALUES (812,'Vokes','Sam Vokes','Silver - Rare','Normal',73,'Stoke City','EFL Championship','Wales','ST','1989-10-21',51,64,75,61,43,81,0,0,0,0,0,0,'Right',3,2,56,52,52,54,54,57,64,65,65,66,69,69,69,65,65,72,300,10000
);
INSERT INTO PLAYER VALUES (813,'Vecchio','Emiliano Vecchio','Silver - Rare','Normal',73,'Al Ittihad','Saudi Professional League','Argentina','CM','1988-11-16',75,76,68,72,57,71,0,0,0,0,0,0,'Right',3,3,62,64,64,65,65,66,72,72,72,73,72,72,72,72,72,71,300,10000
);
INSERT INTO PLAYER VALUES (814,'Oier','Oier Olazabal Paredes','Silver - Rare','Normal',74,'Levante UD','LaLiga Santander','Spain','GK','1989-09-14',0,0,0,0,0,0,74,73,71,44,70,77,'Left',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (815,'Frei','Fabian Frei','Silver - Rare','Normal',74,'FC Basel','Raiffeisen Super League','Switzerland','CDM','1989-01-08',65,72,71,75,72,73,0,0,0,0,0,0,'Right',3,3,71,72,72,73,73,73,75,73,73,73,72,72,72,72,72,72,300,10000
);
INSERT INTO PLAYER VALUES (816,'Bjelland','Andreas Bjelland','Silver - Rare','Normal',74,'FC Kobenhavn','Superliga','Denmark','CB','1988-07-11',43,60,46,63,73,76,0,0,0,0,0,0,'Left',3,2,73,65,65,64,64,71,66,58,58,60,57,57,57,56,56,57,300,10000
);
INSERT INTO PLAYER VALUES (817,'Arter','Harry Arter','Silver - Rare','Normal',74,'Fulham','EFL Championship','Republic of Ireland','CM','1989-12-28',59,71,69,72,67,72,0,0,0,0,0,0,'Left',5,3,69,68,68,68,68,73,73,69,69,71,70,70,70,69,69,67,300,10000
);
INSERT INTO PLAYER VALUES (818,'Fabio Pacheco','Fabio Jose Ferreira Pacheco','Silver - Rare','Normal',74,'Moreirense FC','Liga NOS','Portugal','CDM','1988-05-26',67,65,54,69,74,73,0,0,0,0,0,0,'Right',3,2,73,72,72,72,72,73,69,66,66,65,63,63,63,64,64,61,300,10000
);
INSERT INTO PLAYER VALUES (819,'Yoel','Yoel Rodriguez Oterino','Silver - Rare','Normal',74,'SD Eibar','LaLiga Santander','Spain','GK','1988-08-28',0,0,0,0,0,0,75,75,72,38,74,71,'Right',5,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (820,'Chester','James Chester','Silver - Rare','Normal',74,'Aston Villa','Premier League','Wales','CB','1989-01-23',66,63,34,58,74,74,0,0,0,0,0,0,'Right',3,2,73,69,69,67,67,69,60,58,58,57,54,54,54,56,56,53,300,10000
);
INSERT INTO PLAYER VALUES (821,'Van Der Heijden','Jan-Arie van der Heijden','Silver - Rare','Normal',74,'Feyenoord','Eredivisie','Holland','CB','1988-03-03',37,70,62,72,74,70,0,0,0,0,0,0,'Left',3,3,73,68,68,68,68,74,73,65,65,68,66,66,66,64,64,65,300,10000
);
INSERT INTO PLAYER VALUES (822,'Halliche','Rafik Halliche','Silver - Rare','Normal',74,'Moreirense FC','Liga NOS','Algeria','CB','1986-09-02',44,53,41,53,75,72,0,0,0,0,0,0,'Right',3,2,73,64,64,62,62,66,55,49,49,49,48,48,48,48,48,50,300,10000
);
INSERT INTO PLAYER VALUES (823,'Duenas','Jesus Duenas','Silver - Rare','Normal',74,'Tigres U.A.N.L.','LIGA Bancomer MX','Mexico','CM','1989-03-16',75,73,66,71,69,80,0,0,0,0,0,0,'Right',4,3,71,72,72,73,73,73,73,73,73,72,71,71,71,71,71,70,300,10000
);
INSERT INTO PLAYER VALUES (824,'Morrison','Sean Morrison','Silver - Rare','Normal',74,'Cardiff City','EFL Championship','England','CB','1991-01-08',45,49,29,40,74,77,0,0,0,0,0,0,'Right',2,2,73,62,62,59,59,64,49,44,44,43,43,43,43,41,41,46,300,10000
);
INSERT INTO PLAYER VALUES (825,'Ecuele Manga','Bruno Ecuele Manga','Silver - Rare','Normal',74,'Dijon FCO','Ligue 1 Conforama','Gabon','CB','1988-07-16',54,50,32,56,74,74,0,0,0,0,0,0,'Right',3,2,73,67,67,65,65,69,57,52,52,50,48,48,48,49,49,48,300,10000
);
INSERT INTO PLAYER VALUES (826,'Kaminski','Thomas Kaminski','Silver - Rare','Normal',74,'KAA Gent','Belgium Pro League','Belgium','GK','1992-10-23',0,0,0,0,0,0,73,75,74,46,67,72,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (827,'Poulain','Benoit Poulain','Silver - Rare','Normal',74,'Kayserispor','Super Lig','France','CB','1987-07-24',33,48,26,57,77,74,0,0,0,0,0,0,'Right',2,2,73,65,65,62,62,71,59,49,49,50,45,45,45,45,45,45,300,10000
);
INSERT INTO PLAYER VALUES (828,'Valdifiori','Mirko Valdifiori','Silver - Rare','Normal',74,'SPAL','Serie A TIM','Italy','CDM','1986-04-21',50,73,56,79,69,62,0,0,0,0,0,0,'Right',3,3,69,68,68,69,69,73,74,69,69,71,67,67,67,67,67,62,300,10000
);
INSERT INTO PLAYER VALUES (829,'N''Diaye','Alfred N''Diaye','Silver - Rare','Normal',74,'Malaga CF','LaLiga 1 I 2 I 3','Senegal','CM','1990-03-06',71,70,63,71,71,83,0,0,0,0,0,0,'Right',3,3,74,72,72,72,72,75,73,71,71,71,70,70,70,69,69,68,300,10000
);
INSERT INTO PLAYER VALUES (830,'Alex Bergantinos','Alejandro Bergantinos Garcia','Silver - Rare','Normal',74,'RC Deportivo','LaLiga 1 I 2 I 3','Spain','CDM','1985-06-07',44,63,46,63,74,79,0,0,0,0,0,0,'Right',2,2,73,68,68,68,68,73,67,60,60,61,58,58,58,57,57,56,300,10000
);
INSERT INTO PLAYER VALUES (831,'Room','Eloy Room','Silver - Rare','Normal',74,'Columbus Crew SC','Major League Soccer','Curacao','GK','1989-02-06',0,0,0,0,0,0,74,76,75,45,68,71,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (832,'Jack','Ryan Jack','Silver - Rare','Normal',74,'Rangers FC','Scottish Premiership','Scotland','CDM','1992-02-27',65,71,52,67,71,79,0,0,0,0,0,0,'Right',3,2,72,71,71,71,71,73,70,67,67,66,64,64,64,64,64,61,300,10000
);
INSERT INTO PLAYER VALUES (833,'Risse','Marcel Risse','Silver - Rare','Normal',74,'1. FC Koln','Bundesliga','Germany','RM','1989-12-17',74,73,75,72,66,66,0,0,0,0,0,0,'Right',2,3,67,70,70,71,71,70,72,73,73,73,73,73,73,73,73,72,300,10000
);
INSERT INTO PLAYER VALUES (834,'Diekmeier','Dennis Diekmeier','Silver - Rare','Normal',74,'SV Sandhausen','Bundesliga 2','Germany','RB','1989-10-20',87,66,39,65,69,74,0,0,0,0,0,0,'Right',2,3,70,73,73,72,72,69,64,66,66,61,61,61,61,63,63,59,300,10000
);
INSERT INTO PLAYER VALUES (835,'HuSbauer','Josef HuSbauer','Silver - Rare','Normal',74,'Slavia Praha','Ceska Liga','Czech Republic','CM','1990-03-16',63,73,72,76,58,66,0,0,0,0,0,0,'Right',4,3,61,67,67,69,69,68,73,73,73,73,71,71,71,72,72,68,300,10000
);
INSERT INTO PLAYER VALUES (836,'Balenziaga','Mikel Balenziaga','Silver - Rare','Normal',74,'Athletic Club','LaLiga Santander','Spain','LB','1988-02-29',75,70,46,68,72,75,0,0,0,0,0,0,'Left',4,3,72,73,73,73,73,72,67,68,68,64,63,63,63,65,65,60,300,10000
);
INSERT INTO PLAYER VALUES (837,'Sunzu','Stoppila Sunzu','Silver - Rare','Normal',74,'Football Club de Metz','Ligue 1 Conforama','Zambia','CB','1989-06-22',52,51,38,50,73,82,0,0,0,0,0,0,'Right',3,2,73,65,65,62,62,67,56,49,49,49,48,48,48,46,46,50,300,10000
);
INSERT INTO PLAYER VALUES (838,'Michel','Miguel angel Herrero Javaloyas','Silver - Rare','Normal',74,'R. Valladolid CF','LaLiga Santander','Spain','CM','1988-07-29',49,73,66,78,55,55,0,0,0,0,0,0,'Right',4,3,58,60,60,63,63,66,73,70,70,73,70,70,70,70,70,65,300,10000
);
INSERT INTO PLAYER VALUES (839,'Martinez','Osvaldo Martinez','Silver - Rare','Normal',74,'Club Atlas','LIGA Bancomer MX','Paraguay','CM','1986-04-08',63,74,71,73,58,72,0,0,0,0,0,0,'Right',4,3,63,64,64,66,66,68,73,71,71,73,72,72,72,71,71,69,300,10000
);
INSERT INTO PLAYER VALUES (840,'Pedro Sanchez','Pedro Antonio Sanchez Monino','Silver - Rare','Normal',74,'Albacete Bpie','LaLiga 1 I 2 I 3','Spain','RM','1986-12-12',83,74,71,71,38,68,0,0,0,0,0,0,'Right',3,3,46,54,54,59,59,55,66,73,73,71,70,70,70,73,73,67,300,10000
);
INSERT INTO PLAYER VALUES (841,'Opara','Ike Opara','Silver - Rare','Normal',74,'Minnesota United FC','Major League Soccer','United States','CB','1989-02-21',84,56,38,52,71,82,0,0,0,0,0,0,'Right',2,2,73,67,67,64,64,68,59,56,56,56,55,55,55,53,53,57,300,10000
);
INSERT INTO PLAYER VALUES (842,'Caruzzo','Matias Caruzzo','Silver - Rare','Normal',74,'Rosario Central','SAF','Argentina','CB','1984-08-15',45,51,36,58,73,77,0,0,0,0,0,0,'Right',3,2,73,66,66,64,64,70,60,53,53,54,51,51,51,50,50,51,300,10000
);
INSERT INTO PLAYER VALUES (843,'Silvestri','Marco Silvestri','Silver - Rare','Normal',74,'Hellas Verona','Serie A TIM','Italy','GK','1991-03-02',0,0,0,0,0,0,78,79,68,59,68,74,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,700,13000
);
INSERT INTO PLAYER VALUES (844,'oztekin','Yasin oztekin','Silver - Non-Rare','Normal',73,'Goztepe SK','Super Lig','Turkey','LM','1987-03-19',78,75,71,69,46,65,0,0,0,0,0,0,'Right',3,3,54,58,58,61,61,59,68,72,72,73,73,73,73,73,73,71,150,10000
);
INSERT INTO PLAYER VALUES (845,'Borges','Celso Borges','Silver - Rare','Normal',74,'Goztepe SK','Super Lig','Costa Rica','CDM','1988-05-27',53,69,74,71,73,74,0,0,0,0,0,0,'Right',4,3,72,69,69,69,69,73,73,68,68,71,70,70,70,68,68,71,300,10000
);
INSERT INTO PLAYER VALUES (846,'Tore','Gokhan Tore','Silver - Rare','Normal',74,'Evkur Yeni Malatyaspor','Super Lig','Turkey','RM','1992-01-20',80,77,68,74,43,71,0,0,0,0,0,0,'Left',4,3,53,57,57,60,60,59,68,73,73,73,71,71,71,74,74,69,300,10000
);
INSERT INTO PLAYER VALUES (847,'Junior','Lago Junior','Gold - Rare','Normal',75,'RCD Mallorca','LaLiga Santander','Cote d''Ivoire','LM','1990-12-31',88,75,71,63,34,73,0,0,0,0,0,0,'Right',4,4,46,51,51,56,56,51,64,74,74,72,74,74,74,74,74,73,600,10000
);
INSERT INTO PLAYER VALUES (848,'Bedoya','Alejandro Bedoya','Silver - Rare','Normal',74,'Philadelphia Union','Major League Soccer','United States','CM','1987-04-29',65,72,65,71,66,73,0,0,0,0,0,0,'Right',4,3,68,69,69,71,71,72,73,71,71,71,70,70,70,70,70,69,300,10000
);
INSERT INTO PLAYER VALUES (849,'Corchia','Sebastien Corchia','Silver - Rare','Normal',74,'RCD Espanyol','LaLiga Santander','France','RB','1990-11-01',70,74,65,73,75,65,0,0,0,0,0,0,'Right',3,3,73,73,73,72,72,72,71,71,71,71,71,71,71,71,71,69,300,10000
);
INSERT INTO PLAYER VALUES (850,'Rodriguez','Jose Antonio Rodriguez','Silver - Rare','Normal',74,'Guadalajara','LIGA Bancomer MX','Mexico','GK','1992-07-04',0,0,0,0,0,0,78,75,70,57,66,74,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (851,'Ignatiev','Vladislav Ignatiev','Silver - Rare','Normal',73,'Lokomotiv Moscow','League of Russia','Russia','RB','1987-01-20',76,70,63,71,72,66,0,0,0,0,0,0,'Right',4,3,70,72,72,72,72,71,70,71,71,70,70,70,70,71,71,69,300,10000
);
INSERT INTO PLAYER VALUES (852,'Renatinho','Renato Ribeiro Calixto','Silver - Rare','Normal',74,'Tianjin Quanjian FC','CSL','Brazil','RW','1988-10-04',77,79,72,69,37,65,0,0,0,0,0,0,'Left',3,3,49,54,54,57,57,56,70,73,73,74,74,74,74,74,74,72,300,10000
);
INSERT INTO PLAYER VALUES (853,'Caraglio','Milton Caraglio','Silver - Rare','Normal',74,'Cruz Azul','LIGA Bancomer MX','Argentina','ST','1988-12-01',46,69,76,61,27,81,0,0,0,0,0,0,'Left',3,3,47,45,45,48,48,49,62,65,65,66,69,69,69,67,67,73,300,10000
);
INSERT INTO PLAYER VALUES (854,'Rafael','Rafael Cabral Barbosa','Silver - Rare','Normal',74,'Reading','EFL Championship','Brazil','GK','1990-05-20',0,0,0,0,0,0,75,74,73,54,71,73,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (855,'Stevens','Enda Stevens','Silver - Rare','Normal',74,'Sheffield United','Premier League','Republic of Ireland','LWB','1990-07-09',70,69,45,63,72,73,0,0,0,0,0,0,'Left',2,3,70,72,72,73,73,69,64,66,66,62,62,62,62,64,64,59,300,10000
);
INSERT INTO PLAYER VALUES (856,'Klos','Fabian Klos','Silver - Rare','Normal',74,'DSC Arminia Bielefeld','Bundesliga 2','Germany','ST','1987-12-02',63,63,74,55,38,84,0,0,0,0,0,0,'Right',4,2,52,49,49,50,50,52,60,64,64,66,69,69,69,65,65,73,300,10000
);
INSERT INTO PLAYER VALUES (857,'Le Marchand','Maxime Le Marchand','Silver - Rare','Normal',73,'Fulham','EFL Championship','France','CB','1989-10-11',68,67,38,66,73,73,0,0,0,0,0,0,'Left',3,2,72,71,71,71,71,72,65,63,63,60,57,57,57,59,59,55,300,10000
);
INSERT INTO PLAYER VALUES (858,'Zeegelaar','Marvin Zeegelaar','Silver - Rare','Normal',74,'Watford','Premier League','Holland','LB','1990-08-12',70,72,62,67,73,74,0,0,0,0,0,0,'Left',3,3,72,73,73,73,73,72,70,71,71,70,70,70,70,70,70,69,300,10000
);
INSERT INTO PLAYER VALUES (859,'Clemens','Christian Clemens','Silver - Rare','Normal',74,'1. FC Koln','Bundesliga','Germany','RM','1991-08-04',77,72,69,72,51,68,0,0,0,0,0,0,'Right',3,3,57,61,61,63,63,61,69,73,73,72,72,72,72,72,72,71,300,10000
);
INSERT INTO PLAYER VALUES (860,'Obi','Joel Obi','Silver - Rare','Normal',74,'Chievo Verona','Calcio B','Nigeria','CM','1991-05-22',76,78,68,71,72,71,0,0,0,0,0,0,'Left',3,3,73,73,73,73,73,73,73,74,74,75,74,74,74,74,74,72,300,10000
);
INSERT INTO PLAYER VALUES (861,'Benito','Loris Benito','Silver - Non-Rare','Normal',73,'FC Girondins de Bordeaux','Ligue 1 Conforama','Switzerland','LB','1992-01-07',68,68,50,67,71,75,0,0,0,0,0,0,'Left',3,3,71,72,72,72,72,71,68,67,67,65,64,64,64,65,65,62,150,10000
);
INSERT INTO PLAYER VALUES (862,'HeCa','Milan HeCa','Silver - Non-Rare','Normal',73,'Sparta Praha','Ceska Liga','Czech Republic','GK','1991-03-23',0,0,0,0,0,0,72,74,72,45,67,73,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (863,'Sakho','Diafra Sakho','Silver - Rare','Normal',74,'Stade Rennais FC','Ligue 1 Conforama','Senegal','ST','1989-12-24',71,71,73,58,32,72,0,0,0,0,0,0,'Right',3,3,48,49,49,51,51,50,61,67,67,67,70,70,70,69,69,73,300,10000
);
INSERT INTO PLAYER VALUES (864,'Hourihane','Conor Hourihane','Silver - Rare','Normal',74,'Aston Villa','Premier League','Republic of Ireland','CM','1991-02-02',65,69,69,75,65,74,0,0,0,0,0,0,'Left',4,3,67,70,70,71,71,71,73,71,71,71,69,69,69,70,70,67,300,10000
);
INSERT INTO PLAYER VALUES (865,'Ilsanker','Stefan Ilsanker','Silver - Rare','Normal',74,'RB Leipzig','Bundesliga','Austria','CDM','1989-05-18',58,52,53,57,76,82,0,0,0,0,0,0,'Right',3,2,76,70,70,68,68,73,64,57,57,58,58,58,58,54,54,60,300,10000
);
INSERT INTO PLAYER VALUES (866,'Leckie','Mathew Leckie','Silver - Rare','Normal',74,'Hertha BSC','Bundesliga','Australia','RM','1991-02-04',88,74,68,66,55,74,0,0,0,0,0,0,'Right',4,3,62,64,64,66,66,62,66,73,73,71,73,73,73,74,74,72,300,10000
);
INSERT INTO PLAYER VALUES (867,'Inigo Perez','Inigo Perez Soto','Silver - Rare','Normal',74,'CA Osasuna','LaLiga Santander','Spain','CDM','1988-01-18',64,66,63,77,70,72,0,0,0,0,0,0,'Left',3,2,70,71,71,72,72,73,72,69,69,69,66,66,66,67,67,65,300,10000
);
INSERT INTO PLAYER VALUES (868,'Babacar','Khouma Babacar','Silver - Rare','Normal',74,'Sassuolo','Serie A TIM','Senegal','ST','1993-03-17',68,72,72,55,35,69,0,0,0,0,0,0,'Right',3,3,48,48,48,50,50,49,59,66,66,66,70,70,70,68,68,73,300,10000
);
INSERT INTO PLAYER VALUES (869,'Toornstra','Jens Toornstra','Silver - Rare','Normal',74,'Feyenoord','Eredivisie','Holland','CAM','1989-04-04',65,72,75,75,58,74,0,0,0,0,0,0,'Right',2,3,62,66,66,68,68,68,73,74,74,73,73,73,73,72,72,73,300,10000
);
INSERT INTO PLAYER VALUES (870,'Samu Saiz','Samuel Saiz Alonso','Silver - Rare','Normal',73,'Girona FC','LaLiga 1 I 2 I 3','Spain','CAM','1991-01-22',75,75,69,70,25,59,0,0,0,0,0,0,'Right',3,4,38,47,47,52,52,49,66,72,72,72,71,71,71,72,72,66,300,10000
);
INSERT INTO PLAYER VALUES (871,'Jordi Amat','Jordi Amat Maas','Silver - Rare','Normal',74,'KAS Eupen','Belgium Pro League','Spain','CB','1992-03-21',65,58,48,53,73,77,0,0,0,0,0,0,'Right',3,2,73,66,66,64,64,69,60,54,54,57,56,56,56,53,53,56,300,10000
);
INSERT INTO PLAYER VALUES (872,'Leandro Damiao','Leandro Damiao da Silva dos Santos','Silver - Rare','Normal',74,'Kawasaki Frontale','Meiji Yasuda J1 League','Brazil','ST','1989-07-22',59,68,76,56,35,78,0,0,0,0,0,0,'Right',2,3,51,48,48,49,49,51,62,64,64,66,69,69,69,65,65,73,300,10000
);
INSERT INTO PLAYER VALUES (873,'Vydra','Matej Vydra','Silver - Rare','Normal',73,'Burnley','Premier League','Czech Republic','CAM','1992-05-01',81,73,74,67,35,59,0,0,0,0,0,0,'Right',4,3,47,53,53,56,56,52,65,71,71,72,73,73,73,73,73,72,300,10000
);
INSERT INTO PLAYER VALUES (874,'Linnes','Martin Linnes','Silver - Rare','Normal',74,'Galatasaray SK','Super Lig','Norway','RB','1991-09-20',87,73,57,65,69,66,0,0,0,0,0,0,'Right',3,3,67,73,73,73,73,69,68,71,71,69,68,68,68,70,70,65,300,10000
);
INSERT INTO PLAYER VALUES (875,'Amalfitano','Romain Amalfitano','Silver - Rare','Normal',74,'Dijon FCO','Ligue 1 Conforama','France','CM','1989-08-27',60,72,59,70,68,59,0,0,0,0,0,0,'Right',4,3,64,69,69,71,71,73,73,70,70,71,68,68,68,69,69,61,300,10000
);
INSERT INTO PLAYER VALUES (876,'Sainsbury','Trent Sainsbury','Silver - Rare','Normal',74,'PSV','Eredivisie','Australia','CB','1992-01-05',74,59,48,62,76,73,0,0,0,0,0,0,'Right',3,2,73,72,72,70,70,70,63,62,62,60,59,59,59,59,59,59,300,10000
);
INSERT INTO PLAYER VALUES (877,'Klose','Timm Klose','Silver - Rare','Normal',74,'Norwich City','Premier League','Switzerland','CB','1988-05-09',37,39,38,54,75,75,0,0,0,0,0,0,'Right',3,2,73,63,63,59,59,69,57,46,46,48,46,46,46,42,42,50,300,10000
);
INSERT INTO PLAYER VALUES (878,'Linssen','Bryan Linssen','Silver - Non-Rare','Normal',73,'Vitesse','Eredivisie','Holland','ST','1990-10-08',77,73,71,65,37,66,0,0,0,0,0,0,'Right',2,3,50,54,54,56,56,53,65,70,70,70,72,72,72,71,71,72,150,10000
);
INSERT INTO PLAYER VALUES (879,'Sviatchenko','Erik Sviatchenko','Silver - Rare','Normal',74,'FC Midtjylland','Superliga','Denmark','CB','1991-10-04',58,57,50,58,73,78,0,0,0,0,0,0,'Right',3,2,73,67,67,65,65,70,64,57,57,60,58,58,58,56,56,59,300,10000
);
INSERT INTO PLAYER VALUES (880,'Trauner','Gernot Trauner','Silver - Rare','Normal',74,'LASK Linz','osterreichische Fubball-Bundesliga','Austria','CB','1992-03-25',66,62,57,61,71,85,0,0,0,0,0,0,'Right',3,2,73,69,69,69,69,70,65,63,63,62,63,63,63,62,62,64,300,10000
);
INSERT INTO PLAYER VALUES (881,'Kittel','Sonny Kittel','Silver - Rare','Normal',74,'Hamburger SV','Bundesliga 2','Germany','LW','1993-01-06',75,77,69,73,34,56,0,0,0,0,0,0,'Right',5,4,44,53,53,57,57,54,69,74,74,74,73,73,73,74,74,69,300,10000
);
INSERT INTO PLAYER VALUES (882,'Vicente Gomez','Jose Vicente Gomez Umpierrez','Silver - Rare','Normal',73,'RC Deportivo','LaLiga 1 I 2 I 3','Spain','CM','1988-08-31',33,66,62,71,71,71,0,0,0,0,0,0,'Left',2,3,70,66,66,66,66,72,72,65,65,68,66,66,66,63,63,65,300,10000
);
INSERT INTO PLAYER VALUES (883,'Shinnie','Graeme Shinnie','Silver - Rare','Normal',74,'Derby County','EFL Championship','Scotland','CDM','1991-08-04',77,69,42,68,71,79,0,0,0,0,0,0,'Left',4,3,72,73,73,74,74,73,68,67,67,65,62,62,62,64,64,58,300,10000
);
INSERT INTO PLAYER VALUES (884,'Gibson','Ben Gibson','Silver - Rare','Normal',74,'Burnley','Premier League','England','CB','1993-01-15',59,52,29,48,75,71,0,0,0,0,0,0,'Left',3,2,73,65,65,62,62,67,55,49,49,49,47,47,47,47,47,48,300,10000
);
INSERT INTO PLAYER VALUES (885,'Hinterseer','Lukas Hinterseer','Silver - Rare','Normal',74,'Hamburger SV','Bundesliga 2','Austria','ST','1991-03-28',63,69,74,65,44,75,0,0,0,0,0,0,'Right',3,3,54,54,54,56,56,57,65,69,69,70,71,71,71,69,69,73,300,10000
);
INSERT INTO PLAYER VALUES (886,'Schlupp','Jeffrey Schlupp','Silver - Rare','Normal',74,'Crystal Palace','Premier League','Ghana','LM','1992-12-23',86,73,67,66,69,75,0,0,0,0,0,0,'Left',2,3,70,73,73,73,73,70,69,73,73,71,72,72,72,72,72,71,300,10000
);
INSERT INTO PLAYER VALUES (887,'De Preville','Nicolas De Preville','Silver - Rare','Normal',74,'FC Girondins de Bordeaux','Ligue 1 Conforama','France','CF','1991-01-08',76,75,72,72,36,66,0,0,0,0,0,0,'Right',3,3,50,56,56,59,59,57,69,73,73,74,74,74,74,74,74,73,300,10000
);
INSERT INTO PLAYER VALUES (888,'Diego','Diego Rigonato Rodrigues','Silver - Rare','Normal',74,'Deportivo Toluca','LIGA Bancomer MX','Brazil','LM','1988-03-09',71,75,73,76,43,63,0,0,0,0,0,0,'Left',2,3,52,58,58,61,61,60,71,73,73,74,73,73,73,73,73,71,300,10000
);
INSERT INTO PLAYER VALUES (889,'Ronnow','Frederik Ronnow','Silver - Rare','Normal',74,'Eintracht Frankfurt','Bundesliga','Denmark','GK','1992-08-04',0,0,0,0,0,0,74,77,70,47,66,74,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (890,'Ntep','Paul-Georges Ntep','Silver - Non-Rare','Normal',73,'Kayserispor','Super Lig','Cameroon','LM','1992-07-29',73,77,68,70,29,67,0,0,0,0,0,0,'Right',4,3,43,49,49,54,54,53,66,72,72,72,72,72,72,73,73,69,150,10000
);
INSERT INTO PLAYER VALUES (891,'Cornelius','Andreas Cornelius','Silver - Rare','Normal',74,'Parma','Serie A TIM','Denmark','ST','1993-03-16',64,66,73,55,39,81,0,0,0,0,0,0,'Left',3,3,52,47,47,49,49,52,60,64,64,66,69,69,69,65,65,73,300,10000
);
INSERT INTO PLAYER VALUES (892,'Quignon','Facundo Quignon','Silver - Rare','Normal',74,'Club Atletico Lanus','SAF','Argentina','CDM','1993-05-02',68,78,59,73,69,75,0,0,0,0,0,0,'Left',3,3,70,72,72,73,73,73,74,72,72,72,69,69,69,70,70,67,300,10000
);
INSERT INTO PLAYER VALUES (893,'Stephens','Jack Stephens','Silver - Rare','Normal',74,'Southampton','Premier League','England','CB','1994-01-27',61,67,42,58,74,71,0,0,0,0,0,0,'Right',3,2,73,69,69,68,68,70,63,60,60,60,59,59,59,58,58,58,300,10000
);
INSERT INTO PLAYER VALUES (894,'Viviani','Federico Viviani','Silver - Rare','Normal',74,'SPAL','Serie A TIM','Italy','CDM','1992-03-24',63,75,70,75,71,69,0,0,0,0,0,0,'Right',4,3,70,71,71,72,72,73,74,71,71,72,71,71,71,71,71,69,300,10000
);
INSERT INTO PLAYER VALUES (895,'Bifouma','Thievy Bifouma','Silver - Rare','Normal',74,'Evkur Yeni Malatyaspor','Super Lig','Congo','RM','1992-05-13',93,77,71,63,29,70,0,0,0,0,0,0,'Right',4,4,46,52,52,55,55,51,64,73,73,72,74,74,74,75,75,73,300,10000
);
INSERT INTO PLAYER VALUES (896,'Foulquier','Dimitri Foulquier','Silver - Rare','Normal',74,'Watford','Premier League','France','RM','1993-03-23',73,75,60,68,72,73,0,0,0,0,0,0,'Right',3,3,72,74,74,74,74,72,71,73,73,71,71,71,71,72,72,69,300,10000
);
INSERT INTO PLAYER VALUES (897,'Gnahore','Eddy Gnahore','Gold - Non-Rare','Normal',75,'Amiens SC','Ligue 1 Conforama','France','CM','1993-11-14',66,72,67,71,68,77,0,0,0,0,0,0,'Right',3,3,69,68,68,69,69,72,74,71,71,72,72,72,72,70,70,70,300,10000
);
INSERT INTO PLAYER VALUES (898,'Hubner','Florian Hubner','Silver - Rare','Normal',74,'1. FC Union Berlin','Bundesliga','Germany','CB','1991-03-01',53,45,43,48,77,72,0,0,0,0,0,0,'Right',3,2,73,67,67,64,64,67,53,49,49,48,49,49,49,48,48,53,300,10000
);
INSERT INTO PLAYER VALUES (899,'Bahoken','Stephane Bahoken','Silver - Rare','Normal',74,'Angers SCO','Ligue 1 Conforama','Cameroon','ST','1992-05-28',80,71,72,57,24,71,0,0,0,0,0,0,'Right',3,3,42,47,47,50,50,45,59,68,68,67,70,70,70,70,70,73,300,10000
);
INSERT INTO PLAYER VALUES (900,'Bakalorz','Marvin Bakalorz','Silver - Rare','Normal',74,'Hannover 96','Bundesliga 2','Germany','CDM','1989-09-13',64,67,66,62,74,80,0,0,0,0,0,0,'Right',4,2,74,70,70,69,69,73,69,64,64,66,66,66,66,64,64,67,300,10000
);
INSERT INTO PLAYER VALUES (901,'Trybull','Tom Trybull','Silver - Rare','Normal',73,'Norwich City','Premier League','Germany','CDM','1993-03-09',61,67,48,66,73,74,0,0,0,0,0,0,'Right',3,3,71,69,69,69,69,72,67,63,63,63,60,60,60,61,61,57,300,10000
);
INSERT INTO PLAYER VALUES (902,'Musonda','Charly Musonda','Silver - Rare','Normal',74,'Vitesse','Eredivisie','Belgium','RM','1996-10-15',84,79,64,70,24,43,0,0,0,0,0,0,'Right',5,4,35,48,48,53,53,47,65,73,73,73,72,72,72,74,74,66,300,10000
);
INSERT INTO PLAYER VALUES (903,'Arslanagic','Dino Arslanagic','Silver - Rare','Normal',74,'Royal Antwerp FC','Belgium Pro League','Belgium','CB','1993-04-24',55,57,32,57,73,78,0,0,0,0,0,0,'Right',4,2,73,67,67,66,66,70,60,55,55,53,50,50,50,50,50,49,300,10000
);
INSERT INTO PLAYER VALUES (904,'Juan Carlos','Juan Carlos Real Ruiz','Silver - Rare','Normal',74,'SD Huesca','LaLiga 1 I 2 I 3','Spain','CAM','1991-03-15',67,73,67,72,51,58,0,0,0,0,0,0,'Right',3,3,54,59,59,62,62,61,70,72,72,73,71,71,71,72,72,67,300,10000
);
INSERT INTO PLAYER VALUES (905,'Ruben Pardo','Ruben Pardo Gutierrez','Silver - Rare','Normal',74,'Real Sociedad','LaLiga Santander','Spain','CM','1992-10-22',61,72,68,74,62,55,0,0,0,0,0,0,'Right',4,3,63,64,64,65,65,69,73,70,70,73,71,71,71,70,70,67,300,10000
);
INSERT INTO PLAYER VALUES (906,'Advincula','Luis Advincula','Silver - Rare','Normal',74,'Rayo Vallecano','LaLiga 1 I 2 I 3','Peru','RB','1990-03-02',94,75,64,70,66,76,0,0,0,0,0,0,'Right',4,3,69,73,73,74,74,70,70,74,74,71,72,72,72,74,74,70,300,10000
);
INSERT INTO PLAYER VALUES (907,'Vadillo','alvaro Vadillo Cifuentes','Silver - Rare','Normal',74,'Granada CF','LaLiga Santander','Spain','RM','1994-09-12',87,80,68,68,34,44,0,0,0,0,0,0,'Right',3,4,43,52,52,56,56,51,64,73,73,73,73,73,73,75,75,69,300,10000
);
INSERT INTO PLAYER VALUES (908,'Gouano','Prince-Desir Gouano','Silver - Rare','Normal',74,'Amiens SC','Ligue 1 Conforama','France','CB','1993-12-24',64,52,25,50,74,76,0,0,0,0,0,0,'Right',2,2,73,66,66,63,63,69,55,50,50,48,45,45,45,45,45,45,300,10000
);
INSERT INTO PLAYER VALUES (909,'Ewerton','Ewerton Jose Almeida Santos','Silver - Rare','Normal',74,'Hamburger SV','Bundesliga 2','Brazil','CB','1989-03-23',56,62,37,55,75,72,0,0,0,0,0,0,'Left',2,2,73,67,67,66,66,68,59,55,55,55,53,53,53,53,53,52,300,10000
);
INSERT INTO PLAYER VALUES (910,'Fredericks','Ryan Fredericks','Silver - Rare','Normal',74,'West Ham United','Premier League','England','RB','1992-10-10',92,72,51,66,69,69,0,0,0,0,0,0,'Right',3,3,69,73,73,74,74,70,67,71,71,68,67,67,67,70,70,63,300,10000
);
INSERT INTO PLAYER VALUES (911,'Kopic','Jan Kopic','Silver - Rare','Normal',74,'Viktoria Plzen','Ceska Liga','Czech Republic','LM','1990-06-04',80,76,69,70,40,60,0,0,0,0,0,0,'Right',3,3,48,56,56,60,60,56,68,73,73,73,73,73,73,74,74,69,300,10000
);
INSERT INTO PLAYER VALUES (912,'Verre','Valerio Verre','Silver - Rare','Normal',74,'Hellas Verona','Serie A TIM','Italy','CAM','1994-01-11',69,74,72,73,65,67,0,0,0,0,0,0,'Right',4,3,66,69,69,70,70,70,73,73,73,73,73,73,73,72,72,71,300,10000
);
INSERT INTO PLAYER VALUES (913,'Luis Hernandez','Luis Hernandez Rodriguez','Gold - Non-Rare','Normal',75,'Malaga CF','LaLiga 1 I 2 I 3','Spain','CB','1989-04-14',67,65,49,65,75,74,0,0,0,0,0,0,'Right',4,2,74,73,73,72,72,72,66,64,64,62,61,61,61,62,62,60,300,10000
);
INSERT INTO PLAYER VALUES (914,'Atsu','Christian Atsu','Silver - Rare','Normal',74,'Newcastle United','Premier League','Ghana','LM','1992-01-10',86,77,67,68,34,45,0,0,0,0,0,0,'Left',3,3,42,54,54,57,57,52,66,73,73,73,72,72,72,73,73,67,300,10000
);
INSERT INTO PLAYER VALUES (915,'Jairo','Jairo Samperio Bustara','Silver - Rare','Normal',74,'Hamburger SV','Bundesliga 2','Spain','LM','1993-07-11',84,77,66,68,30,55,0,0,0,0,0,0,'Right',4,3,43,52,52,55,55,51,66,73,73,72,72,72,72,73,73,68,300,10000
);
INSERT INTO PLAYER VALUES (916,'Poko','Andre Poko','Silver - Non-Rare','Normal',73,'Goztepe SK','Super Lig','Gabon','CDM','1993-01-01',74,74,57,64,69,78,0,0,0,0,0,0,'Right',3,3,70,71,71,71,71,72,71,71,71,69,69,69,69,69,69,66,150,10000
);
INSERT INTO PLAYER VALUES (917,'Ciciretti','Amato Ciciretti','Silver - Rare','Normal',74,'Napoli','Serie A TIM','Italy','CAM','1993-12-31',77,75,68,73,35,49,0,0,0,0,0,0,'Left',4,4,42,51,51,55,55,53,68,72,72,73,71,71,71,73,73,66,300,10000
);
INSERT INTO PLAYER VALUES (918,'Falette','Simon Falette','Silver - Rare','Normal',74,'Eintracht Frankfurt','Bundesliga','Guinea','CB','1992-02-19',67,47,44,44,73,83,0,0,0,0,0,0,'Left',3,2,73,65,65,61,61,64,51,49,49,47,48,48,48,47,47,53,300,10000
);
INSERT INTO PLAYER VALUES (919,'Damm','Jurgen Damm','Silver - Rare','Normal',74,'Tigres U.A.N.L.','LIGA Bancomer MX','Mexico','RM','1992-11-07',94,74,63,65,43,70,0,0,0,0,0,0,'Right',3,3,54,60,60,62,62,58,65,73,73,70,71,71,71,73,73,70,300,10000
);
INSERT INTO PLAYER VALUES (920,'Helander','Filip Helander','Silver - Rare','Normal',74,'Rangers FC','Scottish Premiership','Sweden','CB','1993-04-22',47,54,33,44,76,74,0,0,0,0,0,0,'Left',1,2,73,63,63,60,60,65,52,46,46,46,46,46,46,44,44,48,300,10000
);
INSERT INTO PLAYER VALUES (921,'Webster','Adam Webster','Silver - Rare','Normal',74,'Brighton e Hove Albion','Premier League','England','CB','1995-01-04',68,66,29,55,73,73,0,0,0,0,0,0,'Right',4,2,73,68,68,67,67,70,61,58,58,56,53,53,53,54,54,51,300,10000
);
INSERT INTO PLAYER VALUES (922,'Dioudis','Sokratis Dioudis','Silver - Rare','Normal',74,'Panathinaikos FC','Hellas Liga','Greece','GK','1993-02-03',0,0,0,0,0,0,77,78,71,42,67,73,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (923,'Durm','Erik Durm','Silver - Rare','Normal',74,'Eintracht Frankfurt','Bundesliga','Germany','LB','1992-05-12',76,68,53,65,72,70,0,0,0,0,0,0,'Right',3,3,70,73,73,73,73,70,66,68,68,65,65,65,65,67,67,64,300,10000
);
INSERT INTO PLAYER VALUES (924,'Pedro Henrique','Pedro K. Medina da Silva','Silver - Rare','Normal',74,'Kayserispor','Super Lig','Brazil','RM','1990-06-16',84,77,68,69,31,55,0,0,0,0,0,0,'Left',4,3,43,52,52,56,56,51,65,73,73,73,73,73,73,75,75,71,300,10000
);
INSERT INTO PLAYER VALUES (925,'Lucas Torro','Lucas Torro Marset','Silver - Rare','Normal',74,'Eintracht Frankfurt','Bundesliga','Spain','CDM','1994-07-19',60,65,61,65,74,73,0,0,0,0,0,0,'Right',3,2,72,69,69,69,69,73,70,64,64,66,65,65,65,63,63,65,300,10000
);
INSERT INTO PLAYER VALUES (926,'Bessa','Daniel Bessa','Gold - Non-Rare','Normal',75,'Hellas Verona','Serie A TIM','Italy','CAM','1993-01-14',63,78,69,74,55,50,0,0,0,0,0,0,'Right',4,4,56,61,61,64,64,64,72,72,72,74,73,73,73,73,73,68,300,10000
);
INSERT INTO PLAYER VALUES (927,'Gnohere','Harlem-Eddy Gnohere','Silver - Rare','Normal',74,'FCSB','Romania Liga I','France','ST','1988-02-21',65,65,73,53,27,84,0,0,0,0,0,0,'Left',3,3,46,46,46,48,48,47,58,64,64,65,68,68,68,65,65,73,300,10000
);
INSERT INTO PLAYER VALUES (928,'Mawson','Alfie Mawson','Silver - Rare','Normal',73,'Fulham','EFL Championship','England','CB','1994-01-19',54,58,41,49,73,72,0,0,0,0,0,0,'Right',5,2,72,63,63,60,60,68,57,52,52,53,52,52,52,49,49,54,300,10000
);
INSERT INTO PLAYER VALUES (929,'Moberg Karlsson','David Moberg Karlsson','Silver - Rare','Normal',73,'Sparta Praha','Ceska Liga','Sweden','RM','1994-03-20',87,74,67,65,30,60,0,0,0,0,0,0,'Left',4,3,42,51,51,55,55,49,63,72,72,70,72,72,72,73,73,69,300,10000
);
INSERT INTO PLAYER VALUES (930,'Kevin Rodrigues','Kevin Manuel Rodrigues','Silver - Rare','Normal',74,'Real Sociedad','LaLiga Santander','Portugal','LB','1994-03-05',71,64,48,69,72,61,0,0,0,0,0,0,'Left',3,2,70,73,73,72,72,70,65,65,65,62,61,61,61,63,63,60,300,10000
);
INSERT INTO PLAYER VALUES (931,'Doria','Matheus Doria Macedo','Silver - Rare','Normal',74,'Santos Laguna','LIGA Bancomer MX','Brazil','CB','1994-11-08',61,57,52,52,73,75,0,0,0,0,0,0,'Left',2,2,73,66,66,64,64,68,60,57,57,56,58,58,58,55,55,60,300,10000
);
INSERT INTO PLAYER VALUES (932,'Baba','Abdul Rahman Baba','Silver - Rare','Normal',74,'Chelsea','Premier League','Ghana','LB','1994-07-02',78,74,50,66,72,67,0,0,0,0,0,0,'Left',2,3,71,73,73,73,73,71,68,70,70,67,67,67,67,69,69,64,300,10000
);
INSERT INTO PLAYER VALUES (933,'Dessoleil','Dorian Dessoleil','Silver - Rare','Normal',74,'Sporting Charleroi','Belgium Pro League','Belgium','CB','1992-08-07',54,49,46,52,75,76,0,0,0,0,0,0,'Left',3,2,73,65,65,62,62,68,57,49,49,50,49,49,49,47,47,53,300,10000
);
INSERT INTO PLAYER VALUES (934,'Lucas Silva','Lucas Silva Borges','Silver - Rare','Normal',74,'Real Madrid','LaLiga Santander','Brazil','CDM','1993-02-16',59,71,62,68,71,74,0,0,0,0,0,0,'Right',3,3,71,70,70,70,70,73,72,68,68,69,68,68,68,67,67,66,300,10000
);
INSERT INTO PLAYER VALUES (935,'Agu','Mikel Agu','Silver - Rare','Normal',74,'Vitoria Guimaraes','Liga NOS','Nigeria','CDM','1993-05-27',64,66,44,59,73,81,0,0,0,0,0,0,'Right',3,2,74,70,70,70,70,73,65,61,61,59,57,57,57,58,58,56,300,10000
);
INSERT INTO PLAYER VALUES (936,'Wimmer','Kevin Wimmer','Silver - Rare','Normal',73,'Stoke City','EFL Championship','Austria','CB','1992-11-15',53,64,27,59,73,73,0,0,0,0,0,0,'Left',3,2,72,66,66,65,65,71,63,57,57,57,53,53,53,53,53,50,300,10000
);
INSERT INTO PLAYER VALUES (937,'Jozabed','Jozabed Sanchez Ruiz','Silver - Rare','Normal',74,'Girona FC','LaLiga 1 I 2 I 3','Spain','CM','1991-03-08',59,72,71,73,57,64,0,0,0,0,0,0,'Right',3,3,62,64,64,65,65,67,73,71,71,74,73,73,73,71,71,70,300,10000
);
INSERT INTO PLAYER VALUES (938,'Ghezzal','Rachid Ghezzal','Silver - Rare','Normal',74,'Leicester City','Premier League','Algeria','RW','1992-05-09',72,77,68,74,28,58,0,0,0,0,0,0,'Left',3,4,42,50,50,54,54,51,67,73,73,73,72,72,72,74,74,69,300,10000
);
INSERT INTO PLAYER VALUES (939,'Kutepov','Ilya Kutepov','Silver - Rare','Normal',74,'Spartak Moscow','League of Russia','Russia','CB','1993-07-29',33,48,47,57,76,74,0,0,0,0,0,0,'Right',5,2,73,65,65,63,63,72,61,48,48,51,49,49,49,45,45,53,300,10000
);
INSERT INTO PLAYER VALUES (940,'Joao Schmidt','Joao Felipe Schmidt Urbano','Silver - Rare','Normal',74,'Nagoya Grampus','Meiji Yasuda J1 League','Brazil','CM','1993-05-19',54,71,67,74,68,73,0,0,0,0,0,0,'Left',3,3,70,68,68,69,69,72,73,69,69,71,70,70,70,68,68,69,300,10000
);
INSERT INTO PLAYER VALUES (941,'Paterson','Callum Paterson','Silver - Rare','Normal',73,'Cardiff City','EFL Championship','Scotland','ST','1994-10-13',74,67,67,66,69,86,0,0,0,0,0,0,'Right',3,3,73,72,72,71,71,71,70,71,71,69,71,71,71,70,70,72,300,10000
);
INSERT INTO PLAYER VALUES (942,'Verstraete','Birger Verstraete','Silver - Rare','Normal',74,'1. FC Koln','Bundesliga','Belgium','CDM','1994-04-16',72,69,58,71,71,74,0,0,0,0,0,0,'Right',3,3,71,72,72,72,72,73,71,68,68,67,65,65,65,66,66,63,300,10000
);
INSERT INTO PLAYER VALUES (943,'De Blasis','Pablo De Blasis','Silver - Rare','Normal',74,'SD Eibar','LaLiga Santander','Argentina','LM','1988-02-04',76,79,72,70,56,55,0,0,0,0,0,0,'Right',4,3,59,64,64,65,65,63,69,73,73,73,73,73,73,74,74,71,300,10000
);
INSERT INTO PLAYER VALUES (944,'Manquillo','Javier Manquillo Gaitan','Silver - Rare','Normal',74,'Newcastle United','Premier League','Spain','RWB','1994-05-05',73,71,44,63,71,66,0,0,0,0,0,0,'Right',3,3,70,73,73,73,73,69,64,67,67,62,63,63,63,65,65,61,300,10000
);
INSERT INTO PLAYER VALUES (945,'Ruben Garcia','Ruben Garcia Santos','Silver - Rare','Normal',74,'CA Osasuna','LaLiga Santander','Spain','CAM','1993-07-14',79,77,69,70,38,54,0,0,0,0,0,0,'Left',2,4,47,54,54,57,57,54,66,72,72,73,72,72,72,73,73,68,300,10000
);
INSERT INTO PLAYER VALUES (946,'Dack','Bradley Dack','Silver - Rare','Normal',74,'Blackburn Rovers','EFL Championship','England','CAM','1993-12-31',76,76,70,71,52,74,0,0,0,0,0,0,'Right',4,3,60,62,62,63,63,64,70,73,73,73,73,73,73,73,73,72,300,10000
);
INSERT INTO PLAYER VALUES (947,'Czichos','Rafael Czichos','Silver - Rare','Normal',74,'1. FC Koln','Bundesliga','Germany','CB','1990-05-14',59,62,48,59,74,74,0,0,0,0,0,0,'Left',3,2,73,68,68,67,67,69,61,58,58,57,57,57,57,57,57,57,300,10000
);
INSERT INTO PLAYER VALUES (948,'Hahn','Andre Hahn','Silver - Rare','Normal',74,'FC Augsburg','Bundesliga','Germany','RM','1990-08-13',72,66,76,67,55,83,0,0,0,0,0,0,'Right',4,3,64,66,66,67,67,64,68,72,72,70,72,72,72,71,71,74,300,10000
);
INSERT INTO PLAYER VALUES (949,'Niederlechner','Florian Niederlechner','Silver - Rare','Normal',74,'FC Augsburg','Bundesliga','Germany','ST','1990-10-24',70,69,75,57,35,77,0,0,0,0,0,0,'Right',4,3,50,51,51,54,54,52,62,67,67,67,70,70,70,68,68,73,300,10000
);
INSERT INTO PLAYER VALUES (950,'Heuer Fernandes','Daniel Heuer Fernandes','Silver - Rare','Normal',74,'Hamburger SV','Bundesliga 2','Portugal','GK','1992-11-13',0,0,0,0,0,0,75,78,72,43,76,69,'Right',4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (951,'O''Connell','Jack O''Connell','Silver - Rare','Normal',74,'Sheffield United','Premier League','England','CB','1994-03-29',63,55,37,50,73,78,0,0,0,0,0,0,'Left',2,2,73,67,67,66,66,66,53,53,53,49,49,49,49,51,51,50,300,10000
);
INSERT INTO PLAYER VALUES (952,'Van Beek','Sven van Beek','Silver - Rare','Normal',74,'Feyenoord','Eredivisie','Holland','CB','1994-07-28',62,52,34,56,75,73,0,0,0,0,0,0,'Right',2,2,73,68,68,65,65,70,59,52,52,50,48,48,48,48,48,50,300,10000
);
INSERT INTO PLAYER VALUES (953,'Rober','Roberto Suarez Pier','Silver - Rare','Normal',74,'RC Deportivo','LaLiga 1 I 2 I 3','Spain','CB','1995-02-16',54,61,43,61,75,73,0,0,0,0,0,0,'Right',3,2,73,69,69,68,68,72,65,60,60,59,57,57,57,57,57,56,300,10000
);
INSERT INTO PLAYER VALUES (954,'Cavallini','Lucas Cavallini','Silver - Rare','Normal',74,'Puebla','LIGA Bancomer MX','Canada','ST','1992-12-28',76,71,73,49,33,80,0,0,0,0,0,0,'Left',4,3,49,46,46,47,47,49,59,65,65,66,70,70,70,67,67,73,300,10000
);
INSERT INTO PLAYER VALUES (955,'oztunali','Levin oztunali','Silver - Non-Rare','Normal',73,'1. FSV Mainz 05','Bundesliga','Germany','RM','1996-03-15',82,76,67,68,47,68,0,0,0,0,0,0,'Right',2,3,55,60,60,63,63,60,68,72,72,71,72,72,72,73,73,70,150,10000
);
INSERT INTO PLAYER VALUES (956,'Adama','Adama Traore Diarra','Silver - Rare','Normal',74,'Wolverhampton Wanderers','Premier League','Spain','RW','1996-01-25',96,83,60,61,31,75,0,0,0,0,0,0,'Right',2,4,47,55,55,59,59,52,62,73,73,70,71,71,71,74,74,67,650,12000
);
INSERT INTO PLAYER VALUES (957,'Vikonis','Nicolas Vikonis','Silver - Rare','Normal',74,'Puebla','LIGA Bancomer MX','Uruguay','GK','1984-04-06',0,0,0,0,0,0,73,74,75,41,69,72,'Left',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (958,'Pardo','Felipe Pardo','Silver - Rare','Normal',74,'Deportivo Toluca','LIGA Bancomer MX','Colombia','RW','1990-08-17',81,73,75,71,38,80,0,0,0,0,0,0,'Right',4,3,52,55,55,58,58,57,67,74,74,73,74,74,74,74,74,74,300,10000
);
INSERT INTO PLAYER VALUES (959,'Lichnovsky','Igor Lichnovsky','Silver - Rare','Normal',74,'Cruz Azul','LIGA Bancomer MX','Chile','CB','1994-03-07',68,61,40,51,74,75,0,0,0,0,0,0,'Right',4,2,73,67,67,65,65,68,58,56,56,55,54,54,54,54,54,56,300,10000
);
INSERT INTO PLAYER VALUES (960,'Morelo','Wilson Morelo','Silver - Rare','Normal',74,'Colon de Santa Fe','SAF','Colombia','ST','1987-05-21',79,74,74,61,42,67,0,0,0,0,0,0,'Right',3,3,52,56,56,58,58,56,65,70,70,70,72,72,72,71,71,73,300,10000
);
INSERT INTO PLAYER VALUES (961,'Scocco','Ignacio Scocco','Gold - Non-Rare','Normal',77,'Nunez','SAF','Argentina','ST','1985-05-29',73,80,80,71,35,66,0,0,0,0,0,0,'Right',4,4,49,52,52,56,56,56,70,74,74,77,78,78,78,77,77,76,350,10000
);
INSERT INTO PLAYER VALUES (962,'Elia','Eljero Elia','Gold - Rare','Normal',77,'Medipol Basaksehir FK','Super Lig','Holland','LM','1987-02-13',92,84,68,68,35,67,0,0,0,0,0,0,'Right',3,5,48,56,56,60,60,56,68,76,76,76,76,76,76,77,77,72,650,10000
);
INSERT INTO PLAYER VALUES (963,'Junuzovic','Zlatko Junuzovic','Gold - Non-Rare','Normal',77,'FC Red Bull Salzburg','osterreichische Fubball-Bundesliga','Austria','CM','1987-09-26',71,81,73,78,65,73,0,0,0,0,0,0,'Right',4,3,67,72,72,74,74,73,76,77,77,76,75,75,75,76,76,72,350,10000
);
INSERT INTO PLAYER VALUES (964,'Bravo','Claudio Bravo','Gold - Rare','Normal',77,'Manchester City','Premier League','Chile','GK','1983-04-13',0,0,0,0,0,0,77,77,76,56,84,75,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,650,10000
);
INSERT INTO PLAYER VALUES (965,'Odjidja-Ofoe','Vadis Odjidja-Ofoe','Gold - Non-Rare','Normal',77,'KAA Gent','Belgium Pro League','Belgium','CM','1989-02-21',56,74,73,76,69,79,0,0,0,0,0,0,'Right',4,3,71,70,70,71,71,75,76,73,73,74,73,73,73,72,72,72,350,10000
);
INSERT INTO PLAYER VALUES (966,'Ayew','Andre Ayew','Gold - Non-Rare','Normal',76,'Swansea City','EFL Championship','Ghana','RM','1989-12-17',73,78,72,72,56,75,0,0,0,0,0,0,'Left',3,4,64,66,66,68,68,66,73,74,74,75,75,75,75,75,75,74,350,10000
);
INSERT INTO PLAYER VALUES (967,'Gurtner','Regis Gurtner','Gold - Non-Rare','Normal',77,'Amiens SC','Ligue 1 Conforama','France','GK','1986-12-08',0,0,0,0,0,0,78,79,75,44,74,75,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (968,'Schneiderlin','Morgan Schneiderlin','Gold - Non-Rare','Normal',77,'Everton','Premier League','France','CDM','1989-11-08',56,71,60,71,75,76,0,0,0,0,0,0,'Right',3,3,75,72,72,72,72,76,72,68,68,69,67,67,67,67,67,66,350,10000
);
INSERT INTO PLAYER VALUES (969,'Lens','Jeremain Lens','Gold - Non-Rare','Normal',77,'Besiktas JK','Super Lig','Holland','RM','1987-11-24',89,79,74,71,36,71,0,0,0,0,0,0,'Right',4,4,50,57,57,60,60,55,69,76,76,75,76,76,76,77,77,76,350,10000
);
INSERT INTO PLAYER VALUES (970,'Remy','Loic Remy','Gold - Non-Rare','Normal',77,'LOSC Lille','Ligue 1 Conforama','France','ST','1987-01-02',74,73,77,66,37,68,0,0,0,0,0,0,'Right',3,4,50,53,53,55,55,55,67,72,72,73,75,75,75,73,73,76,350,10000
);
INSERT INTO PLAYER VALUES (971,'Suchy','Marek Suchy','Gold - Non-Rare','Normal',77,'FC Augsburg','Bundesliga','Czech Republic','CB','1988-03-29',64,64,52,58,76,78,0,0,0,0,0,0,'Right',3,2,76,70,70,68,68,72,64,59,59,59,58,58,58,57,57,59,350,10000
);
INSERT INTO PLAYER VALUES (972,'De Maio','Sebastian De Maio','Gold - Rare','Normal',77,'Udinese','Serie A TIM','France','CB','1987-03-05',57,55,33,38,79,79,0,0,0,0,0,0,'Right',3,2,76,64,64,60,60,67,51,44,44,45,45,45,45,42,42,48,650,10000
);
INSERT INTO PLAYER VALUES (973,'Aguilar','Pablo Aguilar','Gold - Non-Rare','Normal',77,'Cruz Azul','LIGA Bancomer MX','Paraguay','CB','1987-04-02',63,57,52,53,77,78,0,0,0,0,0,0,'Right',3,2,76,67,67,64,64,69,59,54,54,55,54,54,54,53,53,57,350,10000
);
INSERT INTO PLAYER VALUES (974,'Delph','Fabian Delph','Gold - Non-Rare','Normal',77,'Everton','Premier League','England','LB','1989-11-21',69,79,70,76,73,74,0,0,0,0,0,0,'Left',3,3,73,76,76,77,77,78,78,76,76,76,74,74,74,75,75,71,350,10000
);
INSERT INTO PLAYER VALUES (975,'Roberto','Roberto Jimenez Gago','Gold - Non-Rare','Normal',77,'West Ham United','Premier League','Spain','GK','1986-02-10',0,0,0,0,0,0,80,82,70,46,73,74,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (976,'Terodde','Simon Terodde','Gold - Non-Rare','Normal',76,'1. FC Koln','Bundesliga','Germany','ST','1988-03-02',56,67,78,55,38,77,0,0,0,0,0,0,'Right',4,3,52,49,49,50,50,52,61,65,65,67,71,71,71,67,67,75,350,10000
);
INSERT INTO PLAYER VALUES (977,'Ogbonna','Angelo Ogbonna','Gold - Non-Rare','Normal',77,'West Ham United','Premier League','Italy','CB','1988-05-23',58,60,39,58,79,74,0,0,0,0,0,0,'Left',3,2,76,70,70,68,68,71,61,56,56,55,53,53,53,53,53,54,350,10000
);
INSERT INTO PLAYER VALUES (978,'Traore','Ibrahima Traore','Gold - Non-Rare','Normal',77,'Borussia Monchengladbach','Bundesliga','Guinea','RM','1988-04-21',82,83,70,74,44,49,0,0,0,0,0,0,'Left',4,4,50,59,59,63,63,58,70,76,76,76,76,76,76,77,77,70,350,10000
);
INSERT INTO PLAYER VALUES (979,'Alan Kardec','Alan Kardec de Sousa Pereira Jr','Gold - Non-Rare','Normal',77,'Chongqing Lifan FC','CSL','Brazil','ST','1989-01-12',73,70,76,64,34,74,0,0,0,0,0,0,'Right',3,3,49,53,53,55,55,52,65,71,71,70,73,73,73,72,72,76,350,10000
);
INSERT INTO PLAYER VALUES (980,'Ighalo','Odion Ighalo','Gold - Rare','Normal',77,'Shanghai Greenland Shenhua FC','CSL','Nigeria','ST','1989-06-16',84,78,72,56,36,79,0,0,0,0,0,0,'Right',3,4,53,55,55,57,57,54,64,72,72,71,75,75,75,73,73,76,650,10000
);
INSERT INTO PLAYER VALUES (981,'Douglas','Douglas Renato de Jesus','Gold - Non-Rare','Normal',77,'Vitoria Guimaraes','Liga NOS','Brazil','GK','1983-03-09',0,0,0,0,0,0,78,77,75,36,71,74,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (982,'Rochina','Ruben Rochina Naixes','Gold - Non-Rare','Normal',76,'Levante UD','LaLiga Santander','Spain','CM','1991-03-23',69,80,76,77,54,69,0,0,0,0,0,0,'Left',2,4,60,63,63,66,66,67,75,76,76,78,77,77,77,76,76,74,350,10000
);
INSERT INTO PLAYER VALUES (983,'Janmaat','Daryl Janmaat','Gold - Non-Rare','Normal',77,'Watford','Premier League','Holland','RB','1989-07-22',67,75,65,73,75,74,0,0,0,0,0,0,'Right',3,3,75,76,76,76,76,76,74,74,74,72,72,72,72,72,72,70,350,10000
);
INSERT INTO PLAYER VALUES (984,'Dragovic','Aleksandar Dragovic','Gold - Non-Rare','Normal',77,'Bayer 04 Leverkusen','Bundesliga','Austria','CB','1991-03-06',65,65,51,60,77,75,0,0,0,0,0,0,'Right',4,2,76,71,71,69,69,72,66,62,62,63,63,63,63,61,61,63,350,10000
);
INSERT INTO PLAYER VALUES (985,'Westwood','Ashley Westwood','Gold - Non-Rare','Normal',77,'Burnley','Premier League','England','CM','1990-04-01',60,74,60,79,74,76,0,0,0,0,0,0,'Right',3,3,74,74,74,75,75,78,76,73,73,72,70,70,70,70,70,66,350,10000
);
INSERT INTO PLAYER VALUES (986,'Victor Sanchez','Victor Sanchez Mata','Gold - Non-Rare','Normal',77,'RCD Espanyol','LaLiga Santander','Spain','CM','1987-09-08',55,74,63,77,75,66,0,0,0,0,0,0,'Right',3,3,74,73,73,73,73,76,76,71,71,73,70,70,70,70,70,67,350,10000
);
INSERT INTO PLAYER VALUES (987,'Rincon','Tomas Rincon','Gold - Non-Rare','Normal',77,'Torino','Serie A TIM','Venezuela','CM','1988-01-13',68,76,59,71,76,80,0,0,0,0,0,0,'Right',3,3,76,75,75,76,76,78,76,72,72,72,70,70,70,70,70,66,350,10000
);
INSERT INTO PLAYER VALUES (988,'Johnathan','Johnathan Aparecido Silva','Gold - Non-Rare','Normal',77,'Tianjin TEDA FC','CSL','Brazil','ST','1990-03-29',79,74,76,63,40,76,0,0,0,0,0,0,'Right',5,4,52,55,55,58,58,54,65,72,72,71,74,74,74,73,73,76,350,10000
);
INSERT INTO PLAYER VALUES (989,'Plattenhardt','Marvin Plattenhardt','Gold - Non-Rare','Normal',77,'Hertha BSC','Bundesliga','Germany','LB','1992-01-26',71,75,55,77,74,72,0,0,0,0,0,0,'Left',2,3,73,76,76,77,77,74,72,73,73,70,69,69,69,71,71,66,350,10000
);
INSERT INTO PLAYER VALUES (990,'Malli','Yunus Malli','Gold - Non-Rare','Normal',77,'VfL Wolfsburg','Bundesliga','Turkey','LM','1992-02-24',71,80,68,76,33,57,0,0,0,0,0,0,'Right',4,4,44,54,54,59,59,57,72,76,76,76,74,74,74,76,76,68,350,10000
);
INSERT INTO PLAYER VALUES (991,'Rodriguez','Luis Miguel Rodriguez','Gold - Non-Rare','Normal',77,'Colon de Santa Fe','SAF','Argentina','ST','1985-01-01',67,80,79,73,27,66,0,0,0,0,0,0,'Right',4,4,45,49,49,53,53,53,70,75,75,77,78,78,78,77,77,76,350,10000
);
INSERT INTO PLAYER VALUES (992,'Tosun','Cenk Tosun','Gold - Non-Rare','Normal',77,'Everton','Premier League','Turkey','ST','1991-06-07',71,73,77,66,36,73,0,0,0,0,0,0,'Right',4,3,51,51,51,54,54,54,66,71,71,71,74,74,74,72,72,76,350,10000
);
INSERT INTO PLAYER VALUES (993,'Burgstaller','Guido Burgstaller','Gold - Non-Rare','Normal',77,'FC Schalke 04','Bundesliga','Austria','ST','1989-04-29',67,72,76,66,38,84,0,0,0,0,0,0,'Right',5,3,53,55,55,58,58,58,68,73,73,72,74,74,74,73,73,76,350,10000
);
INSERT INTO PLAYER VALUES (994,'Borja Garcia','Borja Garcia Freire','Gold - Non-Rare','Normal',75,'Girona FC','LaLiga 1 I 2 I 3','Spain','LM','1990-11-02',79,75,70,73,58,65,0,0,0,0,0,0,'Right',3,3,62,67,67,68,68,67,73,74,74,75,74,74,74,74,74,70,300,10000
);
INSERT INTO PLAYER VALUES (995,'Renan Ribeiro','Renan Ribeiro','Gold - Non-Rare','Normal',77,'Sporting CP','Liga NOS','Brazil','GK','1990-03-23',0,0,0,0,0,0,81,80,70,49,67,75,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (996,'Mooy','Aaron Mooy','Gold - Non-Rare','Normal',76,'Brighton e Hove Albion','Premier League','Australia','CM','1990-09-15',59,73,69,77,69,74,0,0,0,0,0,0,'Right',3,3,70,70,70,71,71,74,75,72,72,73,71,71,71,71,71,68,350,10000
);
INSERT INTO PLAYER VALUES (997,'Martin','Jonas Martin','Gold - Non-Rare','Normal',77,'RC Strasbourg Alsace','Ligue 1 Conforama','France','CM','1990-04-09',62,75,69,77,68,73,0,0,0,0,0,0,'Right',4,4,69,71,71,72,72,74,76,74,74,74,72,72,72,72,72,69,350,10000
);
INSERT INTO PLAYER VALUES (998,'Juanmi','Juan Miguel Jimenez Lopez','Gold - Non-Rare','Normal',77,'Real Betis','LaLiga Santander','Spain','LW','1993-05-20',74,78,77,67,30,53,0,0,0,0,0,0,'Right',3,3,44,52,52,55,55,51,68,75,75,76,77,77,77,77,77,76,350,10000
);
INSERT INTO PLAYER VALUES (999,'Ortiz','Celso Ortiz','Gold - Non-Rare','Normal',76,'Monterrey','LIGA Bancomer MX','Paraguay','CDM','1989-01-26',67,73,57,66,74,77,0,0,0,0,0,0,'Left',3,3,73,72,72,73,73,75,72,68,68,70,68,68,68,67,67,64,350,10000
);
INSERT INTO PLAYER VALUES (1000,'Tomas Pina','Tomas Pina Isla','Gold - Non-Rare','Normal',77,'D. Alaves','LaLiga Santander','Spain','CM','1987-10-14',49,74,66,72,72,71,0,0,0,0,0,0,'Right',3,3,72,69,69,70,70,75,76,70,70,73,71,71,71,69,69,69,350,10000
);
INSERT INTO PLAYER VALUES (1001,'Claudio Ramos','Claudio Pires de Morais Ramos','Gold - Non-Rare','Normal',77,'Tondela','Liga NOS','Portugal','GK','1991-11-16',0,0,0,0,0,0,81,79,75,52,65,73,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,350,10000
);
INSERT INTO PLAYER VALUES (1002,'Sergio Leon','Sergio Leon Limones','Gold - Non-Rare','Normal',77,'Levante UD','LaLiga Santander','Spain','ST','1989-01-06',77,78,78,64,43,69,0,0,0,0,0,0,'Right',4,3,53,55,55,58,58,56,66,73,73,73,76,76,76,75,75,76,350,10000
);
INSERT INTO PLAYER VALUES (1003,'Redmond','Nathan Redmond','Gold - Non-Rare','Normal',77,'Southampton','Premier League','England','LM','1994-03-06',84,81,71,71,27,52,0,0,0,0,0,0,'Right',3,4,39,52,52,57,57,51,68,76,76,76,75,75,75,77,77,70,350,10000
);
INSERT INTO PLAYER VALUES (1004,'Andre Andre','Andre Filipe Bras Andre','Gold - Non-Rare','Normal',77,'Vitoria Guimaraes','Liga NOS','Portugal','CM','1989-08-26',69,78,71,76,71,68,0,0,0,0,0,0,'Right',4,3,71,72,72,73,73,74,76,75,75,76,75,75,75,75,75,72,350,10000
);
INSERT INTO PLAYER VALUES (1005,'Funes Mori','Ramiro Funes Mori','Gold - Non-Rare','Normal',77,'Villarreal CF','LaLiga Santander','Argentina','CB','1991-03-05',62,66,50,64,76,76,0,0,0,0,0,0,'Left',3,2,76,72,72,71,71,72,65,63,63,62,61,61,61,61,61,60,350,10000
);
INSERT INTO PLAYER VALUES (1006,'Van Ginkel','Marco van Ginkel','Gold - Non-Rare','Normal',77,'Chelsea','Premier League','Holland','CM','1992-12-01',64,75,77,77,70,70,0,0,0,0,0,0,'Right',4,3,71,70,70,71,71,73,76,74,74,76,76,76,76,75,75,75,350,10000
);
INSERT INTO PLAYER VALUES (1007,'Jorgensen','Nicolai Jorgensen','Gold - Non-Rare','Normal',76,'Feyenoord','Eredivisie','Denmark','ST','1991-01-15',71,73,76,70,39,76,0,0,0,0,0,0,'Right',3,3,52,54,54,57,57,57,69,73,73,74,75,75,75,73,73,75,350,10000
);
INSERT INTO PLAYER VALUES (1008,'Zhang Yufeng','Yufeng Zhang','Bronze - Non-Rare','Normal',48,'Beijing Renhe','CSL','China PR','CM','1998-01-05',65,51,34,46,47,57,0,0,0,0,0,0,'Right',3,2,50,49,49,49,49,49,47,47,47,48,45,45,45,47,47,44,150,10000
);
INSERT INTO PLAYER VALUES (1009,'Offord','Luke Offord','Bronze - Non-Rare','Normal',48,'Crewe Alexandra','EFL League Two','England','CDM','1999-11-19',59,49,26,43,48,39,0,0,0,0,0,0,'Right',3,2,47,48,48,47,47,47,44,45,45,45,43,43,43,45,45,40,150,10000
);
INSERT INTO PLAYER VALUES (1010,'Tweed','Evan Tweed','Bronze - Non-Rare','Normal',48,'Derry City','SSE Airtricity League','Republic of Ireland','CM','1999-03-01',52,46,37,47,42,49,0,0,0,0,0,0,'Right',3,2,46,46,46,46,46,47,47,46,46,46,44,44,44,44,44,43,150,10000
);
INSERT INTO PLAYER VALUES (1011,'Shao Shuai','Shuai Shao','Bronze - Non-Rare','Normal',48,'Beijing Renhe','CSL','China PR','CB','1997-03-10',57,34,23,28,47,51,0,0,0,0,0,0,'Right',3,2,47,45,45,43,43,42,34,34,34,31,32,32,32,32,32,33,150,10000
);
INSERT INTO PLAYER VALUES (1012,'Sykes-Kenworthy','George Sykes-Kenworthy','Bronze - Non-Rare','Normal',48,'Bradford City','EFL League Two','England','GK','1999-10-01',0,0,0,0,0,0,44,51,46,31,45,48,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1013,'Callan','Sean Callan','Bronze - Non-Rare','Normal',48,'Shamrock Rovers','SSE Airtricity League','Republic of Ireland','CB','1999-12-14',56,31,26,25,48,53,0,0,0,0,0,0,'Right',3,2,47,45,45,43,43,41,31,32,32,29,31,31,31,31,31,33,150,10000
);
INSERT INTO PLAYER VALUES (1014,'Ryan','Jack Ryan','Bronze - Non-Rare','Normal',48,'UCD','SSE Airtricity League','Republic of Ireland','CM','2000-02-07',57,48,36,44,40,54,0,0,0,0,0,0,'Right',2,2,45,45,45,45,45,46,47,47,47,47,46,46,46,46,46,46,150,10000
);
INSERT INTO PLAYER VALUES (1015,'Stekelenburg','Maarten Stekelenburg','Silver - Rare','Normal',73,'Everton','Premier League','Holland','GK','1982-09-22',0,0,0,0,0,0,71,73,72,32,76,73,'Right',4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (1016,'Wilbraham','Aaron Wilbraham','Bronze - Rare','Normal',62,'Rochdale','EFL League One','England','ST','1979-10-21',37,49,58,56,28,69,0,0,0,0,0,0,'Right',3,2,45,38,38,39,39,45,52,52,52,56,57,57,57,53,53,61,150,10000
);
INSERT INTO PLAYER VALUES (1017,'Ellison','Kevin Ellison','Bronze - Rare','Normal',58,'Morecambe','EFL League Two','England','LM','1979-02-23',43,63,63,56,43,74,0,0,0,0,0,0,'Left',3,2,53,49,49,50,50,52,56,57,57,59,60,60,60,59,59,61,150,10000
);
INSERT INTO PLAYER VALUES (1018,'Yuri','Yuri de Souza Fonseca','Silver - Non-Rare','Normal',69,'SD Ponferradina','LaLiga 1 I 2 I 3','Brazil','ST','1982-08-08',66,67,70,55,35,68,0,0,0,0,0,0,'Left',4,3,46,48,48,50,50,48,58,63,63,64,66,66,66,65,65,68,150,10000
);
INSERT INTO PLAYER VALUES (1019,'Dainelli','Dario Dainelli','Silver - Rare','Normal',73,'Livorno','Calcio B','Italy','CB','1979-06-09',32,52,33,43,76,65,0,0,0,0,0,0,'Right',3,2,72,59,59,56,56,65,51,42,42,43,43,43,43,40,40,46,300,10000
);
INSERT INTO PLAYER VALUES (1020,'Ishizaki','Stefan Ishizaki','Silver - Non-Rare','Normal',67,'IF Elfsborg','Allsvenskan','Sweden','CM','1982-05-15',57,69,62,70,52,60,0,0,0,0,0,0,'Right',3,3,54,56,56,58,58,59,66,66,66,67,65,65,65,66,66,63,150,10000
);
INSERT INTO PLAYER VALUES (1021,'Porter','Chris Porter','Bronze - Rare','Normal',62,'Crewe Alexandra','EFL League Two','England','ST','1983-12-12',49,57,62,51,38,72,0,0,0,0,0,0,'Right',4,2,48,46,46,47,47,49,55,55,55,57,58,58,58,56,56,61,150,10000
);
INSERT INTO PLAYER VALUES (1022,'Mccombe','Jamie McCombe','Bronze - Rare','Normal',52,'Lincoln City','EFL League One','England','CB','1983-01-01',24,24,22,30,50,57,0,0,0,0,0,0,'Right',2,2,51,41,41,38,38,44,33,28,28,27,27,27,27,26,26,31,150,10000
);
INSERT INTO PLAYER VALUES (1023,'Green','Paul Green','Bronze - Rare','Normal',64,'Crewe Alexandra','EFL League Two','Republic of Ireland','CM','1983-04-10',55,62,56,62,60,72,0,0,0,0,0,0,'Right',3,2,62,62,62,63,63,64,63,60,60,60,58,58,58,59,59,58,150,10000
);
INSERT INTO PLAYER VALUES (1024,'Pogatetz','Emanuel Pogatetz','Silver - Rare','Normal',68,'LASK Linz','osterreichische Fubball-Bundesliga','Austria','CB','1983-01-16',30,36,34,44,66,79,0,0,0,0,0,0,'Left',2,2,67,55,55,53,53,60,47,40,40,40,40,40,40,37,37,44,250,10000
);
INSERT INTO PLAYER VALUES (1025,'Rimando','Nick Rimando','Silver - Non-Rare','Normal',71,'Real Salt Lake','Major League Soccer','United States','GK','1979-06-17',0,0,0,0,0,0,71,73,69,45,69,70,'Right',4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1026,'Howard','Tim Howard','Silver - Non-Rare','Normal',71,'Colorado Rapids','Major League Soccer','United States','GK','1979-03-06',0,0,0,0,0,0,72,68,72,45,72,71,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1027,'Ruben Fernandes','Ruben Miguel Santos Fernandes','Silver - Non-Rare','Normal',70,'Gil Vicente FC','Liga NOS','Portugal','CB','1986-05-06',61,56,51,56,69,73,0,0,0,0,0,0,'Left',3,2,69,65,65,64,64,66,59,56,56,55,55,55,55,54,54,57,150,10000
);
INSERT INTO PLAYER VALUES (1028,'Steele','Luke Steele','Silver - Non-Rare','Normal',68,'Millwall','EFL Championship','England','GK','1984-09-24',0,0,0,0,0,0,68,71,66,50,63,66,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1029,'Ibehre','Jabo Ibehre','Bronze - Rare','Normal',59,'Cambridge United','EFL League Two','England','ST','1983-01-28',62,56,54,50,39,79,0,0,0,0,0,0,'Right',2,2,50,49,49,50,50,50,54,57,57,56,57,57,57,56,56,58,150,10000
);
INSERT INTO PLAYER VALUES (1030,'Morris','Glenn Morris','Bronze - Rare','Normal',64,'Crawley Town','EFL League Two','England','GK','1983-12-20',0,0,0,0,0,0,67,66,59,33,62,64,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1031,'Cretaro','Raffaele Cretaro','Bronze - Non-Rare','Normal',56,'Finn Harps','SSE Airtricity League','Republic of Ireland','ST','1981-10-15',46,61,58,55,32,45,0,0,0,0,0,0,'Right',4,3,40,42,42,44,44,43,53,55,55,57,56,56,56,57,57,55,150,10000
);
INSERT INTO PLAYER VALUES (1032,'Wiland','Johan Wiland','Silver - Rare','Normal',71,'Hammarby IF','Allsvenskan','Sweden','GK','1981-01-24',0,0,0,0,0,0,65,66,75,27,67,77,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,250,10000
);
INSERT INTO PLAYER VALUES (1033,'Beckerman','Kyle Beckerman','Silver - Non-Rare','Normal',70,'Real Salt Lake','Major League Soccer','United States','CDM','1982-04-23',34,64,60,62,68,69,0,0,0,0,0,0,'Right',3,2,67,61,61,61,61,69,66,58,58,62,60,60,60,57,57,60,150,10000
);
INSERT INTO PLAYER VALUES (1034,'Beasley','DaMarcus Beasley','Silver - Non-Rare','Normal',68,'Houston Dynamo','Major League Soccer','United States','LB','1982-05-24',74,66,58,64,65,64,0,0,0,0,0,0,'Left',4,3,65,67,67,67,67,65,64,65,65,64,64,64,64,65,65,62,150,10000
);
INSERT INTO PLAYER VALUES (1035,'Farnerud','Alexander Farnerud','Silver - Non-Rare','Normal',70,'Helsingborgs IF','Allsvenskan','Sweden','CM','1984-05-01',60,68,67,71,61,59,0,0,0,0,0,0,'Left',3,3,62,63,63,64,64,65,69,67,67,69,68,68,68,67,67,66,150,10000
);
INSERT INTO PLAYER VALUES (1036,'Rosenberg','Markus Rosenberg','Silver - Rare','Normal',72,'Malmo FF','Allsvenskan','Sweden','ST','1982-09-27',64,68,72,69,38,79,0,0,0,0,0,0,'Right',3,3,54,53,53,56,56,57,67,69,69,70,70,70,70,70,70,71,300,10000
);
INSERT INTO PLAYER VALUES (1037,'Pedersen','Morten Gamst Pedersen','Silver - Non-Rare','Normal',68,'Tromso IL','Eliteserien','Norway','CM','1981-09-08',38,68,66,72,50,60,0,0,0,0,0,0,'Left',5,3,55,54,54,57,57,60,67,64,64,67,65,65,65,65,65,63,150,10000
);
INSERT INTO PLAYER VALUES (1038,'Coloccini','Fabricio Coloccini','Silver - Non-Rare','Normal',72,'San Lorenzo de Almagro','SAF','Argentina','CB','1982-01-22',40,61,55,58,72,69,0,0,0,0,0,0,'Right',4,2,71,62,62,60,60,66,60,54,54,56,55,55,55,54,54,57,150,10000
);
INSERT INTO PLAYER VALUES (1039,'Deschacht','Olivier Deschacht','Silver - Rare','Normal',71,'SV Zulte-Waregem','Belgium Pro League','Belgium','CB','1981-02-16',37,54,45,60,75,69,0,0,0,0,0,0,'Left',2,2,70,65,65,64,64,68,60,53,53,53,51,51,51,51,51,52,250,10000
);
INSERT INTO PLAYER VALUES (1040,'Kippe','Frode Kippe','Silver - Rare','Normal',65,'Lillestrom SK','Eliteserien','Norway','CB','1978-01-17',25,36,52,49,61,73,0,0,0,0,0,0,'Left',3,2,64,51,51,48,48,59,51,41,41,45,45,45,45,41,41,51,250,10000
);
INSERT INTO PLAYER VALUES (1041,'Jonsson','Jon Jonsson','Bronze - Rare','Normal',64,'IF Elfsborg','Allsvenskan','Sweden','CB','1983-07-08',45,52,47,53,61,64,0,0,0,0,0,0,'Right',3,2,63,54,54,53,53,58,53,48,48,51,50,50,50,48,48,51,150,10000
);
INSERT INTO PLAYER VALUES (1042,'De Camargo','Igor de Camargo','Silver - Non-Rare','Normal',71,'KV Mechelen','Belgium Pro League','Belgium','ST','1983-05-12',43,67,71,63,50,77,0,0,0,0,0,0,'Right',4,3,59,54,54,55,55,59,65,64,64,67,68,68,68,64,64,70,150,10000
);
INSERT INTO PLAYER VALUES (1043,'Poulsen','Jakob Poulsen','Silver - Rare','Normal',71,'FC Midtjylland','Superliga','Denmark','CM','1983-07-07',48,67,70,72,61,70,0,0,0,0,0,0,'Right',3,3,63,63,63,65,65,67,70,67,67,68,66,66,66,66,66,65,250,10000
);
INSERT INTO PLAYER VALUES (1044,'Camara','Souleymane Camara','Silver - Non-Rare','Normal',68,'Montpellier Herault SC','Ligue 1 Conforama','Senegal','ST','1982-12-22',40,68,70,67,55,55,0,0,0,0,0,0,'Right',3,3,58,54,54,55,55,59,64,63,63,66,66,66,66,65,65,67,150,10000
);
INSERT INTO PLAYER VALUES (1045,'Storflor','oyvind Storflor','Bronze - Rare','Normal',63,'Ranheim Fotball','Eliteserien','Norway','RW','1979-12-18',57,63,59,68,34,55,0,0,0,0,0,0,'Right',5,2,44,46,46,49,49,49,60,63,63,63,63,63,63,63,63,62,150,10000
);
INSERT INTO PLAYER VALUES (1046,'Cavalli','Johan Cavalli','Silver - Non-Rare','Normal',68,'Athletic Club Ajaccio','Domino''s Ligue 2','France','CAM','1981-09-12',59,71,61,69,48,58,0,0,0,0,0,0,'Left',4,3,55,54,54,56,56,59,64,65,65,67,65,65,65,66,66,62,150,10000
);
INSERT INTO PLAYER VALUES (1047,'Bodmer','Mathieu Bodmer','Silver - Rare','Normal',68,'Amiens SC','Ligue 1 Conforama','France','CAM','1982-11-22',32,66,61,73,68,62,0,0,0,0,0,0,'Right',4,3,68,61,61,61,61,68,69,63,63,67,65,65,65,62,62,63,250,10000
);
INSERT INTO PLAYER VALUES (1048,'Cowie','Don Cowie','Bronze - Non-Rare','Normal',62,'Ross County','Scottish Premiership','Scotland','RM','1983-02-15',57,60,58,63,50,67,0,0,0,0,0,0,'Right',2,2,55,59,59,61,61,60,62,61,61,60,59,59,59,60,60,57,150,10000
);
INSERT INTO PLAYER VALUES (1049,'Opdal','Hakon Opdal','Silver - Non-Rare','Normal',65,'SK Brann','Eliteserien','Norway','GK','1982-06-11',0,0,0,0,0,0,62,66,63,42,64,64,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1050,'Balmont','Florent Balmont','Silver - Rare','Normal',69,'Dijon FCO','Ligue 1 Conforama','France','CM','1980-02-02',33,66,64,71,71,54,0,0,0,0,0,0,'Right',3,3,68,64,64,64,64,71,68,62,62,65,64,64,64,62,62,61,250,10000
);
INSERT INTO PLAYER VALUES (1051,'Brunt','Chris Brunt','Silver - Rare','Normal',70,'West Bromwich Albion','EFL Championship','Northern Ireland','CM','1984-12-14',50,67,70,75,66,66,0,0,0,0,0,0,'Left',2,3,66,65,65,66,66,68,69,67,67,68,67,67,67,67,67,67,250,10000
);
INSERT INTO PLAYER VALUES (1052,'Jakupovic','Eldin Jakupovic','Silver - Non-Rare','Normal',68,'Leicester City','Premier League','Switzerland','GK','1984-10-02',0,0,0,0,0,0,69,66,68,30,66,69,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1053,'Maric','Mijat Maric','Silver - Non-Rare','Normal',67,'FC Lugano','Raiffeisen Super League','Switzerland','CB','1984-04-30',32,47,54,49,68,73,0,0,0,0,0,0,'Right',4,2,66,59,59,57,57,62,54,47,47,48,49,49,49,46,46,53,150,10000
);
INSERT INTO PLAYER VALUES (1054,'Murphy','Joe Murphy','Bronze - Non-Rare','Normal',62,'Shrewsbury','EFL League One','Republic of Ireland','GK','1981-08-21',0,0,0,0,0,0,59,60,62,36,60,62,'Left',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1055,'Kulovits','Stefan Kulovits','Silver - Non-Rare','Normal',66,'SV Sandhausen','Bundesliga 2','Austria','CDM','1983-04-19',36,62,55,54,67,68,0,0,0,0,0,0,'Right',3,2,66,62,62,61,61,65,59,53,53,55,54,54,54,53,53,53,150,10000
);
INSERT INTO PLAYER VALUES (1056,'Gordon','Craig Gordon','Silver - Non-Rare','Normal',72,'Celtic','Scottish Premiership','Scotland','GK','1982-12-31',0,0,0,0,0,0,73,74,71,35,65,70,'Left',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1057,'Bulman','Dannie Bulman','Bronze - Rare','Normal',61,'Crawley Town','EFL League Two','England','CM','1979-01-24',46,58,44,56,58,75,0,0,0,0,0,0,'Right',3,2,62,58,58,59,59,63,60,55,55,55,53,53,53,52,52,52,150,10000
);
INSERT INTO PLAYER VALUES (1058,'Collin','Adam Collin','Bronze - Non-Rare','Normal',62,'Carlisle United','EFL League Two','England','GK','1984-12-09',0,0,0,0,0,0,63,65,58,31,56,61,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1059,'Bothroyd','Jay Bothroyd','Silver - Non-Rare','Normal',65,'Hokkaido Consadole Sapporo','Meiji Yasuda J1 League','England','ST','1982-05-07',32,59,66,61,28,69,0,0,0,0,0,0,'Left',2,3,44,39,39,41,41,45,55,57,57,59,61,61,61,58,58,64,150,10000
);
INSERT INTO PLAYER VALUES (1060,'Mcanuff','Jobi McAnuff','Bronze - Rare','Normal',64,'Leyton Orient','EFL League Two','Jamaica','LM','1981-11-09',58,66,58,63,45,56,0,0,0,0,0,0,'Right',3,3,51,54,54,56,56,55,61,63,63,64,63,63,63,64,64,60,150,10000
);
INSERT INTO PLAYER VALUES (1061,'Camp','Lee Camp','Silver - Non-Rare','Normal',67,'Birmingham City','EFL Championship','Northern Ireland','GK','1984-08-22',0,0,0,0,0,0,65,67,65,37,71,65,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1062,'Grant','Lee Grant','Silver - Non-Rare','Normal',72,'Manchester United','Premier League','England','GK','1983-01-27',0,0,0,0,0,0,73,72,70,50,73,71,'Right',4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1063,'Holmes','Lee Holmes','Bronze - Rare','Normal',64,'Exeter City','EFL League Two','England','RM','1987-04-02',72,63,56,61,35,59,0,0,0,0,0,0,'Left',2,3,42,49,49,53,53,49,58,63,63,61,60,60,60,63,63,57,150,10000
);
INSERT INTO PLAYER VALUES (1064,'Price','Lewis Price','Bronze - Non-Rare','Normal',62,'Rotherham United','EFL League One','Wales','GK','1984-07-19',0,0,0,0,0,0,61,60,61,37,57,61,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1065,'Bloomfield','Matt Bloomfield','Bronze - Non-Rare','Normal',63,'Wycombe Wanderers','EFL League One','England','CM','1984-02-08',66,61,50,59,61,67,0,0,0,0,0,0,'Right',4,2,62,63,63,63,63,63,62,61,61,60,59,59,59,59,59,57,150,10000
);
INSERT INTO PLAYER VALUES (1066,'Russell','Sam Russell','Bronze - Non-Rare','Normal',59,'Grimsby Town','EFL League Two','England','GK','1982-10-04',0,0,0,0,0,0,56,58,60,34,58,60,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1067,'Bywater','Stephen Bywater','Bronze - Rare','Normal',62,'Burton Albion','EFL League One','England','GK','1981-06-07',0,0,0,0,0,0,59,55,61,36,55,68,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1068,'Downing','Stewart Downing','Silver - Rare','Normal',69,'Blackburn Rovers','EFL Championship','England','RM','1984-07-22',62,70,68,73,40,54,0,0,0,0,0,0,'Left',3,3,47,53,53,56,56,55,66,68,68,70,69,69,69,69,69,67,250,10000
);
INSERT INTO PLAYER VALUES (1069,'Huddlestone','Tom Huddlestone','Silver - Rare','Normal',72,'Derby County','EFL Championship','England','CDM','1986-12-28',40,64,70,75,69,69,0,0,0,0,0,0,'Right',5,2,71,64,64,64,64,71,70,64,64,67,66,66,66,63,63,68,300,10000
);
INSERT INTO PLAYER VALUES (1070,'Berni','Tommaso Berni','Bronze - Rare','Normal',64,'Inter','Serie A TIM','Italy','GK','1983-03-06',0,0,0,0,0,0,64,66,60,29,59,64,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1071,'Routledge','Wayne Routledge','Silver - Non-Rare','Normal',70,'Swansea City','EFL Championship','England','RM','1985-01-07',67,73,64,67,40,54,0,0,0,0,0,0,'Right',2,3,47,54,54,57,57,55,65,69,69,69,68,68,68,69,69,64,150,10000
);
INSERT INTO PLAYER VALUES (1072,'Ratajczak','Michael Ratajczak','Bronze - Rare','Normal',63,'SC Paderborn 07','Bundesliga','Germany','GK','1982-04-16',0,0,0,0,0,0,62,64,64,43,35,64,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1073,'Haas','Daniel Haas','Bronze - Rare','Normal',64,'FC Erzgebirge Aue','Bundesliga 2','Germany','GK','1983-08-01',0,0,0,0,0,0,64,64,63,34,55,62,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1074,'Terzi','Claudio Terzi','Silver - Non-Rare','Normal',72,'La Spezia','Calcio B','Italy','CB','1984-06-19',51,53,41,45,71,77,0,0,0,0,0,0,'Right',3,2,71,64,64,62,62,65,53,48,48,46,47,47,47,46,46,49,150,10000
);
INSERT INTO PLAYER VALUES (1075,'Woodman','Craig Woodman','Bronze - Non-Rare','Normal',62,'Exeter City','EFL League Two','England','LB','1982-12-22',58,59,44,59,60,68,0,0,0,0,0,0,'Left',3,2,61,61,61,61,61,61,59,58,58,57,55,55,55,56,56,53,150,10000
);
INSERT INTO PLAYER VALUES (1076,'Stamatopoulos','Kyriakos Stamatopoulos','Bronze - Non-Rare','Normal',57,'AIK','Allsvenskan','Canada','GK','1979-08-28',0,0,0,0,0,0,57,56,52,32,54,57,'Left',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1077,'Burke','Chris Burke','Silver - Non-Rare','Normal',69,'Kilmarnock','Scottish Premiership','Scotland','RM','1983-12-02',72,71,65,64,39,65,0,0,0,0,0,0,'Right',4,3,47,53,53,56,56,53,62,68,68,67,67,67,67,68,68,64,150,10000
);
INSERT INTO PLAYER VALUES (1078,'Grindheim','Christian Grindheim','Silver - Non-Rare','Normal',67,'FK Haugesund','Eliteserien','Norway','CAM','1983-07-17',38,67,60,69,59,69,0,0,0,0,0,0,'Right',4,3,63,60,60,62,62,66,68,63,63,66,64,64,64,63,63,63,150,10000
);
INSERT INTO PLAYER VALUES (1079,'Braaten','Daniel Braaten','Silver - Rare','Normal',66,'Stabaek Fotball','Eliteserien','Norway','RM','1982-05-25',63,67,64,66,51,70,0,0,0,0,0,0,'Right',4,3,59,57,57,58,58,59,63,65,65,66,66,66,66,66,66,67,250,10000
);
INSERT INTO PLAYER VALUES (1080,'Roche','Barry Roche','Bronze - Rare','Normal',63,'Morecambe','EFL League Two','Republic of Ireland','GK','1982-04-06',0,0,0,0,0,0,59,63,65,22,62,68,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1081,'Gurski','Michael Gurski','Bronze - Non-Rare','Normal',59,'SpVgg Unterhaching','3. Liga','Germany','GK','1979-03-21',0,0,0,0,0,0,53,57,63,26,38,62,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1082,'Valdes','Jaime Valdes','Silver - Rare','Normal',70,'CD Vinazur','Campeonato Scotiabank','Chile','CM','1981-01-11',59,73,69,75,48,54,0,0,0,0,0,0,'Right',4,3,53,55,55,57,57,61,69,69,69,72,70,70,70,70,70,66,250,10000
);
INSERT INTO PLAYER VALUES (1083,'Brozek','PaweL Brozek','Silver - Non-Rare','Normal',65,'WisLa Krakow','Ekstraklasa','Poland','ST','1983-04-21',34,63,66,60,29,63,0,0,0,0,0,0,'Right',4,2,44,40,40,42,42,46,57,58,58,62,62,62,62,60,60,64,150,10000
);
INSERT INTO PLAYER VALUES (1084,'Pegolo','Gianluca Pegolo','Silver - Non-Rare','Normal',70,'Sassuolo','Serie A TIM','Italy','GK','1981-03-25',0,0,0,0,0,0,70,70,68,43,60,70,'Left',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1085,'Langer','Michael Langer','Silver - Non-Rare','Normal',65,'FC Schalke 04','Bundesliga','Austria','GK','1985-01-06',0,0,0,0,0,0,64,65,62,31,60,67,'Right',1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1086,'Ziegler','Reto Ziegler','Silver - Rare','Normal',70,'FC Dallas','Major League Soccer','Switzerland','CB','1986-01-16',59,66,63,72,70,71,0,0,0,0,0,0,'Left',3,2,69,68,68,69,69,70,69,67,67,67,66,66,66,65,65,65,250,10000
);
INSERT INTO PLAYER VALUES (1087,'Grunwald','Pascal Grunwald','Bronze - Non-Rare','Normal',63,'WSG Tirol','osterreichische Fubball-Bundesliga','Austria','GK','1982-11-13',0,0,0,0,0,0,62,61,63,36,65,63,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1088,'Castro','Bram Castro','Silver - Rare','Normal',69,'KV Mechelen','Belgium Pro League','Belgium','GK','1982-09-30',0,0,0,0,0,0,69,68,69,36,50,75,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,250,10000
);
INSERT INTO PLAYER VALUES (1089,'Mannus','Alan Mannus','Silver - Non-Rare','Normal',66,'Shamrock Rovers','SSE Airtricity League','Northern Ireland','GK','1982-05-19',0,0,0,0,0,0,63,64,68,39,62,66,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1090,'Xisco Campos','Francisco Campos Coll','Silver - Non-Rare','Normal',68,'RCD Mallorca','LaLiga Santander','Spain','CB','1982-03-10',55,49,37,54,67,64,0,0,0,0,0,0,'Right',3,2,67,62,62,60,60,62,52,49,49,48,47,47,47,48,48,48,150,10000
);
INSERT INTO PLAYER VALUES (1091,'Mario alvarez','Pedro Mario alvarez Abrante','Silver - Non-Rare','Normal',73,'Atletico de San Luis','LIGA Bancomer MX','Spain','CB','1982-02-02',61,52,42,54,72,72,0,0,0,0,0,0,'Left',3,2,72,66,66,63,63,67,57,50,50,51,49,49,49,49,49,49,150,10000
);
INSERT INTO PLAYER VALUES (1092,'Mccormick','Luke McCormick','Bronze - Non-Rare','Normal',62,'Swindon Town','EFL League Two','England','GK','1983-08-15',0,0,0,0,0,0,58,57,59,37,62,62,'Right',4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1093,'Feeney','Liam Feeney','Silver - Non-Rare','Normal',65,'Blackpool','EFL League One','England','LM','1987-01-21',75,66,57,61,41,65,0,0,0,0,0,0,'Right',3,3,49,55,55,57,57,53,60,64,64,63,62,62,62,64,64,60,150,10000
);
INSERT INTO PLAYER VALUES (1094,'Pinilla','Mauricio Pinilla','Silver - Rare','Normal',73,'Coquimbo Unido','Campeonato Scotiabank','Chile','ST','1984-02-04',55,64,74,55,32,76,0,0,0,0,0,0,'Right',3,3,49,44,44,46,46,48,58,61,61,63,67,67,67,63,63,72,300,10000
);
INSERT INTO PLAYER VALUES (1095,'Nino','Juan Francisco Martinez Modesto','Silver - Rare','Normal',70,'Elche CF','LaLiga 1 I 2 I 3','Spain','CF','1980-06-10',58,70,72,63,46,55,0,0,0,0,0,0,'Right',4,3,53,53,53,55,55,55,63,66,66,69,70,70,70,69,69,69,250,10000
);
INSERT INTO PLAYER VALUES (1096,'Wolfli','Marco Wolfli','Silver - Non-Rare','Normal',67,'BSC Young Boys','Raiffeisen Super League','Switzerland','GK','1982-08-22',0,0,0,0,0,0,69,65,60,39,71,67,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1097,'Martin','David Martin','Silver - Non-Rare','Normal',66,'West Ham United','Premier League','England','GK','1986-01-22',0,0,0,0,0,0,66,65,62,40,66,66,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1098,'Miller','Lee Miller','Bronze - Rare','Normal',64,'Livingston FC','Scottish Premiership','Scotland','ST','1983-05-18',49,60,64,61,43,76,0,0,0,0,0,0,'Right',3,2,55,52,52,53,53,55,60,60,60,61,61,61,61,60,60,63,150,10000
);
INSERT INTO PLAYER VALUES (1099,'Henderson','Ian Henderson','Silver - Non-Rare','Normal',67,'Rochdale','EFL League One','England','ST','1985-01-24',61,70,68,63,35,69,0,0,0,0,0,0,'Right',3,3,47,50,50,53,53,53,64,67,67,68,68,68,68,67,67,66,150,10000
);
INSERT INTO PLAYER VALUES (1100,'Gori','Pier Graziano Gori','Bronze - Rare','Normal',62,'Benevento','Calcio B','Italy','GK','1980-05-10',0,0,0,0,0,0,56,59,58,35,64,67,'Right',1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1101,'Dawson','Michael Dawson','Silver - Non-Rare','Normal',70,'Nottingham Forest','EFL Championship','England','CB','1983-11-18',30,39,33,44,71,64,0,0,0,0,0,0,'Right',3,2,69,56,56,51,51,63,51,39,39,43,42,42,42,37,37,45,150,10000
);
INSERT INTO PLAYER VALUES (1102,'Walke','Alexander Walke','Silver - Rare','Normal',73,'FC Red Bull Salzburg','osterreichische Fubball-Bundesliga','Germany','GK','1983-06-06',0,0,0,0,0,0,73,76,71,36,75,69,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (1103,'Rensing','Michael Rensing','Silver - Non-Rare','Normal',72,'Fortuna Dusseldorf','Bundesliga','Germany','GK','1984-05-14',0,0,0,0,0,0,72,72,71,41,64,72,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1104,'Konig','Ronny Konig','Silver - Rare','Normal',65,'FSV Zwickau','3. Liga','Germany','ST','1983-06-02',30,48,68,48,37,73,0,0,0,0,0,0,'Left',4,2,48,41,41,41,41,46,52,51,51,54,57,57,57,52,52,64,250,10000
);
INSERT INTO PLAYER VALUES (1105,'Whittaker','Steven Whittaker','Silver - Rare','Normal',66,'Hibernian','Scottish Premiership','Scotland','RB','1984-06-16',57,65,62,65,65,72,0,0,0,0,0,0,'Right',4,2,66,65,65,66,66,66,66,65,65,64,64,64,64,64,64,64,250,10000
);
INSERT INTO PLAYER VALUES (1106,'Heerwagen','Philipp Heerwagen','Bronze - Non-Rare','Normal',63,'SV Sandhausen','Bundesliga 2','Germany','GK','1983-04-13',0,0,0,0,0,0,64,63,62,34,54,63,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1107,'Kone','Arouna Kone','Silver - Rare','Normal',73,'Sivasspor','Super Lig','Cote d''Ivoire','ST','1983-11-11',65,71,74,62,37,69,0,0,0,0,0,0,'Right',4,3,49,52,52,54,54,52,64,68,68,69,71,71,71,69,69,72,300,10000
);
INSERT INTO PLAYER VALUES (1108,'Agazzi','Michael Agazzi','Silver - Non-Rare','Normal',69,'Cremona','Calcio B','Italy','GK','1984-07-03',0,0,0,0,0,0,71,70,63,42,69,66,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1109,'Campagnaro','Hugo Campagnaro','Silver - Non-Rare','Normal',70,'Pescara','Calcio B','Argentina','CB','1980-06-27',36,52,39,52,70,69,0,0,0,0,0,0,'Right',3,2,69,59,59,57,57,62,51,47,47,47,46,46,46,46,46,49,150,10000
);
INSERT INTO PLAYER VALUES (1110,'Turan','Ali Turan','Silver - Non-Rare','Normal',71,'Atiker Konyaspor','Super Lig','Turkey','CB','1983-09-06',32,55,37,56,72,64,0,0,0,0,0,0,'Right',3,2,70,60,60,59,59,65,56,50,50,50,49,49,49,48,48,49,150,10000
);
INSERT INTO PLAYER VALUES (1111,'cek','ozgur cek','Silver - Rare','Normal',70,'Kasimpasa SK','Super Lig','Turkey','LB','1991-01-03',77,72,64,70,64,66,0,0,0,0,0,0,'Left',2,3,65,69,69,70,70,68,70,71,71,70,69,69,69,70,70,67,250,10000
);
INSERT INTO PLAYER VALUES (1112,'Inan','Selcuk Inan','Silver - Rare','Normal',73,'Galatasaray SK','Super Lig','Turkey','CM','1985-02-10',48,71,71,77,64,62,0,0,0,0,0,0,'Right',3,3,64,64,64,66,66,69,72,69,69,71,69,69,69,69,69,67,300,10000
);
INSERT INTO PLAYER VALUES (1113,'Gulum','Ersan Gulum','Silver - Rare','Normal',66,'Western United FC','Hyundai A-League','Turkey','CB','1987-05-17',57,55,51,53,62,82,0,0,0,0,0,0,'Left',2,2,65,61,61,61,61,63,57,55,55,53,53,53,53,53,53,55,250,10000
);
INSERT INTO PLAYER VALUES (1114,'Arikan','Hakan Arikan','Silver - Non-Rare','Normal',70,'Kayserispor','Super Lig','Turkey','GK','1982-08-17',0,0,0,0,0,0,74,74,60,44,62,72,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1115,'Bulut','Umut Bulut','Silver - Rare','Normal',70,'Kayserispor','Super Lig','Turkey','ST','1983-03-15',54,60,72,56,41,69,0,0,0,0,0,0,'Right',3,3,51,50,50,52,52,52,59,62,62,62,66,66,66,63,63,69,250,10000
);
INSERT INTO PLAYER VALUES (1116,'Durak','Abdullah Durak','Silver - Non-Rare','Normal',67,'caykur Rizespor','Super Lig','Turkey','CDM','1987-04-01',68,68,61,64,62,66,0,0,0,0,0,0,'Right',3,3,63,65,65,65,65,66,67,66,66,67,66,66,66,66,66,64,150,10000
);
INSERT INTO PLAYER VALUES (1117,'Ceylan','Ufuk Ceylan','Silver - Rare','Normal',68,'Evkur Yeni Malatyaspor','Super Lig','Turkey','GK','1986-06-23',0,0,0,0,0,0,69,67,69,55,63,69,'Left',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,250,10000
);
INSERT INTO PLAYER VALUES (1118,'Lindegaard','Anders Lindegaard','Silver - Non-Rare','Normal',68,'Helsingborgs IF','Allsvenskan','Denmark','GK','1984-04-13',0,0,0,0,0,0,69,68,70,49,69,65,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1119,'Liendl','Michael Liendl','Silver - Rare','Normal',71,'Wolfsberger AC','osterreichische Fubball-Bundesliga','Austria','CM','1985-10-25',53,70,70,73,52,63,0,0,0,0,0,0,'Left',3,3,57,60,60,62,62,64,70,68,68,70,68,68,68,68,68,65,250,10000
);
INSERT INTO PLAYER VALUES (1120,'Maenpaa','Niki Maenpaa','Silver - Non-Rare','Normal',69,'Bristol City','EFL Championship','Finland','GK','1985-01-23',0,0,0,0,0,0,70,66,69,36,65,66,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1121,'Walthert','Laurent Walthert','Bronze - Rare','Normal',64,'Neuchatel Xamax','Raiffeisen Super League','Switzerland','GK','1984-03-30',0,0,0,0,0,0,67,66,61,44,62,65,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1122,'Jung Jo Gook','Jo Gook Jung','Silver - Non-Rare','Normal',68,'Gangwon FC','K LEAGUE Classic','Korea Republic','ST','1984-04-23',59,61,68,58,33,66,0,0,0,0,0,0,'Right',3,2,45,45,45,47,47,47,56,61,61,61,64,64,64,62,62,67,150,10000
);
INSERT INTO PLAYER VALUES (1123,'Lee Dong Gook','Dong Gook Lee','Silver - Rare','Normal',68,'Jeonbuk Hyundai Motors','K LEAGUE Classic','Korea Republic','ST','1979-04-29',44,58,73,62,29,62,0,0,0,0,0,0,'Right',4,2,43,41,41,43,43,45,57,59,59,62,64,64,64,61,61,67,250,10000
);
INSERT INTO PLAYER VALUES (1124,'Jimenez','Luis Jimenez','Silver - Rare','Normal',73,'Al Ittihad','Saudi Professional League','Chile','CAM','1984-06-17',64,73,63,77,42,63,0,0,0,0,0,0,'Right',4,3,52,55,55,59,59,60,69,70,70,72,69,69,69,70,70,65,300,10000
);
INSERT INTO PLAYER VALUES (1125,'Clark','Ricardo Clark','Silver - Non-Rare','Normal',67,'Columbus Crew SC','Major League Soccer','United States','CDM','1983-02-10',61,63,62,61,64,72,0,0,0,0,0,0,'Right',3,2,66,63,63,63,63,66,64,62,62,63,63,63,63,61,61,64,150,10000
);
INSERT INTO PLAYER VALUES (1126,'Farelli','Simone Farelli','Bronze - Non-Rare','Normal',58,'Pescara','Calcio B','Italy','GK','1983-02-19',0,0,0,0,0,0,63,58,57,41,56,55,'Right',1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1127,'Lepoint','Christophe Lepoint','Silver - Rare','Normal',68,'KV Kortrijk','Belgium Pro League','Belgium','CB','1984-10-24',36,58,66,62,67,81,0,0,0,0,0,0,'Right',3,2,67,62,62,62,62,68,66,61,61,62,63,63,63,59,59,65,250,10000
);
INSERT INTO PLAYER VALUES (1128,'Pazzini','Giampaolo Pazzini','Silver - Non-Rare','Normal',72,'Hellas Verona','Serie A TIM','Italy','ST','1984-08-02',56,69,68,56,34,65,0,0,0,0,0,0,'Right',3,3,47,45,45,47,47,47,57,63,63,65,68,68,68,65,65,71,150,10000
);
INSERT INTO PLAYER VALUES (1129,'Gastaldello','Daniele Gastaldello','Silver - Non-Rare','Normal',70,'Brescia','Serie A TIM','Italy','CB','1983-06-25',35,54,40,50,70,64,0,0,0,0,0,0,'Right',3,2,69,57,57,55,55,64,55,47,47,50,48,48,48,46,46,49,750,14000
);
INSERT INTO PLAYER VALUES (1130,'Rosina','Alessandro Rosina','Silver - Rare','Normal',72,'Salerno','Calcio B','Italy','RW','1984-01-31',69,76,70,73,23,46,0,0,0,0,0,0,'Left',3,4,35,47,47,52,52,49,68,72,72,73,72,72,72,72,72,67,300,10000
);
INSERT INTO PLAYER VALUES (1131,'Gjasula','Jurgen Gjasula','Silver - Non-Rare','Normal',67,'1. FC Magdeburg','3. Liga','Albania','CM','1985-12-05',54,67,65,69,53,69,0,0,0,0,0,0,'Right',3,3,57,57,57,59,59,61,66,65,65,66,65,65,65,65,65,64,150,10000
);
INSERT INTO PLAYER VALUES (1132,'Pandev','Goran Pandev','Silver - Rare','Normal',73,'Genoa','Serie A TIM','FYR Macedonia','ST','1983-07-27',49,78,73,71,37,53,0,0,0,0,0,0,'Left',3,3,48,50,50,53,53,54,68,70,70,73,73,73,73,72,72,72,300,10000
);
INSERT INTO PLAYER VALUES (1133,'Maietta','Domenico Maietta','Silver - Rare','Normal',72,'Empoli','Calcio B','Italy','CB','1982-08-03',32,46,16,39,73,67,0,0,0,0,0,0,'Right',2,2,71,59,59,56,56,63,47,39,39,38,36,36,36,36,36,37,300,10000
);
INSERT INTO PLAYER VALUES (1134,'Hunt','Nicky Hunt','Bronze - Rare','Normal',55,'Crewe Alexandra','EFL League Two','England','RB','1983-09-03',35,51,44,50,57,74,0,0,0,0,0,0,'Right',2,2,59,54,54,54,54,56,50,49,49,47,47,47,47,47,47,49,150,10000
);
INSERT INTO PLAYER VALUES (1135,'Bruno Alves','Bruno Eduardo Regufe Alves','Silver - Rare','Normal',73,'Parma','Serie A TIM','Portugal','CB','1981-11-27',37,64,67,64,71,81,0,0,0,0,0,0,'Right',3,3,72,63,63,63,63,68,63,59,59,60,60,60,60,59,59,63,300,10000
);
INSERT INTO PLAYER VALUES (1136,'Potter','Darren Potter','Bronze - Rare','Normal',64,'Tranmere Rovers','EFL League One','Republic of Ireland','CDM','1984-12-21',50,60,53,60,61,70,0,0,0,0,0,0,'Right',3,2,63,60,60,60,60,63,61,58,58,59,58,58,58,57,57,58,150,10000
);
INSERT INTO PLAYER VALUES (1137,'Stuhr-Ellegaard','Kevin Stuhr-Ellegaard','Silver - Rare','Normal',69,'IF Elfsborg','Allsvenskan','Denmark','GK','1983-05-23',0,0,0,0,0,0,66,65,71,37,68,69,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,250,10000
);
INSERT INTO PLAYER VALUES (1138,'Foster','Richard Foster','Bronze - Rare','Normal',64,'St. Johnstone FC','Scottish Premiership','Scotland','RB','1985-07-31',78,63,25,58,60,73,0,0,0,0,0,0,'Right',3,2,63,63,63,63,63,61,55,57,57,53,50,50,50,53,53,46,150,10000
);
INSERT INTO PLAYER VALUES (1139,'O''Grady','Chris O''Grady','Bronze - Rare','Normal',61,'Oldham Athletic','EFL League Two','England','ST','1986-01-25',51,49,61,45,36,81,0,0,0,0,0,0,'Right',3,2,49,42,42,43,43,46,50,51,51,52,55,55,55,52,52,60,150,10000
);
INSERT INTO PLAYER VALUES (1140,'Jones','Billy Jones','Silver - Non-Rare','Normal',67,'Rotherham United','EFL League One','England','RB','1987-03-24',56,65,55,59,69,70,0,0,0,0,0,0,'Right',3,3,68,66,66,66,66,67,62,60,60,59,58,58,58,59,59,58,150,10000
);
INSERT INTO PLAYER VALUES (1141,'Lux','German Lux','Silver - Rare','Normal',71,'Nunez','SAF','Argentina','GK','1982-06-07',0,0,0,0,0,0,69,71,71,33,74,70,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,250,10000
);
INSERT INTO PLAYER VALUES (1142,'Brill','Dean Brill','Bronze - Non-Rare','Normal',62,'Leyton Orient','EFL League Two','England','GK','1985-12-02',0,0,0,0,0,0,61,60,63,33,58,61,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1143,'Lewington','Dean Lewington','Bronze - Rare','Normal',64,'Milton Keynes Dons','EFL League One','England','LWB','1984-05-18',45,59,34,63,64,76,0,0,0,0,0,0,'Left',3,2,65,63,63,63,63,65,61,57,57,56,53,53,53,54,54,50,150,10000
);
INSERT INTO PLAYER VALUES (1144,'Moscardelli','Davide Moscardelli','Silver - Rare','Normal',70,'Pisa','Calcio B','Italy','CF','1980-02-03',42,76,72,66,37,64,0,0,0,0,0,0,'Left',4,4,50,48,48,50,50,51,63,65,65,69,70,70,70,68,68,70,250,10000
);
INSERT INTO PLAYER VALUES (1145,'Vitiello','Roberto Vitiello','Silver - Non-Rare','Normal',65,'Juve Stabia','Calcio B','Italy','CB','1983-05-08',58,51,44,50,65,57,0,0,0,0,0,0,'Right',3,2,64,59,59,57,57,59,51,50,50,50,50,50,50,50,50,51,150,10000
);
INSERT INTO PLAYER VALUES (1146,'Michel','Luis Michel','Silver - Non-Rare','Normal',66,'Club Tijuana','LIGA Bancomer MX','Mexico','GK','1979-07-21',0,0,0,0,0,0,64,63,66,51,66,63,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1147,'Salcido','Carlos Salcido','Silver - Rare','Normal',68,'Tiburones Rojos de Veracruz','LIGA Bancomer MX','Mexico','CB','1980-04-02',33,62,56,66,66,74,0,0,0,0,0,0,'Right',3,2,67,62,62,62,62,67,64,59,59,60,58,58,58,58,58,58,250,10000
);
INSERT INTO PLAYER VALUES (1148,'Lopar','Daniel Lopar','Bronze - Non-Rare','Normal',63,'Western Sydney Wanderers','Hyundai A-League','Switzerland','GK','1985-04-19',0,0,0,0,0,0,64,60,63,40,60,62,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1149,'Cesar','BoStjan Cesar','Silver - Rare','Normal',71,'Chievo Verona','Calcio B','Slovenia','CB','1982-07-09',32,53,27,39,71,71,0,0,0,0,0,0,'Left',3,2,70,57,57,54,54,62,49,41,41,42,42,42,42,39,39,43,250,10000
);
INSERT INTO PLAYER VALUES (1150,'Nugent','David Nugent','Silver - Non-Rare','Normal',68,'Preston North End','EFL Championship','England','ST','1985-05-02',56,69,68,58,35,61,0,0,0,0,0,0,'Right',3,3,45,47,47,49,49,48,60,63,63,65,66,66,66,65,65,67,150,10000
);
INSERT INTO PLAYER VALUES (1151,'Fuchs','Christian Fuchs','Silver - Rare','Normal',73,'Leicester City','Premier League','Austria','LB','1986-04-07',49,70,67,76,75,68,0,0,0,0,0,0,'Left',2,3,75,72,72,72,72,74,72,68,68,69,68,68,68,68,68,68,300,10000
);
INSERT INTO PLAYER VALUES (1152,'Shackell','Jason Shackell','Silver - Non-Rare','Normal',69,'Lincoln City','EFL League One','England','CB','1983-09-27',42,57,39,53,69,73,0,0,0,0,0,0,'Left',3,2,68,61,61,60,60,65,55,50,50,50,49,49,49,48,48,51,150,10000
);
INSERT INTO PLAYER VALUES (1153,'Harrold','Matt Harrold','Bronze - Non-Rare','Normal',60,'Leyton Orient','EFL League Two','England','ST','1984-07-25',55,55,59,48,27,73,0,0,0,0,0,0,'Right',2,2,43,41,41,43,43,43,50,54,54,55,57,57,57,55,55,59,150,10000
);
INSERT INTO PLAYER VALUES (1154,'Gerken','Dean Gerken','Silver - Non-Rare','Normal',67,'Colchester United','EFL League Two','England','GK','1985-05-22',0,0,0,0,0,0,68,68,66,48,65,65,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1155,'Marchetti','Federico Marchetti','Silver - Rare','Normal',73,'Genoa','Serie A TIM','Italy','GK','1983-02-07',0,0,0,0,0,0,72,73,72,53,65,73,'Left',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (1156,'Smith','Eric Smith','Silver - Rare','Normal',65,'KAA Gent','Belgium Pro League','Sweden','CDM','1997-01-08',64,62,56,61,57,74,0,0,0,0,0,0,'Right',3,2,60,58,58,59,59,64,64,60,60,62,60,60,60,59,59,59,250,10000
);
INSERT INTO PLAYER VALUES (1157,'Arce','Fernando Arce','Bronze - Rare','Normal',61,'Club Tijuana','LIGA Bancomer MX','United States','CM','1996-11-27',62,59,53,59,58,73,0,0,0,0,0,0,'Right',3,2,62,59,59,58,58,61,60,58,58,59,58,58,58,57,57,59,150,10000
);
INSERT INTO PLAYER VALUES (1158,'Chavez','Luis Chavez','Silver - Non-Rare','Normal',65,'Pachuca','LIGA Bancomer MX','Mexico','CM','1996-01-15',71,68,61,66,58,50,0,0,0,0,0,0,'Left',2,3,57,63,63,64,64,61,64,66,66,65,64,64,64,66,66,62,150,10000
);
INSERT INTO PLAYER VALUES (1159,'Slivka','Vykintas Slivka','Silver - Non-Rare','Normal',65,'Hibernian','Scottish Premiership','Lithuania','CM','1995-04-29',52,68,57,64,59,67,0,0,0,0,0,0,'Right',3,3,60,59,59,60,60,63,64,62,62,63,60,60,60,60,60,60,150,10000
);
INSERT INTO PLAYER VALUES (1160,'Haikin','Nikita Haikin','Bronze - Non-Rare','Normal',57,'FK Bodo/Glimt','Eliteserien','Russia','GK','1995-07-11',0,0,0,0,0,0,64,61,51,42,60,52,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1161,'Minala','Joseph Minala','Silver - Non-Rare','Normal',69,'Lazio','Serie A TIM','Cameroon','CM','1996-08-24',59,68,63,64,63,71,0,0,0,0,0,0,'Right',3,3,65,63,63,64,64,68,68,65,65,67,66,66,66,64,64,65,150,10000
);
INSERT INTO PLAYER VALUES (1162,'Bnou-Marzouk','Younes Bnou-Marzouk','Silver - Non-Rare','Normal',66,'FC Lugano','Raiffeisen Super League','Morocco','ST','1996-03-02',71,65,65,45,25,58,0,0,0,0,0,0,'Right',3,3,36,40,40,42,42,38,51,59,59,59,63,63,63,61,61,65,150,10000
);
INSERT INTO PLAYER VALUES (1163,'Ball','Dominic Ball','Silver - Non-Rare','Normal',65,'Queens Park Rangers','EFL Championship','England','CDM','1995-08-02',60,58,41,55,65,70,0,0,0,0,0,0,'Right',2,2,65,63,63,62,62,64,60,57,57,57,55,55,55,55,55,54,150,10000
);
INSERT INTO PLAYER VALUES (1164,'Ogilvie','Connor Ogilvie','Bronze - Rare','Normal',64,'Gillingham','EFL League One','England','CB','1996-02-14',67,61,36,57,64,66,0,0,0,0,0,0,'Left',2,2,63,63,63,63,63,61,58,59,59,56,55,55,55,56,56,53,150,10000
);
INSERT INTO PLAYER VALUES (1165,'Kinsella','Liam Kinsella','Silver - Non-Rare','Normal',65,'Walsall','EFL League Two','Republic of Ireland','CM','1996-02-23',74,65,53,61,65,77,0,0,0,0,0,0,'Right',3,2,66,67,67,67,67,67,64,64,64,62,61,61,61,62,62,59,150,10000
);
INSERT INTO PLAYER VALUES (1166,'Veendorp','Keziah Veendorp','Silver - Non-Rare','Normal',67,'FC Emmen','Eredivisie','Holland','CB','1997-02-17',67,57,49,56,65,70,0,0,0,0,0,0,'Right',4,2,66,62,62,60,60,65,59,54,54,56,53,53,53,52,52,54,150,10000
);
INSERT INTO PLAYER VALUES (1167,'Prior','Jerome Prior','Silver - Non-Rare','Normal',66,'Valenciennes FC','Domino''s Ligue 2','France','GK','1995-08-08',0,0,0,0,0,0,66,65,65,51,67,65,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1168,'Ham','Ezequiel Ham','Bronze - Non-Rare','Normal',61,'Argentinos Juniors','SAF','Argentina','CM','1994-03-10',70,62,53,59,54,67,0,0,0,0,0,0,'Right',3,2,58,58,58,59,59,60,60,60,60,59,58,58,58,59,59,58,150,10000
);
INSERT INTO PLAYER VALUES (1169,'Jakubiak','Alex Jakubiak','Bronze - Non-Rare','Normal',58,'Gillingham','EFL League One','Scotland','ST','1996-08-27',73,61,57,45,25,53,0,0,0,0,0,0,'Right',3,2,36,41,41,43,43,40,50,55,55,56,57,57,57,57,57,57,150,10000
);
INSERT INTO PLAYER VALUES (1170,'Komar','Juan Komar','Silver - Rare','Normal',72,'Club Atletico Talleres','SAF','Argentina','CB','1996-08-13',54,46,33,49,73,77,0,0,0,0,0,0,'Right',2,2,71,64,64,62,62,67,56,48,48,48,46,46,46,44,44,49,300,10000
);
INSERT INTO PLAYER VALUES (1171,'Viafara','Fabian Viafara','Silver - Rare','Normal',66,'Deportivo Pasto','Liga Dimayor','Colombia','RB','1992-03-16',86,67,52,52,59,54,0,0,0,0,0,0,'Right',3,3,58,65,65,66,66,59,58,62,62,59,59,59,59,62,62,56,250,10000
);
INSERT INTO PLAYER VALUES (1172,'Feng Gang','Gang Feng','Bronze - Rare','Normal',58,'Hebei China Fortune FC','CSL','China PR','CM','1993-03-06',82,62,46,57,55,49,0,0,0,0,0,0,'Right',3,2,54,59,59,60,60,57,57,59,59,58,57,57,57,59,59,53,150,10000
);
INSERT INTO PLAYER VALUES (1173,'Zhao Yuhao','Yuhao Zhao','Silver - Non-Rare','Normal',65,'Hebei China Fortune FC','CSL','China PR','CDM','1993-04-07',63,55,38,52,64,71,0,0,0,0,0,0,'Right',2,2,64,62,62,61,61,64,59,55,55,55,53,53,53,52,52,52,150,10000
);
INSERT INTO PLAYER VALUES (1174,'Zou Dehai','Dehai Zou','Bronze - Non-Rare','Normal',60,'Beijing Guoan','CSL','China PR','GK','1993-02-27',0,0,0,0,0,0,59,62,61,46,54,59,'Right',1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1175,'Mensah','Bernard Mensah','Silver - Rare','Normal',73,'Kayserispor','Super Lig','Ghana','CAM','1994-10-17',79,75,69,70,63,65,0,0,0,0,0,0,'Right',3,4,64,64,64,66,66,67,70,71,71,72,72,72,72,72,72,71,300,10000
);
INSERT INTO PLAYER VALUES (1176,'Rochinha','Diogo Filipe Rocha Costa','Silver - Non-Rare','Normal',70,'Vitoria Guimaraes','Liga NOS','Portugal','RM','1995-05-03',78,72,63,64,40,48,0,0,0,0,0,0,'Right',3,4,44,54,54,57,57,53,64,69,69,69,68,68,68,70,70,63,150,10000
);
INSERT INTO PLAYER VALUES (1177,'Khan','Otis Khan','Bronze - Rare','Normal',64,'Mansfield Town','EFL League Two','England','CAM','1996-09-05',78,65,60,60,38,55,0,0,0,0,0,0,'Right',3,3,43,50,50,53,53,49,58,64,64,63,62,62,62,64,64,61,150,10000
);
INSERT INTO PLAYER VALUES (1178,'Sivera','Antonio Sivera Salva','Silver - Rare','Normal',73,'D. Alaves','LaLiga Santander','Spain','GK','1996-08-11',0,0,0,0,0,0,73,74,71,57,68,75,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (1179,'Jose Carlos','Jose Carlos Ramirez Suarez','Silver - Non-Rare','Normal',65,'CD Lugo','LaLiga 1 I 2 I 3','Spain','CB','1996-05-10',41,54,26,51,64,65,0,0,0,0,0,0,'Left',3,2,64,60,60,60,60,63,53,49,49,45,44,44,44,44,44,44,150,10000
);
INSERT INTO PLAYER VALUES (1180,'Rasheed','Jonathan Rasheed','Bronze - Non-Rare','Normal',59,'BK Hacken','Allsvenskan','Norway','GK','1991-11-21',0,0,0,0,0,0,61,60,56,30,58,57,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1181,'Granli','Daniel Granli','Bronze - Non-Rare','Normal',63,'AIK','Allsvenskan','Norway','CB','1994-05-01',64,58,48,57,62,68,0,0,0,0,0,0,'Right',3,2,62,62,62,62,62,61,58,58,58,56,55,55,55,56,56,55,150,10000
);
INSERT INTO PLAYER VALUES (1182,'Thorsby','Morten Thorsby','Silver - Non-Rare','Normal',70,'Sampdoria','Serie A TIM','Norway','CM','1996-05-05',64,65,59,65,69,79,0,0,0,0,0,0,'Right',3,2,71,69,69,69,69,70,69,67,67,66,66,66,66,65,65,67,150,10000
);
INSERT INTO PLAYER VALUES (1183,'Reed','Louis Reed','Silver - Non-Rare','Normal',65,'Peterborough United','EFL League One','England','CM','1997-07-25',67,67,50,62,59,67,0,0,0,0,0,0,'Right',3,3,61,61,61,61,61,64,64,62,62,63,61,61,61,61,61,57,150,10000
);
INSERT INTO PLAYER VALUES (1184,'Mesenholer','Daniel Mesenholer','Silver - Non-Rare','Normal',66,'Viktoria Koln','3. Liga','Germany','GK','1995-07-24',0,0,0,0,0,0,67,65,69,49,57,62,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1185,'Friedrich','Marvin Friedrich','Silver - Rare','Normal',73,'1. FC Union Berlin','Bundesliga','Germany','CB','1995-12-13',61,50,36,56,74,70,0,0,0,0,0,0,'Right',3,2,72,66,66,64,64,68,58,52,52,52,49,49,49,49,49,50,300,10000
);
INSERT INTO PLAYER VALUES (1186,'Isted','Harry Isted','Bronze - Non-Rare','Normal',57,'Luton Town','EFL Championship','England','GK','1997-03-05',0,0,0,0,0,0,61,60,55,35,56,53,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1187,'David','Florian David','Silver - Non-Rare','Normal',65,'FC Chambly Oise','Domino''s Ligue 2','France','CAM','1992-11-16',72,64,64,62,48,67,0,0,0,0,0,0,'Right',3,3,55,57,57,58,58,58,63,64,64,64,65,65,65,64,64,64,150,10000
);
INSERT INTO PLAYER VALUES (1188,'Pomazun','Ilya Pomazun','Bronze - Rare','Normal',63,'CSKA Moscow','League of Russia','Russia','GK','1996-08-16',0,0,0,0,0,0,62,66,64,39,68,60,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1189,'Unsain','Ezequiel Unsain','Silver - Rare','Normal',73,'Defensa y Justicia','SAF','Argentina','GK','1995-03-09',0,0,0,0,0,0,79,79,65,54,77,66,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,300,10000
);
INSERT INTO PLAYER VALUES (1190,'Aarons','Rolando Aarons','Silver - Non-Rare','Normal',70,'Newcastle United','Premier League','England','LM','1995-11-16',78,74,62,66,39,46,0,0,0,0,0,0,'Left',3,3,44,54,54,57,57,52,62,69,69,67,67,67,67,69,69,64,150,10000
);
INSERT INTO PLAYER VALUES (1191,'Woodman','Freddie Woodman','Silver - Non-Rare','Normal',67,'Swansea City','EFL Championship','England','GK','1997-03-04',0,0,0,0,0,0,66,68,64,45,59,66,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1192,'Stolas','Alexander Stolas','Bronze - Rare','Normal',64,'FK Haugesund','Eliteserien','Norway','LB','1989-04-30',70,67,68,66,57,69,0,0,0,0,0,0,'Left',2,3,60,63,63,64,64,62,64,66,66,65,66,66,66,66,66,65,150,10000
);
INSERT INTO PLAYER VALUES (1193,'Husing','Oliver Husing','Silver - Rare','Normal',70,'1. FC Heidenheim 1846','Bundesliga 2','Germany','CB','1993-02-17',44,46,32,44,69,80,0,0,0,0,0,0,'Right',2,2,69,60,60,58,58,61,49,45,45,44,43,43,43,42,42,47,250,10000
);
INSERT INTO PLAYER VALUES (1194,'Gooch','Lynden Gooch','Silver - Non-Rare','Normal',68,'Sunderland','EFL League One','United States','RM','1995-12-24',79,69,59,64,51,71,0,0,0,0,0,0,'Right',4,3,57,58,58,59,59,59,63,67,67,66,65,65,65,66,66,63,150,10000
);
INSERT INTO PLAYER VALUES (1195,'Sheridan','Gavin Sheridan','Bronze - Non-Rare','Normal',50,'UCD','SSE Airtricity League','Republic of Ireland','GK','1996-01-03',0,0,0,0,0,0,50,51,45,41,44,52,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1196,'Nuno Valente','Nuno Daniel Costeira Valente','Silver - Non-Rare','Normal',68,'Vitoria Setubal','Liga NOS','Portugal','CM','1991-11-22',70,69,61,66,53,61,0,0,0,0,0,0,'Right',3,3,56,61,61,63,63,61,67,67,67,67,66,66,66,67,67,63,150,10000
);
INSERT INTO PLAYER VALUES (1197,'Vergos','Nikos Vergos','Silver - Non-Rare','Normal',66,'Panathinaikos FC','Hellas Liga','Greece','ST','1996-01-13',71,61,64,47,32,63,0,0,0,0,0,0,'Right',4,2,44,44,44,44,44,45,53,57,57,59,62,62,62,59,59,65,150,10000
);
INSERT INTO PLAYER VALUES (1198,'Koulouris','Efthymios Koulouris','Silver - Non-Rare','Normal',72,'Toulouse Football Club','Ligue 1 Conforama','Greece','ST','1996-03-06',69,67,71,53,27,60,0,0,0,0,0,0,'Right',3,3,40,43,43,45,45,44,59,64,64,65,68,68,68,65,65,71,150,10000
);
INSERT INTO PLAYER VALUES (1199,'Zingerle','Leopold Zingerle','Silver - Non-Rare','Normal',71,'SC Paderborn 07','Bundesliga','Germany','GK','1994-04-10',0,0,0,0,0,0,70,74,68,42,67,72,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1200,'Griesbeck','Sebastian Griesbeck','Silver - Rare','Normal',72,'1. FC Heidenheim 1846','Bundesliga 2','Germany','CDM','1990-10-03',54,60,47,60,72,81,0,0,0,0,0,0,'Right',3,2,72,68,68,67,67,71,64,59,59,58,57,57,57,56,56,56,300,10000
);
INSERT INTO PLAYER VALUES (1201,'Glad','Justen Glad','Silver - Non-Rare','Normal',69,'Real Salt Lake','Major League Soccer','United States','CB','1997-02-28',71,50,27,50,68,74,0,0,0,0,0,0,'Right',2,2,68,64,64,62,62,66,55,50,50,49,46,46,46,46,46,45,150,10000
);
INSERT INTO PLAYER VALUES (1202,'Runarsson','Runar Alex Runarsson','Silver - Non-Rare','Normal',70,'Dijon FCO','Ligue 1 Conforama','Iceland','GK','1995-02-18',0,0,0,0,0,0,71,71,68,45,72,70,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1203,'Han Eui Kwon','Eui Kwon Han','Silver - Non-Rare','Normal',68,'Suwon Samsung Bluewings','K LEAGUE Classic','Korea Republic','LW','1994-06-30',85,70,65,63,42,60,0,0,0,0,0,0,'Right',3,3,48,56,56,58,58,54,61,67,67,66,66,66,66,68,68,63,150,10000
);
INSERT INTO PLAYER VALUES (1204,'Ivan Villar','Ivan Villar Martinez','Silver - Non-Rare','Normal',67,'RC Celta','LaLiga Santander','Spain','GK','1997-07-09',0,0,0,0,0,0,69,69,62,32,64,65,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1205,'Tello','Andres Tello','Silver - Rare','Normal',71,'Benevento','Calcio B','Colombia','CM','1996-09-06',86,74,58,69,61,81,0,0,0,0,0,0,'Right',3,3,67,70,70,71,71,69,70,73,73,71,70,70,70,72,72,68,250,10000
);
INSERT INTO PLAYER VALUES (1206,'Nishi','Tsubasa Nishi','Bronze - Rare','Normal',64,'Daegu FC','K LEAGUE Classic','Japan','CM','1990-04-08',60,66,55,63,51,60,0,0,0,0,0,0,'Right',4,2,54,56,56,58,58,60,63,62,62,63,60,60,60,61,61,57,150,10000
);
INSERT INTO PLAYER VALUES (1207,'Pleguezuelo','Julio Jose Pleguezuelo Selva','Silver - Rare','Normal',68,'FC Twente','Eredivisie','Spain','CB','1997-01-26',68,66,35,55,68,64,0,0,0,0,0,0,'Right',4,3,67,65,65,64,64,65,58,58,58,56,54,54,54,56,56,52,250,10000
);
INSERT INTO PLAYER VALUES (1208,'Cardona','Jown Cardona','Silver - Non-Rare','Normal',68,'Club Leon','LIGA Bancomer MX','Colombia','CAM','1995-01-09',75,72,61,61,45,59,0,0,0,0,0,0,'Right',3,3,51,56,56,58,58,54,61,66,66,67,66,66,66,67,67,62,150,10000
);
INSERT INTO PLAYER VALUES (1209,'Kim Young Bin','Young Bin Kim','Bronze - Non-Rare','Normal',57,'Sangju Sangmu FC','K LEAGUE Classic','Korea Republic','LB','1991-09-20',65,38,24,38,57,70,0,0,0,0,0,0,'Right',3,2,59,56,56,54,54,51,41,43,43,39,40,40,40,41,41,43,150,10000
);
INSERT INTO PLAYER VALUES (1210,'James','Tom James','Silver - Non-Rare','Normal',65,'Hibernian','Scottish Premiership','Wales','RB','1996-04-15',73,62,55,58,61,72,0,0,0,0,0,0,'Right',3,2,62,64,64,64,64,61,59,62,62,59,60,60,60,61,61,60,150,10000
);
INSERT INTO PLAYER VALUES (1211,'Escobar','Franco Escobar','Silver - Non-Rare','Normal',68,'Atlanta United','Major League Soccer','Argentina','RB','1995-02-21',70,66,47,57,69,68,0,0,0,0,0,0,'Right',3,2,68,67,67,67,67,66,61,62,62,60,60,60,60,61,61,59,150,10000
);
INSERT INTO PLAYER VALUES (1212,'Manotas','Mauro Manotas','Silver - Non-Rare','Normal',71,'Houston Dynamo','Major League Soccer','Colombia','ST','1995-07-15',73,69,70,57,33,67,0,0,0,0,0,0,'Right',2,3,46,49,49,52,52,51,61,67,67,67,69,69,69,68,68,70,150,10000
);
INSERT INTO PLAYER VALUES (1213,'Ohemeng','Ernest Ohemeng','Silver - Rare','Normal',68,'CD Mirandes','LaLiga 1 I 2 I 3','Ghana','LW','1996-01-17',91,76,58,54,24,47,0,0,0,0,0,0,'Right',3,3,35,46,46,50,50,42,56,66,66,66,67,67,67,68,68,62,250,10000
);
INSERT INTO PLAYER VALUES (1214,'Nelson Monte','Nelson Macedo Monte','Silver - Rare','Normal',73,'Rio Ave FC','Liga NOS','Portugal','CB','1995-07-30',57,58,35,57,74,73,0,0,0,0,0,0,'Right',2,2,72,67,67,66,66,70,60,56,56,54,52,52,52,53,53,51,300,10000
);
INSERT INTO PLAYER VALUES (1215,'Lee Tae Hee','Tae Hee Lee','Bronze - Non-Rare','Normal',63,'Incheon United FC','K LEAGUE Classic','Korea Republic','GK','1995-04-26',0,0,0,0,0,0,62,63,62,44,61,62,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1216,'Osam','Evan Osam','Bronze - Non-Rare','Normal',55,'UCD','SSE Airtricity League','Republic of Ireland','LB','1997-08-17',74,52,36,46,49,50,0,0,0,0,0,0,'Left',2,2,49,54,54,54,54,50,48,53,53,49,49,49,49,51,51,46,150,10000
);
INSERT INTO PLAYER VALUES (1217,'Du Jia','Jia Du','Bronze - Non-Rare','Normal',59,'Tianjin TEDA FC','CSL','China PR','GK','1993-05-01',0,0,0,0,0,0,59,60,50,49,52,58,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1218,'Bai Yuefeng','Yuefeng Bai','Bronze - Non-Rare','Normal',61,'Tianjin TEDA FC','CSL','China PR','RB','1987-03-28',62,56,53,56,61,70,0,0,0,0,0,0,'Right',3,2,61,60,60,60,60,60,57,58,58,57,57,57,57,58,58,56,150,10000
);
INSERT INTO PLAYER VALUES (1219,'Smith','Nathan Smith','Bronze - Non-Rare','Normal',62,'Port Vale','EFL League Two','England','CB','1996-04-03',59,33,25,28,63,73,0,0,0,0,0,0,'Right',2,2,61,55,55,52,52,51,36,35,35,31,33,33,33,33,33,37,150,10000
);
INSERT INTO PLAYER VALUES (1220,'Chu Jinzhao','Jinzhao Chu','Bronze - Rare','Normal',59,'Tianjin Quanjian FC','CSL','China PR','CB','1993-01-11',82,59,34,49,56,60,0,0,0,0,0,0,'Right',2,2,58,56,56,55,55,57,55,55,55,56,54,54,54,54,54,50,150,10000
);
INSERT INTO PLAYER VALUES (1221,'Success','Isaac Success','Silver - Rare','Normal',73,'Watford','Premier League','Nigeria','ST','1996-01-07',75,75,69,65,35,66,0,0,0,0,0,0,'Right',3,3,48,52,52,55,55,51,63,71,71,70,72,72,72,72,72,72,300,10000
);
INSERT INTO PLAYER VALUES (1222,'Kyei','Grejohn Kyei','Silver - Non-Rare','Normal',68,'Servette FC','Raiffeisen Super League','France','ST','1995-08-12',64,65,65,50,26,76,0,0,0,0,0,0,'Right',3,3,43,42,42,44,44,44,54,60,60,60,63,63,63,61,61,67,150,10000
);
INSERT INTO PLAYER VALUES (1223,'Ramirez','Roberto Ramirez','Silver - Non-Rare','Normal',68,'Godoy Cruz','SAF','Argentina','GK','1996-07-07',0,0,0,0,0,0,69,72,67,48,58,66,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1224,'Silva','Jordan Silva','Silver - Non-Rare','Normal',68,'Club Tijuana','LIGA Bancomer MX','Mexico','CB','1994-07-30',44,41,33,39,70,72,0,0,0,0,0,0,'Right',2,2,67,59,59,56,56,60,46,40,40,40,40,40,40,38,38,45,150,10000
);
INSERT INTO PLAYER VALUES (1225,'Lopez','Leonel Lopez','Silver - Non-Rare','Normal',67,'Club America','LIGA Bancomer MX','Mexico','CM','1994-05-24',65,65,50,65,63,66,0,0,0,0,0,0,'Right',3,3,64,65,65,65,65,66,66,64,64,64,62,62,62,62,62,59,150,10000
);
INSERT INTO PLAYER VALUES (1226,'Beesley','Jake Beesley','Bronze - Non-Rare','Normal',57,'Salford City','EFL League Two','England','ST','1996-12-02',71,54,54,46,43,65,0,0,0,0,0,0,'Right',2,2,49,49,49,49,49,48,50,54,54,53,55,55,55,54,54,56,150,10000
);
INSERT INTO PLAYER VALUES (1227,'Hwang Hyun Soo','Hyun Soo Hwang','Silver - Non-Rare','Normal',66,'FC Seoul','K LEAGUE Classic','Korea Republic','CB','1995-07-22',61,41,43,34,65,70,0,0,0,0,0,0,'Right',4,2,65,58,58,54,54,56,44,41,41,41,43,43,43,41,41,50,150,10000
);
INSERT INTO PLAYER VALUES (1228,'Yoon Seung Won','Seung Won Yoon','Silver - Non-Rare','Normal',65,'FC Seoul','K LEAGUE Classic','Korea Republic','LW','1995-02-11',76,65,60,60,30,65,0,0,0,0,0,0,'Left',4,3,42,47,47,51,51,47,58,65,65,64,64,64,64,65,65,64,150,10000
);
INSERT INTO PLAYER VALUES (1229,'Seo Bo Min','Bo Min Seo','Bronze - Rare','Normal',64,'Seongnam FC','K LEAGUE Classic','Korea Republic','LM','1990-06-22',82,64,60,56,42,59,0,0,0,0,0,0,'Right',4,2,47,54,54,56,56,52,57,63,63,62,62,62,62,64,64,60,150,10000
);
INSERT INTO PLAYER VALUES (1230,'Schmitz','Benno Schmitz','Silver - Non-Rare','Normal',71,'1. FC Koln','Bundesliga','Germany','RB','1994-11-17',69,65,50,64,70,70,0,0,0,0,0,0,'Right',3,2,70,70,70,69,69,68,64,64,64,63,62,62,62,63,63,61,150,10000
);
INSERT INTO PLAYER VALUES (1231,'Fertoli','Hector Fertoli','Silver - Rare','Normal',69,'San Lorenzo de Almagro','SAF','Argentina','LM','1994-12-03',86,72,61,62,41,61,0,0,0,0,0,0,'Right',3,3,49,55,55,57,57,53,61,68,68,67,67,67,67,69,69,65,250,10000
);
INSERT INTO PLAYER VALUES (1232,'Han Seok Jong','Seok Jong Han','Bronze - Rare','Normal',64,'Sangju Sangmu FC','K LEAGUE Classic','Korea Republic','CM','1992-07-19',48,58,46,62,58,72,0,0,0,0,0,0,'Right',3,2,61,60,60,60,60,64,63,57,57,59,56,56,56,55,55,54,150,10000
);
INSERT INTO PLAYER VALUES (1233,'Baek Dong Gyu','Dong Gyu Baek','Bronze - Non-Rare','Normal',61,'Sangju Sangmu FC','K LEAGUE Classic','Korea Republic','CB','1991-05-30',49,46,36,45,60,70,0,0,0,0,0,0,'Right',3,2,60,55,55,54,54,58,52,47,47,47,46,46,46,44,44,47,150,10000
);
INSERT INTO PLAYER VALUES (1234,'Manuel','Benson Manuel','Silver - Rare','Normal',72,'KRC Genk','Belgium Pro League','Belgium','LW','1997-03-28',80,78,61,67,34,58,0,0,0,0,0,0,'Left',4,4,45,53,53,57,57,52,64,71,71,70,69,69,69,72,72,65,300,10000
);
INSERT INTO PLAYER VALUES (1235,'Kang Sang Woo','Sang Woo Kang','Silver - Rare','Normal',66,'Sangju Sangmu FC','K LEAGUE Classic','Korea Republic','LB','1993-10-07',79,64,60,59,64,55,0,0,0,0,0,0,'Right',3,3,60,65,65,66,66,61,60,65,65,63,65,65,65,65,65,64,250,10000
);
INSERT INTO PLAYER VALUES (1236,'Leandro Pereira','Leandro Marcos Pereira','Silver - Non-Rare','Normal',70,'Sanfrecce Hiroshima','Meiji Yasuda J1 League','Brazil','ST','1991-07-13',67,66,68,53,32,76,0,0,0,0,0,0,'Right',2,3,47,47,47,49,49,48,58,63,63,64,67,67,67,64,64,69,150,10000
);
INSERT INTO PLAYER VALUES (1237,'Gulden','Henrik Gulden','Bronze - Non-Rare','Normal',62,'Mjondalen IF','Eliteserien','Norway','CAM','1995-12-29',69,65,52,61,38,43,0,0,0,0,0,0,'Left',4,3,42,50,50,52,52,49,58,61,61,61,60,60,60,61,61,55,150,10000
);
INSERT INTO PLAYER VALUES (1238,'Zander','Luca Zander','Silver - Non-Rare','Normal',67,'FC St. Pauli','Bundesliga 2','Germany','RB','1995-08-09',78,61,37,55,64,67,0,0,0,0,0,0,'Right',3,2,64,66,66,66,66,62,56,60,60,55,54,54,54,57,57,53,150,10000
);
INSERT INTO PLAYER VALUES (1239,'Pachonik','Tobias Pachonik','Silver - Rare','Normal',69,'VVV-Venlo','Eredivisie','Germany','RB','1995-01-04',73,65,49,59,66,78,0,0,0,0,0,0,'Right',2,3,68,68,68,68,68,66,62,63,63,60,60,60,60,61,61,60,250,10000
);
INSERT INTO PLAYER VALUES (1240,'Jeong Woo Jae','Woo Jae Jeong','Silver - Non-Rare','Normal',66,'Jeju United FC','K LEAGUE Classic','Korea Republic','LM','1992-06-28',73,66,60,63,63,68,0,0,0,0,0,0,'Right',4,4,63,65,65,66,66,64,64,65,65,64,64,64,64,65,65,63,150,10000
);
INSERT INTO PLAYER VALUES (1241,'Salles','Esteban Salles','Bronze - Non-Rare','Normal',59,'Grenoble Foot 38','Domino''s Ligue 2','France','GK','1994-03-02',0,0,0,0,0,0,61,62,56,25,56,55,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1242,'Burgess','Scott Burgess','Bronze - Non-Rare','Normal',61,'Port Vale','EFL League Two','England','RM','1997-08-12',75,62,59,55,40,50,0,0,0,0,0,0,'Right',3,3,43,49,49,51,51,48,55,60,60,58,59,59,59,60,60,58,150,10000
);
INSERT INTO PLAYER VALUES (1243,'Akolo','Chadrac Akolo','Silver - Rare','Normal',72,'Amiens SC','Ligue 1 Conforama','Congo DR','RM','1995-04-01',81,77,68,63,26,61,0,0,0,0,0,0,'Right',3,3,40,49,49,53,53,49,63,71,71,70,71,71,71,72,72,68,300,10000
);
INSERT INTO PLAYER VALUES (1244,'Brodersen','Svend Brodersen','Bronze - Rare','Normal',63,'FC St. Pauli','Bundesliga 2','Germany','GK','1997-03-22',0,0,0,0,0,0,64,67,60,42,56,62,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1245,'Grillo','Fausto Grillo','Silver - Non-Rare','Normal',67,'Goztepe SK','Super Lig','Argentina','CB','1993-02-20',73,61,35,48,65,74,0,0,0,0,0,0,'Left',3,2,66,63,63,62,62,59,53,56,56,54,53,53,53,55,55,52,150,10000
);
INSERT INTO PLAYER VALUES (1246,'Ledson','Ryan Ledson','Silver - Non-Rare','Normal',66,'Preston North End','EFL Championship','England','CDM','1997-08-19',61,63,55,63,60,71,0,0,0,0,0,0,'Right',2,2,63,61,61,61,61,65,64,62,62,63,61,61,61,61,61,60,150,10000
);
INSERT INTO PLAYER VALUES (1247,'Ajdini','Bashkim Ajdini','Silver - Non-Rare','Normal',68,'VfL Osnabruck','Bundesliga 2','Germany','RB','1992-12-10',77,71,58,67,61,63,0,0,0,0,0,0,'Right',3,3,61,67,67,68,68,65,67,68,68,67,65,65,65,67,67,61,150,10000
);
INSERT INTO PLAYER VALUES (1248,'Coly','Racine Coly','Silver - Non-Rare','Normal',71,'OGC Nice','Ligue 1 Conforama','Senegal','LB','1995-12-08',80,66,44,60,68,75,0,0,0,0,0,0,'Left',2,2,69,70,70,70,70,67,62,65,65,61,61,61,61,63,63,60,150,10000
);
INSERT INTO PLAYER VALUES (1249,'Ronan','Ronan David Jeronimo','Silver - Rare','Normal',67,'Rio Ave FC','Liga NOS','Brazil','ST','1995-04-22',32,60,67,46,26,80,0,0,0,0,0,0,'Right',2,2,44,39,39,41,41,44,53,54,54,57,61,61,61,56,56,66,250,10000
);
INSERT INTO PLAYER VALUES (1250,'Samuel','Alex Samuel','Bronze - Non-Rare','Normal',63,'Wycombe Wanderers','EFL League One','Wales','ST','1995-09-20',80,63,59,48,22,66,0,0,0,0,0,0,'Right',3,3,38,42,42,44,44,41,52,60,60,60,61,61,61,61,61,62,150,10000
);
INSERT INTO PLAYER VALUES (1251,'Rose','Jack Rose','Bronze - Non-Rare','Normal',62,'Walsall','EFL League Two','England','GK','1995-01-31',0,0,0,0,0,0,64,64,60,42,58,61,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1252,'Cooper','George Cooper','Bronze - Non-Rare','Normal',63,'Peterborough United','EFL League One','England','LM','1996-10-30',78,63,49,63,26,52,0,0,0,0,0,0,'Left',4,3,35,45,45,48,48,43,56,62,62,60,58,58,58,62,62,53,150,10000
);
INSERT INTO PLAYER VALUES (1253,'Kayembe','Joris Kayembe','Silver - Non-Rare','Normal',67,'FC Nantes','Ligue 1 Conforama','Belgium','LW','1994-08-08',81,70,55,60,37,54,0,0,0,0,0,0,'Left',4,3,47,50,50,53,53,51,59,66,66,65,65,65,65,67,67,62,150,10000
);
INSERT INTO PLAYER VALUES (1254,'Auro','Auro Alvaro da Cruz Junior','Silver - Rare','Normal',69,'Toronto FC','Major League Soccer','Brazil','RB','1996-01-23',74,72,51,65,64,62,0,0,0,0,0,0,'Right',3,4,63,68,68,69,69,66,66,67,67,66,64,64,64,66,66,59,250,10000
);
INSERT INTO PLAYER VALUES (1255,'Toure','Thomas Toure','Silver - Non-Rare','Normal',68,'FC Sochaux-Montbeliard','Domino''s Ligue 2','Cote d''Ivoire','LM','1993-12-27',75,68,64,68,43,64,0,0,0,0,0,0,'Right',3,3,52,56,56,58,58,56,64,67,67,67,67,67,67,68,68,66,150,10000
);
INSERT INTO PLAYER VALUES (1256,'Acevedo','Lucas Acevedo','Silver - Rare','Normal',69,'Colon de Santa Fe','SAF','Argentina','CB','1991-11-08',44,39,38,43,67,82,0,0,0,0,0,0,'Right',3,2,68,59,59,57,57,62,49,43,43,43,43,43,43,41,41,48,250,10000
);
INSERT INTO PLAYER VALUES (1257,'De La Cruz','Nicolas De la Cruz','Silver - Rare','Normal',73,'Nunez','SAF','Uruguay','CAM','1997-06-01',78,75,65,70,46,49,0,0,0,0,0,0,'Right',3,3,51,59,59,61,61,58,68,71,71,72,70,70,70,71,71,66,300,10000
);
INSERT INTO PLAYER VALUES (1258,'Spence','Lewis Spence','Bronze - Non-Rare','Normal',62,'Ross County','Scottish Premiership','Scotland','CM','1996-01-28',66,63,46,58,54,57,0,0,0,0,0,0,'Right',3,2,55,58,58,59,59,59,61,60,60,60,58,58,58,58,58,55,150,10000
);
INSERT INTO PLAYER VALUES (1259,'Yaremchuk','Roman Yaremchuk','Silver - Non-Rare','Normal',73,'KAA Gent','Belgium Pro League','Ukraine','ST','1995-11-27',74,69,70,66,45,72,0,0,0,0,0,0,'Right',3,3,55,57,57,59,59,58,66,70,70,70,71,71,71,70,70,72,150,10000
);
INSERT INTO PLAYER VALUES (1260,'Guo Quanbo','Quanbo Guo','Bronze - Non-Rare','Normal',60,'Beijing Guoan','CSL','China PR','GK','1997-08-31',0,0,0,0,0,0,58,60,56,51,60,61,'Right',1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1261,'Knowles','Tom Knowles','Bronze - Non-Rare','Normal',52,'Cambridge United','EFL League Two','England','RM','1998-09-27',78,51,48,42,29,56,0,0,0,0,0,0,'Right',3,2,38,41,41,42,42,38,44,51,51,49,51,51,51,52,52,51,150,10000
);
INSERT INTO PLAYER VALUES (1262,'Baku','Ridle Baku','Silver - Non-Rare','Normal',69,'1. FSV Mainz 05','Bundesliga','Germany','CM','1998-04-08',76,73,59,66,62,64,0,0,0,0,0,0,'Right',4,3,64,66,66,67,67,67,68,69,69,69,68,68,68,69,69,64,150,10000
);
INSERT INTO PLAYER VALUES (1263,'Lloyd','George Lloyd','Bronze - Non-Rare','Normal',55,'Cheltenham Town','EFL League Two','England','ST','2000-02-11',76,59,52,46,23,60,0,0,0,0,0,0,'Right',2,2,35,39,39,42,42,39,48,55,55,54,55,55,55,56,56,54,150,10000
);
INSERT INTO PLAYER VALUES (1264,'Aaneba','Ismael Aaneba','Bronze - Non-Rare','Normal',61,'RC Strasbourg Alsace','Ligue 1 Conforama','France','RB','1999-05-29',66,56,29,51,62,64,0,0,0,0,0,0,'Right',2,2,62,60,60,60,60,59,51,52,52,49,47,47,47,49,49,45,150,10000
);
INSERT INTO PLAYER VALUES (1265,'Rajot','Lorenzo Rajot','Silver - Non-Rare','Normal',65,'Clermont Foot 63','Domino''s Ligue 2','France','CDM','1997-10-13',72,67,51,65,62,56,0,0,0,0,0,0,'Right',3,3,60,65,65,66,66,64,64,64,64,63,61,61,61,64,64,57,150,10000
);
INSERT INTO PLAYER VALUES (1266,'Zohi','Kevin Zohi','Silver - Non-Rare','Normal',68,'RC Strasbourg Alsace','Ligue 1 Conforama','Mali','LM','1996-12-19',78,71,66,58,24,55,0,0,0,0,0,0,'Right',3,3,37,46,46,49,49,43,58,67,67,66,67,67,67,68,68,66,150,10000
);
INSERT INTO PLAYER VALUES (1267,'Hudson-Odoi','Callum Hudson-Odoi','Silver - Rare','Normal',74,'Chelsea','Premier League','England','RW','2000-11-07',85,80,64,67,30,60,0,0,0,0,0,0,'Right',3,4,44,52,52,56,56,51,65,73,73,72,72,72,72,74,74,68,300,10000
);
INSERT INTO PLAYER VALUES (1268,'De Bie','Maxime De Bie','Bronze - Non-Rare','Normal',55,'KV Mechelen','Belgium Pro League','Belgium','CDM','2000-12-13',59,50,33,47,52,55,0,0,0,0,0,0,'Right',2,2,55,52,52,50,50,54,50,47,47,48,46,46,46,45,45,45,150,10000
);
INSERT INTO PLAYER VALUES (1269,'Ojeda','Martin Ojeda','Silver - Non-Rare','Normal',67,'Club Atletico Huracan','SAF','Argentina','LM','1998-11-27',76,69,54,62,29,58,0,0,0,0,0,0,'Left',3,3,41,50,50,53,53,50,61,66,66,64,64,64,64,65,65,61,150,10000
);
INSERT INTO PLAYER VALUES (1270,'Poussin','Gaetan Poussin','Silver - Non-Rare','Normal',66,'FC Girondins de Bordeaux','Ligue 1 Conforama','France','GK','1999-01-13',0,0,0,0,0,0,67,66,65,20,63,67,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1271,'Gouiri','Amine Gouiri','Silver - Non-Rare','Normal',68,'Olympique Lyonnais','Ligue 1 Conforama','France','ST','2000-02-16',72,69,65,55,21,61,0,0,0,0,0,0,'Right',3,3,37,41,41,44,44,43,57,64,64,66,67,67,67,65,65,67,150,10000
);
INSERT INTO PLAYER VALUES (1272,'Sussek','Patrick Sussek','Bronze - Non-Rare','Normal',60,'FC Ingolstadt 04','3. Liga','Germany','CAM','2000-02-08',73,66,48,54,25,48,0,0,0,0,0,0,'Right',3,3,35,43,43,46,46,41,53,60,60,59,58,58,58,60,60,54,150,10000
);
INSERT INTO PLAYER VALUES (1273,'Gilmour','Harvey Gilmour','Bronze - Non-Rare','Normal',60,'Tranmere Rovers','EFL League One','England','CM','1998-12-05',72,61,53,58,51,60,0,0,0,0,0,0,'Left',2,2,54,57,57,58,58,56,59,61,61,59,59,59,59,60,60,56,150,10000
);
INSERT INTO PLAYER VALUES (1274,'Hallam','Jordan Hallam','Bronze - Non-Rare','Normal',57,'Scunthorpe United','EFL League Two','England','CAM','1998-10-06',72,60,57,48,26,46,0,0,0,0,0,0,'Right',3,3,35,41,41,43,43,39,50,56,56,56,58,58,58,57,57,57,150,10000
);
INSERT INTO PLAYER VALUES (1275,'Norrington-Davies','Rhys Norrington-Davies','Bronze - Non-Rare','Normal',56,'Rochdale','EFL League One','Wales','LWB','1999-04-22',66,49,30,46,54,56,0,0,0,0,0,0,'Left',2,2,53,55,55,55,55,50,44,49,49,44,44,44,44,48,48,42,150,10000
);
INSERT INTO PLAYER VALUES (1276,'Smith','Tyler Smith','Bronze - Non-Rare','Normal',58,'Bristol Rovers','EFL League One','England','ST','1998-12-04',82,61,55,43,20,46,0,0,0,0,0,0,'Right',3,2,31,39,39,41,41,35,48,56,56,56,58,58,58,58,58,57,150,10000
);
INSERT INTO PLAYER VALUES (1277,'Laiton','Sonny Laiton','Bronze - Rare','Normal',60,'AJ Auxerre','Domino''s Ligue 2','France','GK','2000-01-28',0,0,0,0,0,0,57,59,59,48,53,56,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1278,'Ranieri','Luca Ranieri','Bronze - Rare','Normal',62,'Fiorentina','Serie A TIM','Italy','CB','1999-04-23',58,60,34,40,65,52,0,0,0,0,0,0,'Left',3,2,61,58,58,57,57,54,47,50,50,47,48,48,48,50,50,47,150,10000
);
INSERT INTO PLAYER VALUES (1279,'sahinturk','Sedat sahinturk','Silver - Non-Rare','Normal',67,'Yukatel Denizlispor','Super Lig','Turkey','LM','1996-02-07',80,66,70,57,37,55,0,0,0,0,0,0,'Left',3,2,43,52,52,54,54,50,59,66,66,64,66,66,66,67,67,65,150,10000
);
INSERT INTO PLAYER VALUES (1280,'Campbell','Tyrese Campbell','Silver - Non-Rare','Normal',65,'Stoke City','EFL Championship','England','ST','1999-12-28',78,62,64,53,33,67,0,0,0,0,0,0,'Left',4,2,46,47,47,48,48,46,55,61,61,61,63,63,63,62,62,64,150,10000
);
INSERT INTO PLAYER VALUES (1281,'Cerofolini','Michele Cerofolini','Bronze - Non-Rare','Normal',60,'Fiorentina','Serie A TIM','Italy','GK','1999-01-04',0,0,0,0,0,0,60,60,60,37,60,63,'Right',1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1282,'Traore','Hamed Junior Traore','Silver - Non-Rare','Normal',70,'Sassuolo','Serie A TIM','Cote d''Ivoire','CAM','2000-02-16',66,73,66,68,56,61,0,0,0,0,0,0,'Right',3,3,59,62,62,63,63,62,67,68,68,69,68,68,68,69,69,67,150,10000
);
INSERT INTO PLAYER VALUES (1283,'Rodrigao','Rodrigo de Souza Prado','Silver - Rare','Normal',66,'Gil Vicente FC','Liga NOS','Brazil','CB','1995-09-11',60,40,31,46,64,76,0,0,0,0,0,0,'Right',2,2,65,58,58,56,56,60,48,45,45,43,42,42,42,41,41,45,250,10000
);
INSERT INTO PLAYER VALUES (1284,'Roffo','Manuel Roffo','Bronze - Non-Rare','Normal',62,'Buenos Aires','SAF','Argentina','GK','2000-04-04',0,0,0,0,0,0,61,64,63,23,61,60,'Right',4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1285,'Tramoni','Matteo Tramoni','Silver - Non-Rare','Normal',65,'Athletic Club Ajaccio','Domino''s Ligue 2','France','LM','2000-01-20',74,68,57,64,45,58,0,0,0,0,0,0,'Right',4,3,51,55,55,56,56,55,61,64,64,64,63,63,63,65,65,61,150,10000
);
INSERT INTO PLAYER VALUES (1286,'Repas','Jan Repas','Silver - Non-Rare','Normal',69,'Stade Malherbe Caen','Domino''s Ligue 2','Slovenia','LM','1997-03-19',77,72,61,67,41,53,0,0,0,0,0,0,'Left',5,3,48,54,54,57,57,54,63,68,68,68,67,67,67,69,69,64,150,10000
);
INSERT INTO PLAYER VALUES (1287,'Yates','Cameron Yates','Bronze - Non-Rare','Normal',57,'Wycombe Wanderers','EFL League One','Scotland','GK','1999-02-14',0,0,0,0,0,0,58,59,57,45,56,56,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1288,'Shaw','Oli Shaw','Bronze - Non-Rare','Normal',63,'Hibernian','Scottish Premiership','Scotland','ST','1998-03-12',67,60,61,44,21,55,0,0,0,0,0,0,'Right',3,2,35,39,39,41,41,38,51,56,56,58,61,61,61,58,58,62,150,10000
);
INSERT INTO PLAYER VALUES (1289,'Murray','Fraser Murray','Bronze - Non-Rare','Normal',60,'Hibernian','Scottish Premiership','Scotland','LM','1999-05-07',71,60,51,57,34,48,0,0,0,0,0,0,'Right',3,3,40,47,47,49,49,46,54,59,59,58,57,57,57,58,58,53,150,10000
);
INSERT INTO PLAYER VALUES (1290,'Akbulut','Arda Akbulut','Bronze - Rare','Normal',63,'Trabzonspor','Super Lig','Turkey','GK','2001-01-01',0,0,0,0,0,0,65,68,61,33,59,64,'Left',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1291,'Gibson','Jordan Gibson','Bronze - Non-Rare','Normal',53,'Bradford City','EFL League Two','England','LM','1998-02-28',66,57,51,46,24,38,0,0,0,0,0,0,'Right',3,3,32,37,37,39,39,35,45,52,52,52,53,53,53,54,54,52,150,10000
);
INSERT INTO PLAYER VALUES (1292,'Grodowski','Joel Grodowski','Bronze - Non-Rare','Normal',53,'SC Preuben Munster','3. Liga','Germany','ST','1997-11-30',58,52,57,36,22,43,0,0,0,0,0,0,'Right',3,2,30,34,34,35,35,32,41,47,47,48,50,50,50,49,49,52,150,10000
);
INSERT INTO PLAYER VALUES (1293,'Martin','Scott Martin','Bronze - Non-Rare','Normal',58,'Hamilton Academical FC','Scottish Premiership','Scotland','CM','1997-04-01',61,57,40,54,54,56,0,0,0,0,0,0,'Right',3,2,55,55,55,55,55,57,57,55,55,56,54,54,54,53,53,51,150,10000
);
INSERT INTO PLAYER VALUES (1294,'Amenyido','Etienne Amenyido','Bronze - Rare','Normal',64,'VfL Osnabruck','Bundesliga 2','Germany','RM','1998-03-01',78,65,58,54,38,69,0,0,0,0,0,0,'Right',3,2,48,53,53,55,55,49,55,63,63,61,63,63,63,63,63,62,150,10000
);
INSERT INTO PLAYER VALUES (1295,'cetin','sahverdi cetin','Bronze - Rare','Normal',59,'Eintracht Frankfurt','Bundesliga','Germany','CDM','2000-09-28',59,65,60,58,54,52,0,0,0,0,0,0,'Right',3,3,55,56,56,57,57,58,61,60,60,63,62,62,62,61,61,59,150,10000
);
INSERT INTO PLAYER VALUES (1296,'Yandas','Mert Hakan Yandas','Bronze - Non-Rare','Normal',62,'Sivasspor','Super Lig','Turkey','CAM','1994-08-19',60,66,53,60,42,57,0,0,0,0,0,0,'Right',3,3,49,52,52,54,54,53,59,62,62,61,61,61,61,61,61,59,150,10000
);
INSERT INTO PLAYER VALUES (1297,'Apeh','Emmanuel Apeh','Silver - Non-Rare','Normal',69,'RC Celta','LaLiga Santander','Nigeria','ST','1996-10-25',72,66,66,54,26,62,0,0,0,0,0,0,'Right',3,3,39,44,44,46,46,43,56,63,63,64,66,66,66,65,65,68,150,10000
);
INSERT INTO PLAYER VALUES (1298,'Berrocal','Juan Berrocal Gonzalez','Silver - Non-Rare','Normal',65,'Sevilla FC','LaLiga Santander','Spain','CB','1999-12-05',60,50,35,48,64,65,0,0,0,0,0,0,'Right',2,2,64,60,60,58,58,61,53,48,48,48,46,46,46,46,46,47,150,10000
);
INSERT INTO PLAYER VALUES (1299,'Coventry','Conor Coventry','Bronze - Non-Rare','Normal',58,'West Ham United','Premier League','Republic of Ireland','CM','2000-03-25',58,60,41,56,48,53,0,0,0,0,0,0,'Right',3,2,50,51,51,53,53,55,57,55,55,56,52,52,52,53,53,47,150,10000
);
INSERT INTO PLAYER VALUES (1300,'Dube','Mthokozisi Dube','Silver - Non-Rare','Normal',66,'Orlando Pirates','South African FL','South Africa','RB','1992-09-10',73,63,34,55,66,57,0,0,0,0,0,0,'Right',3,2,62,65,65,65,65,63,57,59,59,54,53,53,53,55,55,49,150,10000
);
INSERT INTO PLAYER VALUES (1301,'Nani','Matias Nani','Bronze - Non-Rare','Normal',63,'Central Cordoba','SAF','Argentina','CB','1998-03-26',60,50,31,41,62,69,0,0,0,0,0,0,'Left',2,2,62,58,58,57,57,57,47,46,46,43,44,44,44,44,44,46,150,10000
);
INSERT INTO PLAYER VALUES (1302,'Menayese','Rollin Menayese','Bronze - Non-Rare','Normal',59,'Bristol Rovers','EFL League One','Wales','CB','1997-12-04',52,38,29,39,55,72,0,0,0,0,0,0,'Right',3,2,58,52,52,50,50,53,43,39,39,38,37,37,37,37,37,40,150,10000
);
INSERT INTO PLAYER VALUES (1303,'Doornbusch','Trevor Doornbusch','Bronze - Non-Rare','Normal',62,'SC Heerenveen','Eredivisie','Holland','GK','1999-07-06',0,0,0,0,0,0,63,64,62,39,59,62,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1304,'Sessa','Nicolas Sessa','Silver - Non-Rare','Normal',65,'FC Erzgebirge Aue','Bundesliga 2','Germany','CAM','1996-03-23',77,70,58,60,33,50,0,0,0,0,0,0,'Left',2,3,40,49,49,52,52,48,59,65,65,64,63,63,63,65,65,59,150,10000
);
INSERT INTO PLAYER VALUES (1305,'Aksoy','Fatih Aksoy','Bronze - Rare','Normal',64,'Sivasspor','Super Lig','Turkey','CB','1997-11-06',39,51,35,42,65,66,0,0,0,0,0,0,'Right',3,2,63,57,57,55,55,57,48,45,45,44,45,45,45,44,44,47,150,10000
);
INSERT INTO PLAYER VALUES (1306,'Kelleher','Caoimhin Kelleher','Bronze - Non-Rare','Normal',59,'Liverpool','Premier League','Republic of Ireland','GK','1998-11-23',0,0,0,0,0,0,60,62,56,39,53,57,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1307,'Miranda','Juan Miranda Gonzalez','Silver - Rare','Normal',67,'FC Barcelona','LaLiga Santander','Spain','LB','2000-01-19',67,62,39,59,65,57,0,0,0,0,0,0,'Left',3,2,63,66,66,66,66,63,59,61,61,57,57,57,57,59,59,54,250,10000
);
INSERT INTO PLAYER VALUES (1308,'Ljubicic','Dejan Ljubicic','Silver - Non-Rare','Normal',68,'SK Rapid Wien','osterreichische Fubball-Bundesliga','Austria','CDM','1997-10-08',69,66,60,63,66,68,0,0,0,0,0,0,'Right',3,3,66,68,68,68,68,67,65,66,66,64,63,63,63,65,65,63,150,10000
);
INSERT INTO PLAYER VALUES (1309,'Li Chenglong','Chenglong Li','Bronze - Non-Rare','Normal',54,'Beijing Renhe','CSL','China PR','RB','1997-01-06',78,51,27,35,52,49,0,0,0,0,0,0,'Right',3,2,50,53,53,52,52,46,41,47,47,43,44,44,44,47,47,41,150,10000
);
INSERT INTO PLAYER VALUES (1310,'Hernandez','Ronald Hernandez','Bronze - Rare','Normal',62,'Stabaek Fotball','Eliteserien','Venezuela','RB','1997-10-04',83,59,33,48,58,62,0,0,0,0,0,0,'Right',3,2,58,61,61,61,61,56,51,56,56,51,51,51,51,55,55,48,150,10000
);
INSERT INTO PLAYER VALUES (1311,'Escriche','Daniel Escriche Romero','Silver - Non-Rare','Normal',67,'SD Huesca','LaLiga 1 I 2 I 3','Spain','ST','1998-03-24',68,64,66,51,35,54,0,0,0,0,0,0,'Right',3,2,42,44,44,46,46,45,56,61,61,63,65,65,65,62,62,66,150,10000
);
INSERT INTO PLAYER VALUES (1312,'Mcauley','Glen McAuley','Bronze - Non-Rare','Normal',58,'St. Patrick''s Athletic','SSE Airtricity League','Republic of Ireland','ST','2000-02-24',56,54,58,47,21,60,0,0,0,0,0,0,'Right',3,3,36,37,37,39,39,38,48,53,53,54,55,55,55,54,54,57,150,10000
);
INSERT INTO PLAYER VALUES (1313,'Millar','Liam Millar','Bronze - Non-Rare','Normal',62,'Kilmarnock','Scottish Premiership','Canada','ST','1999-09-27',75,65,59,51,22,54,0,0,0,0,0,0,'Right',3,3,35,42,42,44,44,39,52,60,60,60,61,61,61,61,61,61,150,10000
);
INSERT INTO PLAYER VALUES (1314,'Phillips','Nathaniel Phillips','Bronze - Non-Rare','Normal',61,'VfB Stuttgart','Bundesliga 2','England','CB','1997-03-21',51,39,29,43,60,63,0,0,0,0,0,0,'Right',3,2,60,53,53,51,51,54,45,41,41,40,39,39,39,38,38,41,150,10000
);
INSERT INTO PLAYER VALUES (1315,'Grimm','Jeremy Grimm','Silver - Rare','Normal',70,'RC Strasbourg Alsace','Ligue 1 Conforama','France','CDM','1987-03-27',49,60,58,56,73,69,0,0,0,0,0,0,'Right',3,2,71,66,66,64,64,69,63,56,56,57,57,57,57,55,55,58,250,10000
);
INSERT INTO PLAYER VALUES (1316,'De La Rosa','Roberto de la Rosa','Bronze - Non-Rare','Normal',61,'Pachuca','LIGA Bancomer MX','Mexico','ST','2000-01-04',67,58,59,48,18,58,0,0,0,0,0,0,'Right',3,2,33,38,38,41,41,37,50,57,57,57,59,59,59,58,58,60,150,10000
);
INSERT INTO PLAYER VALUES (1317,'Pintor','Lenny Pintor','Bronze - Rare','Normal',64,'ESTAC Troyes','Domino''s Ligue 2','France','ST','2000-08-05',75,68,63,49,27,49,0,0,0,0,0,0,'Right',3,3,37,42,42,44,44,40,53,60,60,62,63,63,63,63,63,63,150,10000
);
INSERT INTO PLAYER VALUES (1318,'Fabio Gonzalez','Fabio Gonzalez Estupinan','Silver - Non-Rare','Normal',65,'UD Las Palmas','LaLiga 1 I 2 I 3','Spain','CDM','1997-02-12',62,62,55,60,63,62,0,0,0,0,0,0,'Right',3,2,63,62,62,61,61,64,63,60,60,62,61,61,61,60,60,60,150,10000
);
INSERT INTO PLAYER VALUES (1319,'Mcgregor','Giovanni McGregor','Bronze - Non-Rare','Normal',58,'Crystal Palace','Premier League','England','CM','1999-01-09',66,56,43,57,51,59,0,0,0,0,0,0,'Right',3,2,55,56,56,56,56,57,57,55,55,56,54,54,54,54,54,51,150,10000
);
INSERT INTO PLAYER VALUES (1320,'Baptiste','Francis Baptiste','Bronze - Non-Rare','Normal',59,'ostersunds FK','Allsvenskan','England','ST','1999-11-08',82,62,60,44,20,46,0,0,0,0,0,0,'Right',3,2,31,39,39,41,41,35,47,57,57,56,58,58,58,59,59,58,150,10000
);
INSERT INTO PLAYER VALUES (1321,'Pedro Goncalves','Pedro Antonio Pereira Goncalves','Silver - Non-Rare','Normal',66,'Famalicao','Liga NOS','Portugal','CAM','1998-06-28',66,69,60,63,44,42,0,0,0,0,0,0,'Right',3,3,45,53,53,55,55,54,63,64,64,65,64,64,64,63,63,59,150,10000
);
INSERT INTO PLAYER VALUES (1322,'Niang','Fallou Niang','Bronze - Non-Rare','Normal',56,'La Berrichonne de Chateauroux','Domino''s Ligue 2','Senegal','CM','1995-05-01',68,57,43,55,51,60,0,0,0,0,0,0,'Right',3,2,54,54,54,55,55,55,55,55,55,55,54,54,54,54,54,52,150,10000
);
INSERT INTO PLAYER VALUES (1323,'Tenaglia','Nahuel Tenaglia','Silver - Non-Rare','Normal',65,'Club Atletico Talleres','SAF','Argentina','RB','1996-02-21',73,63,31,55,63,60,0,0,0,0,0,0,'Right',2,2,63,64,64,63,63,61,56,58,58,57,55,55,55,57,57,50,150,10000
);
INSERT INTO PLAYER VALUES (1324,'Durso','Tomas Durso','Bronze - Non-Rare','Normal',54,'Gimnasia y Esgrima La Plata','SAF','Argentina','GK','1999-02-26',0,0,0,0,0,0,57,54,54,26,53,57,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1325,'Melluso','Matias Melluso','Silver - Non-Rare','Normal',69,'Gimnasia y Esgrima La Plata','SAF','Argentina','LB','1998-06-09',73,68,44,61,66,61,0,0,0,0,0,0,'Left',3,3,65,68,68,68,68,65,63,65,65,62,61,61,61,63,63,58,150,10000
);
INSERT INTO PLAYER VALUES (1326,'Steven Prieto','Steven Nicanor Prieto Morales','Silver - Non-Rare','Normal',65,'R. Oviedo','LaLiga 1 I 2 I 3','Spain','ST','1997-07-30',62,59,64,48,26,66,0,0,0,0,0,0,'Right',3,3,41,41,41,43,43,43,53,57,57,58,61,61,61,58,58,64,150,10000
);
INSERT INTO PLAYER VALUES (1327,'Kwabena','Owusu Kwabena','Bronze - Non-Rare','Normal',62,'CD Leganes','LaLiga Santander','Ghana','LM','1997-06-18',72,64,53,53,26,57,0,0,0,0,0,0,'Right',3,2,37,43,43,46,46,43,54,61,61,60,60,60,60,61,61,58,150,10000
);
INSERT INTO PLAYER VALUES (1328,'Garcia','Juan Manuel Garcia','Silver - Non-Rare','Normal',66,'Arsenal de Sarandi','SAF','Argentina','ST','1992-11-14',65,62,65,45,31,70,0,0,0,0,0,0,'Right',5,3,44,43,43,44,44,43,51,56,56,58,61,61,61,59,59,65,150,10000
);
INSERT INTO PLAYER VALUES (1329,'Carranza','Julian Carranza','Silver - Non-Rare','Normal',67,'Club Atletico Banfield','SAF','Argentina','ST','2000-05-20',69,66,65,54,33,61,0,0,0,0,0,0,'Right',3,3,44,47,47,49,49,47,58,63,63,64,66,66,66,64,64,66,150,10000
);
INSERT INTO PLAYER VALUES (1330,'Payero','Martin Payero','Bronze - Rare','Normal',64,'Club Atletico Talleres','SAF','Argentina','CM','1998-09-11',60,66,52,60,59,67,0,0,0,0,0,0,'Right',2,2,62,61,61,61,61,63,63,62,62,62,62,62,62,61,61,60,150,10000
);
INSERT INTO PLAYER VALUES (1331,'Mattsson','Magnus Mattsson','Bronze - Non-Rare','Normal',63,'Silkeborg IF','Superliga','Denmark','CAM','1999-02-25',75,66,55,58,24,48,0,0,0,0,0,0,'Right',3,3,34,44,44,48,48,44,56,63,63,62,62,62,62,63,63,57,150,10000
);
INSERT INTO PLAYER VALUES (1332,'Mandroiu','Danny Mandroiu','Bronze - Rare','Normal',62,'Bohemian FC','SSE Airtricity League','Republic of Ireland','CAM','1998-10-20',65,61,59,61,51,64,0,0,0,0,0,0,'Right',3,2,54,56,56,57,57,56,59,61,61,61,60,60,60,61,61,59,150,10000
);
INSERT INTO PLAYER VALUES (1333,'Sanders','Max Sanders','Bronze - Non-Rare','Normal',58,'Brighton e Hove Albion','Premier League','England','CM','1999-01-04',55,59,52,57,53,52,0,0,0,0,0,0,'Right',3,2,54,54,54,54,54,56,57,56,56,57,56,56,56,56,56,53,150,10000
);
INSERT INTO PLAYER VALUES (1334,'Moreno','Junior Moreno','Silver - Non-Rare','Normal',70,'D.C. United','Major League Soccer','Venezuela','CDM','1993-07-20',64,63,57,69,67,72,0,0,0,0,0,0,'Right',4,2,68,67,67,67,67,69,67,64,64,64,62,62,62,63,63,62,150,10000
);
INSERT INTO PLAYER VALUES (1335,'Langer','Matti Langer','Bronze - Non-Rare','Normal',60,'Chemnitzer FC','3. Liga','Germany','CDM','1990-02-27',57,53,50,54,59,66,0,0,0,0,0,0,'Left',3,2,61,58,58,57,57,59,58,56,56,56,56,56,56,54,54,57,150,10000
);
INSERT INTO PLAYER VALUES (1336,'Cooper','Michael Cooper','Bronze - Non-Rare','Normal',58,'Plymouth Argyle','EFL League Two','England','GK','1999-10-08',0,0,0,0,0,0,60,63,55,30,57,52,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,150,10000
);
INSERT INTO PLAYER VALUES (1337,'Vavro','Denis Vavro','Silver - Non-Rare','Normal',72,'Lazio','Serie A TIM','Slovakia','CB','1996-04-10',68,57,49,51,70,79,0,0,0,0,0,0,'Right',3,2,71,64,64,62,62,67,60,55,55,57,56,56,56,53,53,58,150,10000
);
INSERT INTO PLAYER VALUES (1338,'Estevez','Nahuel Estevez','Silver - Non-Rare','Normal',65,'Estudiantes de La Plata','SAF','Argentina','RM','1995-11-14',69,65,62,63,60,59,0,0,0,0,0,0,'Right',3,3,59,62,62,63,63,61,63,64,64,64,63,63,63,64,64,62,150,10000
);
INSERT INTO PLAYER VALUES (1339,'Al Shahrani','Mohammed Al Shahrani','Bronze - Non-Rare','Normal',59,'Damac FC','Saudi Professional League','Saudi Arabia','RM','1996-03-26',71,60,54,55,51,58,0,0,0,0,0,0,'Right',3,2,54,56,56,56,56,56,57,58,58,58,58,58,58,58,58,56,150,10000
);
INSERT INTO PLAYER VALUES (1340,'Kike','Enrique Gomez Hermoso','Bronze - Rare','Normal',63,'SD Huesca','LaLiga 1 I 2 I 3','Spain','CB','1999-08-10',58,42,29,36,64,62,0,0,0,0,0,0,'Right',2,2,62,55,55,52,52,53,43,41,41,40,41,41,41,40,40,42,150,10000
);
INSERT INTO PLAYER VALUES (1341,'Ormazabal','Matias Ormazabal','Bronze - Non-Rare','Normal',52,'Curico Unido','Campeonato Scotiabank','Chile','RW','1998-09-21',68,52,56,46,49,52,0,0,0,0,0,0,'Right',2,3,47,49,49,50,50,47,48,51,51,51,52,52,52,52,52,53,150,10000
);
INSERT INTO PLAYER VALUES (1342,'Safranko','Pavol Safranko','Bronze - Non-Rare','Normal',63,'Sepsi OSK','Romania Liga I','Slovakia','ST','1994-11-16',68,59,60,48,30,67,0,0,0,0,0,0,'Right',3,2,42,43,43,45,45,43,52,58,58,57,59,59,59,58,58,62,150,10000
);
INSERT INTO PLAYER VALUES (1343,'Sabbi','Emmanuel Sabbi','Silver - Rare','Normal',68,'Hobro IK','Superliga','United States','RM','1997-12-24',89,75,63,56,33,58,0,0,0,0,0,0,'Right',4,4,44,50,50,52,52,47,59,67,67,67,68,68,68,69,69,66,250,10000
);
INSERT INTO PLAYER VALUES (1344,'Ardaiz','Joaquin Ardaiz','Silver - Non-Rare','Normal',66,'Vancouver Whitecaps FC','Major League Soccer','Uruguay','ST','1999-01-11',79,62,64,50,20,68,0,0,0,0,0,0,'Left',3,3,39,38,38,40,40,38,49,59,59,59,62,62,62,61,61,65,150,10000
);
INSERT INTO PLAYER VALUES (1345,'Erick','Erick de Arruda Serafim','Silver - Non-Rare','Normal',65,'Gil Vicente FC','Liga NOS','Brazil','LW','1997-12-10',75,69,58,58,34,44,0,0,0,0,0,0,'Left',2,3,38,47,47,51,51,44,55,64,64,62,63,63,63,65,65,60,150,10000
);
INSERT INTO PLAYER VALUES (1346,'Ebosse','Enzo Ebosse','Bronze - Non-Rare','Normal',60,'Le Mans FC','Domino''s Ligue 2','France','LB','1999-03-11',67,58,35,49,58,65,0,0,0,0,0,0,'Left',3,2,59,59,59,59,59,56,52,55,55,51,51,51,51,53,53,49,150,10000
);
INSERT INTO PLAYER VALUES (1347,'Jovanovic','SaSa Jovanovic','Silver - Non-Rare','Normal',67,'Al Fateh','Saudi Professional League','Serbia','RM','1991-12-15',83,66,60,64,33,55,0,0,0,0,0,0,'Left',5,3,41,51,51,54,54,49,59,66,66,64,64,64,64,66,66,62,150,10000
);
INSERT INTO PLAYER VALUES (1348,'Moreno','Neyder Moreno','Silver - Non-Rare','Normal',68,'Atletico Nacional','Liga Dimayor','Colombia','RM','1997-02-09',77,69,62,64,48,56,0,0,0,0,0,0,'Right',3,3,52,58,58,60,60,57,62,67,67,66,66,66,66,68,68,62,150,10000
);
INSERT INTO PLAYER VALUES (1349,'Heredia','Leonardo Heredia','Silver - Non-Rare','Normal',68,'Atletico Tucuman','SAF','Argentina','RM','1996-10-11',72,69,64,64,34,67,0,0,0,0,0,0,'Right',4,3,46,51,51,53,53,52,62,67,67,67,67,67,67,67,67,66,150,10000
);
INSERT INTO PLAYER VALUES (1350,'Chancalay','Tomas Chancalay','Silver - Non-Rare','Normal',69,'Colon de Santa Fe','SAF','Argentina','LW','1999-01-01',80,73,63,63,37,61,0,0,0,0,0,0,'Right',3,3,47,53,53,56,56,53,63,68,68,68,68,68,68,69,69,65,150,10000
);
INSERT INTO PLAYER VALUES (1351,'Diarra','Souleymane Diarra','Silver - Rare','Normal',66,'Gazisehir Gaziantep F.K.','Super Lig','Mali','RM','1995-01-30',66,69,56,62,65,67,0,0,0,0,0,0,'Right',3,3,65,66,66,67,67,67,66,65,65,65,63,63,63,64,64,60,250,10000
);
INSERT INTO PLAYER VALUES (1352,'Brown','Jaden Brown','Bronze - Non-Rare','Normal',59,'Huddersfield Town','EFL Championship','England','LB','1999-01-24',69,52,35,43,59,61,0,0,0,0,0,0,'Left',3,2,57,58,58,57,57,52,47,52,52,48,49,49,49,51,51,47,150,10000
);
INSERT INTO PLAYER VALUES (1353,'Marsh','George Marsh','Bronze - Non-Rare','Normal',63,'Leyton Orient','EFL League Two','England','CDM','1998-11-05',61,57,44,58,61,62,0,0,0,0,0,0,'Right',3,2,61,61,61,61,61,62,58,56,56,55,54,54,54,54,54,52,150,10000
);
INSERT INTO PLAYER VALUES (1354,'Roles','Jack Roles','Bronze - Rare','Normal',63,'Cambridge United','EFL League Two','Cyprus','CAM','1999-02-26',67,63,59,59,47,52,0,0,0,0,0,0,'Left',4,3,49,55,55,57,57,55,61,62,62,62,62,62,62,62,62,59,150,10000
);
INSERT INTO PLAYER VALUES (1355,'Bennetts','Keanan Bennetts','Bronze - Rare','Normal',61,'Borussia Monchengladbach','Bundesliga','England','LM','1999-03-09',75,66,57,56,40,55,0,0,0,0,0,0,'Left',4,2,45,51,51,53,53,50,55,60,60,58,59,59,59,61,61,57,150,10000
);
INSERT INTO PLAYER VALUES (1356,'Skipp','Oliver Skipp','Silver - Rare','Normal',67,'Tottenham Hotspur','Premier League','England','CDM','2000-09-16',63,63,45,63,62,62,0,0,0,0,0,0,'Right',3,2,62,63,63,63,63,66,64,61,61,61,59,59,59,59,59,55,250,10000
);
INSERT INTO PLAYER VALUES (1357,'Freitas','Gonzalo Freitas','Silver - Rare','Normal',66,'CD Everton de Vina del Mar','Campeonato Scotiabank','Uruguay','CDM','1991-10-02',57,58,49,60,66,78,0,0,0,0,0,0,'Right',3,2,69,63,63,62,62,65,61,59,59,58,58,58,58,57,57,59,250,10000
);
INSERT INTO PLAYER VALUES (1358,'Messi','Lionel Messi','Gold - Rare','CL',94,'FC Barcelona','LaLiga Santander','Argentina','RW','1987-06-24',87,96,92,92,39,66,0,0,0,0,0,0,'Left',4,4,53,63,63,68,68,66,87,92,92,94,93,93,93,93,93,89,112000,2100000
);
INSERT INTO PLAYER VALUES (1359,'Ronaldo','C. Ronaldo dos Santos Aveiro','Gold - Rare','CL',93,'Piemonte Calcio','Serie A TIM','Portugal','ST','1985-02-05',90,89,93,82,35,78,0,0,0,0,0,0,'Right',4,5,54,61,61,65,65,62,81,88,88,89,91,91,91,90,90,91,89000,1700000
);
INSERT INTO PLAYER VALUES (1360,'Neymar','Neymar da Silva Santos Jr.','Gold - Rare','CL',92,'Paris Saint-Germain','Ligue 1 Conforama','Brazil','LW','1992-02-05',91,95,85,87,32,58,0,0,0,0,0,0,'Right',5,5,47,61,61,67,67,61,83,90,90,90,90,90,90,91,91,84,73000,1400000
);
INSERT INTO PLAYER VALUES (1361,'De Bruyne','Kevin De Bruyne','Gold - Rare','CL',91,'Manchester City','Premier League','Belgium','CAM','1991-06-28',76,87,86,92,61,78,0,0,0,0,0,0,'Right',5,4,67,73,73,77,77,77,88,88,88,89,87,87,87,87,87,83,18500,350000
);
INSERT INTO PLAYER VALUES (1362,'Oblak','Jan Oblak','Gold - Rare','CL',91,'Atlético Madrid','LaLiga Santander','Slovenia','GK','1993-01-07',0,0,0,0,0,0,87,89,92,50,78,90,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5900,110000
);
INSERT INTO PLAYER VALUES (1363,'Hazard','Eden Hazard','Gold - Rare','CL',91,'Real Madrid','LaLiga Santander','Belgium','LW','1991-01-07',91,94,83,86,35,66,0,0,0,0,0,0,'Right',4,4,49,61,61,66,66,63,83,89,89,90,89,89,89,89,89,84,21250,400000
);
INSERT INTO PLAYER VALUES (1364,'Modric','Luka Modric','Gold - Rare','CL',90,'Real Madrid','LaLiga Santander','Croatia','CM','1985-09-09',74,90,76,89,72,66,0,0,0,0,0,0,'Right',4,4,72,79,79,82,82,82,87,85,85,87,83,83,83,85,85,77,5800,110000
);
INSERT INTO PLAYER VALUES (1365,'Ter Stegen','Marc-André ter Stegen','Gold - Rare','CL',90,'FC Barcelona','LaLiga Santander','Germany','GK','1992-04-30',0,0,0,0,0,0,88,90,85,43,88,88,'Right',4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5500,100000
);
INSERT INTO PLAYER VALUES (1366,'Salah','Mohamed Salah','Gold - Rare','CL',90,'Liverpool','Premier League','Egypt','RW','1992-06-15',93,89,86,81,45,74,0,0,0,0,0,0,'Left',3,4,58,67,67,71,71,67,82,87,87,88,88,88,88,88,88,85,18250,350000
);
INSERT INTO PLAYER VALUES (1367,'Van Dijk','Virgil van Dijk','Gold - Rare','CL',90,'Liverpool','Premier League','Holland','CB','1991-07-08',77,72,60,70,90,86,0,0,0,0,0,0,'Right',3,2,88,81,81,79,79,84,75,70,70,70,69,69,69,67,67,70,49750,950000
);
INSERT INTO PLAYER VALUES (1368,'Chiellini','Giorgio Chiellini','Gold - Rare','CL',89,'Piemonte Calcio','Serie A TIM','Italy','CB','1984-08-14',68,62,46,58,90,82,0,0,0,0,0,0,'Left',3,2,86,77,77,74,74,77,62,58,58,56,56,56,56,56,56,59,4200,80000
);
INSERT INTO PLAYER VALUES (1369,'Agüero','Sergio Agüero','Gold - Rare','CL',89,'Manchester City','Premier League','Argentina','ST','1988-06-02',80,88,90,77,33,74,0,0,0,0,0,0,'Right',4,4,51,57,57,61,61,58,77,84,84,86,88,88,88,86,86,87,8700,160000
);
INSERT INTO PLAYER VALUES (1370,'Ramos','Sergio Ramos García','Gold - Rare','CL',89,'Real Madrid','LaLiga Santander','Spain','CB','1986-03-30',72,74,68,75,87,85,0,0,0,0,0,0,'Right',3,3,87,83,83,81,81,84,78,74,74,74,73,73,73,72,72,75,8100,150000
);
INSERT INTO PLAYER VALUES (1371,'Suárez','Luis Suárez','Gold - Rare','CL',89,'FC Barcelona','LaLiga Santander','Uruguay','ST','1987-01-24',73,84,89,80,51,84,0,0,0,0,0,0,'Right',4,3,63,64,64,67,67,68,79,83,83,84,85,85,85,84,84,86,5500,100000
);
INSERT INTO PLAYER VALUES (1372,'Lewandowski','Robert Lewandowski','Gold - Rare','CL',89,'FC Bayern München','Bundesliga','Poland','ST','1988-08-21',77,85,87,74,41,82,0,0,0,0,0,0,'Right',4,4,58,58,58,61,61,63,77,81,81,83,85,85,85,83,83,86,3900,75000
);
INSERT INTO PLAYER VALUES (1373,'Busquets','Sergio Busquets Burgos','Gold - Rare','CL',89,'FC Barcelona','LaLiga Santander','Spain','CDM','1988-07-16',42,81,62,80,85,80,0,0,0,0,0,0,'Right',3,3,82,78,78,79,79,86,84,76,76,78,75,75,75,73,73,71,3900,75000
);
INSERT INTO PLAYER VALUES (1374,'Koulibaly','Kalidou Koulibaly','Gold - Rare','CL',89,'Napoli','Serie A TIM','Senegal','CB','1991-06-20',71,68,28,54,89,87,0,0,0,0,0,0,'Right',3,2,87,77,77,74,74,80,65,60,60,59,58,58,58,56,56,57,4200,80000
);
INSERT INTO PLAYER VALUES (1375,'Kane','Harry Kane','Gold - Rare','CL',89,'Tottenham Hotspur','Premier League','England','ST','1993-07-28',70,81,91,79,47,83,0,0,0,0,0,0,'Right',4,3,61,62,62,65,65,66,79,82,82,83,85,85,85,82,82,87,4400,80000
);
INSERT INTO PLAYER VALUES (1376,'Alisson','Alisson Ramses Becker','Gold - Rare','CL',89,'Liverpool','Premier League','Brazil','GK','1992-10-02',0,0,0,0,0,0,85,89,84,52,85,90,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3600,70000
);
INSERT INTO PLAYER VALUES (1377,'Kanté','N''Golo Kanté','Gold - Rare','CL',89,'Chelsea','Premier League','France','CDM','1991-03-29',78,81,65,77,87,83,0,0,0,0,0,0,'Right',3,2,84,85,85,85,85,87,83,79,79,79,77,77,77,77,77,73,26500,500000
);
INSERT INTO PLAYER VALUES (1378,'Mbappé','Kylian Mbappé','Gold - Rare','CL',89,'Paris Saint-Germain','Ligue 1 Conforama','France','ST','1998-12-20',96,90,84,78,39,75,0,0,0,0,0,0,'Right',4,5,55,63,63,67,67,62,78,87,87,86,88,88,88,88,88,87,81500,1500000
);
INSERT INTO PLAYER VALUES (1379,'Griezmann','Antoine Griezmann','Gold - Rare','CL',89,'FC Barcelona','LaLiga Santander','France','CF','1991-03-21',81,89,86,84,57,72,0,0,0,0,0,0,'Left',3,4,65,71,71,73,73,71,83,87,87,87,87,87,87,87,87,86,7500,140000
);
INSERT INTO PLAYER VALUES (1380,'Piqué','Gerard Piqué Bernabeu','Gold - Rare','CL',88,'FC Barcelona','LaLiga Santander','Spain','CB','1987-02-02',56,69,61,72,88,80,0,0,0,0,0,0,'Right',3,2,85,79,79,77,77,84,77,70,70,71,70,70,70,68,68,70,3600,65000
);
INSERT INTO PLAYER VALUES (1381,'Handanovic','Samir Handanovic','Gold - Rare','CL',88,'Inter','Serie A TIM','Slovenia','GK','1984-07-14',0,0,0,0,0,0,88,89,85,53,69,89,'Right',2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3300,60000
);
INSERT INTO PLAYER VALUES (1382,'Neuer','Manuel Neuer','Gold - Rare','CL',88,'FC Bayern München','Bundesliga','Germany','GK','1986-03-27',0,0,0,0,0,0,87,87,87,56,91,85,'Right',4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3300,60000
);
INSERT INTO PLAYER VALUES (1383,'Ruffier','Stéphane Ruffier','Gold - Rare','IF',86,'AS Saint-Étienne','Ligue 1 Conforama','France','GK','1986-09-27',0,0,0,0,0,0,84,85,86,49,77,87,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10500,50000
);
INSERT INTO PLAYER VALUES (1384,'Hummels','Mats Hummels','Gold - Rare','IF',88,'Borussia Dortmund','Bundesliga','Germany','CB','1988-12-16',52,75,59,78,90,77,0,0,0,0,0,0,'Right',3,3,86,80,80,78,78,85,79,71,71,73,70,70,70,68,68,69,10750,95000
);
INSERT INTO PLAYER VALUES (1385,'Alonso','Marcos Alonso Mendoza','Gold - Rare','IF',84,'Chelsea','Premier League','Spain','LB','1990-12-28',69,80,77,82,83,82,0,0,0,0,0,0,'Left',3,3,82,83,83,83,83,82,82,80,80,79,80,80,80,79,79,80,10250,40000
);
INSERT INTO PLAYER VALUES (1386,'Mina','Yerry Mina','Gold - Rare','IF',82,'Everton','Premier League','Colombia','CB','1994-09-23',55,61,58,60,83,84,0,0,0,0,0,0,'Right',3,2,81,71,71,69,69,74,65,60,60,61,61,61,61,59,59,65,10250,30000
);
INSERT INTO PLAYER VALUES (1387,'Gomis','Alfred Gomis','Gold - Rare','IF',81,'Dijon FCO','Ligue 1 Conforama','Senegal','GK','1993-09-05',0,0,0,0,0,0,82,82,81,47,75,82,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9900,32500
);
INSERT INTO PLAYER VALUES (1388,'Parejo','Daniel Parejo Muñoz','Gold - Rare','IF',87,'Valencia CF','LaLiga Santander','Spain','CM','1989-04-16',42,80,82,90,71,70,0,0,0,0,0,0,'Right',4,3,70,72,72,75,75,79,85,79,79,82,79,79,79,78,78,76,10750,100000
);
INSERT INTO PLAYER VALUES (1389,'Troost-Ekong','William Troost-Ekong','Gold - Rare','IF',81,'Udinese','Serie A TIM','Nigeria','CB','1993-09-01',71,51,38,51,83,82,0,0,0,0,0,0,'Right',3,2,80,72,72,68,68,71,57,53,53,51,51,51,51,49,49,54,9900,32500
);
INSERT INTO PLAYER VALUES (1390,'Taison','Taison Barcellos Freda','Gold - Rare','IF',84,'Shakhtar Donetsk','Ukraine Liga','Brazil','CAM','1988-01-13',93,88,82,78,49,71,0,0,0,0,0,0,'Right',3,4,57,66,66,70,70,67,79,83,83,83,83,83,83,84,84,80,10250,37500
);
INSERT INTO PLAYER VALUES (1391,'Doucouré','Abdoulaye Doucouré','Gold - Rare','IF',84,'Watford','Premier League','France','CM','1993-01-01',72,80,78,76,83,84,0,0,0,0,0,0,'Right',3,3,81,81,81,82,82,84,83,79,79,80,80,80,80,78,78,78,10250,95000
);
INSERT INTO PLAYER VALUES (1392,'Soucek','Tomáš Soucek','Gold - Rare','IF',82,'Slavia Praha','Česká Liga','Czech Republic','CDM','1995-02-27',73,76,72,75,83,85,0,0,0,0,0,0,'Right',3,3,82,81,81,80,80,81,79,76,76,76,75,75,75,75,75,76,10250,37500
);
INSERT INTO PLAYER VALUES (1393,'Griezmann','Antoine Griezmann','Gold - Rare','IF',90,'FC Barcelona','LaLiga Santander','France','LW','1991-03-21',82,90,88,86,58,73,0,0,0,0,0,0,'Left',3,4,66,71,71,74,74,72,84,88,88,89,89,89,89,88,88,87,31500,600000
);
INSERT INTO PLAYER VALUES (1394,'Mantalos','Petros Mantalos','Gold - Rare','IF',81,'AEK Athens','Hellas Liga','Greece','LM','1991-08-31',79,84,76,82,54,67,0,0,0,0,0,0,'Right',4,3,59,65,65,68,68,68,78,80,80,81,79,79,79,80,80,75,9900,32500
);
INSERT INTO PLAYER VALUES (1395,'Nainggolan','Radja Nainggolan','Gold - Rare','IF',85,'Cagliari','Serie A TIM','Belgium','RW','1988-05-04',74,85,82,80,85,84,0,0,0,0,0,0,'Right',3,3,83,84,84,85,85,86,85,82,82,83,83,83,83,82,82,80,10500,120000
);
INSERT INTO PLAYER VALUES (1396,'Martínez','Lautaro Martínez','Gold - Rare','IF',84,'Inter','Serie A TIM','Argentina','ST','1997-08-22',84,85,82,71,43,86,0,0,0,0,0,0,'Right',4,4,58,58,58,60,60,62,75,80,80,82,83,83,83,81,81,84,10250,37500
);
INSERT INTO PLAYER VALUES (1397,'Di María','Ángel Di María','Gold - Rare','IF',87,'Paris Saint-Germain','Ligue 1 Conforama','Argentina','RW','1988-02-14',85,88,82,85,49,69,0,0,0,0,0,0,'Left',2,5,58,67,67,70,70,67,80,85,85,85,84,84,84,85,85,80,10750,130000
);
INSERT INTO PLAYER VALUES (1398,'Yedder','Wissam Ben Yedder','Gold - Rare','IF',85,'AS Monaco Football Club SA','Ligue 1 Conforama','France','ST','1990-08-12',86,87,85,79,41,63,0,0,0,0,0,0,'Right',5,4,53,60,60,63,63,60,76,83,83,84,86,86,86,85,85,84,20750,390000
);
INSERT INTO PLAYER VALUES (1399,'Grealish','Jack Grealish','Gold - Rare','IF',81,'Aston Villa','Premier League','England','LW','1995-09-10',79,83,73,79,44,63,0,0,0,0,0,0,'Right',3,4,52,60,60,65,65,63,76,78,78,80,78,78,78,79,79,72,9900,30000
);
INSERT INTO PLAYER VALUES (1400,'Oršic','Mislav Oršic','Gold - Rare','IF',79,'GNK Dinamo Zagreb','Croatia Liga','Croatia','LM','1992-12-29',93,81,84,74,56,66,0,0,0,0,0,0,'Right',4,3,59,68,68,70,70,66,73,78,78,77,78,78,78,79,79,76,9700,55000
);
INSERT INTO PLAYER VALUES (1401,'Morris','Jordan Morris','Gold - Rare','IF',78,'Seattle Sounders FC','Major League Soccer','United States','LM','1994-10-26',89,73,79,66,41,82,0,0,0,0,0,0,'Right',2,3,56,56,56,58,58,57,67,73,73,74,76,76,76,74,74,80,9600,32500
);
INSERT INTO PLAYER VALUES (1402,'Cornelius','Andreas Cornelius','Gold - Rare','IF',80,'Parma','Serie A TIM','Denmark','ST','1993-03-16',70,72,81,61,46,84,0,0,0,0,0,0,'Left',3,3,58,52,52,54,54,57,66,70,70,73,76,76,76,72,72,81,9800,35000
);
INSERT INTO PLAYER VALUES (1403,'Candeias','Daniel João Santos Candeias','Gold - Rare','IF',79,'Gençlerbirliği','Süper Lig','Portugal','ST','1988-02-25',90,81,73,78,57,74,0,0,0,0,0,0,'Right',4,4,63,69,69,71,71,69,75,80,80,79,78,78,78,79,79,75,9700,45000
);
INSERT INTO PLAYER VALUES (1404,'Goitom','Henok Goitom','Gold - Rare','IF',78,'AIK','Allsvenskan','Eritrea','ST','1984-09-22',62,75,78,73,51,81,0,0,0,0,0,0,'Right',2,3,60,57,57,60,60,64,73,74,74,77,78,78,78,74,74,79,9600,32500
);
INSERT INTO PLAYER VALUES (1405,'Ángel','Ángel Luís Rodríguez Díaz','Gold - Rare','IF',82,'Getafe CF','LaLiga Santander','Spain','ST','1987-04-26',77,82,83,64,38,67,0,0,0,0,0,0,'Right',3,3,51,54,54,56,56,55,69,75,75,78,81,81,81,78,78,81,10250,30000
);
INSERT INTO PLAYER VALUES (1406,'Lukebakio','Dodi Lukebakio','Gold - Rare','FUTmas SBC',84,'Hertha BSC','Bundesliga','Belgium','ST','1997-09-24',93,87,84,76,37,73,0,0,0,0,0,0,'Left',4,4,51,60,60,64,64,58,75,83,83,83,85,85,85,85,85,83,9150,90000
);
INSERT INTO PLAYER VALUES (1407,'Malcuit','Kévin Malcuit','Gold - Rare','FUTmas SBC',84,'Napoli','Serie A TIM','France','RB','1991-07-31',90,85,68,80,81,80,0,0,0,0,0,0,'Right',3,3,80,83,83,83,83,81,79,82,82,79,78,78,78,81,81,76,10250,658264
);
INSERT INTO PLAYER VALUES (1408,'Fekir','Nabil Fekir','Gold - Rare','FUTmas SBC',87,'Real Betis','LaLiga Santander','France','CAM','1993-07-18',82,91,86,84,36,82,0,0,0,0,0,0,'Left',3,4,53,59,59,64,64,63,80,86,86,86,86,86,86,87,87,83,8150,656251
);
INSERT INTO PLAYER VALUES (1409,'Costa','Douglas Costa de Souza','Gold - Rare','FUTmas SBC',86,'Piemonte Calcio','Serie A TIM','Brazil','LM','1990-09-14',95,92,75,81,45,66,0,0,0,0,0,0,'Left',3,5,54,65,65,69,69,64,78,84,84,84,83,83,83,85,85,78,6250,654054
);
INSERT INTO PLAYER VALUES (1410,'Murillo','Jeison Murillo','Gold - Rare','FUTmas SBC',84,'Sampdoria','Serie A TIM','Colombia','CB','1992-05-27',79,72,44,65,85,85,0,0,0,0,0,0,'Right',3,2,84,79,79,77,77,79,68,67,67,64,63,63,63,63,63,64,4000,350005
);
INSERT INTO PLAYER VALUES (1411,'Rashford','Marcus Rashford','Gold - Rare','FUTmas SBC',85,'Manchester United','Premier League','England','ST','1997-10-31',94,87,84,78,47,80,0,0,0,0,0,0,'Right',3,5,59,65,65,69,69,65,77,85,85,84,85,85,85,85,85,84,7500,650000
);
INSERT INTO PLAYER VALUES (1412,'Williams','Iñaki Williams Arthuer','Gold - Rare','FUTmas SBC',84,'Athletic Club','LaLiga Santander','Spain','ST','1994-06-15',96,82,83,76,43,84,0,0,0,0,0,0,'Right',2,4,57,62,62,65,65,61,74,83,83,81,83,83,83,84,84,84,3600,850000
);
INSERT INTO PLAYER VALUES (1413,'Cavani','Edinson Cavani','Gold - Rare','FUTmas SBC',89,'Paris Saint-Germain','Ligue 1 Conforama','Uruguay','ST','1987-02-14',77,81,88,73,56,84,0,0,0,0,0,0,'Right',4,3,66,67,67,69,69,68,76,81,81,82,85,85,85,82,82,87,8500,750000
);
INSERT INTO PLAYER VALUES (1414,'Rebic','Ante Rebic','Gold - Rare','FUTmas SBC',85,'Milan','Serie A TIM','Croatia','ST','1993-09-21',93,85,85,77,44,86,0,0,0,0,0,0,'Right',4,4,60,63,63,66,66,63,76,83,83,82,84,84,84,84,84,85,10000,777777
);
INSERT INTO PLAYER VALUES (1415,'De Gea','David De Gea Quintana','Gold - Rare','FUTmas SBC',90,'Manchester United','Premier League','Spain','GK','1990-11-07',0,0,0,0,0,0,92,93,86,58,82,87,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9850,450000
);
INSERT INTO PLAYER VALUES (1416,'Roussillon','Jérôme Roussillon','Gold - Rare','FUTmas Obj',84,'VfL Wolfsburg','Bundesliga','France','LB','1993-01-06',91,82,67,79,82,81,0,0,0,0,0,0,'Left',3,3,81,84,84,84,84,81,79,81,81,78,78,78,78,80,80,76,2365,350000
);
INSERT INTO PLAYER VALUES (1417,'Sissoko','Moussa Sissoko','Gold - Rare','FUTmas SBC',84,'Tottenham Hotspur','Premier League','France','CM','1989-08-16',83,82,74,83,82,92,0,0,0,0,0,0,'Right',3,3,83,83,83,84,84,84,83,83,83,81,81,81,81,81,81,80,8950,250000
);
INSERT INTO PLAYER VALUES (1418,'Acuña','Marcos Acuña','Gold - Rare','FUTmas SBC',86,'Sporting CP','Liga NOS','Argentina','LW','1991-10-28',82,89,80,87,83,89,0,0,0,0,0,0,'Left',3,4,83,85,85,86,86,85,85,86,86,85,84,84,84,85,85,81,8000,150000
);
INSERT INTO PLAYER VALUES (1419,'Mendy','Ferland Mendy','Gold - Rare','FUTmas SBC',85,'Real Madrid','LaLiga Santander','France','LB','1995-06-08',93,84,70,80,80,86,0,0,0,0,0,0,'Left',5,4,81,84,84,84,84,83,83,84,84,82,82,82,82,83,83,79,7050,200000
);
INSERT INTO PLAYER VALUES (1420,'Sánchez','Davinson Sánchez','Gold - Rare','FUTmas SBC',85,'Tottenham Hotspur','Premier League','Colombia','CB','1996-06-12',76,69,47,59,85,84,0,0,0,0,0,0,'Right',3,2,84,77,77,75,75,79,68,63,63,63,62,62,62,60,60,62,6420,300000
);
INSERT INTO PLAYER VALUES (1421,'Sanches','Renato Júnior Luz Sanches','Gold - Rare','FUTmas SBC',84,'LOSC Lille','Ligue 1 Conforama','Portugal','CM','1997-08-18',83,83,81,81,78,86,0,0,0,0,0,0,'Right',4,3,79,79,79,80,80,82,82,81,81,82,82,82,82,81,81,80,3450,400000
);
INSERT INTO PLAYER VALUES (1422,'Lozano','Hirving Lozano','Gold - Rare','FUTmas SBC',84,'Napoli','Serie A TIM','Mexico','RW','1995-07-30',95,85,81,78,43,68,0,0,0,0,0,0,'Right',3,4,53,63,63,67,67,63,76,83,83,83,83,83,83,84,84,80,2154,600000
);
INSERT INTO PLAYER VALUES (1423,'Vidal','Arturo Vidal','Gold - Rare','FUTmas SBC',86,'FC Barcelona','LaLiga Santander','Chile','CM','1987-05-22',70,83,82,82,87,88,0,0,0,0,0,0,'Right',4,3,87,84,84,84,84,87,85,82,82,83,83,83,83,81,81,82,3654,800000
);
INSERT INTO PLAYER VALUES (1424,'Shaqiri','Xherdan Shaqiri','Gold - Rare','FUTmas SBC',84,'Liverpool','Premier League','Switzerland','RW','1991-10-10',83,87,80,83,47,76,0,0,0,0,0,0,'Left',4,5,57,65,65,70,70,68,80,82,82,83,82,82,82,82,82,77,2548,100000
);
INSERT INTO PLAYER VALUES (1425,'Messi','Lionel Messi','Gold - Rare','TOTY',99,'FC Barcelona','LaLiga Santander','Argentina','RW','1987-06-24',96,99,98,99,50,85,0,0,0,0,0,0,'Left',4,4,64,72,72,76,76,75,94,98,98,99,98,98,98,98,98,96,315000,9000000
);
INSERT INTO PLAYER VALUES (1426,'Mané','Sadio Mané','Gold - Rare','TOTY',97,'Liverpool','Premier League','Senegal','LW','1992-04-10',99,97,95,92,57,88,0,0,0,0,0,0,'Right',4,4,70,75,75,78,78,76,91,96,96,97,97,97,97,96,96,96,265000,5000000
);
INSERT INTO PLAYER VALUES (1427,'Mbappé','Kylian Mbappé','Gold - Rare','TOTY',98,'Paris Saint-Germain','Ligue 1 Conforama','France','ST','1998-12-20',99,98,96,93,55,90,0,0,0,0,0,0,'Right',4,5,68,75,75,79,79,75,90,97,97,97,97,97,97,97,97,97,570000,10800000
);
INSERT INTO PLAYER VALUES (1428,'Alisson','Alisson Ramses Becker','Gold - Rare','TOTY',97,'Liverpool','Premier League','Brazil','GK','1992-10-02',0,0,0,0,0,0,97,97,92,70,95,95,'Right',3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,78000,900000
);
INSERT INTO PLAYER VALUES (1429,'Robertson','Andrew Robertson','Gold - Rare','TOTY',94,'Liverpool','Premier League','Scotland','LB','1994-03-11',94,91,75,94,92,89,0,0,0,0,0,0,'Left',2,3,89,94,94,95,95,93,92,92,92,90,89,89,89,90,90,84,82000,1600000
);
INSERT INTO PLAYER VALUES (1430,'De Ligt','Matthijs de Ligt','Gold - Rare','TOTY',96,'Piemonte Calcio','Serie A TIM','Holland','CB','1999-08-12',85,88,75,86,96,96,0,0,0,0,0,0,'Right',4,2,96,91,91,90,90,95,90,83,83,85,83,83,83,81,81,83,98000,1900000
);
INSERT INTO PLAYER VALUES (1431,'Van Dijk','Virgil van Dijk','Gold - Rare','TOTY',99,'Liverpool','Premier League','Holland','CB','1991-07-08',88,90,80,92,99,98,0,0,0,0,0,0,'Right',3,2,97,92,92,91,91,96,91,86,86,87,86,86,86,84,84,85,316000,6000000
);
INSERT INTO PLAYER VALUES (1432,'Alexander-Arnold','Trent Alexander-Arnold','Gold - Rare','TOTY',95,'Liverpool','Premier League','England','RB','1998-10-07',92,92,85,97,92,87,0,0,0,0,0,0,'Right',4,3,90,94,94,95,95,94,94,94,94,92,92,92,92,92,92,89,111000,2100000
);
INSERT INTO PLAYER VALUES (1433,'Kanté','N''Golo Kanté','Gold - Rare','TOTY',97,'Chelsea','Premier League','France','CDM','1991-03-29',91,95,88,95,97,93,0,0,0,0,0,0,'Right',3,2,92,94,94,95,95,97,97,94,94,95,93,93,93,92,92,89,252000,4800000
);
INSERT INTO PLAYER VALUES (1434,'De Jong','Frenkie de Jong','Gold - Rare','TOTY',94,'FC Barcelona','LaLiga Santander','Holland','CM','1997-05-12',88,95,87,93,88,90,0,0,0,0,0,0,'Right',3,4,88,90,90,91,91,92,95,93,93,94,93,93,93,92,92,90,160000,3000000
);
INSERT INTO PLAYER VALUES (1435,'De Bruyne','Kevin De Bruyne','Gold - Rare','TOTY',98,'Manchester City','Premier League','Belgium','CAM','1991-06-28',88,96,96,99,82,93,0,0,0,0,0,0,'Right',5,4,84,87,87,90,90,91,96,96,96,97,96,96,96,96,96,93,292000,5500000
);
INSERT INTO PLAYER VALUES (1436,'Neuer','Manuel Neuer','Gold - Rare','TOTY Flashback SBC',92,'FC Bayern München','Bundesliga','Germany','GK','1986-03-27',0,0,0,0,0,0,92,91,91,63,95,92,'Right',4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3300,60000
);
INSERT INTO PLAYER VALUES (1437,'Varane','Raphaël Varane','Gold - Rare','Headliners',88,'Real Madrid','LaLiga Santander','France','CB','1993-04-25',86,70,50,67,88,84,0,0,0,0,0,0,'Right',3,2,87,81,81,78,78,84,75,69,69,70,68,68,68,66,66,67,90000,1700000
);
INSERT INTO PLAYER VALUES (1438,'Neymar','Neymar da Silva Santos Jr.','Gold - Rare','Headliners',94,'Paris Saint-Germain','Ligue 1 Conforama','Brazil','CAM','1992-02-05',93,97,89,91,34,60,0,0,0,0,0,0,'Right',5,5,48,63,63,69,69,63,85,93,93,93,92,92,92,94,94,87,406000,7700000
);
INSERT INTO PLAYER VALUES (1439,'Mertens','Dries Mertens','Gold - Rare','Headliners',90,'Napoli','Serie A TIM','Belgium','CF','1987-05-06',91,93,90,86,38,56,0,0,0,0,0,0,'Right',4,4,49,64,64,69,69,64,83,89,89,90,90,90,90,91,91,83,70000,1300000
);
INSERT INTO PLAYER VALUES (1440,'Alberto','Luis Alberto Romero Alconchel','Gold - Rare','Headliners',88,'Lazio','Serie A TIM','Spain','CAM','1992-09-28',77,88,82,91,53,63,0,0,0,0,0,0,'Right',3,4,58,66,66,70,70,70,86,86,86,88,86,86,86,86,86,81,10750,110000
);
INSERT INTO PLAYER VALUES (1441,'Salah','Mohamed Salah','Gold - Rare','Headliners',93,'Liverpool','Premier League','Egypt','RW','1992-06-15',96,92,90,88,48,79,0,0,0,0,0,0,'Left',3,4,61,70,70,75,75,71,86,92,92,92,92,92,92,92,92,88,175000,3300000
);
INSERT INTO PLAYER VALUES (1442,'Walker','Kyle Walker','Gold - Rare','Headliners',87,'Manchester City','Premier League','England','RB','1990-05-28',93,81,68,81,84,84,0,0,0,0,0,0,'Right',2,2,83,86,86,86,86,83,81,82,82,78,79,79,79,79,79,77,49750,950000
);
INSERT INTO PLAYER VALUES (1443,'Saúl','Saúl Ñíguez Esclápez','Gold - Rare','Headliners',87,'Atlético Madrid','LaLiga Santander','Spain','CM','1994-11-21',74,83,82,82,80,80,0,0,0,0,0,0,'Left',4,3,80,80,80,81,81,83,85,83,83,84,84,84,84,82,82,83,10750,140000
);
INSERT INTO PLAYER VALUES (1444,'Semedo','Nélson Cabral Semedo','Gold - Rare','Headliners',86,'FC Barcelona','LaLiga Santander','Portugal','RB','1993-11-16',94,85,61,78,83,79,0,0,0,0,0,0,'Right',3,4,82,86,86,87,87,83,80,82,82,79,78,78,78,80,80,73,41500,800000
);
INSERT INTO PLAYER VALUES (1445,'Lewandowski','Robert Lewandowski','Gold - Rare','Headliners',93,'FC Bayern München','Bundesliga','Poland','ST','1988-08-21',83,90,94,80,45,87,0,0,0,0,0,0,'Right',4,4,62,62,62,65,65,67,82,86,86,89,91,91,91,88,88,93,78000,1500000
);
INSERT INTO PLAYER VALUES (1446,'Pléa','Alassane Pléa','Gold - Rare','Headliners Obj',87,'Borussia Mönchengladbach','Bundesliga','France','ST','1993-03-10',84,85,89,85,46,81,0,0,0,0,0,0,'Right',3,4,60,65,65,69,69,66,81,86,86,86,87,87,87,87,87,88,31500,154500
);
INSERT INTO PLAYER VALUES (1447,'Sánchez','Alexis Sánchez','Gold - Rare','Flashback SBC',89,'Inter','Serie A TIM','Chile','LW','1988-12-19',88,91,87,85,48,84,0,0,0,0,0,0,'Right',3,4,62,66,66,70,70,69,82,87,87,88,88,88,88,88,88,86,90000,1500006
);
INSERT INTO PLAYER VALUES (1448,'Telles','Alex Nicolao Telles','Gold - Rare','Headliners',87,'FC Porto','Liga NOS','Brazil','LB','1992-12-15',88,86,76,88,83,79,0,0,0,0,0,0,'Left',2,3,82,86,86,87,87,85,86,86,86,84,83,83,83,84,84,80,23500,450000
);
INSERT INTO PLAYER VALUES (1449,'Adama','Adama Traoré Diarra','Gold - Rare','Headliners SBC',85,'Wolverhampton Wanderers','Premier League','Spain','RW','1996-01-25',99,89,80,80,43,85,0,0,0,0,0,0,'Right',2,4,58,65,65,69,69,63,75,85,85,82,83,83,83,85,85,81,9000,150000
);
INSERT INTO PLAYER VALUES (1450,'Moreno','Gerard Moreno Balagueró','Gold - Rare','Headliners',87,'Villarreal CF','LaLiga Santander','Spain','RW','1992-04-07',83,85,86,75,51,75,0,0,0,0,0,0,'Left',4,3,62,66,66,68,68,65,76,81,81,82,85,85,85,83,83,86,10750,70000
);
INSERT INTO PLAYER VALUES (1451,'Vardy','Jamie Vardy','Gold - Rare','Headliners',86,'Leicester City','Premier League','England','ST','1987-01-11',91,81,86,72,59,79,0,0,0,0,0,0,'Right',3,3,67,70,70,71,71,67,74,81,81,80,83,83,83,82,82,85,16000,300000
);
INSERT INTO PLAYER VALUES (1452,'Sanson','Morgan Sanson','Gold - Rare','Headliners',84,'Olympique de Marseille','Ligue 1 Conforama','France','CM','1994-08-18',81,82,81,84,76,80,0,0,0,0,0,0,'Right',4,4,77,79,79,80,80,81,83,83,83,83,82,82,82,82,82,81,10250,50000
);
INSERT INTO PLAYER VALUES (1453,'Nainggolan','Radja Nainggolan','Gold - Rare','Headliners',87,'Cagliari','Serie A TIM','Belgium','CAM','1988-05-04',78,87,85,84,87,86,0,0,0,0,0,0,'Right',3,3,85,87,87,88,88,89,88,85,85,86,86,86,86,85,85,83,45000,850000
);
INSERT INTO PLAYER VALUES (1454,'Benzema','Karim Benzema','Gold - Rare','CL TOTT SBC',89,'Real Madrid','LaLiga Santander','France','ST','1987-12-19',79,88,86,83,42,79,0,0,0,0,0,0,'Right',4,4,57,60,60,64,64,64,81,85,85,87,88,88,88,86,86,87,65848,515782
);
INSERT INTO PLAYER VALUES (1455,'Ramos','Sergio Ramos García','Gold - Rare','CL TOTT',90,'Real Madrid','LaLiga Santander','Spain','CB','1986-03-30',73,76,70,76,88,87,0,0,0,0,0,0,'Right',3,3,88,84,84,82,82,85,79,75,75,75,75,75,75,73,73,76,20500,390000
);
INSERT INTO PLAYER VALUES (1456,'Mbappé','Kylian Mbappé','Gold - Rare','CL TOTT',91,'Paris Saint-Germain','Ligue 1 Conforama','France','ST','1998-12-20',98,92,88,82,41,78,0,0,0,0,0,0,'Right',4,5,56,65,65,69,69,64,81,90,90,89,91,91,91,91,91,90,208000,4000000
);
INSERT INTO PLAYER VALUES (1457,'Zaniolo','Nicolò Zaniolo','Gold - Rare','Europa TOTT',83,'Roma','Serie A TIM','Italy','RM','1999-07-02',82,84,79,80,67,85,0,0,0,0,0,0,'Left',3,3,72,73,73,75,75,77,83,83,83,84,85,85,85,83,83,82,10250,35000
);
INSERT INTO PLAYER VALUES (1458,'Koulibaly','Kalidou Koulibaly','Gold - Rare','CL TOTT',90,'Napoli','Serie A TIM','Senegal','CB','1991-06-20',73,70,29,55,90,89,0,0,0,0,0,0,'Right',3,2,88,78,78,75,75,81,66,61,61,60,59,59,59,57,57,58,11000,140000
);
INSERT INTO PLAYER VALUES (1459,'Mertens','Dries Mertens','Gold - Rare','CL TOTT',89,'Napoli','Serie A TIM','Belgium','CF','1987-05-06',90,92,88,84,37,55,0,0,0,0,0,0,'Right',4,4,48,62,62,67,67,62,81,88,88,89,89,89,89,89,89,82,30250,550000
);
INSERT INTO PLAYER VALUES (1460,'Salah','Mohamed Salah','Gold - Rare','CL TOTT',91,'Liverpool','Premier League','Egypt','RW','1992-06-15',94,90,87,84,46,76,0,0,0,0,0,0,'Left',3,4,58,68,68,72,72,69,83,89,89,89,89,89,89,90,90,86,43000,800000
);
INSERT INTO PLAYER VALUES (1461,'Kane','Harry Kane','Gold - Rare','CL TOTT',92,'Tottenham Hotspur','Premier League','England','ST','1993-07-28',77,86,94,84,50,86,0,0,0,0,0,0,'Right',4,3,64,66,66,69,69,70,84,87,87,88,89,89,89,87,87,91,11250,200000
);
INSERT INTO PLAYER VALUES (1462,'Son','Heung Min Son','Gold - Rare','CL TOTT',89,'Tottenham Hotspur','Premier League','Korea Republic','LM','1992-07-08',90,89,89,85,44,71,0,0,0,0,0,0,'Right',5,4,55,65,65,70,70,65,82,88,88,88,89,89,89,89,89,86,54500,1000000
);
INSERT INTO PLAYER VALUES (1463,'De Bruyne','Kevin De Bruyne','Gold - Rare','CL TOTT',93,'Manchester City','Premier League','Belgium','CAM','1991-06-28',79,89,90,94,63,82,0,0,0,0,0,0,'Right',5,4,69,75,75,79,79,79,90,90,90,91,90,90,90,89,89,85,50500,950000
);
INSERT INTO PLAYER VALUES (1464,'Messi','Lionel Messi','Gold - Rare','CL TOTT',96,'FC Barcelona','LaLiga Santander','Argentina','RW','1987-06-24',91,98,94,94,42,70,0,0,0,0,0,0,'Left',4,4,55,65,65,70,70,68,89,94,94,96,95,95,95,95,95,92,194000,3700000
);
INSERT INTO PLAYER VALUES (1465,'Ter Stegen','Marc-André ter Stegen','Gold - Rare','CL TOTT',91,'FC Barcelona','LaLiga Santander','Germany','GK','1992-04-30',0,0,0,0,0,0,90,92,86,44,89,90,'Right',4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,11250,190000
);
INSERT INTO PLAYER VALUES (1466,'Sterling','Raheem Sterling','Gold - Rare','CL TOTT',89,'Manchester City','Premier League','England','LW','1994-12-08',94,90,81,80,46,59,0,0,0,0,0,0,'Right',3,4,53,66,66,70,70,64,80,87,87,87,87,87,87,88,88,80,18500,350000
);
INSERT INTO PLAYER VALUES (1467,'Martínez','Lautaro Martínez','Gold - Rare','CL TOTT',86,'Inter','Serie A TIM','Argentina','ST','1997-08-22',86,87,85,75,45,88,0,0,0,0,0,0,'Right',4,4,60,60,60,63,63,64,78,83,83,85,86,86,86,83,83,87,10500,80000
);
INSERT INTO PLAYER VALUES (1468,'Lewandowski','Robert Lewandowski','Gold - Rare','CL TOTT',92,'FC Bayern München','Bundesliga','Poland','ST','1988-08-21',81,89,93,78,44,86,0,0,0,0,0,0,'Right',4,4,61,61,61,64,64,66,81,85,85,88,90,90,90,87,87,91,21000,400000
);
INSERT INTO PLAYER VALUES (1469,'Tolisso','Corentin Tolisso','Gold - Rare','CL TOTT',85,'FC Bayern München','Bundesliga','France','CM','1994-08-03',72,81,81,81,80,81,0,0,0,0,0,0,'Right',3,3,81,79,79,79,79,83,84,80,80,82,82,82,82,80,80,81,10500,37500
);
INSERT INTO PLAYER VALUES (1470,'Fernandes','Bruno Miguel Borges Fernandes','Gold - Rare','Europa TOTT',86,'Sporting CP','Liga NOS','Portugal','CAM','1994-09-08',80,86,85,88,66,75,0,0,0,0,0,0,'Right',4,4,69,75,75,78,78,78,85,85,85,85,84,84,84,84,84,80,10500,37500
);
INSERT INTO PLAYER VALUES (1471,'Ziyech','Hakim Ziyech','Gold - Rare','CL TOTT',87,'Ajax','Eredivisie','Morocco','CAM','1993-03-19',83,86,78,90,52,68,0,0,0,0,0,0,'Left',2,4,59,68,68,72,72,72,85,86,86,87,84,84,84,85,85,79,10750,40000
);
INSERT INTO PLAYER VALUES (1472,'Tagliafico','Nicolás Tagliafico','Gold - Rare','CL TOTT ',86,'Ajax','Eredivisie','Argentina','LB','1992-08-31',84,80,64,76,85,85,0,0,0,0,0,0,'Left',2,3,84,85,85,85,85,83,78,80,80,76,77,77,77,78,78,76,15000,658000
);
INSERT INTO PLAYER VALUES (1473,'Håland','Erling Braut Håland','Gold - Rare','CL TOTT',84,'FC Red Bull Salzburg','Österreichische Fußball-Bundesliga','Norway','ST','2000-07-21',88,83,86,75,45,86,0,0,0,0,0,0,'Left',3,3,60,61,61,64,64,64,75,81,81,83,85,85,85,83,83,86,10250,30000
);
INSERT INTO PLAYER VALUES (1474,'Morales','José Luis Morales Nogales','Gold - Rare','Player Moments SBC',85,'Levante UD','LaLiga Santander','Spain','ST','1987-07-23',94,90,83,78,59,70,0,0,0,0,0,0,'Right',4,4,63,71,71,74,74,69,79,86,86,85,86,86,86,87,87,83,17500,698000
);
INSERT INTO PLAYER VALUES (1475,'Balotelli','Mario Balotelli','Gold - Rare','Flashback SBC',88,'Brescia','Serie A TIM','Italy','ST','1990-08-12',87,90,88,78,30,87,0,0,0,0,0,0,'Right',4,4,53,56,56,60,60,60,77,84,84,85,87,87,87,85,85,87,25006,578888
);
INSERT INTO PLAYER VALUES (1476,'Fàbregas','Francesc Fàbregas i Soler','Gold - Rare','Flashback SBC',88,'AS Monaco Football Club SA','Ligue 1 Conforama','Spain','CM','1987-05-04',78,88,84,92,70,82,0,0,0,0,0,0,'Right',3,3,75,77,77,79,79,79,87,87,87,87,86,86,86,85,85,85,26581,478000
);
INSERT INTO PLAYER VALUES (1477,'Bailey','Leon Bailey','Gold - Rare','Player Moments SBC',86,'Bayer 04 Leverkusen','Bundesliga','Jamaica','LW','1997-08-09',93,89,85,77,35,70,0,0,0,0,0,0,'Left',4,4,49,58,58,62,62,58,75,84,84,84,85,85,85,86,86,82,65000,56891
);
INSERT INTO PLAYER VALUES (1478,'King','Joshua King','Gold - Rare','Player Moments ',84,'Bournemouth','Premier League','Norway','CF','1992-01-15',90,86,84,74,40,84,0,0,0,0,0,0,'Right',3,4,56,60,60,64,64,62,76,83,83,83,84,84,84,83,83,84,41700,824756
);
INSERT INTO PLAYER VALUES (1479,'Gómez','Alejandro Gómez','Gold - Rare','UCL LIVE SBC',87,'Atalanta','Serie A TIM','Argentina','CAM','1988-02-15',92,89,82,84,41,57,0,0,0,0,0,0,'Right',4,4,50,62,62,67,67,63,79,85,85,86,85,85,85,87,87,78,52300,123000
);
INSERT INTO PLAYER VALUES (1480,'Bale','Gareth Bale','Gold - Rare','UCL LIVE',87,'Real Madrid','LaLiga Santander','Wales','RW','1989-07-16',93,85,89,86,60,79,0,0,0,0,0,0,'Left',3,4,68,72,72,74,74,72,81,86,86,85,86,86,86,87,87,87,84500,1600000
);
INSERT INTO PLAYER VALUES (1481,'Marquinhos','Marcos Aoas Corrêa','Gold - Rare','UCL LIVE',88,'Paris Saint-Germain','Ligue 1 Conforama','Brazil','CB','1994-05-14',78,75,43,76,88,79,0,0,0,0,0,0,'Right',3,3,86,84,84,82,82,85,77,73,73,71,69,69,69,69,69,66,27750,500000
);
INSERT INTO PLAYER VALUES (1482,'Gueye','Idrissa Gueye','Gold - Rare','UCL LIVE SBC',86,'Paris Saint-Germain','Ligue 1 Conforama','Senegal','CDM','1989-09-26',76,82,63,75,88,81,0,0,0,0,0,0,'Right',3,3,85,84,84,84,84,86,81,76,76,76,75,75,75,75,75,72,65802,410000
);
INSERT INTO PLAYER VALUES (1483,'Immobile','Ciro Immobile','Gold - Rare','UEL LIVE',87,'Lazio','Serie A TIM','Italy','ST','1990-02-20',82,82,86,65,40,78,0,0,0,0,0,0,'Right',4,3,56,59,59,61,61,59,72,78,78,80,83,83,83,80,80,85,10750,65000
);
INSERT INTO PLAYER VALUES (1484,'Torreira','Lucas Torreira','Gold - Rare','UEL LIVE',86,'Arsenal','Premier League','Uruguay','CDM','1996-02-11',79,84,74,82,85,79,0,0,0,0,0,0,'Right',3,3,81,83,83,84,84,85,83,81,81,81,79,79,79,80,80,76,23750,450000
);
INSERT INTO PLAYER VALUES (1485,'Lloris','Hugo Lloris','Gold - Rare','UCL LIVE',90,'Tottenham Hotspur','Premier League','France','GK','1986-12-26',0,0,0,0,0,0,91,93,86,66,70,88,'Left',1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,18500,350000
);
INSERT INTO PLAYER VALUES (1486,'Partey','Thomas Partey','Gold - Rare','UCL LIVE',86,'Atlético Madrid','LaLiga Santander','Ghana','CM','1993-06-13',78,81,79,81,83,88,0,0,0,0,0,0,'Right',3,3,83,83,83,83,83,86,85,82,82,83,82,82,82,80,80,80,11000,210000
);
INSERT INTO PLAYER VALUES (1487,'Angeliño','José Ángel Esmoris Tasende','Gold - Rare','UCL LIVE SBC',84,'Manchester City','Premier League','Spain','LB','1997-01-04',89,85,71,84,80,83,0,0,0,0,0,0,'Left',3,4,80,83,83,85,85,82,83,84,84,82,81,81,81,83,83,78,3568,110000
);
INSERT INTO PLAYER VALUES (1488,'Alba','Jordi Alba Ramos','Gold - Rare','UCL LIVE',89,'FC Barcelona','LaLiga Santander','Spain','LB','1989-03-21',92,85,71,83,83,77,0,0,0,0,0,0,'Left',3,3,82,87,87,88,88,84,84,86,86,83,82,82,82,84,84,79,57500,1100000
);
INSERT INTO PLAYER VALUES (1489,'Martial','Anthony Martial','Gold - Rare','UEL LIVE',86,'Manchester United','Premier League','France','LW','1995-12-05',92,88,84,78,44,76,0,0,0,0,0,0,'Right',3,4,57,64,64,68,68,63,77,84,84,84,86,86,86,86,86,84,45750,850000
);
INSERT INTO PLAYER VALUES (1490,'Goretzka','Leon Goretzka','Gold - Rare','UCL LIVE',87,'FC Bayern München','Bundesliga','Germany','CM','1995-02-06',84,84,83,83,79,82,0,0,0,0,0,0,'Right',4,3,80,82,82,82,82,82,85,84,84,85,85,85,85,84,84,84,72500,1400000
);
INSERT INTO PLAYER VALUES (1491,'Depay','Memphis Depay','Gold - Rare','UCL LIVE',87,'Olympique Lyonnais','Ligue 1 Conforama','Holland','CF','1994-02-13',89,86,85,85,36,82,0,0,0,0,0,0,'Right',3,5,53,60,60,64,64,62,79,86,86,86,86,86,86,86,86,85,18750,350000
);
INSERT INTO PLAYER VALUES (1492,'Konaté','Ibrahima Konaté','Gold - Rare','UCL LIVE SBC',84,'RB Leipzig','Bundesliga','France','CB','1999-05-25',83,78,32,60,85,83,0,0,0,0,0,0,'Right',2,3,84,78,78,76,76,80,70,66,66,65,62,62,62,63,63,59,9200,450000
);
INSERT INTO PLAYER VALUES (1493,'Kanté','N''Golo Kanté','Gold - Rare','UCL LIVE',91,'Chelsea','Premier League','France','CDM','1991-03-29',81,84,68,81,89,85,0,0,0,0,0,0,'Right',3,2,85,87,87,88,88,90,86,82,82,82,80,80,80,80,80,75,83500,1600000
);
INSERT INTO PLAYER VALUES (1494,'Sancho','Jadon Sancho','Gold - Rare','UCL LIVE',87,'Borussia Dortmund','Bundesliga','England','RM','2000-03-25',90,92,79,81,40,64,0,0,0,0,0,0,'Right',4,5,50,63,63,68,68,62,79,86,86,86,86,86,86,87,87,79,18250,350000
);
INSERT INTO PLAYER VALUES (1495,'Militão','Éder Gabriel Militão','Gold - Rare','UCL LIVE',86,'Real Madrid','LaLiga Santander','Brazil','CB','1998-01-18',83,77,56,75,86,86,0,0,0,0,0,0,'Right',2,2,85,84,84,84,84,83,76,77,77,73,73,73,73,74,74,71,65000,1200000
);
INSERT INTO PLAYER VALUES (1496,'Wendell','Wendell Nascimento Borges','Gold - Rare','UCL LIVE',81,'Bayer 04 Leverkusen','Bundesliga','Brazil','LB','1993-07-20',86,82,53,79,78,77,0,0,0,0,0,0,'Left',2,4,78,81,81,82,82,80,77,78,78,76,74,74,74,77,77,67,9900,42500
);
INSERT INTO PLAYER VALUES (1497,'Wass','Daniel Wass','Gold - Rare','UCL LIVE',85,'Valencia CF','LaLiga Santander','Denmark','CM','1989-05-31',78,84,84,86,82,81,0,0,0,0,0,0,'Right',3,3,81,83,83,84,84,84,85,84,84,83,83,83,83,83,83,82,10500,140000
);
INSERT INTO PLAYER VALUES (1498,'Neres','David Neres Campos','Gold - Rare','UCL LIVE',84,'Ajax','Eredivisie','Brazil','LW','1997-03-03',88,89,78,78,40,70,0,0,0,0,0,0,'Left',3,5,52,61,61,65,65,63,78,83,83,84,84,84,84,84,84,79,10250,70000
);
INSERT INTO PLAYER VALUES (1499,'Son','Heung Min Son','Gold - Rare','UCL LIVE',89,'Tottenham Hotspur','Premier League','Korea Republic','CF','1992-07-08',90,89,88,84,44,73,0,0,0,0,0,0,'Right',5,4,56,66,66,70,70,66,82,88,88,88,89,89,89,89,89,86,131000,2500000
);
INSERT INTO PLAYER VALUES (1500,'Mahrez','Riyad Mahrez','Gold - Rare','UCL LIVE',87,'Manchester City','Premier League','Algeria','RW','1991-02-21',87,91,84,83,41,64,0,0,0,0,0,0,'Left',4,5,50,61,61,66,66,62,79,86,86,86,85,85,85,87,87,80,16500,310000
);
