--Poiche' viene utilizzato come parametro di output nella funzione MODULE_POSITION, dev'essere creato prima. 
--E' un array che conterra' le posizioni in base al modulo scelto.
create OR REPLACE TYPE array_pos_t is VARRAY(11) of VARCHAR2(3);
/
