BEGIN
DBMS_SCHEDULER.CREATE_JOB (
        job_name => 'job_gift',
        job_type => 'STORED_PROCEDURE',
        job_action => 'GIFT', --Esegue la procedura GIFT.
        start_date => TO_DATE('11-SET-2014 16:40:00','DD-MON-YYYY HH24:MI:SS'),
        repeat_interval => 'FREQ=WEEKLY;BYDAY=THU;BYHOUR=9;', --Ogni giovedi alle 9:00 AM.
        enabled => TRUE ,
        comments => 'Regali in base alla divisione!');
END;
/