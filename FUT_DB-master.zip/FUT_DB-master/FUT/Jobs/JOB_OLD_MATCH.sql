BEGIN
    DBMS_SCHEDULER.CREATE_JOB (
    job_name			=>	'job_rollout_match',
    job_type			=>	'PLSQL_BLOCK',
    job_action		=>	'BEGIN
                            DELETE FROM TMP_MATCH 
                            WHERE MATCH_DATE<SYSDATE-1;
                        END;',
    start_date		=> TRUNC(SYSDATE),
    repeat_interval => 'FREQ=DAILY;BYDAY=MON,TUE,WED,THU,FRI,SAT,SUN; BYHOUR=0;', --Ogni giorno a mezzanotte.
    enabled			=>	TRUE,
    comments		=>	'Cancellazione dei match del giorno precedente, dalla tabella TMP_MATCH');
END;
/