---------------------------------------------------------------------------------------------------------------------------
-- User View GET_PACK_PURCHASES
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 2
--  -> PACK_PURCHASE, PACK, CLUB;
-- OUTPUT:
--  -> Cronologia dei pacchetti comprati dall'utente.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE VIEW GET_PACK_PURCHASES AS
    ( SELECT
        PURCHASE_ID,
        BUYING_PACK_NAME,
        P_DATE,
        PRICE
    FROM
             PACK_PURCHASE P
        JOIN PACK PP ON P.BUYING_PACK_NAME = PP.PACK_NAME
                           AND P.BUYING_CLUB_NAME IN (
            SELECT
                CLUB_NAME
            FROM
                CLUB
            WHERE
                LOWER(USER_NICK) = LOWER(USER)
        )
    ) ORDER BY P_DATE;