---------------------------------------------------------------------------------------------------------------------------
-- User View GET_MANAGERS
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 8
--  -> CLUB_CARD, MANAGER, ACTIVE_DATA_MANAGER, MANAGES, IS_FOUND, PACK_PURCHSE, CLUB, TRANSACTION;
-- OUTPUT:
--  -> Dettagli dei dati attivi dei manager posseduti dal club dell'utente.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE VIEW GET_MANAGERS AS
    ( SELECT
        CARD_CODE,
        F_NAME,
        S_NAME,
        CONTRACTS,
        LEAGUE_NAME     AS PREF_LEAGUE,
        MANAGER_LEAGUE  AS ACTIVE_LEAGUE,
        NATIONALITY
    FROM
             MANAGER M
        JOIN CLUB_CARD            C ON M.CARD_ID = C.MANAGER_ID
        JOIN ACTIVE_DATA_MANAGER  A ON A.M_CARD_CODE = C.CARD_CODE
                           AND C.CARD_CODE IN (
            SELECT
                CARD_CODE
            FROM
                IS_FOUND
            WHERE
                P_ID IN (
                    SELECT
                        PURCHASE_ID
                    FROM
                        PACK_PURCHASE
                    WHERE
                        BUYING_CLUB_NAME IN (
                            SELECT
                                CLUB_NAME
                            FROM
                                CLUB
                            WHERE
                                LOWER(USER_NICK) = LOWER(USER)
                        )
                )
        )
    UNION
    SELECT
        CARD_CODE,
        F_NAME,
        S_NAME,
        CONTRACTS,
        LEAGUE_NAME     AS PREF_LEAGUE,
        MANAGER_LEAGUE  AS ACTIVE_LEAGUE,
        NATIONALITY
    FROM
             MANAGER M
        JOIN CLUB_CARD            C ON M.CARD_ID = C.MANAGER_ID
        JOIN ACTIVE_DATA_MANAGER  A ON A.M_CARD_CODE = C.CARD_CODE
                           AND C.CARD_CODE IN (
            SELECT
                T_CARD_CODE
            FROM
                TRANSACTION
            WHERE
                TRANSITION_B_CLUB_NAME IN (
                    SELECT
                        CLUB_NAME
                    FROM
                        CLUB
                    WHERE
                        LOWER(USER_NICK) = LOWER(USER)
                )
        )
    )ORDER BY CONTRACTS DESC;