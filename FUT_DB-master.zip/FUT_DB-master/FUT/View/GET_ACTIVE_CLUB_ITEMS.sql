---------------------------------------------------------------------------------------------------------------------------
-- User View GET_ACTIVE_CLUB_ITEMS
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 3
--  -> CLUB_ITEM, CLUB_CARD, CLUB;
-- OUTPUT:
--  -> Dettagli dei club_item attivi nel club dell'utente.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE VIEW GET_ACTIVE_CLUB_ITEMS AS
    (
--Seleziona i dettagli che riguardano lo stemma <badge> del club.
     SELECT
        CARD_CODE,
        CATEGORY_ITEM,
        TEAM_NAME
    FROM
             CLUB_ITEM C
        JOIN CLUB_CARD CC ON C.CARD_ID = CC.CLUB_ITEM_ID
                             AND CC.CARD_CODE IN (
            SELECT
                ACTIVE_BADGE_CODE
            FROM
                CLUB
            WHERE
                CLUB_NAME IN (
                    SELECT
                        CLUB_NAME
                    FROM
                        CLUB
                    WHERE
                        LOWER(USER_NICK) = LOWER(USER)
                )
        )
    UNION
--Seleziona i dettagli che riguardano lo stadio del club.
    SELECT
        CARD_CODE,
        CATEGORY_ITEM,
        TEAM_NAME
    FROM
             CLUB_ITEM C
        JOIN CLUB_CARD CC ON C.CARD_ID = CC.CLUB_ITEM_ID
                             AND CC.CARD_CODE IN (
            SELECT
                ACTIVE_STADIUM_CODE
            FROM
                CLUB
            WHERE
                CLUB_NAME IN (
                    SELECT
                        CLUB_NAME
                    FROM
                        CLUB
                    WHERE
                        LOWER(USER_NICK) = LOWER(USER)
                )
        )
    UNION
--Seleziona i dettagli che riguardano il pallone del club.
    SELECT
        CARD_CODE,
        CATEGORY_ITEM,
        TEAM_NAME
    FROM
             CLUB_ITEM C
        JOIN CLUB_CARD CC ON C.CARD_ID = CC.CLUB_ITEM_ID
                             AND CC.CARD_CODE IN (
            SELECT
                ACTIVE_BALL_CODE
            FROM
                CLUB
            WHERE
                CLUB_NAME IN (
                    SELECT
                        CLUB_NAME
                    FROM
                        CLUB
                    WHERE
                        LOWER(USER_NICK) = LOWER(USER)
                )
        )
    UNION
--Seleziona i dettagli che riguardano la prima divisa del club.
    SELECT
        CARD_CODE,
        CATEGORY_ITEM,
        TEAM_NAME
    FROM
             CLUB_ITEM C
        JOIN CLUB_CARD CC ON C.CARD_ID = CC.CLUB_ITEM_ID
                             AND CC.CARD_CODE IN (
            SELECT
                ACTIVE_FIRST_KIT_CODE
            FROM
                CLUB
            WHERE
                CLUB_NAME IN (
                    SELECT
                        CLUB_NAME
                    FROM
                        CLUB
                    WHERE
                        LOWER(USER_NICK) = LOWER(USER)
                )
        )
    UNION
--Seleziona i dettagli che riguardano la seconda divisa del club.
    SELECT
        CARD_CODE,
        CATEGORY_ITEM,
        TEAM_NAME
    FROM
             CLUB_ITEM C
        JOIN CLUB_CARD CC ON C.CARD_ID = CC.CLUB_ITEM_ID
                             AND CC.CARD_CODE IN (
            SELECT
                ACTIVE_SECOND_KIT_CODE
            FROM
                CLUB
            WHERE
                CLUB_NAME IN (
                    SELECT
                        CLUB_NAME
                    FROM
                        CLUB
                    WHERE
                        LOWER(USER_NICK) = LOWER(USER)
                )
        )
    )ORDER BY CATEGORY_ITEM;