---------------------------------------------------------------------------------------------------------------------------
-- User View GET_PLAYERS_FOR_SALE
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 6
--  -> CLUB_CARD, PLAYER, CLUB, TRANSACTION;
-- OUTPUT:
--  -> Dettagli dei player in vendita sul mercato.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE VIEW GET_PLAYERS_FOR_SALE AS
    ( SELECT
        PRICE,
        CARD_CODE,
        PLAYER_NAME,
        POSITION,
        NATIONALITY,
        LEAGUE_NAME
    FROM
             PLAYER P
        JOIN CLUB_CARD   C ON P.CARD_ID = C.PLAYER_ID
        JOIN TRANSACTION  T ON T.T_CARD_CODE = C.CARD_CODE
                             AND C.CARD_CODE IN (
            SELECT
                T_CARD_CODE
            FROM
                TRANSACTION
            WHERE
                TRANSITION_B_CLUB_NAME IS NULL
                AND TRANSITION_S_CLUB_NAME IN (
                    SELECT
                        CLUB_NAME
                    FROM
                        CLUB
                    WHERE
                        LOWER(USER_NICK) <> LOWER(USER)
                )
        )
    )ORDER BY PRICE DESC, POSITION;