---------------------------------------------------------------------------------------------------------------------------
-- Function MODULE_POSITIONS
---------------------------------------------------------------------------------------------------------------------------
-- TYPE:
--  -> array_pos_t: is VARRAY(11) of VARCHAR2(3);
-- INPUT:
--	-> module: modulo della squadra esempio '4-4-2';
-- OUTPUT:
--  -> array: array che contiene la posizioni del modulo dato in input.
-- ESEMPIO:
--  -> chiamata: select MODULE_POSITIONS('4-3-3') FROM DUAL;
--              output -> ('GK','LB','CB','CB','RB','CM','CM','CM','LW','ST','RW');
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION MODULE_POSITIONS (
    MODULE IN SQUAD.MODULES%TYPE
) RETURN ARRAY_POS_T IS
    ARR ARRAY_POS_T;
    MODULE_IN_ERROR EXCEPTION;
BEGIN
    IF MODULE = '4-4-2' THEN
        ARR := ARRAY_POS_T('GK', 'LB', 'CB', 'CB', 'RB',
                          'LM', 'CM', 'CM', 'RM', 'ST',
                          'ST');
    ELSIF MODULE = '3-1-4-2' THEN
        ARR := ARRAY_POS_T('GK', 'CB', 'CB', 'CB', 'LM',
                          'CM', 'CDM', 'CM', 'RM', 'ST',
                          'ST');
    ELSIF MODULE = '3-4-1-2' THEN
        ARR := ARRAY_POS_T('GK', 'CB', 'CB', 'CB', 'LM',
                          'CM', 'CM', 'RM', 'CAM', 'ST',
                          'ST');
    ELSIF MODULE = '3-4-3' THEN
        ARR := ARRAY_POS_T('GK', 'CB', 'CB', 'CB', 'LM',
                          'CM', 'CM', 'RM', 'LW', 'ST',
                          'RW');
    ELSIF MODULE = '3-5-2' THEN
        ARR := ARRAY_POS_T('GK', 'CB', 'CB', 'CB', 'LM',
                          'CDM', 'CDM', 'RM', 'CAM', 'ST',
                          'ST');
    ELSIF MODULE = '4-1-2-1-2' THEN
        ARR := ARRAY_POS_T('GK', 'LB', 'CB', 'CB', 'RB',
                          'LM', 'CDM', 'RM', 'CAM', 'ST',
                          'ST');
    ELSIF MODULE = '4-1-3-2' THEN
        ARR := ARRAY_POS_T('GK', 'LB', 'CB', 'CB', 'RB',
                          'CDM', 'LM', 'CM', 'RM', 'ST',
                          'ST');
    ELSIF MODULE = '4-1-4-1' THEN
        ARR := ARRAY_POS_T('GK', 'LB', 'CB', 'CB', 'RB',
                          'CDM', 'LM', 'CM', 'CM', 'RM',
                          'ST');
    ELSIF MODULE = '4-2-2-2' THEN
        ARR := ARRAY_POS_T('GK', 'LB', 'CB', 'CB', 'RB',
                          'CAM', 'CDM', 'CDM', 'CAM', 'ST',
                          'ST');
    ELSIF MODULE = '4-2-3-1' THEN
        ARR := ARRAY_POS_T('GK', 'LB', 'CB', 'CB', 'RB',
                          'CDM', 'CAM', 'CDM', 'CAM', 'CAM',
                          'ST');
    ELSIF MODULE = '4-2-4' THEN
        ARR := ARRAY_POS_T('GK', 'LB', 'CB', 'CB', 'RB',
                          'CM', 'CM', 'LW', 'RW', 'ST',
                          'ST');
    ELSIF MODULE = '4-3-1-2' THEN
        ARR := ARRAY_POS_T('GK', 'LB', 'CB', 'CB', 'RB',
                          'CM', 'CM', 'CM', 'CAM', 'ST',
                          'ST');
    ELSIF MODULE = '4-3-2-1' THEN
        ARR := ARRAY_POS_T('GK', 'LB', 'CB', 'CB', 'RB',
                          'CM', 'CM', 'CM', 'LF', 'ST',
                          'RF');
    ELSIF MODULE = '4-3-3' THEN
        ARR := ARRAY_POS_T('GK', 'LB', 'CB', 'CB', 'RB',
                          'CM', 'CM', 'CM', 'LW', 'ST',
                          'RW');
    ELSIF MODULE = '4-4-1-1' THEN
        ARR := ARRAY_POS_T('GK', 'LB', 'CB', 'CB', 'RB',
                          'LM', 'CM', 'CM', 'RM', 'CF',
                          'ST');
    ELSIF MODULE = '4-5-1' THEN
        ARR := ARRAY_POS_T('GK', 'LB', 'CB', 'CB', 'RB',
                          'LM', 'CM', 'RM', 'CAM', 'CAM',
                          'ST');
    ELSIF MODULE = '5-2-1-2' THEN
        ARR := ARRAY_POS_T('GK', 'LWB', 'CB', 'CB', 'CB',
                          'RWB', 'CM', 'CM', 'CAM', 'ST',
                          'ST');
    ELSIF MODULE = '5-2-2-1' THEN
        ARR := ARRAY_POS_T('GK', 'LWB', 'CB', 'CB', 'CB',
                          'RWB', 'CM', 'CM', 'LW', 'ST',
                          'RW');
    ELSIF MODULE = '5-3-2' THEN
        ARR := ARRAY_POS_T('GK', 'LWB', 'CB', 'CB', 'CB',
                          'RWB', 'CM', 'CM', 'CM', 'ST',
                          'ST');
    ELSIF MODULE = '5-4-1' THEN
        ARR := ARRAY_POS_T('GK', 'LWB', 'CB', 'CB', 'CB',
                          'RWB', 'LM', 'CM', 'CM', 'RM',
                          'ST');
    ELSIF MODULE = '5-2-1-2' THEN
        ARR := ARRAY_POS_T('GK', 'LWB', 'CB', 'CB', 'CB',
                          'RWB', 'CM', 'CM', 'CAM', 'ST',
                          'ST');
    ELSE
        RAISE MODULE_IN_ERROR;
    END IF;

    RETURN ARR;
EXCEPTION
    WHEN MODULE_IN_ERROR THEN
        RAISE_APPLICATION_ERROR(-20002, 'Errore inserimento, ('
                                        || MODULE
                                        || ') non e'' stato trovato!');
END MODULE_POSITIONS;
/