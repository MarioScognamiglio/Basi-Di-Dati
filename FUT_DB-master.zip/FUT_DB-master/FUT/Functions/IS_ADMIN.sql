--------------------------------------------------------
-- Function IS_ADMIN
--------------------------------------------------------
-- Tabelle interessate: 1
--  -> CLUB
-- INPUT:
--	-> input_club_name: nome del club;
-- 	-> user_logon: nome utente dell'utente che chiama la funzione;
-- OUTPUT:
--	-> Se non e' l'admin a chiamare la funzione, ritorna il nome del club del utente chiamante.
--  -> Altrimenti il nome del club, che corrisponde a <input_club_name>, poiche' l'amministratore
--  ->  puo' chiamare le funzioni su qualsiasi club, mentre l'utente solo sul proprio club.
--------------------------------------------------------
CREATE OR REPLACE FUNCTION IS_ADMIN (
    INPUT_CLUB_NAME  CLUB.CLUB_NAME%TYPE,
    USER_LOGON       CLUB.USER_NICK%TYPE
) RETURN VARCHAR2 IS

    N1                NUMBER(2, 0);           
    USER_CLUB_NAME    CLUB.CLUB_NAME%TYPE; --Nome del club dell'utente.
    ACTUAL_CLUB_NAME  CLUB.CLUB_NAME%TYPE; --Variabile d'appoggio.

    NO_CLUB_FOUND EXCEPTION; --Se il club <input_club_name> non viene trovato.
    --Nel caso in cui l'utente A chiama la funzione con il nome del club dell'utente B
    -- o con un nome club non valido.
    USER_CLUB_ERROR EXCEPTION;
BEGIN
--Copio il nome del club dato in ingresso.
    ACTUAL_CLUB_NAME := INPUT_CLUB_NAME;

--Se l'utente chiamante non e' amministratore.
    IF USER_LOGON <> 'ADMINFUT' THEN

--Controllo se esiste un club di propieta' dell'utente <user_logon>.
        SELECT
            COUNT(*)
        INTO N1
        FROM
            CLUB
        WHERE
            LOWER(USER_NICK) = LOWER(USER_LOGON);

--Se il club non esiste.
        IF N1 = 0 THEN
            RAISE NO_CLUB_FOUND;
        END IF;

--Se esiste, seleziono il nome del club in <user_club_name>.
        SELECT
            CLUB_NAME
        INTO USER_CLUB_NAME
        FROM
            CLUB
        WHERE
            LOWER(USER_NICK) = LOWER(USER_LOGON);

    ELSE
--E' l'amministratore il chiamante, il nome del club dato in ingresso non varia
--  quindi lo copio in <user_club_name>.
        USER_CLUB_NAME := ACTUAL_CLUB_NAME;
    END IF;

--Se il nome del club <input_club_name> che e' uguale a <actual_club_name> non e' NULL,
--  e non corrisponde al nome del club dell'utente chiamante <user_club_name>,
--  e l'utente chiamante non e' amministratore.
--Esempio: user = PLAYER1; il nome del club del PLAYER1 e' 'club1';
--          <actual_club_name> = 'club2';
--          <user_club_name> = 'club1'; 
--Il PLAYER1 sta chiamando una funzione con un nome del club che non corrisponde al suo, e non puo'
--  solo l'amministratore puo' e si genera l'eccezione <user_club_error>.         
    IF
        ACTUAL_CLUB_NAME IS NOT NULL
        AND USER_CLUB_NAME <> ACTUAL_CLUB_NAME
        AND USER_LOGON <> 'ADMINFUT'
    THEN
        RAISE USER_CLUB_ERROR;
    END IF;

--Ritorno il nome del club.
    RETURN USER_CLUB_NAME;
EXCEPTION
    WHEN NO_CLUB_FOUND THEN
        RAISE_APPLICATION_ERROR(-20001, 'L''utente '
                                          || USER_LOGON
                                          || ' non ha un club!');
    WHEN USER_CLUB_ERROR THEN
        RAISE_APPLICATION_ERROR(-20002, 'Il club '
                                          || INPUT_CLUB_NAME
                                          || ' non appartiene all''utente '
                                          || USER_LOGON);
END IS_ADMIN;
/