---------------------------------------------------------------------------------------------------------------------------
-- Function IDX_POSITION
---------------------------------------------------------------------------------------------------------------------------
-- INPUT-OUTPUT:
--	-> pos:     posizione del <player>;
--  -> choice:  se e' uguale ad 'r' la funzione ritorna il ruolo del player;
--              se e' uguale ad 'i' la funzione ritorna l'indice intero della posizione del <player>. 
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION IDX_POSITION (
    POS     IN  PLAYER.POSITION%TYPE,
    CHOICE  IN  CHAR
) RETURN INTEGER IS

    RUOLO    INTEGER; --Valore di ritorno, <choice = 'r'>. 
    IDX_POS  INTEGER; --Valore di ritorno, <choice = 'i'>.
    TYPE ARRAY_POS IS VARRAY(17) OF VARCHAR2(3);
    POS_ARR  ARRAY_POS; --Array che contiene tutte le posizioni.

    INVALID_CHOICE EXCEPTION; --Se la scelta e' diversa da 'r' o 'i'.
BEGIN
    POS_ARR := ARRAY_POS('GK', 'RB', 'CB', 'LB', 'RWB',
                        'LWB', 'CDM', 'CM', 'CAM', 'RM',
                        'LM', 'RW', 'LW', 'CF', 'RF',
                        'LF', 'ST');

    FOR I IN 1..17 LOOP
        IF POS_ARR(I) = POS THEN
            IDX_POS := I;
--Se la posizione e' GK (portiere) il ruolo sara 1 = portiere.
            IF I = 1 THEN
                RUOLO := 1;
--Se la posizione e' compresa tra 2 e 6 il ruolo sara' 2 = difensore.
            ELSIF
                I > 1
                AND I < 7
            THEN
                RUOLO := 2;
--Se la posizione e' compresa tra 7 e 11 il ruolo sara' 3 = centrocampista.
            ELSIF
                I >= 7
                AND I < 12
            THEN
                RUOLO := 3;
--Se la posizione e' compresa tra 12 e 17 il ruolo sara' 4 = attaccante.
            ELSIF
                I >= 12
                AND I < 18
            THEN
                RUOLO := 4;
            END IF;

        END IF;
    END LOOP;

--Se la scelta in input e' ('r'), ritorno il ruolo calcolato.
    IF CHOICE = 'r' THEN
        RETURN RUOLO;
--Se la scelta in input e' ('i'), ritorno l'indice della posizione data in input.
    ELSIF CHOICE = 'i' THEN
        RETURN IDX_POS;
--Altrimenti la scelta non e' valida.
    ELSE
        RAISE INVALID_CHOICE;
    END IF;

EXCEPTION
    WHEN INVALID_CHOICE THEN
        RAISE_APPLICATION_ERROR(-20002, 'La scelta ('
                                          || CHOICE
                                          || ') non e'' valida!');
END IDX_POSITION;
/