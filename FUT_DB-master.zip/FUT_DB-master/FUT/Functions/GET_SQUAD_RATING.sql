---------------------------------------------------------------------------------------------------------------------------
-- Function GET_SQUAD_RATING
---------------------------------------------------------------------------------------------------------------------------
-- Tabelle interessate: 1
--	-> IS_PART_OF		
-- INPUT:
--	-> s_name: il nome della squadra;
--	-> c_name: il nome del club che possiede la squadra <s_name>;
-- OUTPUT:
--	-> number: nuovo valore di <squad_rating> della squadra <s_name>
--       cosi calcolato : 
--          1. CF (fattore_correzione):
--              Con i che va da 1..players_totali = n;
--              CF = [(overall_1 - ar ) + ... + (overall_n - ar)/2] 
--              Per ogni [overall_i > ar];
--          2. squad_rating = (overall_sum + fattore_correzione ) / players_totali.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION GET_SQUAD_RATING (
    S_NAME  IN  SQUAD.NAME%TYPE,
    C_NAME  IN  CLUB.CLUB_NAME%TYPE
) RETURN NUMBER IS

    OVERALL_SUM    NUMBER(5, 0); --Somma totale della valutaione <overall> dei players nella squadra. 
    AR             NUMBER(2, 0); --Media somma_valutazioni/players_totali <overallsum/total_players>. 
    TOTAL_PLAYERS  NUMBER(2, 0); --Players totali. 
    CF             NUMBER(5, 2); --Fattore di correzione.  
    S_RATING       NUMBER(2, 0); --Valutazione della squadra <squad_rating>. 
BEGIN
    CF := 0; 
-- <ar>: conterra' la media della valutazione <rating> dei <player>.
-- <total_players>: quanti players ci sono in squadra.
-- <overall_sum>: la somma delle valutazioni <rating> dei players in squadra.
    SELECT
        AVG(PLAYER_RATING),
        COUNT(PLAYER_CARD_CODE),
        SUM(PLAYER_RATING)
    INTO
        AR,
        TOTAL_PLAYERS,
        OVERALL_SUM
    FROM
        IS_PART_OF
    WHERE
            SQUAD_NAME = S_NAME;

-- <cf> = [(valutazione_1 - ar) + ... + (valutazione_n - ar)/2] , per ogni (valutazione_i > ar).
    SELECT
        ( SUM(PLAYER_RATING) - AR * COUNT(PLAYER_CARD_CODE) )
    INTO CF
    FROM
        IS_PART_OF
    WHERE
            SQUAD_NAME = S_NAME
        AND PLAYER_RATING > AR;

    CF := CF / 2; 

--Calcolo della valutazione <rating> della squadra.
    S_RATING := ( OVERALL_SUM + CF ) / TOTAL_PLAYERS; 

--Ritorna la valutazione <rating> della squadra.
    RETURN S_RATING;
END GET_SQUAD_RATING;
/