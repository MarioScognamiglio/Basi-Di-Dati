--------------------------------------------------------
-- Function GET_SQUAD
--------------------------------------------------------
-- Tabelle interessate: 4
--  -> PLAYER, CLUB_CARD, ACTIVE_DATA_PLAYER, IS_PART_OF;
-- Function interessate: 1
--	-> IS_ADMIN;	
-- INPUT:
--	-> s_club_name: nome del club che possiede la squadra;
-- 	-> s_name: nome della squadra;
-- OUTPUT:
--	-> Dettagli di tutti i giocatori che fanno parte della squadra <s_name>.
--------------------------------------------------------
CREATE OR REPLACE FUNCTION GET_SQUAD (
    S_CLUB_NAME  SQUAD.SQUAD_CLUB_NAME%TYPE,
    S_NAME       SQUAD.NAME%TYPE
) RETURN SYS_REFCURSOR IS
    GETSQUAD  SYS_REFCURSOR;--Valore di ritorno.
    C_NAME    CLUB.CLUB_NAME%TYPE;--Nome del club.
BEGIN
--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione GET_SQUAD;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <s_club_name>
--Altrimenti il nome del club <c_name> sara' quello dell'utente.
--In breve l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
    SELECT
        IS_ADMIN(S_CLUB_NAME, USER)
    INTO C_NAME
    FROM
        DUAL;

    OPEN GETSQUAD FOR 
        SELECT
            CARD_CODE,
            PLAYER_NAME,
            POSITION         AS NATURAL_POS,
            PLAYER_POSITION  AS SQUAD_POS,
            HOLDER,
            CONTRACTS,
            PLAYER_FITNESS,
            ACTIVE_TRAINING  AS TRAIN,
            PLAYER_CHEMISTRY,
            PLAYER_RATING,
            NATIONALITY,
            LEAGUE_NAME
        FROM
                PLAYER P
            JOIN CLUB_CARD           C       --JOIN: per selezionare il CARD_CODE della carta.
            ON P.CARD_ID = C.PLAYER_ID
            JOIN ACTIVE_DATA_PLAYER  A       --JOIN: per selezionare CONTRACTS,PLAYER_FITNESS della carta.
            ON A.P_CARD_CODE = C.CARD_CODE
            JOIN IS_PART_OF          I       --JOIN: per selezionare PLAYER_POSITION,HOLDER,PLAYER_CHEMISTRY,PLAYER_RATING.
            ON I.PLAYER_CARD_CODE = A.P_CARD_CODE
                                AND I.SQUAD_NAME = S_NAME
            ORDER BY SQUAD_POS, CONTRACTS, PLAYER_FITNESS;

    RETURN GETSQUAD;
END GET_SQUAD;
/