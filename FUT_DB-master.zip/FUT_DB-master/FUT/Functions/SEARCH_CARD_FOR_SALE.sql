---------------------------------------------------------------------------------------------------------------------------
-- Function SEARCH_CARD_FOR_SALE
---------------------------------------------------------------------------------------------------------------------------
-- INPUT:
--	-> cc_name: se il chiamante e' amministratore: contiene il nome del club su cui effettuare le operazioni;
--              se il chiamante non e' amministratore: contiene o NULL, oppure il nome del club dell'utente chiamante.
--  -> c_type: ('Player','Consumable','Club Item','Manager') tipologia di carta;
--  -> c_name: ('Player_name','Category','Category','F_name') nome della carta in base alla tipologia;
-- OUTPUT:
--  -> Se la carta cercata e' in vendita ritorna il codice carta e il prezzo.
---------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION SEARCH_CARD_FOR_SALE (
    CLUB_NN  CLUB.CLUB_NAME%TYPE,
    C_TYPE   VARCHAR2,
    C_NAME   VARCHAR2
) RETURN SYS_REFCURSOR IS
    S_CARD  SYS_REFCURSOR; --Valore di ritorno.
    N1      NUMBER(2, 0); --Contatore.
    CLUB_N  CLUB.CLUB_NAME%TYPE; --Nome del club effettivo (is_admin).
BEGIN
--La funzione is_admin, ritorna il nome del club in base all'utente che chiama la funzione SEARCH_CARD_FOR_SALE;
--Se e' l'amministratore a chiamare la funzione il nome del club <c_name> sara' uguale a <cc_name>
--Altrimenti il nome del club <c_name> sara' quello dell'utente.
--In breve l'amministratore puo' eseguire la funzione su qualsiasi club, l'utente solo sul suo club.
    SELECT
        IS_ADMIN(CLUB_NN, USER)
    INTO CLUB_N
    FROM
        DUAL;

--Se la tipologia di carta che stiamo cercando e' di tipo <player>.
    IF C_TYPE = 'Player' THEN

--Controllo se c'e' in vendita il <player> cercato.
        SELECT
            COUNT(PLAYER_NAME)
        INTO N1
        FROM
            PLAYER
        WHERE
                PLAYER_NAME = C_NAME
            AND CARD_ID IN (
                SELECT
                    PLAYER_ID
                FROM
                    CLUB_CARD
                WHERE
                    CARD_CODE IN (
                        SELECT
                            T_CARD_CODE
                        FROM
                            TRANSACTION
--Il club che compra deve essere nullo altrimenti e' stato squistato
-- e il club che vende deve essere diverso dal club che sta cercando la carta in vendita.
                        WHERE
                            TRANSITION_B_CLUB_NAME IS NULL
                            AND TRANSITION_S_CLUB_NAME != CLUB_N
                    )
            );
--Se ho trovato il player che sto cercando, seleziono il codice carta e il prezzo.
        IF N1 <> 0 THEN
            OPEN S_CARD FOR SELECT
                                T_CARD_CODE,
                                PRICE
                            FROM
                                TRANSACTION
                            WHERE
                                T_CARD_CODE IN (
                                    SELECT
                                        CARD_CODE
                                    FROM
                                        CLUB_CARD
                                    WHERE
                                        PLAYER_ID IN (
                                            SELECT
                                                CARD_ID
                                            FROM
                                                PLAYER
                                            WHERE
                                                PLAYER_NAME = C_NAME
                                        )
                                )ORDER BY PRICE;

            RETURN S_CARD;
        ELSE--Se non trovo il <player> che sto cercando.
            RAISE NO_DATA_FOUND;
        END IF;
--Se la tipologia di carta scelta e' di tipo <Consumable>.
    ELSIF C_TYPE = 'Consumable' THEN

--La categoria <c_name> del consumabile puo' essere:
-- ('Contract','Fitness','Healing','Training','GKTraining','Positioning','Manager League').
        SELECT
            COUNT(CATEGORY)
        INTO N1
        FROM
            CONSUMABLE
        WHERE
                CATEGORY = C_NAME
            AND CARD_ID IN (
                SELECT
                    CONSUMABLE_ID
                FROM
                    CLUB_CARD
                WHERE
                    CARD_CODE IN (
                        SELECT
                            T_CARD_CODE
                        FROM
                            TRANSACTION
                        WHERE
                            TRANSITION_B_CLUB_NAME IS NULL
                            AND TRANSITION_S_CLUB_NAME != CLUB_N
                    )
            );

        IF N1 <> 0 THEN
            OPEN S_CARD FOR SELECT
                                T_CARD_CODE,
                                PRICE
                            FROM
                                TRANSACTION
                            WHERE
                                T_CARD_CODE IN (
                                    SELECT
                                        CARD_CODE
                                    FROM
                                        CLUB_CARD
                                    WHERE
                                        CONSUMABLE_ID IN (
                                            SELECT
                                                CARD_ID
                                            FROM
                                                CONSUMABLE
                                            WHERE
                                                CATEGORY = C_NAME
                                        )
                                )ORDER BY PRICE;

            RETURN S_CARD;
        ELSE
            RAISE NO_DATA_FOUND;
        END IF;
--Se la tipologia di carta e' di tipo <Club item>.
    ELSIF C_TYPE = 'Club item' THEN

--La categoria <c_name> del club_item puo' essere:
--  ('Kit','Ball','Badge','Stadium').
        SELECT
            COUNT(CATEGORY_ITEM)
        INTO N1
        FROM
            CLUB_ITEM
        WHERE
                CATEGORY_ITEM = C_NAME
            AND CARD_ID IN (
                SELECT
                    CLUB_ITEM_ID
                FROM
                    CLUB_CARD
                WHERE
                    CARD_CODE IN (
                        SELECT
                            T_CARD_CODE
                        FROM
                            TRANSACTION
                        WHERE
                            TRANSITION_B_CLUB_NAME IS NULL
                            AND TRANSITION_S_CLUB_NAME != CLUB_N
                    )
            );

        IF N1 <> 0 THEN
            OPEN S_CARD FOR SELECT
                                T_CARD_CODE,
                                PRICE
                            FROM
                                TRANSACTION
                            WHERE
                                T_CARD_CODE IN (
                                    SELECT
                                        CARD_CODE
                                    FROM
                                        CLUB_CARD
                                    WHERE
                                        CLUB_ITEM_ID IN (
                                            SELECT
                                                CARD_ID
                                            FROM
                                                CLUB_ITEM
                                            WHERE
                                                CATEGORY_ITEM = C_NAME
                                        )
                                )ORDER BY PRICE;

            RETURN S_CARD;
        ELSE
            RAISE NO_DATA_FOUND;
        END IF;

--Se la tipologia di carta e' di tipo <Manager>.
    ELSIF C_TYPE = 'Manager' THEN
        SELECT
            COUNT(F_NAME)
        INTO N1
        FROM
            MANAGER
        WHERE
                F_NAME = C_NAME
            AND CARD_ID IN (
                SELECT
                    MANAGER_ID
                FROM
                    CLUB_CARD
                WHERE
                    CARD_CODE IN (
                        SELECT
                            T_CARD_CODE
                        FROM
                            TRANSACTION
                        WHERE
                            TRANSITION_B_CLUB_NAME IS NULL
                            AND TRANSITION_S_CLUB_NAME != CLUB_N
                    )
            );

        IF N1 <> 0 THEN
            OPEN S_CARD FOR SELECT
                                T_CARD_CODE,
                                PRICE
                            FROM
                                TRANSACTION
                            WHERE
                                T_CARD_CODE IN (
                                    SELECT
                                        CARD_CODE
                                    FROM
                                        CLUB_CARD
                                    WHERE
                                        MANAGER_ID IN (
                                            SELECT
                                                CARD_ID
                                            FROM
                                                MANAGER
                                            WHERE
                                                F_NAME = C_NAME
                                        )
                                ) ORDER BY PRICE;

            RETURN S_CARD;
        ELSE
            RAISE NO_DATA_FOUND;
        END IF;

    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('La carta '
                             || C_TYPE
                             || ' '
                             || C_NAME
                             || ' non e'' in vendita''');
END SEARCH_CARD_FOR_SALE;
/